/**
 * REAL persistence output, not a hand-authored fixture.
 *
 * Produced by running tda-wasm's GUDHI Rips + persistent cohomology over a
 * 50-point unit circle (maxEdgeLength 2.2, cap
 * 2), then applying the Nerve-theorem filter.
 *
 * The raw engine emitted 18475 pairs; 18424 of them were
 * Vietoris-Rips truncation artifacts above the ambient dimension and were
 * dropped, leaving 50 components and exactly 1 loop — which is what
 * a circle has. Stories use this so the documentation shows true output
 * (SPEC.md §5: never synthesize persistence pairs).
 *
 * Regenerate: site/scripts/generate-hero-data.mjs
 */
import type { PersistencePair } from 'tda-wasm';

/** 50 points on the unit circle, flat [x0, y0, x1, y1, …]. */
export const CIRCLE_50: number[] = [
1, 0, 0.99211, 0.12533, 0.96858, 0.24869, 0.92978, 0.36812, 0.87631, 0.48175, 0.80902, 0.58779, 0.72897, 0.68455, 0.63742, 0.77051, 0.53583, 0.84433, 0.42578, 0.90483, 0.30902, 0.95106, 0.18738, 0.98229, 0.06279, 0.99803, -0.06279, 0.99803, -0.18738, 0.98229, -0.30902, 0.95106, -0.42578, 0.90483, -0.53583, 0.84433, -0.63742, 0.77051, -0.72897, 0.68455, -0.80902, 0.58779, -0.87631, 0.48175, -0.92978, 0.36812, -0.96858, 0.24869, -0.99211, 0.12533, -1, 0, -0.99211, -0.12533, -0.96858, -0.24869, -0.92978, -0.36812, -0.87631, -0.48175, -0.80902, -0.58779, -0.72897, -0.68455, -0.63742, -0.77051, -0.53583, -0.84433, -0.42578, -0.90483, -0.30902, -0.95106, -0.18738, -0.98229, -0.06279, -0.99803, 0.06279, -0.99803, 0.18738, -0.98229, 0.30902, -0.95106, 0.42578, -0.90483, 0.53583, -0.84433, 0.63742, -0.77051, 0.72897, -0.68455, 0.80902, -0.58779, 0.87631, -0.48175, 0.92978, -0.36812, 0.96858, -0.24869, 0.99211, -0.12533
];

/** Nerve-filtered persistence pairs for CIRCLE_50. */
export const CIRCLE_50_PAIRS: PersistencePair[] = [
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: 0.125581 },
  { dimension: 0, birth: 0, death: Infinity },
  { dimension: 1, birth: 0.125581, death: 1.752613 },
];

export const CIRCLE_50_MAX_EDGE = 2.2;

/** The single H1 class: the loop. Born ~2·sin(π/50), dies ~√3. */
export const CIRCLE_50_LOOP = CIRCLE_50_PAIRS.find((p) => p.dimension === 1)!;
