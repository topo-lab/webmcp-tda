/**
 * <Grid2D>: the sublevel set itself — {f ≤ t} on a grid of values, drawn as a
 * heat field (SPEC.md §4.7). The grid-domain counterpart of <Field2D>, and the
 * primary surface for a cubical filtration: the user moves the threshold and
 * watches the set fill.
 *
 * NOTHING GROWS HERE. <Field2D> draws ⋃ᵢ S_i(t), a union of shapes that get
 * bigger with t, and its whole job is to evaluate a scale law. This surface has
 * no scale law to evaluate, because a cubical filtration has no shapes: the
 * cells are fixed, the VALUES are fixed, and t only decides which cells are in.
 * So there is no `shapeAt` call here and no convention to name — the component
 * takes a `GridFiltration` and cannot be handed a cloud filtration by mistake
 * (SPEC.md §3.1b).
 *
 * ONE RECT PER VALUE, ALWAYS. Every cell of the grid is drawn at every t,
 * inside or out, carrying `data-inside`. Drawing only the cells that are in
 * would make the picture a silhouette with no context: the reader could not see
 * where the threshold has got to, only where it has been. The set that is IN is
 * inked; the rest is empty — an outline and nothing else — so the boundary
 * between them is the threshold, which is what the picture is about.
 *
 * THE HEAT IS DEPTH, AND IT IS AN OPACITY. A cell's ink strength is how early
 * the sweep reached it, normalised across the grid's own range: the deepest
 * values are solid, the ones just inside the threshold are faint. Strength
 * rather than hue because a single colour is a single token — a consumer
 * retints the whole field by setting one custom property, and there is no
 * two-colour ramp to interpolate in JavaScript and no palette baked in here.
 *
 * WHAT A CELL IS depends on the construction, and the drawing says which:
 *   - `cubical-t` — a value IS a pixel, a top-dimensional cell. The rect is
 *     that pixel, and the grid covers width × height cells exactly.
 *   - `cubical-v` — a value is a grid VERTEX; the squares of the complex lie
 *     BETWEEN the vertices, so the complex spans (width−1) × (height−1) and the
 *     rect drawn is the vertex's own half-cell neighbourhood, centred on it.
 *     The drawn field therefore reaches half a cell past the complex on every
 *     side. `data-cell-basis` records which of the two a reader is looking at,
 *     because the same array under the two conventions is two different
 *     pictures of two different complexes.
 *
 * COLOUR (DESIGN.md "Colour"): every colour is a prop, and every default is a
 * CSS custom property with a fallback to `currentColor` — so the field inherits
 * the surrounding ink until a consumer binds `--grid-ink` / `--grid-rule`, and
 * no palette value is written into this file.
 *
 * SVG, like <Field2D> and <Nerve2D>: the cells are one element each because
 * each is separately addressable and separately inked, and a grid a browser can
 * draw at all is a grid whose cell count is a DOM size a browser is fine with.
 */
import type { GridDirection, GridFiltration } from '../filtration/types';

/** Props for `<Grid2D>`. */
export interface Grid2DProps {
  /** A grid filtration. `construction` and `direction` decide what is drawn. */
  filtration: GridFiltration;
  /** Current threshold. Filters what is inked; never triggers a recompute (SPEC.md §1.5). */
  t: number;
  width?: number;
  height?: number;
  padding?: number;
  /** Ink of the cells that are INSIDE the set. Defaults to the `--grid-ink` token. */
  color?: string;
  /** Opacity of the deepest cell inside the set. Shallower cells scale down from it. */
  opacity?: number;
  /**
   * Ink strength of the cell that has only just entered, as a fraction of
   * `opacity`. Above 0 so that a cell exactly at the threshold is visible as
   * something rather than as nothing: a cell at t IS in the complex, and a
   * ramp that faded it to zero would draw the boundary outside the set.
   */
  minShade?: number;
  /** Colour of the cell rules. Defaults to the `--grid-rule` token. */
  gridColor?: string;
  /** Width of those rules, in pixels of the drawing box. 0 draws none. */
  gridWidth?: number;
  /** Their opacity. Kept well under the field's: the grid is scaffolding. */
  gridOpacity?: number;
  className?: string;
  'aria-label'?: string;
}

/**
 * What the threshold means, per direction. The library's own words, like
 * `<Field2D>`'s convention line — the GUARANTEE wording is never written here,
 * it is read from `filtration.guarantee.label`, which is the engine's phrase.
 */
const DIRECTION_LABEL: Record<GridDirection, string> = {
  sublevel: 'sublevel set {f ≤ t}: t sweeps up from the lowest value',
  superlevel: 'superlevel set {f ≥ t}: t sweeps down from the highest value',
};

/**
 * The sublevel set of a grid filtration — `{f ≤ t}` drawn as a heat field
 * (SPEC.md §4.7). The grid-domain counterpart of `<Field2D>`: nothing grows,
 * the cells are fixed and t only decides which are in.
 */
export function Grid2D({
  filtration,
  t,
  width = 320,
  height = 320,
  padding = 16,
  color = 'var(--grid-ink, currentColor)',
  opacity = 0.9,
  minShade = 0.18,
  gridColor = 'var(--grid-rule, currentColor)',
  gridWidth = 0.4,
  gridOpacity = 0.18,
  className,
  'aria-label': ariaLabel = 'The set below the current threshold, on the value grid',
}: Grid2DProps) {
  const { values, guarantee, construction, direction, tMin, tMax } = filtration;
  const cols = filtration.width;
  const rows = filtration.height;

  // A vertex value's cell is centred on the lattice point, so the drawn field
  // is one cell wider and taller than the complex it belongs to. A pixel value
  // IS its cell, so the two coincide.
  const vertexBased = construction === 'cubical-v';
  const cell = Math.min((width - 2 * padding) / cols, (height - 2 * padding) / rows);
  const fieldWidth = cell * cols;
  const fieldHeight = cell * rows;
  const originX = (width - fieldWidth) / 2;
  const originY = (height - fieldHeight) / 2;

  // Depth = how early the sweep reaches a value, in [0, 1], 1 being first.
  // A constant grid has no range to normalise across, and every cell in it is
  // reached at the same instant, so every cell is at full depth.
  const span = tMax - tMin;
  const depthOf = (v: number): number => {
    if (!(span > 0)) return 1;
    return direction === 'sublevel' ? (tMax - v) / span : (v - tMin) / span;
  };

  const cells: {
    key: number;
    x: number;
    y: number;
    value: number;
    inside: boolean;
    shade: number;
  }[] = [];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const value = values[row * cols + col];
      cells.push({
        key: row * cols + col,
        x: originX + col * cell,
        y: originY + row * cell,
        value,
        inside: filtration.containsValue(value, t),
        shade: minShade + (1 - minShade) * depthOf(value),
      });
    }
  }

  return (
    <div
      className={className}
      data-testid="grid-2d"
      data-construction={construction}
      data-direction={direction}
      data-cell-basis={vertexBased ? 'vertex' : 'pixel'}
      data-grid-size={`${cols}x${rows}`}
    >
      <svg
        role="img"
        aria-label={ariaLabel}
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        style={{ display: 'block' }}
      >
        {cells.map((c) => (
          <rect
            key={c.key}
            data-testid="grid-2d-cell"
            data-inside={c.inside ? 'true' : 'false'}
            data-value={c.value}
            x={c.x}
            y={c.y}
            width={cell}
            height={cell}
            // Outside the set the cell is EMPTY, not faintly filled: the whole
            // claim of the picture is where the threshold has got to, and a
            // tinted outside blurs that line into a gradient.
            fill={c.inside ? color : 'none'}
            fillOpacity={c.inside ? opacity * c.shade : 0}
            stroke={gridWidth > 0 ? gridColor : 'none'}
            strokeWidth={gridWidth}
            strokeOpacity={gridOpacity}
          />
        ))}
      </svg>
      <p
        data-testid="grid-2d-threshold"
        style={{
          fontSize: 10,
          opacity: 0.65,
          margin: '4px 0 0',
          fontFamily: 'ui-monospace, monospace',
        }}
      >
        {/*
          The construction is named by the ENGINE's phrase, read off the
          filtration — never assembled here (SPEC.md §1.4). Only the sentence
          about which side of the threshold is drawn is this library's own.
        */}
        {guarantee.label} · {DIRECTION_LABEL[direction]}
      </p>
    </div>
  );
}
