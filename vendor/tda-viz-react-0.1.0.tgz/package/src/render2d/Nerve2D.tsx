/**
 * <Nerve2D>: the simplicial complex the cover induces at scale t, drawn over
 * the field (SPEC.md §4.1). For a nerve, the complex and the union of shapes
 * are the same space up to homotopy — a simplex appears exactly when its shapes
 * start overlapping, which is why this component and <Field2D> share one
 * projection.
 *
 * VERTEX IDENTITY (SPEC.md §3.1). A vertex of `simplices` is not always a
 * point. In the k-fold cover it is a k-SUBSET of the input, drawn at that
 * subset's barycentre, and there are more vertices than points. This component
 * therefore reads `vertexPositions` — never `cloud.points` — and when
 * `vertexKind` is 'subset' it draws those vertices with their own glyph and
 * says on the drawing what they are. A ball sits on an input point while a
 * vertex stands for a set of them: two different objects on one canvas, and
 * they must not read as one thing (SPEC.md §8 Q5).
 *
 * Honesty (SPEC.md §1.4): a flag complex is NOT a nerve — a triangle there is
 * not a claim that three shapes share a point — and the drawing says so
 * whenever the filtration's guarantee says so.
 */
import { useMemo } from 'react';
import type { Simplex } from 'tda-wasm';
import type { Filtration } from '../filtration/types';
import { projectCloud } from './project';

export interface Nerve2DProps {
  filtration: Filtration;
  /** Current scale. Filters what is drawn; never triggers a recompute (SPEC.md §1.5). */
  t: number;
  width?: number;
  height?: number;
  padding?: number;
  showEdges?: boolean;
  showTriangles?: boolean;
  /**
   * Draw a marker per vertex. Defaults to ON for subset vertices, because
   * nothing else on the canvas is at a barycentre, and OFF for point vertices,
   * where <PointCloud2D> already draws the cloud.
   */
  showVertices?: boolean;
  edgeColor?: string;
  triangleColor?: string;
  vertexColor?: string;
  /**
   * Vertex triples to emphasize (any order), e.g. Rips triangles that are
   * not nerve triangles in the SPEC.md §7 story-3 comparison.
   */
  highlightTriangles?: number[][];
  highlightColor?: string;
  className?: string;
  'aria-label'?: string;
}

const tripleKey = (vs: readonly number[]) => [...vs].sort((a, b) => a - b).join(',');

/** Hollow diamond, in data-free pixel space: a glyph no shape or point uses. */
const diamond = (x: number, y: number, r: number) =>
  `M${x} ${y - r}L${x + r} ${y}L${x} ${y + r}L${x - r} ${y}Z`;

export function Nerve2D({
  filtration,
  t,
  width = 320,
  height = 320,
  padding = 16,
  showEdges = true,
  showTriangles = true,
  showVertices,
  edgeColor = '#ea580c',
  triangleColor = '#fdba74',
  vertexColor = '#7c3aed',
  highlightTriangles,
  highlightColor = '#dc2626',
  className,
  'aria-label': ariaLabel = 'Complex at the current scale',
}: Nerve2DProps) {
  const { cloud, complexType, guarantee, vertexKind, vertexCount, vertexSubsets } = filtration;

  // The projection is the CLOUD's, shared with <Field2D> so the complex draws
  // over the union of shapes it describes. Vertex positions go through the same
  // map — subset barycentres lie in the cloud's convex hull, so they land inside
  // the same frame.
  const projection = useMemo(
    () => projectCloud(cloud.points, cloud.dimension, width, height, padding),
    [cloud, width, height, padding],
  );

  /**
   * Pixel position PER VERTEX, from `vertexPositions` (SPEC.md §3.1). Reading
   * `cloud.points` here would be right for every 'point' filtration and wrong
   * for the k-fold cover, which is the bug this indirection exists to prevent.
   */
  const pos = useMemo(() => {
    const { px, py } = projection;
    const flat = filtration.vertexPositions;
    const dim = cloud.dimension;
    const out: { x: number; y: number }[] = [];
    for (let v = 0; v < vertexCount; v++) {
      out.push({ x: px(flat[v * dim]), y: py(flat[v * dim + 1]) });
    }
    return out;
  }, [filtration, projection, cloud.dimension, vertexCount]);

  const active = filtration.simplicesAt(t);
  const { vertices, edges, triangles } = useMemo(() => {
    const vs: Simplex[] = [];
    const e: Simplex[] = [];
    const tri: Simplex[] = [];
    for (const s of active) {
      if (s.vertices.length === 1) vs.push(s);
      else if (s.vertices.length === 2) e.push(s);
      else if (s.vertices.length === 3) tri.push(s);
    }
    return { vertices: vs, edges: e, triangles: tri };
  }, [active]);

  const highlighted = useMemo(
    () => new Set((highlightTriangles ?? []).map(tripleKey)),
    [highlightTriangles],
  );

  const isSubset = vertexKind === 'subset';
  const drawVertices = showVertices ?? isSubset;
  const valid = (v: number) => v >= 0 && v < pos.length;

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      role="img"
      aria-label={ariaLabel}
      data-testid="nerve-2d"
      data-complex-type={complexType}
      data-guarantee={guarantee.kind}
      data-vertex-kind={vertexKind}
      data-edge-count={edges.length}
      data-triangle-count={triangles.length}
    >
      {showTriangles &&
        triangles.map((s, i) => {
          if (!s.vertices.every(valid)) return null;
          const pts = s.vertices.map((v) => `${pos[v].x},${pos[v].y}`).join(' ');
          const isHighlighted = highlighted.has(tripleKey(s.vertices));
          return (
            <polygon
              key={`t${i}`}
              data-testid="nerve-triangle"
              data-highlight={isHighlighted ? 'true' : undefined}
              points={pts}
              fill={isHighlighted ? highlightColor : triangleColor}
              fillOpacity={isHighlighted ? 0.45 : 0.28}
              stroke={isHighlighted ? highlightColor : 'none'}
              strokeWidth={isHighlighted ? 1.5 : 0}
            />
          );
        })}

      {showEdges &&
        edges.map((s, i) => {
          if (!s.vertices.every(valid)) return null;
          const [a, b] = s.vertices;
          return (
            <line
              key={`e${i}`}
              data-testid="nerve-edge"
              x1={pos[a].x}
              y1={pos[a].y}
              x2={pos[b].x}
              y2={pos[b].y}
              stroke={edgeColor}
              strokeWidth={1}
              strokeOpacity={0.65}
            />
          );
        })}

      {drawVertices &&
        vertices.map((s, i) => {
          const v = s.vertices[0];
          if (!valid(v)) return null;
          const { x, y } = pos[v];
          const members = vertexSubsets?.[v];
          // Subset vertices get a hollow diamond and name their members; point
          // vertices get a plain dot, because that is all they are.
          return isSubset ? (
            <path
              key={`v${i}`}
              data-testid="nerve-subset-vertex"
              data-subset={members?.join(',')}
              d={diamond(x, y, 4)}
              fill="none"
              stroke={vertexColor}
              strokeWidth={1.2}
            >
              <title>{`vertex ${v}: barycentre of input points {${members?.join(', ')}}`}</title>
            </path>
          ) : (
            <circle
              key={`v${i}`}
              data-testid="nerve-vertex"
              cx={x}
              cy={y}
              r={2}
              fill={vertexColor}
              fillOpacity={0.8}
            />
          );
        })}

      {isSubset && (
        <text
          data-testid="nerve-2d-subset-label"
          x={padding}
          y={height - 18}
          fontSize={9}
          fill="#6b7280"
          fontFamily="ui-monospace, monospace"
        >
          ◇ = a vertex of the mosaic: a subset of the input, drawn at its barycentre ({vertexCount}{' '}
          vertices, {cloud.points.length / cloud.dimension} points)
        </text>
      )}

      {guarantee.kind === 'flag' && (
        <text
          data-testid="nerve-2d-flag-label"
          x={padding}
          y={height - 6}
          fontSize={9}
          fill="#6b7280"
          fontFamily="ui-monospace, monospace"
        >
          {guarantee.label}: a simplex means the shapes meet pairwise, not that they share a point
        </text>
      )}
    </svg>
  );
}
