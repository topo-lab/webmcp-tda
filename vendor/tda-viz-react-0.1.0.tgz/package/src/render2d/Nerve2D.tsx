/**
 * <Nerve2D>: the simplicial complex the cover induces at scale t, drawn over
 * the field (SPEC.md §4.1). For a nerve, the complex and the union of shapes
 * are the same space up to homotopy — a simplex appears exactly when its shapes
 * start overlapping, which is why this component and <Field2D> share one
 * projection.
 *
 * VERTEX IDENTITY (SPEC.md §3.1). A vertex of `simplices` is not always a
 * point. In the k-fold cover it is a k-SUBSET of the input, drawn at that
 * subset's barycentre, and there are more vertices than points. This component
 * therefore reads `vertexPositions` — never `cloud.points` — and when
 * `vertexKind` is 'subset' it draws those vertices with their own glyph and
 * says on the drawing what they are. A ball sits on an input point while a
 * vertex stands for a set of them: two different objects on one canvas, and
 * they must not read as one thing (SPEC.md §8 Q5).
 *
 * Honesty (SPEC.md §1.4): a flag complex is NOT a nerve — a triangle there is
 * not a claim that three shapes share a point — and the drawing says so
 * whenever the filtration's guarantee says so.
 *
 * ONE PATH PER LAYER, NOT ONE ELEMENT PER SIMPLEX (SPEC.md §4.1). A 60-point
 * circle at t near tMax has on the order of 20,000 triangles; one `<polygon>`
 * each is 20,000 DOM nodes for a single frame. Following `<Field2D>` /
 * `shapePath.ts` and the site's `atlasGeometry.ts` `complexPathsAt`, every
 * triangle present at t is instead one subpath of ONE merged `<path>`
 * (`M x y L x y L x y Z`, repeated), and every edge is one subpath of a
 * second merged `<path>` (`M x y L x y`, repeated) — two DOM nodes however
 * many simplices are present, not two thousand. `highlightTriangles` is the
 * one exception: a highlighted triangle needs its own colour, opacity and
 * stroke, so it is held OUT of the merged bulk path and drawn as its own
 * element, exactly as before — highlighting a handful of triangles for a
 * callout was never the element-count problem. Vertices stay individual
 * elements too: there are never more of them than input points (or mosaic
 * vertices), which is the count this technique exists to avoid for simplices.
 */
import { useMemo } from 'react';
import type { Simplex } from 'tda-wasm';
import type { Filtration } from '../filtration/types';
import { projectCloud } from './project';

/** Props for `<Nerve2D>`. */
export interface Nerve2DProps {
  filtration: Filtration;
  /** Current scale. Filters what is drawn; never triggers a recompute (SPEC.md §1.5). */
  t: number;
  width?: number;
  height?: number;
  padding?: number;
  showEdges?: boolean;
  showTriangles?: boolean;
  /**
   * Draw a marker per vertex. Defaults to ON for subset vertices, because
   * nothing else on the canvas is at a barycentre, and OFF for point vertices,
   * where <PointCloud2D> already draws the cloud.
   */
  showVertices?: boolean;
  edgeColor?: string;
  /**
   * Stroke width of the 1-skeleton, in pixels of the drawing box.
   *
   * It is a prop rather than a stylesheet concern because the right weight
   * depends on the ground and on how dense the complex gets: near a loop's
   * death a Čech complex draws hundreds of edges over thousands of faces, and
   * at 1px on a near-white sheet that is a scribble rather than structure. 1 is
   * what this component has always stroked at, kept as the default.
   */
  edgeWidth?: number;
  /** Opacity of the 1-skeleton. Defaults to 0.65, so an edge colour may instead carry its own alpha at 1. */
  edgeOpacity?: number;
  triangleColor?: string;
  /** Opacity of the merged face fill. Defaults to 0.28. */
  triangleOpacity?: number;
  vertexColor?: string;
  /** Radius of a point vertex's disc, in pixels of the drawing box. Defaults to 2. */
  vertexRadius?: number;
  /** Opacity of a point vertex's disc. Defaults to 0.8. */
  vertexOpacity?: number;
  /**
   * A halo painted UNDER each point vertex, in the colour of the surface behind
   * the picture — normally the stage's own well.
   *
   * The job is legibility, not decoration: a point is the data, the edges over
   * it are derived, and without a break in the ink a dot sitting on a dense
   * 1-skeleton is indistinguishable from a crossing. Painted with
   * `paint-order: stroke`, so the stroke lies beneath the fill and the visible
   * ring is `vertexHaloWidth / 2` outside the disc. Off by default.
   */
  vertexHaloColor?: string;
  /** Stroke width of that halo. Defaults to 1.2; ignored without `vertexHaloColor`. */
  vertexHaloWidth?: number;
  /**
   * The two explanatory notes this component sets INSIDE its own SVG: the
   * subset-vertex legend, and — on a flag complex — the guarantee sentence.
   * On by default, because a picture that does not say what a simplex means on
   * a flag complex is the decorative-guarantee failure SPEC.md §1.4 exists to
   * prevent.
   *
   * A caller may turn them off ONLY because it states the guarantee itself. On
   * a stage with its own caption line the note is a second copy of wording the
   * reader already has, set in the drawing rather than in the layout, and it
   * collides with whatever else the stage puts at its bottom edge. Turning it
   * off to make a picture tidier while showing the guarantee nowhere would be
   * the dishonesty, not the prop.
   */
  showNotes?: boolean;
  /**
   * Vertex triples to emphasize (any order), e.g. Rips triangles that are
   * not nerve triangles in the SPEC.md §7 story-3 comparison.
   */
  highlightTriangles?: number[][];
  highlightColor?: string;
  className?: string;
  'aria-label'?: string;
}

const tripleKey = (vs: readonly number[]) => [...vs].sort((a, b) => a - b).join(',');

/** Hollow diamond, in data-free pixel space: a glyph no shape or point uses. */
const diamond = (x: number, y: number, r: number) =>
  `M${x} ${y - r}L${x + r} ${y}L${x} ${y + r}L${x - r} ${y}Z`;

/**
 * The simplicial complex present at scale t, drawn over the field
 * (SPEC.md §4.1). Vertices come from `vertexPositions`, never `cloud.points`,
 * because a k-fold cover vertex stands for a subset rather than a point.
 */
export function Nerve2D({
  filtration,
  t,
  width = 320,
  height = 320,
  padding = 16,
  showEdges = true,
  showTriangles = true,
  showVertices,
  edgeColor = '#ea580c',
  edgeWidth = 1,
  edgeOpacity = 0.65,
  triangleColor = '#fdba74',
  triangleOpacity = 0.28,
  vertexColor = '#7c3aed',
  vertexRadius = 2,
  vertexOpacity = 0.8,
  vertexHaloColor,
  vertexHaloWidth = 1.2,
  showNotes = true,
  highlightTriangles,
  highlightColor = '#dc2626',
  className,
  'aria-label': ariaLabel = 'Complex at the current scale',
}: Nerve2DProps) {
  const { cloud, complexType, guarantee, vertexKind, vertexCount, vertexSubsets } = filtration;

  // The projection is the CLOUD's, shared with <Field2D> so the complex draws
  // over the union of shapes it describes. Vertex positions go through the same
  // map — subset barycentres lie in the cloud's convex hull, so they land inside
  // the same frame.
  const projection = useMemo(
    () => projectCloud(cloud.points, cloud.dimension, width, height, padding),
    [cloud, width, height, padding],
  );

  /**
   * Pixel position PER VERTEX, from `vertexPositions` (SPEC.md §3.1). Reading
   * `cloud.points` here would be right for every 'point' filtration and wrong
   * for the k-fold cover, which is the bug this indirection exists to prevent.
   */
  const pos = useMemo(() => {
    const { px, py } = projection;
    const flat = filtration.vertexPositions;
    const dim = cloud.dimension;
    const out: { x: number; y: number }[] = [];
    for (let v = 0; v < vertexCount; v++) {
      out.push({ x: px(flat[v * dim]), y: py(flat[v * dim + 1]) });
    }
    return out;
  }, [filtration, projection, cloud.dimension, vertexCount]);

  const active = filtration.simplicesAt(t);
  const { vertices, edges, triangles } = useMemo(() => {
    const vs: Simplex[] = [];
    const e: Simplex[] = [];
    const tri: Simplex[] = [];
    for (const s of active) {
      if (s.vertices.length === 1) vs.push(s);
      else if (s.vertices.length === 2) e.push(s);
      else if (s.vertices.length === 3) tri.push(s);
    }
    return { vertices: vs, edges: e, triangles: tri };
  }, [active]);

  const highlighted = useMemo(
    () => new Set((highlightTriangles ?? []).map(tripleKey)),
    [highlightTriangles],
  );

  /**
   * The bulk of the drawing, collapsed into two path strings (one subpath per
   * simplex, `M x y L x y (L x y)? Z`) instead of one SVG element per
   * triangle / edge — see the module doc comment. A highlighted triangle is
   * held OUT of `trianglesPath` and drawn as its own element below, because it
   * needs a colour, opacity and stroke the rest of the bulk does not share.
   */
  const { trianglesPath, highlightedTriangles, edgesPath } = useMemo(() => {
    const inRange = (v: number) => v >= 0 && v < pos.length;
    let triPath = '';
    const hl: Simplex[] = [];
    for (const s of triangles) {
      if (!s.vertices.every(inRange)) continue;
      if (highlighted.has(tripleKey(s.vertices))) {
        hl.push(s);
        continue;
      }
      const [a, b, c] = s.vertices;
      triPath += `M${pos[a].x} ${pos[a].y}L${pos[b].x} ${pos[b].y}L${pos[c].x} ${pos[c].y}Z`;
    }
    let edgePath = '';
    for (const s of edges) {
      if (!s.vertices.every(inRange)) continue;
      const [a, b] = s.vertices;
      edgePath += `M${pos[a].x} ${pos[a].y}L${pos[b].x} ${pos[b].y}`;
    }
    return { trianglesPath: triPath, highlightedTriangles: hl, edgesPath: edgePath };
  }, [triangles, edges, pos, highlighted]);

  const isSubset = vertexKind === 'subset';
  const drawVertices = showVertices ?? isSubset;
  const valid = (v: number) => v >= 0 && v < pos.length;

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      role="img"
      aria-label={ariaLabel}
      data-testid="nerve-2d"
      data-complex-type={complexType}
      data-guarantee={guarantee.kind}
      data-vertex-kind={vertexKind}
      data-edge-count={edges.length}
      data-triangle-count={triangles.length}
    >
      {showTriangles && trianglesPath && (
        <path
          data-testid="nerve-triangle"
          d={trianglesPath}
          fillRule="nonzero"
          fill={triangleColor}
          fillOpacity={triangleOpacity}
          stroke="none"
        />
      )}

      {showTriangles &&
        highlightedTriangles.map((s, i) => {
          const pts = s.vertices.map((v) => `${pos[v].x},${pos[v].y}`).join(' ');
          return (
            <polygon
              key={`ht${i}`}
              data-testid="nerve-triangle"
              data-highlight="true"
              points={pts}
              fill={highlightColor}
              fillOpacity={0.45}
              stroke={highlightColor}
              strokeWidth={1.5}
            />
          );
        })}

      {showEdges && edgesPath && (
        <path
          data-testid="nerve-edge"
          d={edgesPath}
          fill="none"
          stroke={edgeColor}
          strokeWidth={edgeWidth}
          strokeOpacity={edgeOpacity}
        />
      )}

      {drawVertices &&
        vertices.map((s, i) => {
          const v = s.vertices[0];
          if (!valid(v)) return null;
          const { x, y } = pos[v];
          const members = vertexSubsets?.[v];
          // Subset vertices get a hollow diamond and name their members; point
          // vertices get a plain dot, because that is all they are.
          return isSubset ? (
            <path
              key={`v${i}`}
              data-testid="nerve-subset-vertex"
              data-subset={members?.join(',')}
              d={diamond(x, y, 4)}
              fill="none"
              stroke={vertexColor}
              strokeWidth={1.2}
            >
              <title>{`vertex ${v}: barycentre of input points {${members?.join(', ')}}`}</title>
            </path>
          ) : (
            <circle
              key={`v${i}`}
              data-testid="nerve-vertex"
              cx={x}
              cy={y}
              r={vertexRadius}
              fill={vertexColor}
              fillOpacity={vertexOpacity}
              stroke={vertexHaloColor ?? 'none'}
              strokeWidth={vertexHaloColor ? vertexHaloWidth : 0}
              // Under the fill, never over it: the halo is a break in the ink
              // around the disc, not a ring drawn on top of the data.
              paintOrder={vertexHaloColor ? 'stroke' : undefined}
            />
          );
        })}

      {showNotes && isSubset && (
        <text
          data-testid="nerve-2d-subset-label"
          x={padding}
          y={height - 18}
          fontSize={9}
          fill="#6b7280"
          fontFamily="ui-monospace, monospace"
        >
          ◇ = a vertex of the mosaic: a subset of the input, drawn at its barycentre ({vertexCount}{' '}
          vertices, {cloud.points.length / cloud.dimension} points)
        </text>
      )}

      {showNotes && guarantee.kind === 'flag' && (
        <text
          data-testid="nerve-2d-flag-label"
          x={padding}
          y={height - 6}
          fontSize={9}
          fill="#6b7280"
          fontFamily="ui-monospace, monospace"
        >
          {guarantee.label}: a simplex means the shapes meet pairwise, not that they share a point
        </text>
      )}
    </svg>
  );
}
