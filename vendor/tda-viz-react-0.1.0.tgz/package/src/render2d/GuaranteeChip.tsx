/**
 * <GuaranteeChip>: the honest label, as a component (SPEC.md §1.4, §1.6).
 *
 * The wording is the LIBRARY's, not the consumer's. Every filtration carries
 * `guarantee.label` — text fixed by tda-wasm's SPEC FR-6 and reproduced
 * verbatim — and this component renders exactly that string. It composes
 * nothing: a renderer that has to assemble its own honesty chip will
 * eventually assemble the wrong one, which is the whole reason the guarantee
 * is data on the filtration.
 *
 * It also carries the two facts that travel with particular constructions and
 * are just as load-bearing as the label:
 *
 *   - QUANTIZATION (box filtrations, SPEC.md §1.3 point 3). Values are grid
 *     values, not measurements. Two box diagrams at different steps are not
 *     comparable — a bottleneck distance between them mostly measures the
 *     grids — so the warning is not optional decoration.
 *   - SUBSET VERTICES (the k-fold cover, SPEC.md §3.1). A vertex is a
 *     k-subset of the input drawn at its barycentre, so the markers on the
 *     drawing are not the input points and must not be read as such.
 *
 * Plain HTML, main entry: it sits beside a 2D SVG stage or over a PlayCanvas
 * canvas equally well, and pulls in no renderer of its own.
 *
 * COLOUR (DESIGN.md "Colour"): the nerve/flag pair and the quantization
 * warning are read from two CSS custom properties, never hard-coded hex —
 *
 *   - `--nerve` (fallback `#0f766e`, deep teal) — a construction whose
 *     persistence provably equals the topology of the union of shapes.
 *   - `--flag` (fallback `#b45309`, rust) — a construction built from
 *     pairwise intersections only, which claims less. Also the colour of the
 *     quantization warning, which is a caveat rather than a construction kind.
 *
 * so a consumer drawing on an ink ground sets `--nerve` / `--flag` to the
 * DESIGN.md `--nerve-on-ink` / `--flag-on-ink` pair on an ancestor element —
 * a custom property, so it cascades in without `!important`.
 */
import type { AnyFiltration } from '../filtration/types';

/** Props for `<GuaranteeChip>`. */
export interface GuaranteeChipProps {
  /**
   * Any filtration, over either domain: the chip reads its guarantee,
   * quantization and vertex kind, and a grid filtration's guarantee is the
   * engine's own name for the cubical convention it was built in
   * (SPEC.md §3.1b). The chip composes nothing in either case.
   */
  filtration: AnyFiltration;
  /**
   * Show the one-line meaning of `guarantee.kind` under the verbatim label.
   * The label alone says what the complex IS; this says what that buys.
   */
  showMeaning?: boolean;
  className?: string;
}

/**
 * What the two guarantee kinds mean, in one line each (SPEC.md §1.4). Keyed by
 * `kind`, so a new complex type inherits the right sentence with no edit here.
 */
const KIND_MEANING = {
  nerve:
    'a nerve lemma applies: the complex is homotopy equivalent to the union of the shapes at every scale',
  flag: 'a flag complex: a simplex means the shapes meet PAIRWISE, not that they share a common point',
  // Not a hedge and not a boast. There is no cover here whose nerve the
  // complex might be, and no pairwise graph it might be the flag complex of:
  // the cells ARE the set, so there is no lemma between the picture and the
  // homology and nothing to withhold (SPEC.md §1.4).
  cubical:
    'the complex IS the thresholded set’s own cells: no cover, no lemma, and nothing between the picture and its homology',
} as const;

/**
 * The quantization sentence, verbatim and asserted by test. Named so a caller
 * can show it somewhere else (an axis label) without paraphrasing it.
 */
export const QUANTIZATION_WARNING =
  'bar endpoints are grid values; diagrams at different π are not comparable';

/** The ink each guarantee kind is carried in. Tokens, never a hex literal here. */
function chipInk(kind: 'nerve' | 'flag' | 'cubical'): string {
  if (kind === 'nerve') return 'var(--nerve, #0f766e)';
  if (kind === 'cubical') return 'var(--cubical, #4338ca)';
  return 'var(--flag, #b45309)';
}

const caption = {
  fontSize: 10,
  opacity: 0.7,
  margin: '4px 0 0',
  fontFamily: 'ui-monospace, monospace',
} as const;

/**
 * The filtration's own guarantee, as a label (SPEC.md §1.4): whether the
 * complex is a nerve, a flag complex, or exact, in the library's words rather
 * than a consumer's.
 */
export function GuaranteeChip({ filtration, showMeaning = true, className }: GuaranteeChipProps) {
  const { guarantee, quantization, complexType } = filtration;
  // Narrow ONCE, on `domain`, and read every domain-specific fact off the
  // narrowed value. The grid has no cloud and no vertices, and saying so here
  // is cheaper than a component that discovers it at the property access.
  const grid = filtration.domain === 'grid' ? filtration : null;
  const cloudy = filtration.domain === 'cloud' ? filtration : null;
  const vertexKind = cloudy?.vertexKind ?? null;
  const vertexCount = cloudy?.vertexCount ?? 0;
  const vertexSubsets = cloudy?.vertexSubsets ?? null;
  const pointCount = cloudy ? cloudy.cloud.points.length / cloudy.cloud.dimension : 0;
  // Every subset of the order-k mosaic has the same size k; read it off the
  // data rather than assuming, so a mixed-size input cannot be mislabelled.
  const subsetSizes = vertexSubsets ? new Set(vertexSubsets.map((s) => s.length)) : null;
  const k = subsetSizes && subsetSizes.size === 1 ? [...subsetSizes][0] : null;

  return (
    <div
      className={className}
      data-testid="guarantee-chip"
      data-guarantee={guarantee.kind}
      data-complex-type={complexType}
      data-quantized={quantization ? 'true' : undefined}
      data-vertex-kind={vertexKind ?? undefined}
      data-domain={filtration.domain}
    >
      <span
        data-testid="guarantee-chip-label"
        style={{
          display: 'inline-block',
          padding: '2px 8px',
          borderRadius: 999,
          fontSize: 11,
          fontFamily: 'ui-monospace, monospace',
          // Nerve and flag are different claims about the same picture, so they
          // are different colours: teal states an equivalence, rust withholds
          // one. Never the same chip in two wordings. Read from the DESIGN.md
          // custom properties (never a hex literal) so a consumer on the ink
          // ground can retint both without `!important`.
          // Three kinds, three inks. Cubical gets its OWN token rather than
          // borrowing the nerve's: the two make different claims, and a chip
          // that painted them the same colour would say they were the same
          // claim to every reader who reads colour before text.
          border: `1px solid ${chipInk(guarantee.kind)}`,
          color: chipInk(guarantee.kind),
        }}
      >
        {guarantee.label}
      </span>

      {showMeaning && (
        <p data-testid="guarantee-chip-meaning" style={caption}>
          {KIND_MEANING[guarantee.kind]}
        </p>
      )}

      {quantization && (
        <p
          data-testid="guarantee-chip-quantization"
          style={{ ...caption, color: 'var(--flag, #b45309)' }}
        >
          step π = {quantization.step} · {quantization.steps} steps · {QUANTIZATION_WARNING}
        </p>
      )}

      {grid && (
        <p data-testid="guarantee-chip-grid" style={caption}>
          {grid.width} × {grid.height} values on{' '}
          {grid.construction === 'cubical-t' ? 'pixels' : 'grid vertices'}; the other convention
          reads the same numbers as the other kind of cell and gives a different diagram
        </p>
      )}

      {vertexKind === 'subset' && (
        <p data-testid="guarantee-chip-vertices" style={caption}>
          vertices are {k === null ? 'subsets' : `${k}-subsets`} of the input, drawn at their
          barycentres: {vertexCount} vertices from {pointCount} points
        </p>
      )}
    </div>
  );
}
