/**
 * <GuaranteeChip>: the honest label, as a component (SPEC.md §1.4, §1.6).
 *
 * The wording is the LIBRARY's, not the consumer's. Every filtration carries
 * `guarantee.label` — text fixed by tda-wasm's SPEC FR-6 and reproduced
 * verbatim — and this component renders exactly that string. It composes
 * nothing: a renderer that has to assemble its own honesty chip will
 * eventually assemble the wrong one, which is the whole reason the guarantee
 * is data on the filtration.
 *
 * It also carries the two facts that travel with particular constructions and
 * are just as load-bearing as the label:
 *
 *   - QUANTIZATION (box filtrations, SPEC.md §1.3 point 3). Values are grid
 *     values, not measurements. Two box diagrams at different steps are not
 *     comparable — a bottleneck distance between them mostly measures the
 *     grids — so the warning is not optional decoration.
 *   - SUBSET VERTICES (the k-fold cover, SPEC.md §3.1). A vertex is a
 *     k-subset of the input drawn at its barycentre, so the markers on the
 *     drawing are not the input points and must not be read as such.
 *
 * Plain HTML, main entry: it sits beside a 2D SVG stage or over a PlayCanvas
 * canvas equally well, and pulls in no renderer of its own.
 */
import type { Filtration } from '../filtration/types';

export interface GuaranteeChipProps {
  /** Any filtration: the chip reads its guarantee, quantization and vertex kind. */
  filtration: Filtration;
  /**
   * Show the one-line meaning of `guarantee.kind` under the verbatim label.
   * The label alone says what the complex IS; this says what that buys.
   */
  showMeaning?: boolean;
  className?: string;
}

/**
 * What the two guarantee kinds mean, in one line each (SPEC.md §1.4). Keyed by
 * `kind`, so a new complex type inherits the right sentence with no edit here.
 */
const KIND_MEANING = {
  nerve:
    'a nerve lemma applies: the complex is homotopy equivalent to the union of the shapes at every scale',
  flag: 'a flag complex: a simplex means the shapes meet PAIRWISE, not that they share a common point',
} as const;

/**
 * The quantization sentence, verbatim and asserted by test. Named so a caller
 * can show it somewhere else (an axis label) without paraphrasing it.
 */
export const QUANTIZATION_WARNING =
  'bar endpoints are grid values; diagrams at different π are not comparable';

const caption = {
  fontSize: 10,
  opacity: 0.7,
  margin: '4px 0 0',
  fontFamily: 'ui-monospace, monospace',
} as const;

export function GuaranteeChip({ filtration, showMeaning = true, className }: GuaranteeChipProps) {
  const { guarantee, quantization, complexType, vertexKind, vertexCount, vertexSubsets } =
    filtration;
  const pointCount = filtration.cloud.points.length / filtration.cloud.dimension;
  // Every subset of the order-k mosaic has the same size k; read it off the
  // data rather than assuming, so a mixed-size input cannot be mislabelled.
  const subsetSizes = vertexSubsets ? new Set(vertexSubsets.map((s) => s.length)) : null;
  const k = subsetSizes && subsetSizes.size === 1 ? [...subsetSizes][0] : null;

  return (
    <div
      className={className}
      data-testid="guarantee-chip"
      data-guarantee={guarantee.kind}
      data-complex-type={complexType}
      data-quantized={quantization ? 'true' : undefined}
      data-vertex-kind={vertexKind}
    >
      <span
        data-testid="guarantee-chip-label"
        style={{
          display: 'inline-block',
          padding: '2px 8px',
          borderRadius: 999,
          fontSize: 11,
          fontFamily: 'ui-monospace, monospace',
          // Nerve and flag are different claims about the same picture, so they
          // are different colours: green states an equivalence, amber withholds
          // one. Never the same chip in two wordings.
          border: `1px solid ${guarantee.kind === 'nerve' ? '#15803d' : '#b45309'}`,
          color: guarantee.kind === 'nerve' ? '#15803d' : '#b45309',
        }}
      >
        {guarantee.label}
      </span>

      {showMeaning && (
        <p data-testid="guarantee-chip-meaning" style={caption}>
          {KIND_MEANING[guarantee.kind]}
        </p>
      )}

      {quantization && (
        <p data-testid="guarantee-chip-quantization" style={{ ...caption, color: '#b45309' }}>
          step π = {quantization.step} · {quantization.steps} steps · {QUANTIZATION_WARNING}
        </p>
      )}

      {vertexKind === 'subset' && (
        <p data-testid="guarantee-chip-vertices" style={caption}>
          vertices are {k === null ? 'subsets' : `${k}-subsets`} of the input, drawn at their
          barycentres: {vertexCount} vertices from {pointCount} points
        </p>
      )}
    </div>
  );
}
