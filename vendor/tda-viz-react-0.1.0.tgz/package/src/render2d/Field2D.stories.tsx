import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CIRCLE12_WING,
  CIRCLE12_WING_ESTIMATED_NORMALS,
  CIRCLE24_ALPHA,
  ELLIPSE_ELLIPSOID_CECH,
  ELLIPSE_ELLIPSOID_RIPS,
  JITTERED8_KFOLD2,
  RING6_BOX,
  RING6_BOX_HALFSTEP,
  SPIRAL16_ELLIPSOID_RIPS_3D,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { Field2D } from './Field2D';
import { GuaranteeChip } from './GuaranteeChip';

/**
 * The space itself. At scale t the filtration is the union of the growing
 * shapes X_t = ⋃ᵢ S_i(t) — and this component draws exactly that set, as ONE
 * merged region. It is not n translucent shapes: overlapping shapes would
 * double-count the intersections, which are precisely the regions whose
 * pattern the complex records.
 *
 * The shape is whatever the filtration grows, already scaled to t by
 * `shapeAt(i, t)`: a disc for the ball constructions, an ellipse fitted from a
 * local PCA frame, the wing's concave hexagon, an axis-aligned box on the π
 * grid. This component re-derives no scale law, which is why the picture cannot
 * drift away from the barcode beside it.
 *
 * Radii and semi-axes are per point. Under the weighted alpha filtration the
 * ball around pᵢ has squared radius t + wᵢ (Edelsbrunner's convention), so
 * heavier points carry larger balls at every t. The drawn convention is read
 * from the filtration and displayed under the drawing, because a picture
 * that does not name its convention can silently contradict the barcode
 * beside it. All data here is recorded output of the real GUDHI engine.
 *
 * One of these stories deliberately draws NO shapes: a 3D ellipsoid seen from
 * above, which would be a central slice rather than an outline. It says why.
 * The projection fits the CLOUD, so shapes grow past the frame at large t;
 * the shape stories pass a larger `padding` to leave the growth some room.
 */
const meta = {
  title: '2D/Field2D',
  component: Field2D,
  tags: ['autodocs'],
} satisfies Meta<typeof Field2D>;

export default meta;
type Story = StoryObj<typeof meta>;

const circle = recordedFiltration(CIRCLE24_ALPHA);
const weighted = recordedFiltration(WEIGHTED3_ALPHA);

/** t = 0 on an unweighted circle: every ball has radius √0 = 0. The space is 24 points. */
export const CircleAtZero: Story = { args: { filtration: circle, t: 0 } };

/**
 * Just past the first critical value (t ≈ sin²(π/24)): adjacent balls have
 * met and X_t is an annulus — a thin ring with a hole. β₁ = 1 from here
 * until the hole fills.
 */
export const CircleAnnulus: Story = { args: { filtration: circle, t: 0.05 } };

/** The annulus thickens as t grows; the hole (the H₁ class) survives. */
export const CircleThickAnnulus: Story = { args: { filtration: circle, t: 0.5 } };

/**
 * t = 1 is the squared circumradius of the circle: the balls reach the
 * center, the hole fills, and the H₁ bar dies exactly here.
 */
export const CircleHoleFilled: Story = { args: { filtration: circle, t: 1.0 } };

/**
 * The key capability (SPEC §7 story 2): three points, one heavy (w = 0.5).
 * At t = 0 the heavy ball already has radius √0.5 ≈ 0.707 while the light
 * points are still points — radii are per point, not one shared scalar.
 */
export const WeightedAtZero: Story = { args: { filtration: weighted, t: 0 } };

/**
 * Between the heavy-light contacts (t ≈ 0.658, 0.766) and the light-light
 * contact (t = 0.89): the union is connected through the heavy ball while
 * the light pair still has a gap.
 */
export const WeightedHeavyBridges: Story = { args: { filtration: weighted, t: 0.8 } };

/**
 * A Rips filtration of the same idea: t is EDGE LENGTH, so the drawn radius
 * is t/2 — two balls touch exactly when their points are t apart. The label
 * under the canvas names this, because drawing t as the radius here would
 * contradict the homology.
 */
export const RipsConvention: Story = {
  args: { filtration: recordedFiltration(TRIANGLE_RIPS), t: 1.0 },
};

/** Čech: t IS the ball radius; the drawn radius equals the filtration index. */
export const CechConvention: Story = {
  args: { filtration: recordedFiltration(TRIANGLE_CECH), t: 0.5 },
};

/** Below every ball's birth nothing is drawn — an empty space is a real state. */
export const BeforeAnyBall: Story = { args: { filtration: weighted, t: -0.5 } };

// ── The complex menu: the shape is not always a ball (SPEC.md §1.1) ──────

/**
 * Every shape story shows the guarantee chip beside the drawing: the union on
 * screen is equivalent to the complex only when the complex is a nerve, and the
 * chip is where that claim is made or withheld.
 */
const withChip: Story['render'] = (args) => (
  <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
    <Field2D {...args} />
    <GuaranteeChip filtration={args.filtration} />
  </div>
);

/**
 * Ellipsoids, fitted per point from a local PCA frame on a 16-point ellipse.
 * The semi-axes are (t/2)·profile — t is TWICE the ellipsoid radius, the
 * Rips-comparable scale the engine emits — and the FRAME DOES NOT MOVE with t.
 * That is not a detail: re-fitting per scale would break X_s ⊆ X_t and the
 * persistence beside it would be the persistence of nothing.
 */
export const EllipsoidsAtSmallScale: Story = {
  args: { filtration: recordedFiltration(ELLIPSE_ELLIPSOID_RIPS), t: 0.6, padding: 70 },
  render: withChip,
};

/** The same ellipsoids, later: anisotropy is visible as the union thickens along the curve. */
export const EllipsoidsGrown: Story = {
  args: { filtration: recordedFiltration(ELLIPSE_ELLIPSOID_RIPS), t: 1.2, padding: 70 },
  render: withChip,
};

/**
 * The same ellipsoids again, from the ellipsoidal Čech build. Identical shapes
 * and an identical 1-skeleton — the difference is in the complex, not the
 * picture of the space, and only this one is a nerve of the union on screen.
 */
export const EllipsoidsCechSameShapes: Story = {
  args: { filtration: recordedFiltration(ELLIPSE_ELLIPSOID_CECH), t: 1.2, padding: 70 },
  render: withChip,
};

/**
 * A 3D ellipsoid filtration seen from above draws NO shapes. Dropping z would
 * show the ellipse of frame[0], frame[1] — a central slice, not the outline —
 * and a slice is a different set than the shape whose births are on the
 * barcode. Use `<Field3D>` from `tda-viz-react/3d`.
 */
export const Ellipsoids3DRefused: Story = {
  args: { filtration: recordedFiltration(SPIRAL16_ELLIPSOID_RIPS_3D), t: 1.2 },
  render: withChip,
};

/**
 * The wing: a concave hexagon around a FIXED unit normal — spine half-length
 * q·t along ±α, wing edges of length t at ±θ from the spine direction. Here
 * q = 1/3, θ = π/2 on a 12-point circle, where the outward radial IS the exact
 * normal (`normalSource: 'supplied'`).
 *
 * The polygon is `point + t · outline[v]` with the outline `computeWingGeometry`
 * returned — the same `unit_wing()` the engine's birth solver intersects — so
 * nothing here re-derives the hexagon and the drawing cannot drift from the
 * barcode.
 */
export const WingsExactNormals: Story = {
  args: { filtration: recordedFiltration(CIRCLE12_WING), t: 0.35, padding: 90 },
  render: withChip,
};

/**
 * The same wing complex built from a neighbourhood size k instead. The engine
 * estimates the normals internally, and `computeWingGeometry` reads them back
 * out of the builder, so these hexagons are drawn too — they are the wings whose
 * births are on the barcode, not a re-estimate. What changes is provenance:
 * every shape reports `normalSource: 'osculating'`, and a point whose fit
 * degenerated would report `'tangent'` instead.
 *
 * On a circle the osculating fit is exact, so this drawing and the one above
 * coincide to about 1e-8. On a cloud with an inflection they would not, and the
 * `normalSource` on each shape is how a reviewer knows which picture they are
 * looking at.
 */
export const WingsEstimatedNormals: Story = {
  args: { filtration: recordedFiltration(CIRCLE12_WING_ESTIMATED_NORMALS), t: 0.35, padding: 90 },
  render: withChip,
};

/**
 * Boxes on a 6-point ring, step π = 0.25, at step 2. These are the engine's own
 * grown boxes, looked up — never interpolated: an interpolated box is a shape
 * the filtration never contained, and between grid values the drawing simply
 * does not change.
 */
export const BoxesStepTwo: Story = {
  args: { filtration: recordedFiltration(RING6_BOX), t: 0.5, padding: 80 },
  render: withChip,
};

/**
 * The SAME cloud on a grid twice as fine (π = 0.125), at the same t. The chip
 * carries the warning that matters: the values are grid values, so this
 * diagram and the one above are NOT comparable — a distance between them
 * mostly measures the two grids.
 */
export const BoxesFinerGrid: Story = {
  args: { filtration: recordedFiltration(RING6_BOX_HALFSTEP), t: 0.5, padding: 80 },
  render: withChip,
};

/**
 * The k-fold cover: the shapes are still balls, at radius √t around the INPUT
 * points, while the complex's vertices are 2-subsets drawn elsewhere (see
 * `<Nerve2D>`). Two different objects on one drawing, which is why the chip
 * spells out the vertex count against the point count. 3D cloud, seen from
 * above.
 */
export const KFoldBallsAtSqrtT: Story = {
  args: { filtration: recordedFiltration(JITTERED8_KFOLD2), t: 0.4, padding: 60 },
  render: withChip,
};
