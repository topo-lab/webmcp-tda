/**
 * <ConstructionIndex>: the two-band index of constructions — the navigation
 * architecture, not a tab bar (DESIGN.md §Layout).
 *
 * The constructions are grouped under the two headings COMMON INTERSECTION and
 * PAIRWISE INTERSECTION, so selecting one is always an act of reading its
 * classification. That is the first and weakest of the four guarantee signals,
 * and the only one that cannot be missed: you cannot reach a construction without
 * passing through the claim it makes (DESIGN.md §Expressing the guarantee without
 * a badge, signal 1). The band an entry sits in is its `guarantee.kind`
 * (SPEC.md §1.4); the headings and rules are the library's own words
 * (`BAND_HEADING`, `BAND_RULE` in src/filtration/guarantees.ts), never retyped
 * by a consumer.
 *
 * Keyboard model, deliberately two tablists rather than one:
 *   - ARROW KEYS move within a band, with automatic activation, which is the
 *     standard tabs pattern;
 *   - TAB moves between bands, because each band exposes exactly one tab stop
 *     (roving tabindex). Tabbing therefore walks the classification, and the
 *     structure is audible to a screen reader as two labelled lists rather than
 *     one flat six.
 *
 * Two states a consumer needs and the Atlas did not:
 *   - `disabled` entries are listed but not selectable — a construction the
 *     current cloud cannot have (the wing complex is 2D only, the k-fold cover 3D
 *     only). They keep their place in the classification, are skipped by the
 *     arrow keys and never become the band's tab stop. The index states no
 *     reason: the omission is the engine's rule, and the engine's own message is
 *     what a consumer surfaces if a build is ever attempted.
 *   - `locked` freezes the selection — a lesson that teaches one rule keeps the
 *     index visible so the classification stays legible, but nothing else may be
 *     chosen. Every entry except the selected one behaves as disabled.
 *
 * Promoted from the site's Atlas index (2026-09-02). Plain HTML on the main
 * entry; styled through the class names below, with the band colour passed in
 * so a consumer can bind it to its own tokens.
 */
import { useEffect, useRef } from 'react';
import { BAND_HEADING, BAND_ORDER, BAND_RULE } from '../filtration/guarantees';
import type { ComplexGuaranteeKind } from '../filtration/types';

export interface ConstructionIndexEntry {
  /** Stable id, e.g. the `complexType`. Selection and tab ids key on it. */
  readonly id: string;
  /** Display name, e.g. "Vietoris–Rips". */
  readonly name: string;
  /** Which band the entry sits in: its `guarantee.kind`. */
  readonly kind: ComplexGuaranteeKind;
  /**
   * Optional siglum shown before the name ("1.2"). The site numbers entries by
   * band so the first component is the classification, not a position in a
   * list of six; a consumer with no figures omits it.
   */
  readonly figure?: string;
  /** Optional annotation after the name, e.g. "experimental" (SPEC.md §1.6). */
  readonly annotation?: string;
  /** Listed but not selectable. See the file header. */
  readonly disabled?: boolean;
}

export interface ConstructionIndexProps {
  entries: readonly ConstructionIndexEntry[];
  selectedId: string;
  onSelect(id: string): void;
  /** The panel this index drives (`aria-controls`). */
  panelId: string;
  /** Freeze the selection: every other entry behaves as disabled. */
  locked?: boolean;
  /**
   * Prefix for the generated element ids (`${idPrefix}-tab-${id}`,
   * `${idPrefix}-band-${kind}`). Default "construction".
   */
  idPrefix?: string;
  /**
   * The colour each band is carried in — the guarantee pair (DESIGN.md §Color).
   * Pass CSS tokens (`var(--nerve)`) to bind it to a stylesheet; the defaults
   * are the pair's hex values.
   */
  bandColors?: Readonly<Record<ComplexGuaranteeKind, string>>;
  'aria-label'?: string;
  className?: string;
}

/** The guarantee pair, as DESIGN.md §Color states it: deep teal and rust. */
export const DEFAULT_BAND_COLORS: Readonly<Record<ComplexGuaranteeKind, string>> = Object.freeze({
  nerve: '#0f766e',
  flag: '#b45309',
});

export const constructionTabId = (id: string, idPrefix = 'construction') => `${idPrefix}-tab-${id}`;

const bandHeadingId = (kind: ComplexGuaranteeKind, idPrefix: string) => `${idPrefix}-band-${kind}`;

interface IndexBandProps {
  kind: ComplexGuaranteeKind;
  entries: readonly ConstructionIndexEntry[];
  selectedId: string;
  onSelect(id: string): void;
  panelId: string;
  locked: boolean;
  idPrefix: string;
  color: string;
}

function IndexBand({
  kind,
  entries,
  selectedId,
  onSelect,
  panelId,
  locked,
  idPrefix,
  color,
}: IndexBandProps) {
  const headingId = bandHeadingId(kind, idPrefix);
  const buttons = useRef<(HTMLButtonElement | null)[]>([]);
  const pendingFocus = useRef<number | null>(null);

  // Arrow keys select AND move focus, so the focused tab is always the selected
  // one within a band. Focus is applied after the selection has rendered.
  useEffect(() => {
    if (pendingFocus.current === null) return;
    buttons.current[pendingFocus.current]?.focus();
    pendingFocus.current = null;
  });

  const isDisabled = (entry: ConstructionIndexEntry) =>
    entry.disabled === true || (locked && entry.id !== selectedId);

  const selectedIndex = entries.findIndex((e) => e.id === selectedId);
  // The band's single tab stop: its selected tab, or its first selectable one
  // when the selection lives in the other band. A band with nothing selectable
  // has no tab stop at all.
  const firstEnabled = entries.findIndex((e) => !isDisabled(e));
  const tabbableIndex = selectedIndex >= 0 ? selectedIndex : firstEnabled;

  const move = (from: number, delta: number) => {
    if (entries.length === 0) return;
    // Walk cyclically to the next selectable entry; a full turn with none
    // selectable is a no-op.
    for (let step = 1; step <= entries.length; step++) {
      const next = (from + delta * step + entries.length * step) % entries.length;
      if (!isDisabled(entries[next])) {
        pendingFocus.current = next;
        onSelect(entries[next].id);
        return;
      }
    }
  };

  return (
    <div className="construction-band" data-band={kind} data-locked={locked || undefined}>
      <h3 id={headingId} className="construction-band-heading" style={{ color }}>
        {BAND_HEADING[kind]}
      </h3>
      <p className="construction-band-rule">{BAND_RULE[kind]}</p>
      <div
        role="tablist"
        aria-labelledby={headingId}
        aria-orientation="vertical"
        className="construction-band-list"
        style={{ borderColor: color }}
      >
        {entries.map((entry, i) => {
          const selected = entry.id === selectedId;
          const disabled = isDisabled(entry);
          return (
            <button
              key={entry.id}
              ref={(node) => {
                buttons.current[i] = node;
              }}
              type="button"
              role="tab"
              id={constructionTabId(entry.id, idPrefix)}
              aria-selected={selected}
              aria-controls={panelId}
              aria-disabled={disabled || undefined}
              disabled={disabled && !selected}
              tabIndex={i === tabbableIndex ? 0 : -1}
              className="construction-tab"
              data-selected={selected}
              data-construction={entry.id}
              onClick={() => {
                if (!disabled) onSelect(entry.id);
              }}
              onKeyDown={(event) => {
                if (locked) return;
                switch (event.key) {
                  case 'ArrowDown':
                  case 'ArrowRight':
                    event.preventDefault();
                    move(i, 1);
                    break;
                  case 'ArrowUp':
                  case 'ArrowLeft':
                    event.preventDefault();
                    move(i, -1);
                    break;
                  case 'Home':
                    event.preventDefault();
                    move(-1, 1);
                    break;
                  case 'End':
                    event.preventDefault();
                    move(entries.length, -1);
                    break;
                  default:
                    break;
                }
              }}
            >
              {entry.figure !== undefined && (
                <span className="construction-tab-figure">{entry.figure}</span>
              )}
              <span className="construction-tab-name">{entry.name}</span>
              {entry.annotation !== undefined && (
                <span className="construction-tab-annotation">{entry.annotation}</span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function ConstructionIndex({
  entries,
  selectedId,
  onSelect,
  panelId,
  locked = false,
  idPrefix = 'construction',
  bandColors = DEFAULT_BAND_COLORS,
  'aria-label': ariaLabel = 'Constructions, grouped by the guarantee they carry',
  className,
}: ConstructionIndexProps) {
  return (
    <nav
      className={className ? `construction-index ${className}` : 'construction-index'}
      aria-label={ariaLabel}
      data-testid="construction-index"
      data-locked={locked || undefined}
    >
      {BAND_ORDER.map((kind) => (
        <IndexBand
          key={kind}
          kind={kind}
          entries={entries.filter((e) => e.kind === kind)}
          selectedId={selectedId}
          onSelect={onSelect}
          panelId={panelId}
          locked={locked}
          idPrefix={idPrefix}
          color={bandColors[kind]}
        />
      ))}
    </nav>
  );
}
