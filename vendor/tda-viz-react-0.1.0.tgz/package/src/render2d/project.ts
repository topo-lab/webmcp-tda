/**
 * Shared 2D projection: aspect-preserving fit of a cloud into a pixel box.
 * <Field2D> and <Nerve2D> MUST share this so the nerve draws exactly over
 * the union of balls it describes.
 */

export interface Projection2D {
  /** Pixel position per point (y flipped: data y-up renders naturally). */
  pos: { x: number; y: number }[];
  /** Pixels per data unit — converts filtration radii into pixel radii. */
  pxPerUnit: number;
  /**
   * The same map `pos` was built with, for coordinates that are NOT input
   * points: the outline of a growing shape, or the barycentre of a k-fold
   * mosaic vertex. Two functions of one scalar each rather than one function of
   * a point, because the map is axis-aligned (uniform scale, y flipped) and
   * these run per vertex per frame — an allocated `{x, y}` per call would not.
   */
  px(x: number): number;
  py(y: number): number;
}

/**
 * @param points Flat coordinates; `stride` 2 or 3 (3D clouds project by
 *               dropping z — an orthographic top-down view, use the 3d entry
 *               for a real camera).
 */
export function projectCloud(
  points: number[],
  stride: number,
  width: number,
  height: number,
  padding: number,
): Projection2D {
  const n = Math.floor(points.length / stride);
  if (n === 0) {
    return { pos: [], pxPerUnit: 1, px: (x) => x, py: (y) => y };
  }

  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;
  for (let i = 0; i < n; i++) {
    const x = points[i * stride];
    const y = points[i * stride + 1];
    if (x < minX) minX = x;
    if (x > maxX) maxX = x;
    if (y < minY) minY = y;
    if (y > maxY) maxY = y;
  }

  const spanX = maxX - minX || 1;
  const spanY = maxY - minY || 1;
  const innerW = Math.max(width - padding * 2, 1);
  const innerH = Math.max(height - padding * 2, 1);
  const scale = Math.min(innerW / spanX, innerH / spanY);
  const offX = padding + (innerW - spanX * scale) / 2;
  const offY = padding + (innerH - spanY * scale) / 2;

  const px = (x: number) => offX + (x - minX) * scale;
  const py = (y: number) => offY + (maxY - y) * scale;

  const pos: { x: number; y: number }[] = [];
  for (let i = 0; i < n; i++) {
    pos.push({ x: px(points[i * stride]), y: py(points[i * stride + 1]) });
  }
  return { pos, pxPerUnit: scale, px, py };
}
