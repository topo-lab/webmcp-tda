import type { Meta, StoryObj } from '@storybook/react-vite';
import { PointCloud2D } from './PointCloud2D';
import { CIRCLE_50 } from '../__fixtures__/realCircle';

/**
 * The raw data, before any topology is computed. Flat `[x0, y0, x1, y1, …]`
 * coordinates are projected into an aspect-preserving SVG viewport, so a
 * circle stays circular regardless of the box it is given.
 *
 * This is the 2D tree. It is pure SVG and imports no PlayCanvas — the 3D
 * equivalent lives behind the separate `tda-viz-react/3d` entry so that a 2D
 * consumer never ships a WebGL renderer (SPEC.md §3).
 */
const meta = {
  title: '2D/PointCloud2D',
  component: PointCloud2D,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Renders a 2D point cloud as SVG. Colour defaults to `currentColor`, so Tailwind `text-*` utilities style it from the parent.',
      },
    },
  },
} satisfies Meta<typeof PointCloud2D>;

export default meta;
type Story = StoryObj<typeof meta>;

function figureEight(n: number): number[] {
  const pts: number[] = [];
  for (let i = 0; i < n; i++) {
    const t = (2 * Math.PI * i) / n;
    pts.push(Math.sin(2 * t) / 2, Math.sin(t));
  }
  return pts;
}

function twoClusters(n: number): number[] {
  const pts: number[] = [];
  for (let i = 0; i < n; i++) {
    const cx = i < n / 2 ? -0.6 : 0.6;
    const a = (i * 2.399) % (2 * Math.PI);
    const r = 0.22 * Math.sqrt((i % (n / 2)) / (n / 2));
    pts.push(cx + r * Math.cos(a), r * Math.sin(a));
  }
  return pts;
}

/**
 * The same 50 points used throughout the persistence stories. One component
 * per point at scale zero, and one loop waiting to be found.
 */
export const Circle: Story = {
  args: { points: CIRCLE_50 },
};

/**
 * Two loops instead of one. A figure eight is the standard example for "two
 * H₁ classes in a single lane" — same degree, so they share a barcode lane
 * rather than getting one lane each.
 */
export const FigureEight: Story = {
  args: { points: figureEight(80) },
};

/**
 * Components that genuinely die. Two blobs merge into one as the scale grows,
 * which is an H₀ death rather than an H₁ birth.
 */
export const TwoClusters: Story = {
  args: { points: twoClusters(90) },
};

/**
 * The weight glyph (SPEC §4.2): marker radius scales with √wᵢ, so a weighted
 * cloud is visibly weighted before any ball is drawn. This is the SPEC §7
 * story-2 cloud — the heavy point (w = 0.5) reads as heavy at a glance. The
 * glyph is a marker; <Field2D> draws the true ball radii √(t + wᵢ).
 */
export const WeightGlyph: Story = {
  args: { points: [0, 0, 2, 0, 1, 1.6], weights: [0.5, 0, 0], pointRadius: 4 },
};

/** Empty input renders an empty frame — not a placeholder shape. */
export const Empty: Story = {
  args: { points: [] },
};

/** A single point: the smallest non-empty cloud. */
export const SinglePoint: Story = {
  args: { points: [0, 0] },
};

/**
 * Aspect preservation under a deliberately wide viewport. The circle must not
 * become an ellipse.
 */
export const WideViewport: Story = {
  args: { points: CIRCLE_50, width: 640, height: 220 },
};

/** Larger marks for presentation contexts or small embeds. */
export const LargePoints: Story = {
  args: { points: CIRCLE_50, pointRadius: 6, color: '#ea580c' },
};

/** Dense cloud, to check rendering cost and overplotting. */
export const Dense: Story = {
  args: {
    points: Array.from({ length: 1200 }, (_, i) => {
      const a = i * 2.399963;
      const r = Math.sqrt(i / 1200);
      return [r * Math.cos(a), r * Math.sin(a)];
    }).flat(),
    pointRadius: 1.5,
  },
};
