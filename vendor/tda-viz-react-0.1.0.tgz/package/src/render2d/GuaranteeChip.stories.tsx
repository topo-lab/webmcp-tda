import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CIRCLE12_WING,
  CIRCLE24_ALPHA,
  ELLIPSE_ELLIPSOID_CECH,
  ELLIPSE_ELLIPSOID_RIPS,
  JITTERED8_KFOLD2,
  RING6_BOX,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { GuaranteeChip } from './GuaranteeChip';

/**
 * What the complex on screen actually IS.
 *
 * The wording belongs to the library, not to the consumer: every filtration
 * carries `guarantee = { kind, label }`, the label is fixed by tda-wasm's own
 * SPEC FR-6, and this component prints it verbatim. A test asserts every
 * character, so a flag complex can never be presented as a nerve — the
 * difference is a claim about the mathematics, not a matter of tone.
 *
 * The chip also carries the two facts that travel with particular
 * constructions: a box filtration's values are grid values (two box diagrams
 * at different steps are not comparable), and a k-fold cover's vertices are
 * k-subsets drawn at barycentres rather than the input points.
 *
 * Every story that draws a complex should show this chip beside it.
 */
const meta = {
  title: 'Honesty/GuaranteeChip',
  component: GuaranteeChip,
  tags: ['autodocs'],
} satisfies Meta<typeof GuaranteeChip>;

export default meta;
type Story = StoryObj<typeof meta>;

/** Alpha: the nerve of the cover by ball ∩ power cell, with exact combinatorics. */
export const Alpha: Story = { args: { filtration: recordedFiltration(CIRCLE24_ALPHA) } };

/** Čech: the nerve of the ball cover, by definition. */
export const Cech: Story = { args: { filtration: recordedFiltration(TRIANGLE_CECH) } };

/**
 * Rips: a flag complex. Its triangle says the three balls meet pairwise; it
 * does NOT say they share a point, and the chip refuses to imply otherwise.
 */
export const Rips: Story = { args: { filtration: recordedFiltration(TRIANGLE_RIPS) } };

/**
 * The pair that makes the distinction concrete: the same ellipsoids at the
 * same scale, one a flag complex and one a true nerve. The union of ellipsoids
 * on screen is equivalent to the ellipsoidal Čech complex — not to its flag
 * sibling.
 */
export const EllipsoidFlag: Story = {
  args: { filtration: recordedFiltration(ELLIPSE_ELLIPSOID_RIPS) },
};
export const EllipsoidNerve: Story = {
  args: { filtration: recordedFiltration(ELLIPSE_ELLIPSOID_CECH) },
};

/** Wing: the first public implementation, and a flag complex (Weng–Zhao Eq. 3.5). */
export const Wing: Story = { args: { filtration: recordedFiltration(CIRCLE12_WING) } };

/**
 * Box: a nerve by Helly for axis-aligned boxes — AND quantized. The step and
 * the incomparability warning are part of the label's meaning, not a footnote.
 */
export const BoxQuantized: Story = { args: { filtration: recordedFiltration(RING6_BOX) } };

/**
 * k-fold cover: exact by the Almost Nerve lemma, with vertices that are
 * 2-subsets of the 8 input points, drawn at their barycentres. There are more
 * vertices than points, and the chip says so in numbers.
 */
export const KFoldSubsetVertices: Story = {
  args: { filtration: recordedFiltration(JITTERED8_KFOLD2) },
};

/** Label only: for a caller with their own explanatory copy. */
export const LabelOnly: Story = {
  args: { filtration: recordedFiltration(RING6_BOX), showMeaning: false },
};
