import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CIRCLE12_WING_ESTIMATED_NORMALS,
  CIRCLE24_ALPHA,
  JITTERED8_KFOLD1,
  JITTERED8_KFOLD2,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { Field2D } from './Field2D';
import { GuaranteeChip } from './GuaranteeChip';
import { Nerve2D } from './Nerve2D';

/**
 * The nerve of the ball cover: a k-simplex for every k+1 balls with a common
 * point. The Nerve theorem says this complex is homotopy equivalent to the
 * union of balls (for convex balls, which these are) — so the complex drawn
 * here and the region <Field2D> draws are the same space up to homotopy, and
 * a simplex appears exactly when its balls start overlapping.
 *
 * Čech is exactly this nerve. Alpha is the nerve restricted by the power
 * diagram (far fewer simplices, same homology). Rips is NOT a nerve — it is
 * the flag complex of the 1-skeleton — and this component labels it as such
 * on the drawing. Every simplex shown is recorded GUDHI output; moving t
 * filters the display and never recomputes (SPEC §1.5).
 */
const meta = {
  title: '2D/Nerve2D',
  component: Nerve2D,
  tags: ['autodocs'],
} satisfies Meta<typeof Nerve2D>;

export default meta;
type Story = StoryObj<typeof meta>;

const circle = recordedFiltration(CIRCLE24_ALPHA);
const weighted = recordedFiltration(WEIGHTED3_ALPHA);
const rips = recordedFiltration(TRIANGLE_RIPS);
const cech = recordedFiltration(TRIANGLE_CECH);

/** Below the first edge: 24 vertices, no simplices — a complex of points. */
export const CircleVerticesOnly: Story = { args: { filtration: circle, t: 0.01 } };

/**
 * The ring: adjacent balls overlap pairwise, so the nerve is a 24-gon —
 * one loop, the H₁ class the barcode shows as its long bar.
 */
export const CircleRing: Story = { args: { filtration: circle, t: 0.05 } };

/** Triangles of the alpha triangulation fill the ring as t approaches 1. */
export const CircleFilling: Story = { args: { filtration: circle, t: 0.9 } };

/**
 * Weighted cloud at t = 0.8: both edges to the heavy point are present
 * (they entered at 0.658 and 0.766) but the light–light edge is not (0.89).
 * Weights change which simplices come first — this is the point of the
 * weighted filtration.
 */
export const WeightedHeavyEdgesFirst: Story = { args: { filtration: weighted, t: 0.8 } };

/** Overlaying the nerve on the field shows the Nerve theorem as a picture. */
export const OverField: Story = {
  args: { filtration: weighted, t: 0.8 },
  render: (args) => (
    <div style={{ position: 'relative', width: 320 }}>
      {/* <Field2D> takes a ball filtration; this composition is fixed to the
          weighted alpha fixture, so pass it directly rather than widening. */}
      <Field2D filtration={weighted} t={args.t} />
      <div style={{ position: 'absolute', top: 0, left: 0 }}>
        <Nerve2D {...args} />
      </div>
    </div>
  ),
};

/**
 * Rips carries a permanent caveat on the drawing: it is the flag complex of
 * the 1-skeleton, so its triangle here states "all three edges exist", NOT
 * "the three balls share a point".
 */
export const RipsIsNotANerve: Story = { args: { filtration: rips, t: 1.0 } };

/** Čech IS the nerve; no caveat is drawn because none is needed. */
export const CechIsTheNerve: Story = { args: { filtration: cech, t: 0.6 } };

/**
 * The highlight channel used by the rips-vs-čech acceptance story: mark a
 * triangle (here the Rips triangle at t = 1, whose balls of radius t/2 = 0.5
 * share no common point until radius ≈ 0.577).
 */
export const HighlightedTriangle: Story = {
  args: { filtration: rips, t: 1.0, highlightTriangles: [[0, 1, 2]] },
};

// ── Vertices that are not points (SPEC.md §3.1) ──────────────────────────

const kfold2 = recordedFiltration(JITTERED8_KFOLD2);
const kfold1 = recordedFiltration(JITTERED8_KFOLD1);

const withChip: Story['render'] = (args) => (
  <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
    <Nerve2D {...args} />
    <GuaranteeChip filtration={args.filtration} />
  </div>
);

/**
 * The order-2 mosaic of 8 jittered lattice points, seen from above. Its 22
 * vertices are 2-SUBSETS of the input, each drawn as a hollow diamond at its
 * pair's barycentre — a glyph nothing else on the canvas uses, because a vertex
 * standing for a set of points is not one of the points. Hover a diamond to see
 * which members it stands for.
 */
export const KFoldSubsetVertices: Story = {
  args: { filtration: kfold2, t: 0.6 },
  render: withChip,
};

/** The same mosaic later: more of the complex, same 22 vertices. */
export const KFoldSubsetVerticesGrown: Story = {
  args: { filtration: kfold2, t: 1.2 },
  render: withChip,
};

/**
 * k = 1: every subset is a singleton, so the diamonds land on the input points
 * and the filtration reproduces the alpha complex. Comparing this with the k = 2
 * story above is the point — the vertices moved because the vertices ARE
 * different objects, not because the drawing changed its mind.
 */
export const KFoldK1IsAlpha: Story = {
  args: { filtration: kfold1, t: 0.6 },
  render: withChip,
};

/**
 * A complex whose SHAPES cannot be drawn is still fully drawable as a complex:
 * this is the wing filtration built from an estimated neighbourhood, where
 * `<Field2D>` shows nothing but the reason. The flag caveat is on the drawing,
 * in the filtration's own words.
 */
export const WingComplexWithoutItsShapes: Story = {
  args: { filtration: recordedFiltration(CIRCLE12_WING_ESTIMATED_NORMALS), t: 0.5 },
  render: withChip,
};
