// <Nerve2D>: the simplices the cover induces at scale t (SPEC.md §4.1), drawn
// at vertexPosition(v) — which is NOT cloud.points when a vertex is a subset.
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  CIRCLE12_WING,
  JITTERED8_KFOLD1,
  JITTERED8_KFOLD2,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { Nerve2D } from '../Nerve2D';
import { projectCloud } from '../project';

const cech = recordedFiltration(TRIANGLE_CECH);
const rips = recordedFiltration(TRIANGLE_RIPS);
const weighted = recordedFiltration(WEIGHTED3_ALPHA);
const kfold2 = recordedFiltration(JITTERED8_KFOLD2);

describe('<Nerve2D> draws exactly the simplices present at t', () => {
  it('shows nothing above t (Čech triangle enters at its circumradius 0.57735)', () => {
    render(<Nerve2D filtration={cech} t={0.5} />);
    const svg = screen.getByTestId('nerve-2d');
    expect(svg).toHaveAttribute('data-edge-count', '3');
    expect(svg).toHaveAttribute('data-triangle-count', '0');
  });

  it('adds the triangle exactly at its filtration value', () => {
    render(<Nerve2D filtration={cech} t={0.57735} />);
    const svg = screen.getByTestId('nerve-2d');
    expect(svg).toHaveAttribute('data-triangle-count', '1');
  });

  it('weighted alpha: heavy-point edges are present before the light-light edge', () => {
    // Edges [0,2] and [0,1] enter at 0.657556 / 0.765625; edge [1,2] at 0.89.
    render(<Nerve2D filtration={weighted} t={0.8} />);
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-edge-count', '2');
  });

  it('respects showEdges / showTriangles toggles without deleting counts', () => {
    render(<Nerve2D filtration={cech} t={1} showTriangles={false} />);
    expect(screen.queryAllByTestId('nerve-triangle')).toHaveLength(0);
    expect(screen.getAllByTestId('nerve-edge')).toHaveLength(3);
  });
});

describe('<Nerve2D> honesty labels (SPEC.md §1.4)', () => {
  it('carries the caveat on a Rips complex, in the filtration\u2019s own words', () => {
    render(<Nerve2D filtration={rips} t={1} />);
    const label = screen.getByTestId('nerve-2d-flag-label').textContent ?? '';
    expect(label).toContain(rips.guarantee.label);
    expect(label).toMatch(/not that they share a point/);
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-guarantee', 'flag');
  });

  it('carries it on every flag complex, not just Rips (the wing complex)', () => {
    render(<Nerve2D filtration={recordedFiltration(CIRCLE12_WING)} t={0.5} />);
    expect(screen.getByTestId('nerve-2d-flag-label').textContent).toContain(
      'flag complex (Rips-type)',
    );
  });

  it('does not put the caveat on an actual nerve (Čech)', () => {
    render(<Nerve2D filtration={cech} t={1} />);
    expect(screen.queryByTestId('nerve-2d-flag-label')).not.toBeInTheDocument();
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-guarantee', 'nerve');
  });
});

describe('<Nerve2D> subset vertices (SPEC.md §3.1: two index spaces)', () => {
  it('places a k-fold vertex at its subset\u2019s barycentre, not at a point', () => {
    render(<Nerve2D filtration={kfold2} t={1.2} width={320} height={320} padding={16} />);
    const { px, py } = projectCloud(kfold2.cloud.points, 3, 320, 320, 16);
    const glyphs = screen.getAllByTestId('nerve-subset-vertex');
    // More vertices than input points: the fact a renderer reading
    // cloud.points would silently get wrong.
    expect(kfold2.vertexCount).toBeGreaterThan(8);
    expect(glyphs.length).toBeGreaterThan(8);

    // Every drawn diamond sits on the barycentre of the subset it names.
    for (const glyph of glyphs) {
      const members = (glyph.getAttribute('data-subset') ?? '').split(',').map(Number);
      const d = glyph.getAttribute('d') ?? '';
      const [, xs, ys] = /^M(-?[\d.]+) (-?[\d.]+)/.exec(d)!;
      let bx = 0;
      let by = 0;
      for (const i of members) {
        bx += kfold2.cloud.points[i * 3];
        by += kfold2.cloud.points[i * 3 + 1];
      }
      bx /= members.length;
      by /= members.length;
      expect(+xs).toBeCloseTo(px(bx), 6);
      // The M command of the diamond is 4px above the centre.
      expect(+ys + 4).toBeCloseTo(py(by), 6);
    }
  });

  it('names the members of each subset for a reader, not just for a test', () => {
    render(<Nerve2D filtration={kfold2} t={1.2} />);
    const glyph = screen.getAllByTestId('nerve-subset-vertex')[0];
    const members = glyph.getAttribute('data-subset')!;
    expect(members.split(',')).toHaveLength(2);
    expect(glyph.querySelector('title')?.textContent).toMatch(/barycentre of input points/);
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-vertex-kind', 'subset');
  });

  it('says on the drawing that the diamonds are subsets, with both counts', () => {
    render(<Nerve2D filtration={kfold2} t={1.2} />);
    const text = screen.getByTestId('nerve-2d-subset-label').textContent ?? '';
    expect(text).toMatch(/subset of the input, drawn at its barycentre/);
    expect(text).toContain(`${kfold2.vertexCount} vertices`);
    expect(text).toContain('8 points');
  });

  it('at k = 1 every subset is a singleton, so vertices ARE the points', () => {
    const kfold1 = recordedFiltration(JITTERED8_KFOLD1);
    render(<Nerve2D filtration={kfold1} t={1.2} width={320} height={320} padding={16} />);
    const { px } = projectCloud(kfold1.cloud.points, 3, 320, 320, 16);
    expect(kfold1.vertexCount).toBe(8);
    for (const glyph of screen.getAllByTestId('nerve-subset-vertex')) {
      const members = (glyph.getAttribute('data-subset') ?? '').split(',').map(Number);
      expect(members).toHaveLength(1);
      const [, xs] = /^M(-?[\d.]+) /.exec(glyph.getAttribute('d') ?? '')!;
      expect(+xs).toBeCloseTo(px(kfold1.cloud.points[members[0] * 3]), 6);
    }
  });

  it('draws no vertex markers for a point-vertex filtration unless asked', () => {
    const { rerender } = render(<Nerve2D filtration={cech} t={1} />);
    expect(screen.queryAllByTestId('nerve-vertex')).toHaveLength(0);
    expect(screen.queryByTestId('nerve-2d-subset-label')).not.toBeInTheDocument();
    rerender(<Nerve2D filtration={cech} t={1} showVertices />);
    expect(screen.getAllByTestId('nerve-vertex')).toHaveLength(3);
    // A point vertex is a dot, never the subset diamond.
    expect(screen.queryAllByTestId('nerve-subset-vertex')).toHaveLength(0);
  });
});

describe('<Nerve2D> highlighting (for the rips-vs-cech comparison, SPEC.md §7 story 3)', () => {
  it('marks listed triangles with data-highlight', () => {
    render(<Nerve2D filtration={rips} t={1.2} highlightTriangles={[[0, 1, 2]]} />);
    const triangles = screen.getAllByTestId('nerve-triangle');
    expect(triangles).toHaveLength(1);
    expect(triangles[0]).toHaveAttribute('data-highlight', 'true');
  });

  it('matches triples regardless of vertex order', () => {
    render(<Nerve2D filtration={rips} t={1.2} highlightTriangles={[[2, 0, 1]]} />);
    expect(screen.getAllByTestId('nerve-triangle')[0]).toHaveAttribute('data-highlight', 'true');
  });

  it('leaves unlisted triangles unmarked', () => {
    render(<Nerve2D filtration={rips} t={1.2} highlightTriangles={[[0, 1, 3]]} />);
    expect(screen.getAllByTestId('nerve-triangle')[0]).not.toHaveAttribute('data-highlight');
  });
});

describe('<Nerve2D> chrome', () => {
  it('passes className through (v1 SVG convention)', () => {
    render(<Nerve2D filtration={cech} t={1} className="my-nerve" />);
    expect(screen.getByTestId('nerve-2d')).toHaveClass('my-nerve');
  });
});
