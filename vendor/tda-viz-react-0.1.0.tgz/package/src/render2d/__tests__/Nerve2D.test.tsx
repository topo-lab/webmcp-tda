// <Nerve2D>: the simplices the cover induces at scale t (SPEC.md §4.1), drawn
// at vertexPosition(v) — which is NOT cloud.points when a vertex is a subset.
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  CIRCLE12_WING,
  CIRCLE24_ALPHA,
  JITTERED8_KFOLD1,
  JITTERED8_KFOLD2,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { Nerve2D } from '../Nerve2D';
import { projectCloud } from '../project';

const cech = recordedFiltration(TRIANGLE_CECH);
const rips = recordedFiltration(TRIANGLE_RIPS);
const weighted = recordedFiltration(WEIGHTED3_ALPHA);
const kfold2 = recordedFiltration(JITTERED8_KFOLD2);

describe('<Nerve2D> draws exactly the simplices present at t', () => {
  it('shows nothing above t (Čech triangle enters at its circumradius 0.57735)', () => {
    render(<Nerve2D filtration={cech} t={0.5} />);
    const svg = screen.getByTestId('nerve-2d');
    expect(svg).toHaveAttribute('data-edge-count', '3');
    expect(svg).toHaveAttribute('data-triangle-count', '0');
  });

  it('adds the triangle exactly at its filtration value', () => {
    render(<Nerve2D filtration={cech} t={0.57735} />);
    const svg = screen.getByTestId('nerve-2d');
    expect(svg).toHaveAttribute('data-triangle-count', '1');
  });

  it('weighted alpha: heavy-point edges are present before the light-light edge', () => {
    // Edges [0,2] and [0,1] enter at 0.657556 / 0.765625; edge [1,2] at 0.89.
    render(<Nerve2D filtration={weighted} t={0.8} />);
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-edge-count', '2');
  });

  it('respects showEdges / showTriangles toggles without deleting counts', () => {
    render(<Nerve2D filtration={cech} t={1} showTriangles={false} />);
    expect(screen.queryAllByTestId('nerve-triangle')).toHaveLength(0);
    // Every edge at t is one subpath of ONE merged path element (see below),
    // so the DOM element count is 1 regardless of how many edges are drawn —
    // the count that must survive is the logical one, `data-edge-count`.
    expect(screen.getAllByTestId('nerve-edge')).toHaveLength(1);
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-edge-count', '3');
  });
});

describe('<Nerve2D> merges simplices into one path per layer (SPEC.md §4.1)', () => {
  it('CANONICAL REGRESSION: N triangles present at t render as ONE <path>, not N', () => {
    const circle = recordedFiltration(CIRCLE24_ALPHA);
    render(<Nerve2D filtration={circle} t={1} />);
    const svg = screen.getByTestId('nerve-2d');
    const triangleCount = Number(svg.getAttribute('data-triangle-count'));
    // Sanity: this fixture really does have more than one triangle at t — the
    // regression is meaningless against a complex with only one.
    expect(triangleCount).toBeGreaterThan(1);

    const triangleEls = screen.getAllByTestId('nerve-triangle');
    expect(triangleEls).toHaveLength(1);
    expect(triangleEls[0].tagName.toLowerCase()).toBe('path');
    expect(triangleEls[0]).toHaveAttribute('fill-rule', 'nonzero');

    // Same for edges: however many, ONE element.
    const edgeCount = Number(svg.getAttribute('data-edge-count'));
    expect(edgeCount).toBeGreaterThan(1);
    const edgeEls = screen.getAllByTestId('nerve-edge');
    expect(edgeEls).toHaveLength(1);
    expect(edgeEls[0].tagName.toLowerCase()).toBe('path');
  });

  it('the merged triangle path draws exactly the geometry the old per-triangle polygon did', () => {
    const width = 320;
    const height = 320;
    const padding = 16;
    render(<Nerve2D filtration={rips} t={1.2} width={width} height={height} padding={padding} />);

    const { px, py } = projectCloud(rips.cloud.points, 2, width, height, padding);
    const triangle = rips.simplicesAt(1.2).find((s) => s.vertices.length === 3)!;
    const [a, b, c] = triangle.vertices;
    // Exactly the path a `<polygon points="…">` at the same three vertices
    // would have covered: same coordinates, same vertex order, closed.
    const expected =
      `M${px(rips.cloud.points[a * 2])} ${py(rips.cloud.points[a * 2 + 1])}` +
      `L${px(rips.cloud.points[b * 2])} ${py(rips.cloud.points[b * 2 + 1])}` +
      `L${px(rips.cloud.points[c * 2])} ${py(rips.cloud.points[c * 2 + 1])}Z`;
    expect(screen.getByTestId('nerve-triangle').getAttribute('d')).toBe(expected);
  });

  it('renders no triangle/edge path element when nothing is present at t', () => {
    render(<Nerve2D filtration={cech} t={0} />);
    expect(screen.queryAllByTestId('nerve-triangle')).toHaveLength(0);
    expect(screen.queryAllByTestId('nerve-edge')).toHaveLength(0);
  });
});

describe('<Nerve2D> honesty labels (SPEC.md §1.4)', () => {
  it('carries the caveat on a Rips complex, in the filtration\u2019s own words', () => {
    render(<Nerve2D filtration={rips} t={1} />);
    const label = screen.getByTestId('nerve-2d-flag-label').textContent ?? '';
    expect(label).toContain(rips.guarantee.label);
    expect(label).toMatch(/not that they share a point/);
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-guarantee', 'flag');
  });

  it('carries it on every flag complex, not just Rips (the wing complex)', () => {
    render(<Nerve2D filtration={recordedFiltration(CIRCLE12_WING)} t={0.5} />);
    expect(screen.getByTestId('nerve-2d-flag-label').textContent).toContain(
      'flag complex (Rips-type)',
    );
  });

  it('does not put the caveat on an actual nerve (Čech)', () => {
    render(<Nerve2D filtration={cech} t={1} />);
    expect(screen.queryByTestId('nerve-2d-flag-label')).not.toBeInTheDocument();
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-guarantee', 'nerve');
  });
});

describe('<Nerve2D> subset vertices (SPEC.md §3.1: two index spaces)', () => {
  it('places a k-fold vertex at its subset\u2019s barycentre, not at a point', () => {
    render(<Nerve2D filtration={kfold2} t={1.2} width={320} height={320} padding={16} />);
    const { px, py } = projectCloud(kfold2.cloud.points, 3, 320, 320, 16);
    const glyphs = screen.getAllByTestId('nerve-subset-vertex');
    // More vertices than input points: the fact a renderer reading
    // cloud.points would silently get wrong.
    expect(kfold2.vertexCount).toBeGreaterThan(8);
    expect(glyphs.length).toBeGreaterThan(8);

    // Every drawn diamond sits on the barycentre of the subset it names.
    for (const glyph of glyphs) {
      const members = (glyph.getAttribute('data-subset') ?? '').split(',').map(Number);
      const d = glyph.getAttribute('d') ?? '';
      const [, xs, ys] = /^M(-?[\d.]+) (-?[\d.]+)/.exec(d)!;
      let bx = 0;
      let by = 0;
      for (const i of members) {
        bx += kfold2.cloud.points[i * 3];
        by += kfold2.cloud.points[i * 3 + 1];
      }
      bx /= members.length;
      by /= members.length;
      expect(+xs).toBeCloseTo(px(bx), 6);
      // The M command of the diamond is 4px above the centre.
      expect(+ys + 4).toBeCloseTo(py(by), 6);
    }
  });

  it('names the members of each subset for a reader, not just for a test', () => {
    render(<Nerve2D filtration={kfold2} t={1.2} />);
    const glyph = screen.getAllByTestId('nerve-subset-vertex')[0];
    const members = glyph.getAttribute('data-subset')!;
    expect(members.split(',')).toHaveLength(2);
    expect(glyph.querySelector('title')?.textContent).toMatch(/barycentre of input points/);
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-vertex-kind', 'subset');
  });

  it('says on the drawing that the diamonds are subsets, with both counts', () => {
    render(<Nerve2D filtration={kfold2} t={1.2} />);
    const text = screen.getByTestId('nerve-2d-subset-label').textContent ?? '';
    expect(text).toMatch(/subset of the input, drawn at its barycentre/);
    expect(text).toContain(`${kfold2.vertexCount} vertices`);
    expect(text).toContain('8 points');
  });

  it('at k = 1 every subset is a singleton, so vertices ARE the points', () => {
    const kfold1 = recordedFiltration(JITTERED8_KFOLD1);
    render(<Nerve2D filtration={kfold1} t={1.2} width={320} height={320} padding={16} />);
    const { px } = projectCloud(kfold1.cloud.points, 3, 320, 320, 16);
    expect(kfold1.vertexCount).toBe(8);
    for (const glyph of screen.getAllByTestId('nerve-subset-vertex')) {
      const members = (glyph.getAttribute('data-subset') ?? '').split(',').map(Number);
      expect(members).toHaveLength(1);
      const [, xs] = /^M(-?[\d.]+) /.exec(glyph.getAttribute('d') ?? '')!;
      expect(+xs).toBeCloseTo(px(kfold1.cloud.points[members[0] * 3]), 6);
    }
  });

  it('draws no vertex markers for a point-vertex filtration unless asked', () => {
    const { rerender } = render(<Nerve2D filtration={cech} t={1} />);
    expect(screen.queryAllByTestId('nerve-vertex')).toHaveLength(0);
    expect(screen.queryByTestId('nerve-2d-subset-label')).not.toBeInTheDocument();
    rerender(<Nerve2D filtration={cech} t={1} showVertices />);
    expect(screen.getAllByTestId('nerve-vertex')).toHaveLength(3);
    // A point vertex is a dot, never the subset diamond.
    expect(screen.queryAllByTestId('nerve-subset-vertex')).toHaveLength(0);
  });
});

describe('<Nerve2D> highlighting (for the rips-vs-cech comparison, SPEC.md §7 story 3)', () => {
  it('marks listed triangles with data-highlight', () => {
    render(<Nerve2D filtration={rips} t={1.2} highlightTriangles={[[0, 1, 2]]} />);
    const triangles = screen.getAllByTestId('nerve-triangle');
    expect(triangles).toHaveLength(1);
    expect(triangles[0]).toHaveAttribute('data-highlight', 'true');
  });

  it('matches triples regardless of vertex order', () => {
    render(<Nerve2D filtration={rips} t={1.2} highlightTriangles={[[2, 0, 1]]} />);
    expect(screen.getAllByTestId('nerve-triangle')[0]).toHaveAttribute('data-highlight', 'true');
  });

  it('leaves unlisted triangles unmarked', () => {
    render(<Nerve2D filtration={rips} t={1.2} highlightTriangles={[[0, 1, 3]]} />);
    expect(screen.getAllByTestId('nerve-triangle')[0]).not.toHaveAttribute('data-highlight');
  });
});

describe('<Nerve2D> chrome', () => {
  it('passes className through (v1 SVG convention)', () => {
    render(<Nerve2D filtration={cech} t={1} className="my-nerve" />);
    expect(screen.getByTestId('nerve-2d')).toHaveClass('my-nerve');
  });
});

describe('<Nerve2D> ink weight: the caller sets it, not a stylesheet', () => {
  // These existed as CSS overrides on the consuming site, which works only
  // because a presentation attribute loses to a rule — a fragile way to set
  // geometry the component owns. Every default below is the value the
  // component drew at before they were props.
  it('BACKWARDS COMPATIBLE: edges default to 1px at 0.65, faces to 0.28', () => {
    render(<Nerve2D filtration={cech} t={1} />);
    const edge = screen.getAllByTestId('nerve-edge')[0];
    expect(edge).toHaveAttribute('stroke-width', '1');
    expect(edge).toHaveAttribute('stroke-opacity', '0.65');
    expect(screen.getAllByTestId('nerve-triangle')[0]).toHaveAttribute('fill-opacity', '0.28');
  });

  it('takes a hairline edge weight and an opacity of 1 for a colour carrying its own alpha', () => {
    render(<Nerve2D filtration={cech} t={1} edgeWidth={0.6} edgeOpacity={1} triangleOpacity={1} />);
    const edge = screen.getAllByTestId('nerve-edge')[0];
    expect(edge).toHaveAttribute('stroke-width', '0.6');
    expect(edge).toHaveAttribute('stroke-opacity', '1');
    expect(screen.getAllByTestId('nerve-triangle')[0]).toHaveAttribute('fill-opacity', '1');
  });
});

describe('<Nerve2D> point vertices: the disc, and the halo that lifts it off the ink', () => {
  it('BACKWARDS COMPATIBLE: r = 2 at 0.8, and no halo', () => {
    render(<Nerve2D filtration={cech} t={1} showVertices />);
    const dot = screen.getAllByTestId('nerve-vertex')[0];
    expect(dot).toHaveAttribute('r', '2');
    expect(dot).toHaveAttribute('fill-opacity', '0.8');
    expect(dot).toHaveAttribute('stroke', 'none');
    expect(dot).toHaveAttribute('stroke-width', '0');
    expect(dot).not.toHaveAttribute('paint-order');
  });

  it('takes a radius and a solid fill, because a point is data', () => {
    render(<Nerve2D filtration={cech} t={1} showVertices vertexRadius={1.3} vertexOpacity={1} />);
    const dot = screen.getAllByTestId('nerve-vertex')[0];
    expect(dot).toHaveAttribute('r', '1.3');
    expect(dot).toHaveAttribute('fill-opacity', '1');
  });

  it('paints the halo UNDER the fill, so the ring is outside the disc', () => {
    render(<Nerve2D filtration={cech} t={1} showVertices vertexHaloColor="#eaeef5" />);
    const dot = screen.getAllByTestId('nerve-vertex')[0];
    expect(dot).toHaveAttribute('stroke', '#eaeef5');
    expect(dot).toHaveAttribute('stroke-width', '1.2');
    expect(dot).toHaveAttribute('paint-order', 'stroke');
  });

  it('takes the halo width from a prop', () => {
    render(
      <Nerve2D
        filtration={cech}
        t={1}
        showVertices
        vertexHaloColor="#eaeef5"
        vertexHaloWidth={2}
      />,
    );
    expect(screen.getAllByTestId('nerve-vertex')[0]).toHaveAttribute('stroke-width', '2');
  });

  it('leaves a subset vertex alone: a diamond is hollow, and a halo would fill it', () => {
    render(<Nerve2D filtration={kfold2} t={1} vertexHaloColor="#eaeef5" />);
    const diamonds = screen.getAllByTestId('nerve-subset-vertex');
    expect(diamonds.length).toBeGreaterThan(0);
    expect(diamonds[0]).toHaveAttribute('fill', 'none');
  });
});

describe('<Nerve2D> the notes it sets inside its own drawing', () => {
  // A flag complex says so ON the picture, because a picture that does not is
  // the decorative-guarantee failure the guarantee table exists to prevent.
  it('BACKWARDS COMPATIBLE: a flag complex carries its guarantee sentence', () => {
    render(<Nerve2D filtration={rips} t={1.2} />);
    expect(screen.getByTestId('nerve-2d-flag-label').textContent).toContain(
      'meet pairwise, not that they share a point',
    );
  });

  it('a nerve carries no such sentence — there is nothing to warn about', () => {
    render(<Nerve2D filtration={cech} t={1} />);
    expect(screen.queryByTestId('nerve-2d-flag-label')).toBeNull();
  });

  it('labels subset vertices by default, because nothing else is at a barycentre', () => {
    render(<Nerve2D filtration={kfold2} t={1} />);
    expect(screen.getByTestId('nerve-2d-subset-label')).toBeInTheDocument();
  });

  it('showNotes={false} withholds BOTH, for a caller that states the guarantee itself', () => {
    // The site's plane stage does: its caption line under the stage reads
    // filtration.guarantee.label verbatim, so the in-SVG copy is a duplicate
    // that also collides with the stage's readout.
    render(<Nerve2D filtration={rips} t={1.2} showNotes={false} />);
    expect(screen.queryByTestId('nerve-2d-flag-label')).toBeNull();
    render(<Nerve2D filtration={kfold2} t={1} showNotes={false} />);
    expect(screen.queryByTestId('nerve-2d-subset-label')).toBeNull();
  });

  it('withholds the NOTE and nothing else: the guarantee is still on the element', () => {
    // The machine-readable claim is not a note and is never suppressible.
    render(<Nerve2D filtration={rips} t={1.2} showNotes={false} />);
    expect(screen.getByTestId('nerve-2d')).toHaveAttribute('data-guarantee', 'flag');
  });
});
