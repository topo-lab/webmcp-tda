// <Field2D>: X_t itself — the union of the GROWING SHAPES as ONE merged region
// (SPEC.md §4.1). The shape is whatever shapeAt(i, t) returns: discs,
// ellipses, wing hexagons, boxes. The drawing is a single SVG path, so these
// tests read its path data — the geometry on screen, not a mock's call log.
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  CIRCLE12_WING,
  CIRCLE12_WING_ESTIMATED_NORMALS,
  ELLIPSE_ELLIPSOID_RIPS,
  RING6_BOX,
  SPIRAL16_ELLIPSOID_RIPS_3D,
  TETRA4_ALPHA,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { Field2D } from '../Field2D';
import { projectCloud } from '../project';

const NUM = String.raw`-?\d+(?:\.\d+)?`;
const r2 = (v: number) => Math.round(v * 100) / 100;

/** The one merged path's data, or '' when nothing is drawn. */
const pathData = () => screen.queryByTestId('field-2d-union')?.getAttribute('d') ?? '';

/** One subpath per shape; every subpath is closed with Z. */
const subpaths = (d = pathData()) =>
  d
    .split('Z')
    .filter((s) => s.length > 0)
    .map((s) => `${s}Z`);

/** Arc subpath (disc or ellipse): the leading M and the first A parameters. */
function arcOf(sub: string) {
  const m = new RegExp(`^M(${NUM}) (${NUM})A(${NUM}) (${NUM}) (${NUM})`).exec(sub);
  if (!m) throw new Error(`not an arc subpath: ${sub}`);
  return { x0: +m[1], y0: +m[2], rx: +m[3], ry: +m[4], rotation: +m[5] };
}

/** Polygon subpath (wing, box): its vertices in path order. */
function polygonOf(sub: string): [number, number][] {
  return [...sub.matchAll(new RegExp(`[ML](${NUM}) (${NUM})`, 'g'))].map((m) => [+m[1], +m[2]]);
}

const projectionOf = (rec: { cloud: { points: number[]; dimension: 2 | 3 } }) =>
  projectCloud(rec.cloud.points, rec.cloud.dimension, 320, 320, 16);

const weighted = recordedFiltration(WEIGHTED3_ALPHA);

describe('<Field2D> balls: per-point radii (the single fact v1 got wrong)', () => {
  it('at t=0 draws ONLY the heavy ball, at radius sqrt(0.5) in data units', () => {
    render(<Field2D filtration={weighted} t={0} />);
    const { pxPerUnit } = projectionOf(WEIGHTED3_ALPHA);
    const subs = subpaths();
    expect(subs).toHaveLength(1); // light points have radius 0: no ball yet
    expect(arcOf(subs[0]).rx).toBeCloseTo(r2(Math.sqrt(0.5) * pxPerUnit), 2);
  });

  it('at t=0.5 draws all three balls with DIFFERENT per-point radii', () => {
    render(<Field2D filtration={weighted} t={0.5} />);
    const { pxPerUnit } = projectionOf(WEIGHTED3_ALPHA);
    const radii = subpaths()
      .map((s) => arcOf(s).rx)
      .sort((a, b) => a - b);
    expect(radii).toHaveLength(3);
    expect(radii[0]).toBeCloseTo(r2(Math.sqrt(0.5) * pxPerUnit), 2);
    expect(radii[1]).toBeCloseTo(r2(Math.sqrt(0.5) * pxPerUnit), 2);
    expect(radii[2]).toBeCloseTo(r2(1 * pxPerUnit), 2);
  });

  it('is monotone in t: no shape ever shrinks (SPEC.md §1.1)', () => {
    const { rerender } = render(<Field2D filtration={weighted} t={0.2} />);
    const before = subpaths().map((s) => arcOf(s).rx);
    rerender(<Field2D filtration={weighted} t={0.6} />);
    const after = subpaths().map((s) => arcOf(s).rx);
    expect(after.length).toBeGreaterThanOrEqual(before.length);
    for (const r of before) expect(Math.max(...after)).toBeGreaterThanOrEqual(r);
  });

  it('draws a 3D ball cloud as its silhouette: a disc of the same radius', () => {
    render(<Field2D filtration={recordedFiltration(TETRA4_ALPHA)} t={0.5} />);
    const { pxPerUnit } = projectionOf(TETRA4_ALPHA);
    expect(subpaths()).toHaveLength(4);
    expect(arcOf(subpaths()[0]).rx).toBeCloseTo(r2(Math.sqrt(0.5) * pxPerUnit), 2);
  });
});

describe('<Field2D> union rendering (SPEC.md §4.1: one merged region)', () => {
  it('accumulates every shape into ONE path, filled once, nonzero winding', () => {
    render(<Field2D filtration={weighted} t={0.5} />);
    const paths = screen.getByTestId('field-2d').querySelectorAll('path');
    expect(paths).toHaveLength(1);
    // Even-odd would punch a hole out of every overlap — the exact regions the
    // complex is about.
    expect(paths[0].getAttribute('fill-rule')).toBe('nonzero');
    expect(paths[0].getAttribute('fill-opacity')).toBe('0.28');
  });

  it('gives every polygon subpath the same handedness as the arcs', () => {
    // Mixed handedness cancels under nonzero winding, so this is the property
    // the merged path rests on. Signed area < 0 for every wing hexagon.
    render(<Field2D filtration={recordedFiltration(CIRCLE12_WING)} t={0.6} />);
    for (const sub of subpaths()) {
      const pts = polygonOf(sub);
      let area = 0;
      for (let i = 0; i < pts.length; i++) {
        const [x0, y0] = pts[i];
        const [x1, y1] = pts[(i + 1) % pts.length];
        area += x0 * y1 - x1 * y0;
      }
      expect(area).toBeLessThan(0);
    }
  });

  it('draws nothing at all before any shape exists', () => {
    render(<Field2D filtration={weighted} t={-1} />);
    expect(screen.queryByTestId('field-2d-union')).toBeNull();
  });
});

describe('<Field2D> ellipses (SPEC.md §1.3: semi-axes (t/2)·profile on a FIXED frame)', () => {
  const rec = ELLIPSE_ELLIPSOID_RIPS;
  const ellipsoid = recordedFiltration(rec);

  it.each([0.8, 1.6])('at t=%s the semi-axes are (t/2)·profile in pixels', (t) => {
    render(<Field2D filtration={ellipsoid} t={t} />);
    const { pxPerUnit } = projectionOf(rec);
    const subs = subpaths();
    expect(subs).toHaveLength(rec.ellipsoid.geometry.length);
    subs.forEach((sub, i) => {
      const g = rec.ellipsoid.geometry[i];
      const { rx, ry } = arcOf(sub);
      expect(rx).toBeCloseTo(r2((t / 2) * g.semiAxes[0] * pxPerUnit), 2);
      expect(ry).toBeCloseTo(r2((t / 2) * g.semiAxes[1] * pxPerUnit), 2);
    });
  });

  it('doubles the semi-axes when t doubles, and keeps the frame fixed', () => {
    const { rerender } = render(<Field2D filtration={ellipsoid} t={0.8} />);
    const small = subpaths().map(arcOf);
    rerender(<Field2D filtration={ellipsoid} t={1.6} />);
    const big = subpaths().map(arcOf);
    small.forEach((s, i) => {
      expect(big[i].rx).toBeCloseTo(2 * s.rx, 1);
      expect(big[i].ry).toBeCloseTo(2 * s.ry, 1);
      // Monotone only BECAUSE the frame does not move with t (SPEC.md §1.1).
      expect(big[i].rotation).toBe(s.rotation);
    });
  });

  it('orients each ellipse by its fitted frame, flipped for screen y', () => {
    render(<Field2D filtration={ellipsoid} t={1.2} />);
    subpaths().forEach((sub, i) => {
      const f0 = rec.ellipsoid.geometry[i].frame[0];
      const expected = r2((-Math.atan2(f0[1], f0[0]) * 180) / Math.PI);
      expect(arcOf(sub).rotation).toBeCloseTo(expected, 2);
    });
  });

  it('refuses a 3D ellipsoid rather than drawing a central slice', () => {
    render(<Field2D filtration={recordedFiltration(SPIRAL16_ELLIPSOID_RIPS_3D)} t={1.2} />);
    expect(screen.queryByTestId('field-2d-union')).toBeNull();
    expect(screen.getByTestId('field-2d')).toHaveAttribute('data-shapes-drawn', 'false');
    const reason = screen.getByTestId('field-2d-shapes-unavailable').textContent ?? '';
    expect(reason).toMatch(/central slice, not the outline/);
    expect(reason).toMatch(/<Field3D>/);
  });
});

describe('<Field2D> wings (wing_complex.hpp: A, B, C, D, C\u2032, B\u2032)', () => {
  const rec = CIRCLE12_WING;
  const wing = recordedFiltration(rec);

  it('draws one concave hexagon per point, at the engine\u2019s own outline', () => {
    const t = 0.6;
    render(<Field2D filtration={wing} t={t} />);
    const { px, py } = projectionOf(rec);
    const subs = subpaths();
    expect(subs).toHaveLength(12);
    subs.forEach((sub, i) => {
      const drawn = polygonOf(sub);
      expect(drawn).toHaveLength(6);
      // The shape is the filtration's, not this component's: compare against
      // shapeAt's own outline, projected. Handedness normalization may reverse
      // the order, so compare as sets of rounded points.
      const expected = wing
        .shapeAt(i, t)
        .outline.map((p) => `${r2(px(p[0]))},${r2(py(p[1]))}`)
        .sort();
      expect(drawn.map(([x, y]) => `${x},${y}`).sort()).toEqual(expected);
    });
  });

  it('is homothetic about the point: every offset scales linearly with t', () => {
    const { px, py } = projectionOf(rec);
    const cx = px(rec.cloud.points[0]);
    const cy = py(rec.cloud.points[1]);
    const spread = (sub: string) =>
      Math.max(...polygonOf(sub).map(([x, y]) => Math.hypot(x - cx, y - cy)));

    const { rerender } = render(<Field2D filtration={wing} t={0.3} />);
    const small = spread(subpaths()[0]);
    rerender(<Field2D filtration={wing} t={0.6} />);
    expect(spread(subpaths()[0])).toBeCloseTo(2 * small, 1);
  });

  it('draws the wings of an ESTIMATED-normal build too, from the engine\u2019s outline', () => {
    // This build used to draw nothing: the engine estimated its normals from k
    // and returned none. `computeWingGeometry` returns them now, so the hexagons
    // are the builder's own — no re-estimate anywhere in this library.
    const rec = CIRCLE12_WING_ESTIMATED_NORMALS;
    const estimated = recordedFiltration(rec);
    const t = 0.6;
    render(<Field2D filtration={estimated} t={t} />);
    expect(screen.getByTestId('field-2d')).toHaveAttribute('data-shapes-drawn', 'true');
    expect(screen.queryByTestId('field-2d-shapes-unavailable')).toBeNull();

    const { px, py } = projectionOf(rec);
    const subs = subpaths();
    expect(subs).toHaveLength(12);
    subs.forEach((sub, i) => {
      const drawn = polygonOf(sub);
      expect(drawn).toHaveLength(6);
      const expected = rec.wing.geometry[i].outline
        .map((offset) => {
          const x = rec.wing.geometry[i].point[0] + t * offset[0];
          const y = rec.wing.geometry[i].point[1] + t * offset[1];
          return `${r2(px(x))},${r2(py(y))}`;
        })
        .sort();
      expect(drawn.map(([x, y]) => `${x},${y}`).sort()).toEqual(expected);
    });
    expect(estimated.shapeAt(0, t).normalSource).toBe('osculating');
  });
});

describe('<Field2D> boxes (SPEC.md §1.3: a lookup on the grid, never an interpolation)', () => {
  const rec = RING6_BOX;
  const box = recordedFiltration(rec);
  const step = rec.box.stepSize;

  it('draws nothing at step 0: the boxes are still the points', () => {
    render(<Field2D filtration={box} t={0} />);
    expect(screen.queryByTestId('field-2d-union')).toBeNull();
  });

  it('draws the engine\u2019s own box at step 1', () => {
    render(<Field2D filtration={box} t={step} />);
    const { px, py } = projectionOf(rec);
    const extents = rec.box.extents!;
    const subs = subpaths();
    expect(subs).toHaveLength(6);
    subs.forEach((sub, i) => {
      const b = extents[1][i];
      const xs = polygonOf(sub).map(([x]) => x);
      const ys = polygonOf(sub).map(([, y]) => y);
      expect(Math.min(...xs)).toBeCloseTo(r2(px(b.lower[0])), 2);
      expect(Math.max(...xs)).toBeCloseTo(r2(px(b.upper[0])), 2);
      // py flips: the data upper bound is the smaller screen y.
      expect(Math.min(...ys)).toBeCloseTo(r2(py(b.upper[1])), 2);
      expect(Math.max(...ys)).toBeCloseTo(r2(py(b.lower[1])), 2);
    });
  });

  it('between grid values shows the LAST COMPLETED step, unchanged', () => {
    const { rerender } = render(<Field2D filtration={box} t={step} />);
    const onGrid = pathData();
    rerender(<Field2D filtration={box} t={step * 1.6} />);
    // An interpolated box is a shape the filtration never contained.
    expect(pathData()).toBe(onGrid);
    rerender(<Field2D filtration={box} t={step * 2} />);
    expect(pathData()).not.toBe(onGrid);
  });
});

describe('<Field2D> convention display (SPEC.md §1.3: name the shape law you draw)', () => {
  it.each([
    [WEIGHTED3_ALPHA, 'alpha', /√\(t \+ wᵢ\)/],
    [TRIANGLE_RIPS, 'rips', /t\/2/],
    [TRIANGLE_CECH, 'cech', /t is the ball radius/],
    [ELLIPSE_ELLIPSOID_RIPS, 'ellipsoid-2r', /TWICE the ellipsoid radius/],
    [CIRCLE12_WING, 'wing-eps', /spine half-length q·t/],
    [RING6_BOX, 'box-step', /step × π/],
  ])('names the %s# convention on the drawing', (rec, convention, pattern) => {
    render(<Field2D filtration={recordedFiltration(rec)} t={0.5} />);
    expect(screen.getByTestId('field-2d')).toHaveAttribute('data-convention', convention);
    expect(screen.getByTestId('field-2d-convention').textContent).toMatch(pattern);
  });

  it('exposes the shape kind for styling and for tests', () => {
    render(<Field2D filtration={recordedFiltration(RING6_BOX)} t={0.5} />);
    expect(screen.getByTestId('field-2d')).toHaveAttribute('data-shape-kind', 'box');
  });
});

describe('<Field2D> chrome', () => {
  it('passes className through and labels the drawing', () => {
    render(<Field2D filtration={weighted} t={0} className="my-field" aria-label="the space" />);
    expect(screen.getByTestId('field-2d')).toHaveClass('my-field');
    expect(screen.getByRole('img', { name: 'the space' })).toBeInTheDocument();
  });

  it('renders an empty cloud without drawing or crashing (a real state)', () => {
    const empty = recordedFiltration({
      name: 'EMPTY',
      cloud: { points: [], weights: [], dimension: 2 },
      complexType: 'alpha',
      convention: 'alpha',
      maxSimplexDimension: 0,
      simplices: [],
      rawPairs: [],
    });
    render(<Field2D filtration={empty} t={1} />);
    expect(screen.queryByTestId('field-2d-union')).toBeNull();
  });
});
