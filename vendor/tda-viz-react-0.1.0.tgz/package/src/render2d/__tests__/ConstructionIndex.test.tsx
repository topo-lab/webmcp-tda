/**
 * The index is the navigation architecture, so its behaviour is a correctness
 * requirement rather than a nicety: a reader must not be able to reach a
 * construction without passing through its classification, and the keyboard
 * must walk the classification the same way the eye does.
 */
import { fireEvent, render, screen } from '@testing-library/react';
import { useState } from 'react';
import { describe, expect, it, vi } from 'vitest';
import { BAND_HEADING, BAND_RULE, COMPLEX_GUARANTEES } from '../../filtration/guarantees';
import type { FiltrationComplexType } from '../../filtration/types';
import {
  ConstructionIndex,
  constructionTabId,
  type ConstructionIndexEntry,
} from '../ConstructionIndex';

const NAMES: Record<FiltrationComplexType, string> = {
  cech: 'Čech',
  'ellipsoid-cech': 'Ellipsoid–Čech',
  box: 'Box',
  rips: 'Vietoris–Rips',
  'ellipsoid-rips': 'Ellipsoid–Rips',
  wing: 'Wing',
  alpha: 'Alpha',
  kfold: 'k-fold cover',
};

/** The six 2D constructions, banded by the library's own table. */
const SIX: FiltrationComplexType[] = [
  'cech',
  'ellipsoid-cech',
  'box',
  'rips',
  'ellipsoid-rips',
  'wing',
];

function entries(types: FiltrationComplexType[] = SIX): ConstructionIndexEntry[] {
  const counters: Record<string, number> = { nerve: 0, flag: 0 };
  return types.map((id) => {
    const kind = COMPLEX_GUARANTEES[id].kind;
    counters[kind] += 1;
    return {
      id,
      name: NAMES[id],
      kind,
      figure: `${kind === 'nerve' ? 1 : 2}.${counters[kind]}`,
    };
  });
}

function Harness({
  items = entries(),
  initial = 'cech',
  locked = false,
  onSelect,
}: {
  items?: ConstructionIndexEntry[];
  initial?: string;
  locked?: boolean;
  onSelect?: (id: string) => void;
}) {
  const [selected, setSelected] = useState(initial);
  return (
    <>
      <ConstructionIndex
        entries={items}
        selectedId={selected}
        onSelect={(id) => {
          onSelect?.(id);
          setSelected(id);
        }}
        panelId="plate"
        locked={locked}
      />
      <div
        id="plate"
        role="tabpanel"
        aria-labelledby={constructionTabId(selected)}
        data-selected={selected}
      />
    </>
  );
}

const tablists = () => screen.getAllByRole('tablist');
const selected = () => screen.getByRole('tab', { selected: true });
const names = (list: HTMLElement) =>
  Array.from(list.querySelectorAll('[role="tab"]')).map(
    (t) => t.querySelector('.construction-tab-name')?.textContent,
  );

describe('the two-band index', () => {
  it('presents two labelled bands, the nerves first, in the library’s own words', () => {
    render(<Harness />);
    const lists = tablists();
    expect(lists).toHaveLength(2);
    expect(screen.getByText(BAND_HEADING.nerve)).toBeInTheDocument();
    expect(screen.getByText(BAND_HEADING.flag)).toBeInTheDocument();
    expect(screen.getByText(BAND_RULE.nerve)).toBeInTheDocument();
    expect(screen.getByText(BAND_RULE.flag)).toBeInTheDocument();
    expect(lists[0]).toHaveAttribute('aria-labelledby', 'construction-band-nerve');
    expect(lists[1]).toHaveAttribute('aria-labelledby', 'construction-band-flag');
  });

  it('groups every entry by its guarantee kind, never by the order it was given', () => {
    // Given interleaved, the bands still sort them.
    render(
      <Harness
        items={entries(['rips', 'cech', 'wing', 'box', 'ellipsoid-rips', 'ellipsoid-cech'])}
      />,
    );
    const [nerveBand, flagBand] = tablists();
    expect(names(nerveBand)).toEqual(['Čech', 'Box', 'Ellipsoid–Čech']);
    expect(names(flagBand)).toEqual(['Vietoris–Rips', 'Wing', 'Ellipsoid–Rips']);
  });

  it('shows the figure number when given, and nothing where none is', () => {
    render(<Harness />);
    const [nerveBand, flagBand] = tablists();
    const figures = (list: HTMLElement) =>
      Array.from(list.querySelectorAll('.construction-tab-figure')).map((n) => n.textContent);
    expect(figures(nerveBand)).toEqual(['1.1', '1.2', '1.3']);
    expect(figures(flagBand)).toEqual(['2.1', '2.2', '2.3']);
  });

  it('omits the figure and carries an annotation when asked', () => {
    render(
      <Harness
        items={[
          { id: 'rips', name: 'Vietoris–Rips', kind: 'flag', annotation: 'experimental' },
          { id: 'cech', name: 'Čech', kind: 'nerve' },
        ]}
      />,
    );
    expect(document.querySelectorAll('.construction-tab-figure')).toHaveLength(0);
    const rips = screen.getByRole('tab', { name: /Vietoris–Rips/ });
    expect(rips.querySelector('.construction-tab-annotation')?.textContent).toBe('experimental');
  });

  it('selects exactly one construction, and aria-selected says which', () => {
    render(<Harness />);
    expect(screen.getAllByRole('tab', { selected: true })).toHaveLength(1);
    expect(selected()).toHaveAccessibleName(/Čech/);
  });

  it('points every tab at the one panel it drives', () => {
    render(<Harness />);
    const panel = screen.getByRole('tabpanel');
    for (const tab of screen.getAllByRole('tab')) {
      expect(tab).toHaveAttribute('aria-controls', panel.id);
    }
    expect(panel).toHaveAttribute('aria-labelledby', selected().id);
  });

  it('selects on click, and the panel follows', () => {
    const onSelect = vi.fn();
    render(<Harness onSelect={onSelect} />);
    fireEvent.click(screen.getByRole('tab', { name: /Wing/ }));
    expect(onSelect).toHaveBeenCalledWith('wing');
    expect(selected()).toHaveAccessibleName(/Wing/);
    expect(screen.getByRole('tabpanel')).toHaveAttribute('data-selected', 'wing');
  });

  it('moves within a band on the arrow keys, wrapping, and selects as it goes', () => {
    render(<Harness />);
    const cech = screen.getByRole('tab', { name: /^1\.1/ });
    fireEvent.keyDown(cech, { key: 'ArrowDown' });
    expect(selected()).toHaveAccessibleName(/Ellipsoid–Čech/);
    expect(document.activeElement).toHaveAccessibleName(/Ellipsoid–Čech/);

    fireEvent.keyDown(selected(), { key: 'ArrowDown' });
    expect(selected()).toHaveAccessibleName(/Box/);

    // Wraps within the band; it never crosses into PAIRWISE INTERSECTION.
    fireEvent.keyDown(selected(), { key: 'ArrowDown' });
    expect(selected()).toHaveAccessibleName(/^1\.1/);
    expect(selected().closest('[data-band]')).toHaveAttribute('data-band', 'nerve');

    fireEvent.keyDown(selected(), { key: 'ArrowUp' });
    expect(selected()).toHaveAccessibleName(/Box/);
  });

  it('supports Home and End within a band', () => {
    render(<Harness initial="ellipsoid-cech" />);
    fireEvent.keyDown(selected(), { key: 'End' });
    expect(selected()).toHaveAccessibleName(/Box/);
    fireEvent.keyDown(selected(), { key: 'Home' });
    expect(selected()).toHaveAccessibleName(/^1\.1/);
  });

  it('exposes ONE tab stop per band, so Tab moves between classes', () => {
    render(<Harness />);
    const stops = (list: HTMLElement) =>
      Array.from(list.querySelectorAll('[role="tab"]')).filter(
        (tab) => tab.getAttribute('tabindex') === '0',
      );
    const perBand = tablists().map(stops);
    expect(perBand.map((tabs) => tabs.length)).toEqual([1, 1]);
    expect(perBand[0][0]).toHaveAccessibleName(/Čech/);
    expect(perBand[1][0]).toHaveAccessibleName(/Vietoris–Rips/);

    fireEvent.click(screen.getByRole('tab', { name: /Wing/ }));
    const flagStops = stops(tablists()[1]);
    expect(flagStops).toHaveLength(1);
    expect(flagStops[0]).toHaveAccessibleName(/Wing/);
  });
});

describe('disabled entries', () => {
  const withWingDisabled = () =>
    entries().map((e) => (e.id === 'wing' ? { ...e, disabled: true } : e));

  it('are listed in their band but cannot be selected', () => {
    const onSelect = vi.fn();
    render(<Harness items={withWingDisabled()} onSelect={onSelect} />);
    const wing = screen.getByRole('tab', { name: /Wing/ });
    expect(wing).toBeDisabled();
    expect(wing).toHaveAttribute('aria-disabled', 'true');
    fireEvent.click(wing);
    expect(onSelect).not.toHaveBeenCalled();
    expect(selected()).toHaveAccessibleName(/Čech/);
  });

  it('are skipped by the arrow keys', () => {
    render(<Harness items={withWingDisabled()} initial="ellipsoid-rips" />);
    fireEvent.keyDown(selected(), { key: 'ArrowDown' });
    // Wing is next in the band but disabled, so the wrap lands on Rips.
    expect(selected()).toHaveAccessibleName(/Vietoris–Rips/);
    fireEvent.keyDown(selected(), { key: 'ArrowUp' });
    expect(selected()).toHaveAccessibleName(/Ellipsoid–Rips/);
  });

  it('never become a band’s tab stop', () => {
    const items = entries().map((e) =>
      e.kind === 'flag' && e.id !== 'wing' ? { ...e, disabled: true } : e,
    );
    render(<Harness items={items} />);
    const flagBand = tablists()[1];
    const stops = Array.from(flagBand.querySelectorAll('[role="tab"]')).filter(
      (tab) => tab.getAttribute('tabindex') === '0',
    );
    expect(stops).toHaveLength(1);
    expect(stops[0]).toHaveAccessibleName(/Wing/);
  });

  it('state no reason of their own: the omission is the engine’s rule', () => {
    render(<Harness items={withWingDisabled()} />);
    const wing = screen.getByRole('tab', { name: /Wing/ });
    expect(wing.textContent).toBe('2.3Wing');
    expect(wing).not.toHaveAttribute('title');
  });
});

describe('a locked index', () => {
  it('keeps the classification visible but freezes the selection', () => {
    const onSelect = vi.fn();
    render(<Harness initial="rips" locked onSelect={onSelect} />);
    expect(screen.getByTestId('construction-index')).toHaveAttribute('data-locked', 'true');
    expect(screen.getAllByRole('tablist')).toHaveLength(2);
    expect(selected()).toHaveAccessibleName(/Vietoris–Rips/);

    for (const tab of screen.getAllByRole('tab')) {
      if (tab.getAttribute('aria-selected') === 'true') {
        expect(tab).not.toBeDisabled();
      } else {
        expect(tab).toBeDisabled();
      }
    }

    fireEvent.click(screen.getByRole('tab', { name: /^1\.1/ }));
    fireEvent.keyDown(selected(), { key: 'ArrowDown' });
    expect(onSelect).not.toHaveBeenCalled();
    expect(selected()).toHaveAccessibleName(/Vietoris–Rips/);
  });
});
