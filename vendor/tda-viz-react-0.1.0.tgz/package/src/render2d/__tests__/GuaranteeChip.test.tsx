// <GuaranteeChip>: the honest label as a component (SPEC.md §1.4, §1.6).
// The label text is a QUOTATION (tda-wasm SPEC FR-6) and is asserted character
// for character here, exactly as the filtration layer's own guarantee test
// does — a chip that paraphrases is a chip that can inflate.
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  CIRCLE12_WING,
  CIRCLE24_ALPHA,
  ELLIPSE_ELLIPSOID_CECH,
  ELLIPSE_ELLIPSOID_RIPS,
  JITTERED8_KFOLD2,
  RING6_BOX,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { GuaranteeChip, QUANTIZATION_WARNING } from '../GuaranteeChip';

describe('<GuaranteeChip> renders the library\u2019s wording, verbatim', () => {
  it.each([
    [TRIANGLE_RIPS, 'flag', 'flag complex (Rips-type)'],
    [TRIANGLE_CECH, 'nerve', 'true nerve (Cech)'],
    [CIRCLE24_ALPHA, 'nerve', 'alpha complex (exact combinatorics)'],
    [JITTERED8_KFOLD2, 'nerve', 'exact (order-k Delaunay nerve)'],
    [RING6_BOX, 'nerve', 'nerve (= flag, by Helly for boxes); step-quantized'],
    [CIRCLE12_WING, 'flag', 'flag complex (Rips-type)'],
    [ELLIPSE_ELLIPSOID_RIPS, 'flag', 'flag complex (Rips-type)'],
    [ELLIPSE_ELLIPSOID_CECH, 'nerve', 'true nerve (ellipsoidal Cech)'],
  ])('$0.name: %s', (rec, kind, label) => {
    render(<GuaranteeChip filtration={recordedFiltration(rec)} />);
    expect(screen.getByTestId('guarantee-chip-label').textContent).toBe(label);
    expect(screen.getByTestId('guarantee-chip')).toHaveAttribute('data-guarantee', kind);
  });

  it('never presents a flag complex as an equivalence', () => {
    render(<GuaranteeChip filtration={recordedFiltration(ELLIPSE_ELLIPSOID_RIPS)} />);
    const meaning = screen.getByTestId('guarantee-chip-meaning').textContent ?? '';
    expect(meaning).toMatch(/PAIRWISE/);
    expect(meaning).not.toMatch(/homotopy equivalent/);
  });

  it('states the equivalence for a nerve, which is what a nerve buys', () => {
    render(<GuaranteeChip filtration={recordedFiltration(ELLIPSE_ELLIPSOID_CECH)} />);
    expect(screen.getByTestId('guarantee-chip-meaning').textContent).toMatch(
      /homotopy equivalent to the union of the shapes at every scale/,
    );
  });

  it('omits the meaning line when asked, keeping the verbatim label', () => {
    render(<GuaranteeChip filtration={recordedFiltration(TRIANGLE_RIPS)} showMeaning={false} />);
    expect(screen.queryByTestId('guarantee-chip-meaning')).toBeNull();
    expect(screen.getByTestId('guarantee-chip-label').textContent).toBe('flag complex (Rips-type)');
  });
});

describe('<GuaranteeChip> quantization (SPEC.md §1.3: grid values, not measurements)', () => {
  it('warns on a box filtration, naming the step and the incomparability', () => {
    const box = recordedFiltration(RING6_BOX);
    render(<GuaranteeChip filtration={box} />);
    const chip = screen.getByTestId('guarantee-chip');
    expect(chip).toHaveAttribute('data-quantized', 'true');
    const text = screen.getByTestId('guarantee-chip-quantization').textContent ?? '';
    expect(text).toContain(QUANTIZATION_WARNING);
    expect(text).toContain(String(box.quantization.step));
    expect(text).toContain(`${box.quantization.steps} steps`);
  });

  it('says nothing about a grid when values are measurements', () => {
    render(<GuaranteeChip filtration={recordedFiltration(CIRCLE24_ALPHA)} />);
    expect(screen.queryByTestId('guarantee-chip-quantization')).toBeNull();
    expect(screen.getByTestId('guarantee-chip')).not.toHaveAttribute('data-quantized');
  });
});

describe('<GuaranteeChip> vertex identity (SPEC.md §3.1: two index spaces)', () => {
  it('says the k-fold vertices are k-subsets drawn at barycentres, with the counts', () => {
    const kfold = recordedFiltration(JITTERED8_KFOLD2);
    render(<GuaranteeChip filtration={kfold} />);
    expect(screen.getByTestId('guarantee-chip')).toHaveAttribute('data-vertex-kind', 'subset');
    const text = screen.getByTestId('guarantee-chip-vertices').textContent ?? '';
    expect(text).toMatch(/2-subsets of the input/);
    expect(text).toMatch(/barycentres/);
    expect(text).toContain(`${kfold.vertexCount} vertices`);
    expect(text).toContain('8 points');
    // The whole point of the sentence: there are more vertices than points.
    expect(kfold.vertexCount).toBeGreaterThan(8);
  });

  it('says nothing when a vertex simply IS a point', () => {
    render(<GuaranteeChip filtration={recordedFiltration(CIRCLE24_ALPHA)} />);
    expect(screen.queryByTestId('guarantee-chip-vertices')).toBeNull();
    expect(screen.getByTestId('guarantee-chip')).toHaveAttribute('data-vertex-kind', 'point');
  });
});
