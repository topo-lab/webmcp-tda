import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { PointCloud2D } from '../PointCloud2D';

const SQUARE = [0, 0, 1, 0, 1, 1, 0, 1];

describe('<PointCloud2D> (pure SVG — no PlayCanvas, no WebGL)', () => {
  it('renders one circle per point', () => {
    render(<PointCloud2D points={SQUARE} />);
    expect(screen.getAllByTestId('tda-point')).toHaveLength(4);
  });

  it('renders an accessible svg (role img with a default label)', () => {
    render(<PointCloud2D points={SQUARE} />);
    const svg = screen.getByRole('img');
    expect(svg.tagName.toLowerCase()).toBe('svg');
    expect(svg).toHaveAccessibleName(/point cloud/i);
  });

  it('renders empty state honestly: an svg with zero points, nothing synthesized', () => {
    render(<PointCloud2D points={[]} />);
    const svg = screen.getByRole('img');
    expect(svg).toHaveAttribute('data-empty', 'true');
    expect(screen.queryAllByTestId('tda-point')).toHaveLength(0);
  });

  it('keeps every point inside the viewBox', () => {
    const width = 300;
    const height = 200;
    render(<PointCloud2D points={SQUARE} width={width} height={height} />);
    for (const circle of screen.getAllByTestId('tda-point')) {
      const cx = Number(circle.getAttribute('cx'));
      const cy = Number(circle.getAttribute('cy'));
      expect(cx).toBeGreaterThanOrEqual(0);
      expect(cx).toBeLessThanOrEqual(width);
      expect(cy).toBeGreaterThanOrEqual(0);
      expect(cy).toBeLessThanOrEqual(height);
    }
  });

  it('preserves aspect ratio (a circle must look like a circle)', () => {
    // Points on a unit circle: x-extent equals y-extent, so the rendered
    // extents must match even in a non-square viewport.
    const circlePts: number[] = [];
    for (let i = 0; i < 16; i++) {
      const t = (2 * Math.PI * i) / 16;
      circlePts.push(Math.cos(t), Math.sin(t));
    }
    render(<PointCloud2D points={circlePts} width={400} height={200} />);
    const xs = screen.getAllByTestId('tda-point').map((c) => Number(c.getAttribute('cx')));
    const ys = screen.getAllByTestId('tda-point').map((c) => Number(c.getAttribute('cy')));
    const xExtent = Math.max(...xs) - Math.min(...xs);
    const yExtent = Math.max(...ys) - Math.min(...ys);
    expect(Math.abs(xExtent - yExtent)).toBeLessThan(1e-6);
  });

  it('passes className through for Tailwind styling', () => {
    render(<PointCloud2D points={SQUARE} className="text-cyan-500" />);
    expect(screen.getByRole('img')).toHaveClass('text-cyan-500');
  });

  it('rejects flat arrays with an odd number of coordinates', () => {
    expect(() => render(<PointCloud2D points={[1, 2, 3]} />)).toThrow(/length|multiple/i);
  });

  it('draws supplied filtration edges behind the points', () => {
    render(<PointCloud2D points={SQUARE} edges={[{ vertices: [0, 1], filtration: 0.5 }]} />);
    expect(screen.getByTestId('tda-edge')).toHaveAttribute('data-filtration', '0.5');
  });

  it('projects caller-supplied disk radii from data units and keeps them below edges', () => {
    render(
      <PointCloud2D
        points={SQUARE}
        width={100}
        height={100}
        padding={10}
        diskRadii={[0.25, 0, 0.5, 0]}
        edges={[{ vertices: [0, 1] }]}
      />,
    );
    const disks = screen.getAllByTestId('tda-disk');
    expect(disks).toHaveLength(2);
    expect(Number(disks[0]?.getAttribute('r'))).toBe(20);
    expect(Number(disks[1]?.getAttribute('r'))).toBe(40);
    const svgChildren = Array.from(screen.getByRole('img').children);
    expect(svgChildren.indexOf(disks[0]!)).toBeLessThan(
      svgChildren.indexOf(screen.getByTestId('tda-edge')),
    );
  });

  it('can reserve a stable viewport for the final disk radius', () => {
    render(
      <PointCloud2D
        points={SQUARE}
        width={100}
        height={100}
        padding={10}
        diskRadii={[0.5, 0.5, 0.5, 0.5]}
        fitDiskRadii={[0.5, 0.5, 0.5, 0.5]}
      />,
    );
    const disks = screen.getAllByTestId('tda-disk');
    expect(Number(disks[0]?.getAttribute('r'))).toBe(20);
    expect(Number(disks[0]?.getAttribute('cx'))).toBe(30);
  });

  it('opens the built-in coordinate dialog and commits exact coordinates', () => {
    const changes: number[][] = [];
    render(
      <PointCloud2D
        points={SQUARE}
        editable
        interactionMode="edit"
        onPointsChange={(nextPoints) => changes.push(nextPoints)}
      />,
    );
    fireEvent.click(screen.getAllByTestId('tda-point')[0], { detail: 1 });
    expect(screen.getByRole('dialog', { name: 'Edit point 1' })).toBeInTheDocument();
    fireEvent.change(screen.getByRole('spinbutton', { name: 'X coordinate' }), {
      target: { value: '2.5' },
    });
    fireEvent.change(screen.getByRole('spinbutton', { name: 'Y coordinate' }), {
      target: { value: '-1.25' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Save coordinates' }));
    expect(changes.at(-1)?.slice(0, 2)).toEqual([2.5, -1.25]);
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });

  it('keeps invalid coordinate values in the dialog for correction', () => {
    render(
      <PointCloud2D
        points={SQUARE}
        editable
        interactionMode="edit"
        onPointsChange={() => undefined}
      />,
    );
    fireEvent.click(screen.getAllByTestId('tda-point')[0], { detail: 1 });
    fireEvent.change(screen.getByRole('spinbutton', { name: 'X coordinate' }), {
      target: { value: '' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Save coordinates' }));
    expect(screen.getByRole('alert')).toHaveTextContent('finite numbers');
    expect(screen.getByRole('dialog')).toBeInTheDocument();
  });

  it('still accepts a caller-supplied coordinate prompt', () => {
    const changes: number[][] = [];
    render(
      <PointCloud2D
        points={SQUARE}
        editable
        interactionMode="edit"
        onPointsChange={(nextPoints) => changes.push(nextPoints)}
        promptForPoint={() => [2.5, -1.25]}
      />,
    );
    fireEvent.click(screen.getAllByTestId('tda-point')[0], { detail: 1 });
    expect(changes.at(-1)?.slice(0, 2)).toEqual([2.5, -1.25]);
  });

  it('draws coordinate axes with labelled ticks when requested', () => {
    const { rerender } = render(<PointCloud2D points={SQUARE} width={200} height={200} />);
    expect(screen.queryAllByTestId('tda-axis')).toHaveLength(0);
    rerender(<PointCloud2D points={SQUARE} width={200} height={200} showAxes />);
    expect(screen.getAllByTestId('tda-axis')).toHaveLength(2);
    expect(screen.getAllByTestId('tda-axis-tick').length).toBeGreaterThan(2);
    expect(screen.getAllByTestId('tda-axis-label').some((label) => label.textContent === '0')).toBe(
      true,
    );
  });

  it('keeps a requested projection center fixed when point coordinates change', () => {
    const { rerender } = render(
      <PointCloud2D
        points={SQUARE}
        width={200}
        height={200}
        showAxes
        projectionCenter={[0, 0]}
      />,
    );
    const [initialXAxis, initialYAxis] = screen.getAllByTestId('tda-axis');
    const initialCenter = [initialYAxis?.getAttribute('x1'), initialXAxis?.getAttribute('y1')];

    rerender(
      <PointCloud2D
        points={[0, 0, 3, 0, 1, 1, 0, 1]}
        width={200}
        height={200}
        showAxes
        projectionCenter={[0, 0]}
      />,
    );
    const [movedXAxis, movedYAxis] = screen.getAllByTestId('tda-axis');
    expect([movedYAxis?.getAttribute('x1'), movedXAxis?.getAttribute('y1')]).toEqual(initialCenter);
  });

  it('exposes editable points to keyboard users', () => {
    const changes: number[][] = [];
    render(
      <PointCloud2D
        points={SQUARE}
        editable
        interactionMode="edit"
        onPointsChange={(nextPoints) => changes.push(nextPoints)}
        promptForPoint={() => [3, 4]}
      />,
    );
    fireEvent.keyDown(screen.getAllByTestId('tda-point')[1], { key: 'Enter' });
    expect(changes.at(-1)).toEqual([0, 0, 3, 4, 1, 1, 0, 1]);
  });

  it('keeps edit clicks and move drags as mutually exclusive tools', () => {
    const changes: number[][] = [];
    const prompts: number[] = [];
    const { rerender } = render(
      <PointCloud2D
        points={SQUARE}
        editable
        interactionMode="move"
        onPointsChange={(nextPoints) => changes.push(nextPoints)}
        promptForPoint={(_, index) => {
          prompts.push(index);
          return [2, 2];
        }}
      />,
    );
    fireEvent.click(screen.getAllByTestId('tda-point')[0], { detail: 1 });
    expect(prompts).toHaveLength(0);

    rerender(
      <PointCloud2D
        points={SQUARE}
        editable
        interactionMode="edit"
        onPointsChange={(nextPoints) => changes.push(nextPoints)}
        promptForPoint={(_, index) => {
          prompts.push(index);
          return [2, 2];
        }}
      />,
    );
    fireEvent.pointerDown(screen.getAllByTestId('tda-point')[0], { pointerId: 1 });
    fireEvent.click(screen.getAllByTestId('tda-point')[0], { detail: 1 });
    expect(prompts).toEqual([0]);
    expect(changes.at(-1)?.slice(0, 2)).toEqual([2, 2]);
  });

  it('drags a point by converting pointer pixels back to data coordinates', () => {
    const changes: number[][] = [];
    render(
      <PointCloud2D
        points={SQUARE}
        width={100}
        height={100}
        padding={10}
        editable
        onPointsChange={(nextPoints) => changes.push(nextPoints)}
      />,
    );
    const svg = screen.getByRole('img');
    Object.defineProperty(svg, 'getBoundingClientRect', {
      value: () => ({
        left: 0,
        top: 0,
        width: 100,
        height: 100,
        right: 100,
        bottom: 100,
        x: 0,
        y: 0,
        toJSON: () => ({}),
      }),
    });
    fireEvent.pointerDown(screen.getAllByTestId('tda-point')[0], { pointerId: 1 });
    fireEvent.pointerMove(svg, { pointerId: 1, clientX: 50, clientY: 50 });
    expect(changes.at(-1)?.slice(0, 2)).toEqual([0.5, 0.5]);
  });
});

describe('<PointCloud2D> weight glyph (SPEC.md §4.2: weight is visible per point)', () => {
  it('scales the marker radius with sqrt(w_i): heavier points draw larger', () => {
    render(<PointCloud2D points={[0, 0, 1, 0]} weights={[0.5, 0]} pointRadius={3} />);
    const [heavy, light] = screen.getAllByTestId('tda-point');
    expect(Number(heavy.getAttribute('r'))).toBeCloseTo(3 * (1 + Math.sqrt(0.5)), 6);
    expect(Number(light.getAttribute('r'))).toBe(3);
  });

  it('tags each marker with its weight for inspection', () => {
    render(<PointCloud2D points={[0, 0, 1, 0]} weights={[0.5, 0]} />);
    expect(screen.getAllByTestId('tda-point')[0]).toHaveAttribute('data-weight', '0.5');
  });

  it('draws all-zero weights identically to the unweighted case', () => {
    render(<PointCloud2D points={[0, 0, 1, 0]} weights={[0, 0]} pointRadius={3} />);
    for (const c of screen.getAllByTestId('tda-point')) {
      expect(Number(c.getAttribute('r'))).toBe(3);
    }
  });
});
