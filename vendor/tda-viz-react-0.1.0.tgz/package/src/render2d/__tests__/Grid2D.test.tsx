// <Grid2D>: the thresholded set on a grid of values (SPEC.md §4.7). Nothing
// grows here, so these tests read which CELLS are in at t and how strongly they
// are inked — the picture on screen, not a mock's call log.
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  DIAGONAL3_CUBICAL_T,
  DIAGONAL3_CUBICAL_V,
  TWOHOLE11X9_CUBICAL_T,
  TWORINGS10_CUBICAL_T,
  TWORINGS10_CUBICAL_T_SUPER,
  WELLS24_CUBICAL_V,
  recordedGridFiltration,
} from '../../__fixtures__/realFiltrations';
import { GRID_GUARANTEES } from '../../filtration/guarantees';
import { Grid2D } from '../Grid2D';

const cells = () => screen.getAllByTestId('grid-2d-cell');
const inside = () => cells().filter((c) => c.getAttribute('data-inside') === 'true');

describe('<Grid2D> draws the grid, all of it, every time', () => {
  const f = recordedGridFiltration(TWORINGS10_CUBICAL_T);

  it('draws exactly one cell per grid value', () => {
    render(<Grid2D filtration={f} t={0} />);
    expect(cells()).toHaveLength(f.width * f.height);
    expect(cells()).toHaveLength(100);
  });

  it('draws them all at every threshold, in and out alike', () => {
    const { rerender } = render(<Grid2D filtration={f} t={-5} />);
    // Below every value: nothing is in, and the grid is still all there. A
    // silhouette would show where the sweep has BEEN and never where it is.
    expect(cells()).toHaveLength(100);
    expect(inside()).toHaveLength(0);
    rerender(<Grid2D filtration={f} t={5} />);
    expect(cells()).toHaveLength(100);
    expect(inside()).toHaveLength(100);
  });

  it('one cell per value on a NON-SQUARE grid too, the right way round', () => {
    const wide = recordedGridFiltration(TWOHOLE11X9_CUBICAL_T);
    render(<Grid2D filtration={wide} t={0} />);
    expect(cells()).toHaveLength(99);
    expect(screen.getByTestId('grid-2d')).toHaveAttribute('data-grid-size', '11x9');
  });

  it('marks each cell with its own value, read from the data', () => {
    render(<Grid2D filtration={f} t={0} />);
    const drawn = cells().map((c) => Number(c.getAttribute('data-value')));
    expect(drawn).toEqual([...f.values]);
  });
});

describe('<Grid2D> fills the set the threshold names, and empties the rest', () => {
  const f = recordedGridFiltration(TWORINGS10_CUBICAL_T);

  it('at t = 0 exactly the low cells are inked — the 48 ring cells', () => {
    render(<Grid2D filtration={f} t={0} />);
    const low = [...f.values].filter((v) => v === 0).length;
    expect(low).toBe(48); // two 5x5 blocks with their centres punched out
    expect(inside()).toHaveLength(low);
    for (const c of inside()) expect(Number(c.getAttribute('data-value'))).toBe(0);
  });

  it('a cell outside the set is EMPTY: no fill, not a faint one', () => {
    render(<Grid2D filtration={f} t={0} />);
    const out = cells().filter((c) => c.getAttribute('data-inside') === 'false');
    expect(out.length).toBeGreaterThan(0);
    for (const c of out) {
      expect(c.getAttribute('fill')).toBe('none');
      expect(Number(c.getAttribute('fill-opacity'))).toBe(0);
    }
  });

  it('agrees with the filtration’s own predicate at every critical value', () => {
    for (const t of f.criticalValues) {
      const { unmount } = render(<Grid2D filtration={f} t={t} />);
      const expected = [...f.values].filter((v) => f.containsValue(v, t)).length;
      expect(inside(), `t = ${t}`).toHaveLength(expected);
      unmount();
    }
  });

  it('a superlevel filtration fills the other side, from the other end', () => {
    const sup = recordedGridFiltration(TWORINGS10_CUBICAL_T_SUPER);
    render(<Grid2D filtration={sup} t={1} />);
    expect(screen.getByTestId('grid-2d')).toHaveAttribute('data-direction', 'superlevel');
    // {f >= 1}: the bright ground, which is what the low fill was not.
    expect(inside()).toHaveLength([...sup.values].filter((v) => v === 1).length);
  });
});

describe('<Grid2D> inks by depth: how early the sweep reached a cell', () => {
  const f = recordedGridFiltration(WELLS24_CUBICAL_V);

  it('the deepest cell is the strongest and a cell just entered is the faintest', () => {
    render(<Grid2D filtration={f} t={f.tMax} />);
    const inked = inside().map((c) => ({
      v: Number(c.getAttribute('data-value')),
      o: Number(c.getAttribute('fill-opacity')),
    }));
    expect(inked).toHaveLength(f.width * f.height);
    const deepest = inked.reduce((a, b) => (b.v < a.v ? b : a));
    const shallowest = inked.reduce((a, b) => (b.v > a.v ? b : a));
    expect(deepest.o).toBeGreaterThan(shallowest.o);
    // Never zero: a cell at the threshold IS in the complex, and fading it out
    // would draw the boundary of the set outside the set.
    expect(shallowest.o).toBeGreaterThan(0);
  });

  it('a grid with one value everywhere has no range to ramp, and inks it whole', () => {
    const flat = recordedGridFiltration({
      ...TWORINGS10_CUBICAL_T,
      values: new Array(100).fill(3),
    });
    render(<Grid2D filtration={flat} t={3} />);
    const opacities = new Set(inside().map((c) => c.getAttribute('fill-opacity')));
    expect(inside()).toHaveLength(100);
    expect(opacities.size).toBe(1);
  });
});

describe('<Grid2D> says what it is drawing, and does not compose the wording', () => {
  const t = recordedGridFiltration(DIAGONAL3_CUBICAL_T);
  const v = recordedGridFiltration(DIAGONAL3_CUBICAL_V);

  it('names the construction in the ENGINE’s words, read off the filtration', () => {
    render(<Grid2D filtration={t} t={0} />);
    const line = screen.getByTestId('grid-2d-threshold').textContent ?? '';
    expect(line).toContain(GRID_GUARANTEES['cubical-t'].label);
    expect(line).toContain(t.guarantee.label);
  });

  it('says something DIFFERENT for the other convention, from the same grid', () => {
    const { rerender } = render(<Grid2D filtration={t} t={0} />);
    const first = screen.getByTestId('grid-2d-threshold').textContent;
    rerender(<Grid2D filtration={v} t={0} />);
    expect(screen.getByTestId('grid-2d-threshold').textContent).not.toBe(first);
    expect(screen.getByTestId('grid-2d')).toHaveAttribute('data-construction', 'cubical-v');
    expect(screen.getByTestId('grid-2d')).toHaveAttribute('data-cell-basis', 'vertex');
  });

  it('records which cell a value sits on: a pixel under T, a vertex under V', () => {
    const { rerender } = render(<Grid2D filtration={t} t={0} />);
    expect(screen.getByTestId('grid-2d')).toHaveAttribute('data-cell-basis', 'pixel');
    rerender(<Grid2D filtration={v} t={0} />);
    expect(screen.getByTestId('grid-2d')).toHaveAttribute('data-cell-basis', 'vertex');
  });

  /**
   * The drawing contains NO TEXT AT ALL. Every word on this surface is in the
   * caption below the SVG, and the guarantee half of that caption is
   * `filtration.guarantee.label` — the engine's phrase, read from the data.
   * A `<text>` node inside the picture is where a typed label would go, so its
   * absence is the mechanical form of "the wording is never typed here"
   * (SPEC.md §1.4).
   */
  it('types no guarantee wording: the SVG has no <text> at all', () => {
    const { container } = render(<Grid2D filtration={t} t={0} />);
    expect(container.querySelectorAll('svg text')).toHaveLength(0);
    const source = String(Grid2D);
    for (const g of Object.values(GRID_GUARANTEES)) {
      expect(source, `the component body spells out "${g.label}"`).not.toContain(g.label);
    }
  });
});

describe('<Grid2D> takes its colours from props, with token defaults', () => {
  const f = recordedGridFiltration(TWORINGS10_CUBICAL_T);

  it('defaults to CSS custom properties, so a consumer retints without a fork', () => {
    render(<Grid2D filtration={f} t={0} />);
    expect(inside()[0].getAttribute('fill')).toBe('var(--grid-ink, currentColor)');
    expect(cells()[0].getAttribute('stroke')).toBe('var(--grid-rule, currentColor)');
  });

  it('honours the colour, opacity and rule props it is given', () => {
    render(
      <Grid2D
        filtration={f}
        t={0}
        color="var(--mine)"
        opacity={0.5}
        minShade={1}
        gridColor="var(--rule)"
        gridWidth={0}
      />,
    );
    expect(inside()[0].getAttribute('fill')).toBe('var(--mine)');
    expect(Number(inside()[0].getAttribute('fill-opacity'))).toBeCloseTo(0.5, 6);
    // gridWidth 0 draws no rule at all rather than a zero-width one.
    expect(cells()[0].getAttribute('stroke')).toBe('none');
  });
});
