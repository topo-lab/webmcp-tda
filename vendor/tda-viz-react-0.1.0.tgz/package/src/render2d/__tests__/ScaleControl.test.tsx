// <ScaleControl> (SPEC.md §4.4): shows t, the convention, the radius it
// implies, and snap-to-event buttons. Controlled; owns nothing.
import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import {
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { ScaleControl } from '../ScaleControl';

const cech = recordedFiltration(TRIANGLE_CECH); // criticalValues [0, 0.5, 0.57735]
const rips = recordedFiltration(TRIANGLE_RIPS);
const weighted = recordedFiltration(WEIGHTED3_ALPHA); // tMin -0.5

describe('<ScaleControl> is controlled', () => {
  it('reports slider changes and keeps displaying the prop', () => {
    const onChange = vi.fn();
    render(<ScaleControl filtration={cech} t={0.3} onChange={onChange} />);
    const slider = screen.getByRole('slider');
    fireEvent.change(slider, { target: { value: '0.5' } });
    expect(onChange).toHaveBeenCalledWith(0.5);
    expect(slider).toHaveValue('0.3'); // still the prop: controlled
  });

  it('spans the real domain of the filtration, including negative weighted starts', () => {
    render(<ScaleControl filtration={weighted} t={0} onChange={() => {}} />);
    const slider = screen.getByRole('slider');
    expect(slider).toHaveAttribute('min', '-0.5');
    expect(Number(slider.getAttribute('max'))).toBeCloseTo(1.085557, 5);
  });
});

describe('<ScaleControl> displays t, the convention, and the radius it implies', () => {
  it('shows the current t', () => {
    render(<ScaleControl filtration={cech} t={0.5} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control-t').textContent).toMatch(/0\.500/);
  });

  it('rips: names the convention and computes radius t/2', () => {
    render(<ScaleControl filtration={rips} t={1} onChange={() => {}} />);
    const c = screen.getByTestId('scale-control-convention');
    expect(c.textContent).toMatch(/rips/i);
    expect(c.textContent).toMatch(/t\/2/);
    expect(screen.getByTestId('scale-control-radius').textContent).toMatch(/0\.500/);
  });

  it('cech: radius is t itself', () => {
    render(<ScaleControl filtration={cech} t={0.5} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control-convention').textContent).toMatch(/čech|cech/i);
    expect(screen.getByTestId('scale-control-radius').textContent).toMatch(/0\.500/);
  });

  it('alpha with weights: shows the per-point radius RANGE, not one number', () => {
    render(<ScaleControl filtration={weighted} t={0} onChange={() => {}} />);
    const radius = screen.getByTestId('scale-control-radius');
    expect(radius.textContent).toMatch(/0\.000/); // lightest point
    expect(radius.textContent).toMatch(/0\.707/); // heaviest point, sqrt(0.5)
  });
});

describe('<ScaleControl> snap-to-event buttons', () => {
  it('next jumps to the next critical value', () => {
    const onChange = vi.fn();
    render(<ScaleControl filtration={cech} t={0.2} onChange={onChange} />);
    fireEvent.click(screen.getByTestId('scale-control-next'));
    expect(onChange).toHaveBeenCalledWith(0.5);
  });

  it('prev jumps to the previous critical value', () => {
    const onChange = vi.fn();
    render(<ScaleControl filtration={cech} t={0.55} onChange={onChange} />);
    fireEvent.click(screen.getByTestId('scale-control-prev'));
    expect(onChange).toHaveBeenCalledWith(0.5);
  });

  it('disables next at the last event and prev at the first', () => {
    const last = render(<ScaleControl filtration={cech} t={0.57735} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control-next')).toBeDisabled();
    last.unmount();
    render(<ScaleControl filtration={cech} t={0} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control-prev')).toBeDisabled();
  });
});
