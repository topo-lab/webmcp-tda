// <ScaleControl> (SPEC.md §4.4): shows t, the convention, the radius it
// implies, and snap-to-event buttons. Controlled; owns nothing.
import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import {
  CIRCLE12_WING,
  RING6_BOX,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { ScaleControl } from '../ScaleControl';

const cech = recordedFiltration(TRIANGLE_CECH); // criticalValues [0, 0.5, 0.57735]
const rips = recordedFiltration(TRIANGLE_RIPS);
const weighted = recordedFiltration(WEIGHTED3_ALPHA); // tMin -0.5
const wing = recordedFiltration(CIRCLE12_WING); // shapeKind 'wing', convention 'wing-eps'
const box = recordedFiltration(RING6_BOX); // shapeKind 'box', convention 'box-step'

describe('<ScaleControl> is controlled', () => {
  it('reports slider changes and keeps displaying the prop', () => {
    const onChange = vi.fn();
    render(<ScaleControl filtration={cech} t={0.3} onChange={onChange} />);
    const slider = screen.getByRole('slider');
    fireEvent.change(slider, { target: { value: '0.5' } });
    expect(onChange).toHaveBeenCalledWith(0.5);
    expect(slider).toHaveValue('0.3'); // still the prop: controlled
  });

  it('spans the real domain of the filtration, including negative weighted starts', () => {
    render(<ScaleControl filtration={weighted} t={0} onChange={() => {}} />);
    const slider = screen.getByRole('slider');
    expect(slider).toHaveAttribute('min', '-0.5');
    expect(Number(slider.getAttribute('max'))).toBeCloseTo(1.085557, 5);
  });
});

describe('<ScaleControl> displays t, the convention, and the radius it implies', () => {
  it('shows the current t', () => {
    render(<ScaleControl filtration={cech} t={0.5} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control-t').textContent).toMatch(/0\.500/);
  });

  it('rips: names the convention and computes radius t/2', () => {
    render(<ScaleControl filtration={rips} t={1} onChange={() => {}} />);
    const c = screen.getByTestId('scale-control-convention');
    expect(c.textContent).toMatch(/rips/i);
    expect(c.textContent).toMatch(/t\/2/);
    expect(screen.getByTestId('scale-control-radius').textContent).toMatch(/0\.500/);
  });

  it('cech: radius is t itself', () => {
    render(<ScaleControl filtration={cech} t={0.5} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control-convention').textContent).toMatch(/čech|cech/i);
    expect(screen.getByTestId('scale-control-radius').textContent).toMatch(/0\.500/);
  });

  it('alpha with weights: shows the per-point radius RANGE, not one number', () => {
    render(<ScaleControl filtration={weighted} t={0} onChange={() => {}} />);
    const radius = screen.getByTestId('scale-control-radius');
    expect(radius.textContent).toMatch(/0\.000/); // lightest point
    expect(radius.textContent).toMatch(/0\.707/); // heaviest point, sqrt(0.5)
  });
});

// CANONICAL REGRESSION (defect 4): <ScaleControl> used to declare
// `filtration: BallFiltration`, a type error for every non-ball construction.
// It now takes the full `Filtration` union — one ball member (above) and one
// non-ball member (below) — and switches its readout on `shapeKind` honestly.
describe('<ScaleControl> widened to the full Filtration union (non-ball members)', () => {
  it('wing: has no ball radius, so the readout states the scale value and the wing convention instead', () => {
    render(<ScaleControl filtration={wing} t={0.5} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control')).toHaveAttribute('data-convention', 'wing-eps');
    expect(screen.getByTestId('scale-control-convention').textContent).toMatch(/wing/i);
    const radius = screen.getByTestId('scale-control-radius').textContent ?? '';
    // Never a fabricated "ball radius" — the wing has none.
    expect(radius).not.toMatch(/drawn radius/);
    expect(radius).toMatch(/no ball radius/);
    expect(radius).toMatch(/wing-eps/);
    expect(radius).toMatch(/0\.500/);
  });

  it('box: quantized and non-ball — the readout names the box-step convention, not a radius', () => {
    render(<ScaleControl filtration={box} t={1} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control')).toHaveAttribute('data-convention', 'box-step');
    expect(screen.getByTestId('scale-control-convention').textContent).toMatch(/box/i);
    expect(screen.getByTestId('scale-control-convention').textContent).toMatch(/step.*π|π.*step/);
    const radius = screen.getByTestId('scale-control-radius').textContent ?? '';
    expect(radius).not.toMatch(/drawn radius/);
    expect(radius).toMatch(/no ball radius/);
    expect(radius).toMatch(/box-step/);
    expect(radius).toMatch(/1\.000/);
  });

  it('the slider and snap buttons still work for a non-ball filtration', () => {
    const onChange = vi.fn();
    render(<ScaleControl filtration={wing} t={0.5} onChange={onChange} />);
    const slider = screen.getByRole('slider');
    fireEvent.change(slider, { target: { value: '0.6' } });
    expect(onChange).toHaveBeenCalledWith(0.6);
  });
});

describe('<ScaleControl> snap-to-event buttons', () => {
  it('next jumps to the next critical value', () => {
    const onChange = vi.fn();
    render(<ScaleControl filtration={cech} t={0.2} onChange={onChange} />);
    fireEvent.click(screen.getByTestId('scale-control-next'));
    expect(onChange).toHaveBeenCalledWith(0.5);
  });

  it('prev jumps to the previous critical value', () => {
    const onChange = vi.fn();
    render(<ScaleControl filtration={cech} t={0.55} onChange={onChange} />);
    fireEvent.click(screen.getByTestId('scale-control-prev'));
    expect(onChange).toHaveBeenCalledWith(0.5);
  });

  it('disables next at the last event and prev at the first', () => {
    const last = render(<ScaleControl filtration={cech} t={0.57735} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control-next')).toBeDisabled();
    last.unmount();
    render(<ScaleControl filtration={cech} t={0} onChange={() => {}} />);
    expect(screen.getByTestId('scale-control-prev')).toBeDisabled();
  });
});
