// @vitest-environment node
//
// Direct geometry contracts for states that are easy to miss through a React
// render: empty/constant clouds and zero-area growing shapes. A zero-area shape
// is absent, not a decorative dot, because it has not entered X_t yet.
import { describe, expect, it } from 'vitest';
import type { GrowingShape } from '../../filtration/types';
import { projectCloud, type Projection2D } from '../project';
import { shapeSubpath, unionPath } from '../shapePath';

const identity: Projection2D = {
  pos: [],
  pxPerUnit: 1,
  px: (x) => x,
  py: (y) => y,
};

describe('projectCloud boundary geometry', () => {
  it('maps an empty cloud with the identity rather than inventing a viewport centre', () => {
    const projection = projectCloud([], 2, 320, 200, 16);
    expect(projection.pos).toEqual([]);
    expect(projection.pxPerUnit).toBe(1);
    expect(projection.px(3.5)).toBe(3.5);
    expect(projection.py(-2)).toBe(-2);
  });

  it('keeps a constant cloud finite and co-located on both collapsed axes', () => {
    const projection = projectCloud([2, 5, 2, 5], 2, 100, 80, 10);
    expect(projection.pos).toHaveLength(2);
    expect(projection.pos[0]).toEqual(projection.pos[1]);
    expect(Number.isFinite(projection.pos[0]!.x)).toBe(true);
    expect(Number.isFinite(projection.pos[0]!.y)).toBe(true);
    expect(projection.pos[0]!.x).toBeGreaterThanOrEqual(0);
    expect(projection.pos[0]!.x).toBeLessThanOrEqual(100);
    expect(projection.pos[0]!.y).toBeGreaterThanOrEqual(0);
    expect(projection.pos[0]!.y).toBeLessThanOrEqual(80);
  });

  it('clamps a too-small viewport to a positive scale', () => {
    const projection = projectCloud([0, 0, 1, 1], 2, 0, 0, 10);
    expect(projection.pxPerUnit).toBe(1);
    expect(projection.pos.every(({ x, y }) => Number.isFinite(x) && Number.isFinite(y))).toBe(true);
  });
});

describe('shapeSubpath zero-area honesty', () => {
  it.each([
    { kind: 'ball', center: [0, 0], radius: 0 },
    {
      kind: 'ellipsoid',
      center: [0, 0],
      frame: [
        [1, 0],
        [0, 1],
      ],
      semiAxes: [1, 0],
    },
    {
      kind: 'wing',
      center: [0, 0],
      normal: [1, 0],
      normalSource: 'supplied',
      spineHalfLength: 0,
      wingLength: 0,
      theta: Math.PI / 2,
      outline: [
        [0, 0],
        [0, 0],
        [0, 0],
        [0, 0],
        [0, 0],
        [0, 0],
      ],
    },
    { kind: 'box', lower: [1, 1], upper: [1, 2], step: 0 },
    { kind: 'box', lower: [1, 1], upper: [2, 1], step: 0 },
  ] as const)('does not draw a fictitious region for $kind', (shape) => {
    expect(shapeSubpath(shape as GrowingShape, identity)).toBeNull();
  });

  it('normalizes a counter-clockwise wing to the union path winding', () => {
    const path = shapeSubpath(
      {
        kind: 'wing',
        center: [0, 0],
        normal: [1, 0],
        normalSource: 'supplied',
        spineHalfLength: 1,
        wingLength: 1,
        theta: Math.PI / 2,
        // Counter-clockwise in this identity pixel coordinate system.
        outline: [
          [0, 0],
          [2, 0],
          [3, 1],
          [2, 2],
          [0, 2],
          [-1, 1],
        ],
      },
      identity,
    );
    if (!path) throw new Error('positive-area wing unexpectedly disappeared');
    const points = [...path.matchAll(/[ML](-?[\d.]+) (-?[\d.]+)/g)].map((match) => [
      Number(match[1]),
      Number(match[2]),
    ]);
    let twiceArea = 0;
    points.forEach(([x0, y0], index) => {
      const [x1, y1] = points[(index + 1) % points.length]!;
      twiceArea += x0 * y1 - x1 * y0;
    });
    expect(twiceArea).toBeLessThan(0);
  });

  it('omits only the zero-area member when composing one union path', () => {
    const shapes: GrowingShape[] = [
      { kind: 'ball', center: [0, 0], radius: 0 },
      { kind: 'ball', center: [2, 0], radius: 1 },
    ];
    const path = unionPath((index) => shapes[index]!, shapes.length, 0, identity);
    expect(path.match(/M/g)).toHaveLength(1);
  });
});
