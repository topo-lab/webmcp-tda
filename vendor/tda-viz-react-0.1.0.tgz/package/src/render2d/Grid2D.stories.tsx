import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  DIAGONAL3_CUBICAL_T,
  DIAGONAL3_CUBICAL_V,
  TWOHOLE11X9_CUBICAL_T,
  TWORINGS10_CUBICAL_T,
  TWORINGS10_CUBICAL_T_SUPER,
  TWORINGS10_CUBICAL_V,
  WELLS24_CUBICAL_V,
  recordedGridFiltration,
} from '../__fixtures__/realFiltrations';
import { Barcode } from '../persistence/Barcode';
import { Grid2D } from './Grid2D';
import { GuaranteeChip } from './GuaranteeChip';

/**
 * <Grid2D> draws the set the threshold names, on a grid of values. It is the
 * grid domain's stage, the counterpart of <Field2D>: same job, no shapes.
 *
 * Nothing here grows. A cubical filtration has fixed cells and fixed values,
 * and t decides which cells are in — so the picture changes by filling, not by
 * expanding, and there is no scale law to name.
 *
 * THE TWO CONVENTIONS ARE THE SUBJECT. The same array of numbers is two
 * different filtrations depending on whether a value belongs to a PIXEL (the
 * T-construction) or to a grid VERTEX (the V-construction), and the two give
 * different diagrams. Under T two low pixels that touch corner to corner share
 * a vertex, and a vertex takes the minimum of the pixels around it, so they are
 * connected from the start. Under V two low vertices that touch corner to
 * corner have no edge between them, because a square lattice has no diagonals.
 * T reads a grid with diagonal contact; V does not. The stories below put the
 * same picture under both.
 *
 * All data here is recorded output of the real GUDHI engine.
 */
const meta = {
  title: '2D/Grid2D',
  component: Grid2D,
  tags: ['autodocs'],
} satisfies Meta<typeof Grid2D>;

export default meta;
type Story = StoryObj<typeof meta>;

const rings = recordedGridFiltration(TWORINGS10_CUBICAL_T);
const ringsV = recordedGridFiltration(TWORINGS10_CUBICAL_V);
const wells = recordedGridFiltration(WELLS24_CUBICAL_V);

/** The stage, its chip and its score: what a consumer actually assembles. */
const withChip: Story['render'] = (args) => (
  <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
    <Grid2D {...args} />
    <div>
      <GuaranteeChip filtration={args.filtration} />
      <Barcode filtration={args.filtration} t={args.t} width={300} height={140} />
    </div>
  </div>
);

/**
 * Two 5×5 low rings on a high ground, at t = 0: the low set is exactly the two
 * rings, and each carries a loop around its punched-out centre. β0 = 1, β1 = 2
 * under the T-construction — one region, because the two rings meet corner to
 * corner and T sees that contact.
 */
export const TwoRingsAtZero: Story = {
  args: { filtration: rings, t: 0 },
  render: withChip,
};

/**
 * The same grid at t = 1, when the bright ground arrives: everything is inside,
 * the loops are filled, β0 = 1 and β1 = 0. The ink strength still shows which
 * cells were reached first.
 */
export const TwoRingsFilled: Story = {
  args: { filtration: rings, t: 1 },
  render: withChip,
};

// ── The two conventions on one array (SPEC.md §1.3) ──────────────────────

/**
 * THE SAME NINE NUMBERS, side by side. `0 2 2 / 2 0 2 / 2 2 0`: three low
 * values on the main diagonal.
 *
 * Left, the T-construction — the numbers are pixels. The three low pixels meet
 * at shared corner vertices, each of which takes the minimum of the pixels
 * around it and so is present at t = 0. ONE component, and the diagram is a
 * single essential bar.
 *
 * Right, the V-construction — the numbers are lattice vertices, and every edge
 * takes the maximum of its two ends. There is no diagonal edge to join the low
 * vertices, so every edge out of one enters at 2. THREE components until t = 2,
 * and two of them die there.
 *
 * No threshold makes the two agree. A picture that mixes them is wrong.
 */
export const OneArrayTwoConventions: Story = {
  args: { filtration: recordedGridFiltration(DIAGONAL3_CUBICAL_T), t: 0 },
  render: () => (
    <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>
      {[DIAGONAL3_CUBICAL_T, DIAGONAL3_CUBICAL_V].map((rec) => {
        const f = recordedGridFiltration(rec);
        return (
          <div key={rec.construction}>
            <Grid2D filtration={f} t={0} width={200} height={200} />
            <GuaranteeChip filtration={f} />
            <p style={{ fontSize: 11, fontFamily: 'ui-monospace, monospace' }}>
              {/* Counted from the filtration, never written into the prose. */}
              at t = 0: β₀ = {f.bettiAt(0)[0]}, β₁ = {f.bettiAt(0)[1]}
            </p>
            <Barcode filtration={f} t={0} width={200} height={90} />
          </div>
        );
      })}
    </div>
  ),
};

/**
 * The same contrast on a picture large enough to see: two rings touching at one
 * corner. T counts ONE dark region, V counts TWO — and both count two loops, so
 * the disagreement is precisely and only about the corner. The extra H₀ bar on
 * the right is that disagreement, drawn.
 */
export const CornerContact: Story = {
  args: { filtration: rings, t: 0 },
  render: () => (
    <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>
      {[rings, ringsV].map((f) => (
        <div key={f.construction}>
          <Grid2D filtration={f} t={0} width={240} height={240} />
          <GuaranteeChip filtration={f} />
          <p style={{ fontSize: 11, fontFamily: 'ui-monospace, monospace' }}>
            at t = 0: β₀ = {f.bettiAt(0)[0]}, β₁ = {f.bettiAt(0)[1]}
          </p>
          <Barcode filtration={f} t={0} width={240} height={100} />
        </div>
      ))}
    </div>
  ),
};

// ── Direction, and a field with more than two thresholds ─────────────────

/**
 * The superlevel set {f ≥ t} of the same rings, at t = 1: the BRIGHT ground and
 * the two punched-out centres. The sweep runs downward from the highest value,
 * so the bars run downward too — this is not the sublevel diagram upside down,
 * it is the diagram of a different filtration.
 */
export const Superlevel: Story = {
  args: { filtration: recordedGridFiltration(TWORINGS10_CUBICAL_T_SUPER), t: 1 },
  render: withChip,
};

/**
 * A smooth height field — three Gaussian wells on a tilted plane — where the
 * threshold has somewhere to go. A binary image has two distinct values and
 * therefore two interesting thresholds; this one has hundreds, and the basins
 * fill and merge as t rises. Scrub `t` between −0.9 and 0.35.
 */
export const HeightFieldMidSweep: Story = {
  args: { filtration: wells, t: -0.2 },
  render: withChip,
};

/**
 * A NON-SQUARE grid: 11 wide, 9 tall, one dark region with two holes. It is
 * here because a grid whose sides differ is the case a wrong dimension order
 * scrambles — the same picture and its transpose must give the same diagram,
 * and this library routes the T-construction through the binding for which
 * they do.
 */
export const NonSquare: Story = {
  args: { filtration: recordedGridFiltration(TWOHOLE11X9_CUBICAL_T), t: 0, padding: 40 },
  render: withChip,
};
