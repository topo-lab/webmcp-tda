/**
 * <PointCloud2D>: an SVG point cloud with optional controlled editing.
 * An explicit interaction mode keeps dragging and exact coordinate editing
 * from competing for the same pointer gesture. Point rendering remains pure SVG.
 */
import {
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type FormEvent,
  type KeyboardEvent as ReactKeyboardEvent,
  type PointerEvent as ReactPointerEvent,
} from 'react';
import { createPortal } from 'react-dom';

export interface PointCloud2DEdge {
  vertices: readonly [number, number];
  filtration?: number;
}

export type PointCoordinatePrompt = (
  point: readonly [number, number],
  index: number,
) => readonly [number, number] | null;

export type PointCloud2DInteractionMode = 'move' | 'edit';

export interface PointCloud2DProps {
  /** Flat coordinates [x0, y0, x1, y1, ...]. */
  points: number[];
  weights?: number[];
  dimension?: 2;
  width?: number;
  height?: number;
  padding?: number;
  pointRadius?: number;
  color?: string;
  /** Optional 1-skeleton drawn beneath the point markers. */
  edges?: readonly PointCloud2DEdge[];
  edgeColor?: string;
  edgeWidth?: number;
  /** Optional per-point disk radii in the same data units as the coordinates. */
  diskRadii?: readonly number[];
  /** Optional final radii used only to reserve a stable, unclipped viewport. */
  fitDiskRadii?: readonly number[];
  projectionCenter?: readonly [number, number];
  diskColor?: string;
  diskOpacity?: number;
  diskStrokeColor?: string;
  showAxes?: boolean;
  axisColor?: string;
  axisLabelColor?: string;
  axisTickCount?: number;
  /** Enables drag and exact-coordinate editing when onPointsChange is supplied. */
  editable?: boolean;
  /** Move uses drag; edit uses a single click or Enter to request exact coordinates. */
  interactionMode?: PointCloud2DInteractionMode;
  onPointsChange?: (points: number[]) => void;
  /** Override the built-in coordinate editor. */
  promptForPoint?: PointCoordinatePrompt;
  className?: string;
  'aria-label'?: string;
}

interface Projection {
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  scale: number;
  offsetX: number;
  offsetY: number;
}

function createProjection(
  points: number[],
  width: number,
  height: number,
  padding: number,
  fitDiskRadii: readonly number[] = [],
  projectionCenter?: readonly [number, number],
): Projection {
  if (points.length % 2 !== 0)
    throw new Error(`points length ${points.length} is not a multiple of 2`);
  if (points.length === 0)
    return { minX: 0, maxX: 0, minY: 0, maxY: 0, scale: 1, offsetX: 0, offsetY: 0 };

  const xs = points.filter((_, index) => index % 2 === 0);
  const ys = points.filter((_, index) => index % 2 === 1);
  const radii = xs.map((_, index) => Math.max(0, fitDiskRadii[index] ?? 0));
  const dataMinX = Math.min(...xs.map((x, index) => x - radii[index]!));
  const dataMaxX = Math.max(...xs.map((x, index) => x + radii[index]!));
  const dataMinY = Math.min(...ys.map((y, index) => y - radii[index]!));
  const dataMaxY = Math.max(...ys.map((y, index) => y + radii[index]!));
  const halfSpanX = projectionCenter
    ? Math.max(Math.abs(dataMinX - projectionCenter[0]), Math.abs(dataMaxX - projectionCenter[0]))
    : 0;
  const halfSpanY = projectionCenter
    ? Math.max(Math.abs(dataMinY - projectionCenter[1]), Math.abs(dataMaxY - projectionCenter[1]))
    : 0;
  const minX = projectionCenter ? projectionCenter[0] - halfSpanX : dataMinX;
  const maxX = projectionCenter ? projectionCenter[0] + halfSpanX : dataMaxX;
  const minY = projectionCenter ? projectionCenter[1] - halfSpanY : dataMinY;
  const maxY = projectionCenter ? projectionCenter[1] + halfSpanY : dataMaxY;
  const spanX = maxX - minX || 1;
  const spanY = maxY - minY || 1;
  const innerWidth = Math.max(1, width - 2 * padding);
  const innerHeight = Math.max(1, height - 2 * padding);
  const scale = Math.min(innerWidth / spanX, innerHeight / spanY);
  return {
    minX,
    maxX,
    minY,
    maxY,
    scale,
    offsetX: padding + (innerWidth - spanX * scale) / 2,
    offsetY: padding + (innerHeight - spanY * scale) / 2,
  };
}

function projectPoints(points: number[], projection: Projection): Array<readonly [number, number]> {
  const positions: Array<readonly [number, number]> = [];
  for (let index = 0; index < points.length; index += 2) {
    positions.push([
      projection.offsetX + (points[index]! - projection.minX) * projection.scale,
      projection.offsetY + (projection.maxY - points[index + 1]!) * projection.scale,
    ]);
  }
  return positions;
}

function createTicks(
  minimum: number,
  maximum: number,
  requestedCount: number,
): { values: number[]; step: number } {
  const count = Math.max(2, Math.floor(requestedCount));
  const span = Math.max(Number.EPSILON, maximum - minimum);
  const roughStep = span / count;
  const magnitude = 10 ** Math.floor(Math.log10(roughStep));
  const normalized = roughStep / magnitude;
  const multiple = normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 5 ? 5 : 10;
  const step = multiple * magnitude;
  const first = Math.ceil(minimum / step) * step;
  const values: number[] = [];
  for (let value = first; value <= maximum + step * 1e-9; value += step) {
    values.push(Math.abs(value) < step * 1e-9 ? 0 : value);
  }
  return { values, step };
}

function formatTick(value: number, step: number): string {
  if (value === 0) return '0';
  const absolute = Math.abs(value);
  if (absolute >= 10_000 || absolute < 0.001) return value.toExponential(1).replace('.0e', 'e');
  const decimals = Math.max(0, Math.min(6, -Math.floor(Math.log10(step))));
  return value.toFixed(decimals).replace(/\.0+$|(?<=\.[0-9]*[1-9])0+$/, '');
}

export function PointCloud2D({
  points,
  weights,
  width = 320,
  height = 320,
  padding = 16,
  pointRadius = 3,
  color = 'currentColor',
  edges = [],
  edgeColor = '#5ac8e8',
  edgeWidth = 1.25,
  diskRadii = [],
  fitDiskRadii = [],
  projectionCenter,
  diskColor = '#5ac8e8',
  diskOpacity = 0.12,
  diskStrokeColor = diskColor,
  showAxes = false,
  axisColor = 'currentColor',
  axisLabelColor = axisColor,
  axisTickCount = 5,
  editable = false,
  interactionMode = 'move',
  onPointsChange,
  promptForPoint,
  className,
  'aria-label': ariaLabel = 'Point cloud (2D)',
}: PointCloud2DProps) {
  const fittedProjection = useMemo(
    () => createProjection(points, width, height, padding, fitDiskRadii, projectionCenter),
    [points, width, height, padding, fitDiskRadii, projectionCenter],
  );
  const [dragging, setDragging] = useState<{
    index: number;
    pointerId: number;
    projection: Projection;
  } | null>(null);
  const [editing, setEditing] = useState<{ index: number; x: string; y: string } | null>(null);
  const [editorError, setEditorError] = useState('');
  const svgRef = useRef<SVGSVGElement>(null);
  const firstInputRef = useRef<HTMLInputElement>(null);
  const editorTitleId = useId();
  const projection = dragging?.projection ?? fittedProjection;
  const positions = useMemo(() => projectPoints(points, projection), [points, projection]);
  const xTicks = useMemo(
    () => createTicks(projection.minX, projection.maxX, axisTickCount),
    [projection.minX, projection.maxX, axisTickCount],
  );
  const yTicks = useMemo(
    () => createTicks(projection.minY, projection.maxY, axisTickCount),
    [projection.minY, projection.maxY, axisTickCount],
  );
  const canEdit = editable && Boolean(onPointsChange);
  const canMove = canEdit && interactionMode === 'move';
  const canPrompt = canEdit && interactionMode === 'edit';
  const radius = (index: number) =>
    pointRadius * (1 + Math.sqrt(Math.max(weights?.[index] ?? 0, 0)));

  const emitPoint = (index: number, point: readonly [number, number]) => {
    if (!onPointsChange) return;
    const next = [...points];
    next[index * 2] = point[0];
    next[index * 2 + 1] = point[1];
    onPointsChange(next);
  };

  const closeEditor = () => {
    const pointIndex = editing?.index;
    setEditing(null);
    setEditorError('');
    window.setTimeout(() => {
      if (pointIndex === undefined) return;
      svgRef.current
        ?.querySelector<SVGCircleElement>(`[data-point-index="${pointIndex}"]`)
        ?.focus();
    });
  };

  const editPoint = (index: number) => {
    if (!canEdit) return;
    const point: readonly [number, number] = [points[index * 2]!, points[index * 2 + 1]!];
    if (promptForPoint) {
      const edited = promptForPoint(point, index);
      if (edited) emitPoint(index, edited);
      return;
    }
    setEditorError('');
    setEditing({ index, x: String(point[0]), y: String(point[1]) });
  };

  const saveCoordinates = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!editing || editing.x.trim() === '' || editing.y.trim() === '') {
      setEditorError('Enter two finite numbers.');
      return;
    }
    const nextPoint: readonly [number, number] = [Number(editing.x), Number(editing.y)];
    if (nextPoint.some((value) => !Number.isFinite(value))) {
      setEditorError('Enter two finite numbers.');
      return;
    }
    emitPoint(editing.index, nextPoint);
    closeEditor();
  };

  const editingIndex = editing?.index;
  useEffect(() => {
    if (editingIndex === undefined) return;
    firstInputRef.current?.focus();
    firstInputRef.current?.select();
  }, [editingIndex]);

  const pointerPosition = (event: ReactPointerEvent<SVGSVGElement>): readonly [number, number] => {
    const bounds = svgRef.current!.getBoundingClientRect();
    return [
      ((event.clientX - bounds.left) / Math.max(bounds.width, 1)) * width,
      ((event.clientY - bounds.top) / Math.max(bounds.height, 1)) * height,
    ];
  };

  const handlePointerMove = (event: ReactPointerEvent<SVGSVGElement>) => {
    if (!dragging || event.pointerId !== dragging.pointerId) return;
    const [svgX, svgY] = pointerPosition(event);
    emitPoint(dragging.index, [
      dragging.projection.minX + (svgX - dragging.projection.offsetX) / dragging.projection.scale,
      dragging.projection.maxY - (svgY - dragging.projection.offsetY) / dragging.projection.scale,
    ]);
  };

  const stopDragging = (event: ReactPointerEvent<SVGSVGElement>) => {
    if (!dragging || event.pointerId !== dragging.pointerId) return;
    if (svgRef.current?.hasPointerCapture?.(event.pointerId))
      svgRef.current.releasePointerCapture?.(event.pointerId);
    setDragging(null);
  };

  const handleKeyDown = (event: ReactKeyboardEvent<SVGCircleElement>, index: number) => {
    if (!canPrompt || (event.key !== 'Enter' && event.key !== ' ')) return;
    event.preventDefault();
    editPoint(index);
  };

  const plotLeft = projection.offsetX;
  const plotRight =
    projection.offsetX + (projection.maxX - projection.minX || 1) * projection.scale;
  const plotTop = projection.offsetY;
  const plotBottom =
    projection.offsetY + (projection.maxY - projection.minY || 1) * projection.scale;
  const projectX = (value: number) =>
    projection.offsetX + (value - projection.minX) * projection.scale;
  const projectY = (value: number) =>
    projection.offsetY + (projection.maxY - value) * projection.scale;
  const yAxisX = Math.min(plotRight, Math.max(plotLeft, projectX(0)));
  const xAxisY = Math.min(plotBottom, Math.max(plotTop, projectY(0)));

  return (
    <>
      <svg
        ref={svgRef}
        role="img"
        aria-label={ariaLabel}
        viewBox={`0 0 ${width} ${height}`}
        width={width}
        height={height}
        className={className}
        data-empty={positions.length === 0 ? 'true' : undefined}
        data-editable={canEdit ? 'true' : undefined}
        data-interaction-mode={canEdit ? interactionMode : undefined}
        style={canMove ? { touchAction: 'none' } : undefined}
        onPointerMove={handlePointerMove}
        onPointerUp={stopDragging}
        onPointerCancel={stopDragging}
      >
        {showAxes && positions.length > 0 ? (
          <g aria-hidden="true" pointerEvents="none">
            <line
              data-testid="tda-axis"
              x1={plotLeft}
              y1={xAxisY}
              x2={plotRight}
              y2={xAxisY}
              stroke={axisColor}
              strokeOpacity={0.52}
              strokeWidth={0.8}
            />
            <line
              data-testid="tda-axis"
              x1={yAxisX}
              y1={plotTop}
              x2={yAxisX}
              y2={plotBottom}
              stroke={axisColor}
              strokeOpacity={0.52}
              strokeWidth={0.8}
            />
            {xTicks.values.map((value) => {
              const x = projectX(value);
              return (
                <g key={`x-${value}`}>
                  <line
                    data-testid="tda-axis-tick"
                    x1={x}
                    y1={xAxisY - 3}
                    x2={x}
                    y2={xAxisY + 3}
                    stroke={axisColor}
                    strokeOpacity={0.65}
                    strokeWidth={0.8}
                  />
                  <text
                    data-testid="tda-axis-label"
                    x={x}
                    y={Math.min(height - 2, xAxisY + 13)}
                    fill={axisLabelColor}
                    fillOpacity={0.78}
                    fontFamily="ui-monospace, monospace"
                    fontSize={8}
                    textAnchor="middle"
                  >
                    {formatTick(value, xTicks.step)}
                  </text>
                </g>
              );
            })}
            {yTicks.values.map((value) => {
              const y = projectY(value);
              return (
                <g key={`y-${value}`}>
                  <line
                    data-testid="tda-axis-tick"
                    x1={yAxisX - 3}
                    y1={y}
                    x2={yAxisX + 3}
                    y2={y}
                    stroke={axisColor}
                    strokeOpacity={0.65}
                    strokeWidth={0.8}
                  />
                  <text
                    data-testid="tda-axis-label"
                    x={Math.max(2, yAxisX - 6)}
                    y={y + 3}
                    fill={axisLabelColor}
                    fillOpacity={0.78}
                    fontFamily="ui-monospace, monospace"
                    fontSize={8}
                    textAnchor="end"
                  >
                    {formatTick(value, yTicks.step)}
                  </text>
                </g>
              );
            })}
            <text
              x={plotRight - 2}
              y={Math.max(9, xAxisY - 6)}
              fill={axisLabelColor}
              fillOpacity={0.85}
              fontFamily="ui-monospace, monospace"
              fontSize={9}
              textAnchor="end"
            >
              x
            </text>
            <text
              x={yAxisX}
              y={Math.max(9, plotTop - 6)}
              fill={axisLabelColor}
              fillOpacity={0.85}
              fontFamily="ui-monospace, monospace"
              fontSize={9}
              textAnchor="middle"
            >
              y
            </text>
          </g>
        ) : null}
        {positions.map(([cx, cy], index) => {
          const dataRadius = Math.max(0, diskRadii[index] ?? 0);
          if (dataRadius === 0) return null;
          return (
            <circle
              key={`disk-${index}`}
              data-testid="tda-disk"
              data-point-index={index}
              data-radius={dataRadius}
              cx={cx}
              cy={cy}
              r={dataRadius * projection.scale}
              fill={diskColor}
              fillOpacity={diskOpacity}
              stroke={diskStrokeColor}
              strokeOpacity={Math.min(1, diskOpacity * 3.5)}
              strokeWidth={0.9}
              pointerEvents="none"
            />
          );
        })}
        {edges.map((edge, index) => {
          const [source, target] = edge.vertices;
          const start = positions[source];
          const end = positions[target];
          if (!start || !end) return null;
          return (
            <line
              key={`${source}-${target}-${index}`}
              data-testid="tda-edge"
              data-filtration={edge.filtration}
              x1={start[0]}
              y1={start[1]}
              x2={end[0]}
              y2={end[1]}
              stroke={edgeColor}
              strokeWidth={edgeWidth}
              strokeOpacity={0.62}
            />
          );
        })}
        {positions.map(([cx, cy], index) => (
          <circle
            key={index}
            data-testid="tda-point"
            data-point-index={index}
            data-weight={weights?.[index] !== undefined ? String(weights[index]) : undefined}
            cx={cx}
            cy={cy}
            r={radius(index)}
            fill={color}
            stroke={canEdit ? '#0b5260' : undefined}
            strokeWidth={canEdit ? 1.2 : undefined}
            role={canPrompt ? 'button' : undefined}
            tabIndex={canPrompt ? 0 : undefined}
            aria-label={
              canEdit
                ? `Point ${index + 1}: ${points[index * 2]}, ${points[index * 2 + 1]}. ${canMove ? 'Drag to move.' : 'Click or press Enter to edit coordinates.'}`
                : undefined
            }
            style={
              canEdit
                ? {
                    cursor: canMove ? (dragging?.index === index ? 'grabbing' : 'grab') : 'pointer',
                  }
                : undefined
            }
            onPointerDown={
              canMove
                ? (event) => {
                    event.preventDefault();
                    svgRef.current?.setPointerCapture?.(event.pointerId);
                    setDragging({
                      index,
                      pointerId: event.pointerId,
                      projection: fittedProjection,
                    });
                  }
                : undefined
            }
            onClick={
              canPrompt
                ? (event) => {
                    if (event.detail <= 1) editPoint(index);
                  }
                : undefined
            }
            onKeyDown={canPrompt ? (event) => handleKeyDown(event, index) : undefined}
          />
        ))}
      </svg>
      {editing && typeof document !== 'undefined'
        ? createPortal(
            <div
              data-tda-coordinate-editor="true"
              onClick={closeEditor}
              style={{
                position: 'fixed',
                inset: 0,
                zIndex: 2147483647,
                padding: 16,
                display: 'grid',
                placeItems: 'center',
                background: 'var(--tda-coordinate-dialog-scrim, rgba(10, 15, 28, .78))',
                backdropFilter: 'blur(6px)',
              }}
            >
              <form
                role="dialog"
                aria-modal="true"
                aria-labelledby={editorTitleId}
                onSubmit={saveCoordinates}
                onClick={(event) => event.stopPropagation()}
                onKeyDown={(event) => {
                  if (event.key === 'Escape') {
                    event.preventDefault();
                    closeEditor();
                  }
                }}
                style={{
                  width: 'min(100%, 400px)',
                  minHeight: 252,
                  padding: 22,
                  boxSizing: 'border-box',
                  display: 'flex',
                  flexDirection: 'column',
                  border:
                    '1px solid var(--tda-coordinate-dialog-rule, var(--rule-on-ink, GrayText))',
                  borderRadius: 2,
                  color: 'var(--tda-coordinate-dialog-text, var(--text-on-ink, CanvasText))',
                  background: 'var(--tda-coordinate-dialog-bg, var(--ink-2, Canvas))',
                  fontFamily: 'var(--tda-coordinate-dialog-font, ui-sans-serif, sans-serif)',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'baseline',
                    justifyContent: 'space-between',
                    gap: 16,
                  }}
                >
                  <div>
                    <div
                      style={{
                        color: 'var(--tda-coordinate-dialog-dim, var(--text-on-ink-dim, GrayText))',
                        fontFamily: 'var(--tda-coordinate-dialog-mono, ui-monospace, monospace)',
                        fontSize: 10,
                        letterSpacing: '.12em',
                        textTransform: 'uppercase',
                      }}
                    >
                      Exact coordinate
                    </div>
                    <h2
                      id={editorTitleId}
                      style={{ margin: '6px 0 0', fontSize: 21, lineHeight: 1.15, fontWeight: 600 }}
                    >
                      Edit point {editing.index + 1}
                    </h2>
                  </div>
                  <div
                    aria-hidden="true"
                    style={{
                      color: 'var(--tda-coordinate-dialog-signal, var(--signal, Highlight))',
                      fontFamily: 'var(--tda-coordinate-dialog-mono, ui-monospace, monospace)',
                      fontSize: 13,
                    }}
                  >
                    (x, y)
                  </div>
                </div>
                <div
                  style={{
                    marginTop: 22,
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: 12,
                  }}
                >
                  <label
                    style={{
                      display: 'grid',
                      gap: 7,
                      color: 'var(--tda-coordinate-dialog-dim, var(--text-on-ink-dim, GrayText))',
                      fontFamily: 'var(--tda-coordinate-dialog-mono, ui-monospace, monospace)',
                      fontSize: 10,
                      letterSpacing: '.06em',
                      textTransform: 'uppercase',
                    }}
                  >
                    X coordinate
                    <input
                      ref={firstInputRef}
                      type="number"
                      step="any"
                      value={editing.x}
                      onChange={(event) => setEditing({ ...editing, x: event.target.value })}
                      style={{
                        minWidth: 0,
                        height: 42,
                        padding: '0 11px',
                        boxSizing: 'border-box',
                        border:
                          '1px solid var(--tda-coordinate-dialog-rule, var(--rule-on-ink, GrayText))',
                        borderRadius: 4,
                        outlineColor:
                          'var(--tda-coordinate-dialog-signal, var(--signal, Highlight))',
                        color: 'var(--tda-coordinate-dialog-text, var(--text-on-ink, FieldText))',
                        background: 'var(--tda-coordinate-dialog-field, var(--ink, Field))',
                        fontFamily: 'var(--tda-coordinate-dialog-mono, ui-monospace, monospace)',
                        fontSize: 13,
                        fontVariantNumeric: 'tabular-nums',
                      }}
                    />
                  </label>
                  <label
                    style={{
                      display: 'grid',
                      gap: 7,
                      color: 'var(--tda-coordinate-dialog-dim, var(--text-on-ink-dim, GrayText))',
                      fontFamily: 'var(--tda-coordinate-dialog-mono, ui-monospace, monospace)',
                      fontSize: 10,
                      letterSpacing: '.06em',
                      textTransform: 'uppercase',
                    }}
                  >
                    Y coordinate
                    <input
                      type="number"
                      step="any"
                      value={editing.y}
                      onChange={(event) => setEditing({ ...editing, y: event.target.value })}
                      style={{
                        minWidth: 0,
                        height: 42,
                        padding: '0 11px',
                        boxSizing: 'border-box',
                        border:
                          '1px solid var(--tda-coordinate-dialog-rule, var(--rule-on-ink, GrayText))',
                        borderRadius: 4,
                        outlineColor:
                          'var(--tda-coordinate-dialog-signal, var(--signal, Highlight))',
                        color: 'var(--tda-coordinate-dialog-text, var(--text-on-ink, FieldText))',
                        background: 'var(--tda-coordinate-dialog-field, var(--ink, Field))',
                        fontFamily: 'var(--tda-coordinate-dialog-mono, ui-monospace, monospace)',
                        fontSize: 13,
                        fontVariantNumeric: 'tabular-nums',
                      }}
                    />
                  </label>
                </div>
                <p
                  role={editorError ? 'alert' : undefined}
                  style={{
                    minHeight: 17,
                    margin: '9px 0 0',
                    color: 'var(--tda-coordinate-dialog-error, Mark)',
                    fontSize: 11,
                    lineHeight: 1.4,
                  }}
                >
                  {editorError}
                </p>
                <div
                  style={{ marginTop: 'auto', display: 'flex', justifyContent: 'flex-end', gap: 8 }}
                >
                  <button
                    type="button"
                    onClick={closeEditor}
                    style={{
                      minHeight: 38,
                      padding: '0 14px',
                      border:
                        '1px solid var(--tda-coordinate-dialog-rule, var(--rule-on-ink, GrayText))',
                      borderRadius: 4,
                      color: 'var(--tda-coordinate-dialog-text, var(--text-on-ink, ButtonText))',
                      background: 'transparent',
                      fontFamily: 'var(--tda-coordinate-dialog-mono, ui-monospace, monospace)',
                      fontSize: 10,
                      fontWeight: 600,
                      letterSpacing: '.05em',
                      textTransform: 'uppercase',
                      cursor: 'pointer',
                    }}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    style={{
                      minHeight: 38,
                      padding: '0 14px',
                      border:
                        '1px solid var(--tda-coordinate-dialog-signal, var(--signal, Highlight))',
                      borderRadius: 4,
                      color: 'var(--tda-coordinate-dialog-action-text, var(--ink, HighlightText))',
                      background: 'var(--tda-coordinate-dialog-signal, var(--signal, Highlight))',
                      fontFamily: 'var(--tda-coordinate-dialog-mono, ui-monospace, monospace)',
                      fontSize: 10,
                      fontWeight: 700,
                      letterSpacing: '.05em',
                      textTransform: 'uppercase',
                      cursor: 'pointer',
                    }}
                  >
                    Save coordinates
                  </button>
                </div>
              </form>
            </div>,
            document.body,
          )
        : null}
    </>
  );
}
