import { useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CIRCLE12_WING,
  CIRCLE24_ALPHA,
  RING6_BOX,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import type { Filtration } from '../filtration/types';
import { Field2D } from './Field2D';
import { Nerve2D } from './Nerve2D';
import { ScaleControl } from './ScaleControl';

/**
 * The scrubber for t. It replaces v1's EpsilonPlayhead because "ε" implies a
 * specific convention; this control names the convention it is scrubbing and
 * shows the ball radius the current t implies (a RANGE under weights, since
 * per-point radii differ) — or, for a non-ball filtration (ellipsoid, wing,
 * box), the scale value and that construction's own convention, because no
 * radius law exists to state. The ⟨ ⟩ buttons snap between criticalValues —
 * the filtration only changes at those values, and a continuous slider
 * skips over the moments that matter.
 *
 * Controlled; owns nothing. Scrubbing filters what is drawn — persistence
 * was computed once and already contains every t (SPEC §1.5).
 */
const meta = {
  title: '2D/ScaleControl',
  component: ScaleControl,
  tags: ['autodocs'],
} satisfies Meta<typeof ScaleControl>;

export default meta;
type Story = StoryObj<typeof meta>;

const circle = recordedFiltration(CIRCLE24_ALPHA);
const weighted = recordedFiltration(WEIGHTED3_ALPHA);
const rips = recordedFiltration(TRIANGLE_RIPS);
const wing = recordedFiltration(CIRCLE12_WING);
const box = recordedFiltration(RING6_BOX);

function Wired({ filtration, initial }: { filtration: Filtration; initial: number }) {
  const [t, setT] = useState(initial);
  return (
    <div style={{ width: 340, display: 'grid', gap: 8 }}>
      <div style={{ position: 'relative', width: 320 }}>
        <Field2D filtration={filtration} t={t} />
        <div style={{ position: 'absolute', top: 0, left: 0 }}>
          <Nerve2D filtration={filtration} t={t} />
        </div>
      </div>
      <ScaleControl filtration={filtration} t={t} onChange={setT} />
    </div>
  );
}

/** Alpha convention: t is squared radius, so the radius readout is √t here (w = 0). */
export const AlphaCircle: Story = {
  args: { filtration: circle, t: 0.3, onChange: () => {} },
  render: (args) => <Wired filtration={args.filtration} initial={args.t} />,
};

/**
 * Weighted cloud: the radius readout becomes a per-point RANGE — at t = 0
 * the lightest ball has radius 0 while the heavy one is already at √0.5.
 * The slider domain also starts at −0.5, because the heavy vertex enters the
 * filtration at t = −w.
 */
export const WeightedRange: Story = {
  args: { filtration: weighted, t: 0, onChange: () => {} },
  render: (args) => <Wired filtration={args.filtration} initial={args.t} />,
};

/** Rips: the readout shows radius t/2, the honest half of the edge-length index. */
export const RipsConvention: Story = {
  args: { filtration: rips, t: 1, onChange: () => {} },
  render: (args) => <Wired filtration={args.filtration} initial={args.t} />,
};

/**
 * Wing: a flag complex with no ball radius at all. The readout says so and
 * names the wing convention instead of stating a radius the shape has none of.
 */
export const WingHasNoRadius: Story = {
  args: { filtration: wing, t: 0.5, onChange: () => {} },
  render: (args) => <Wired filtration={args.filtration} initial={args.t} />,
};

/**
 * Box: another non-ball, and quantized besides. `--box-step` names t as
 * step·π; the readout states that convention rather than a radius.
 */
export const BoxHasNoRadius: Story = {
  args: { filtration: box, t: 1, onChange: () => {} },
  render: (args) => <Wired filtration={args.filtration} initial={args.t} />,
};

/** Uncontrolled display of the raw control (what the host app composes). */
export const Bare: Story = { args: { filtration: circle, t: 0.5, onChange: () => {} } };

/** Disabled while a host app is rebuilding a filtration — a real state. */
export const Disabled: Story = {
  args: { filtration: circle, t: 0.5, onChange: () => {}, disabled: true },
};
