/**
 * <ScaleControl> (SPEC.md §4.4): the scrubber for t. Replaces v1's
 * <EpsilonPlayhead>, because "ε" implies a specific convention and the
 * control must be honest about which one it is: it shows t, the convention,
 * the drawn radius that t implies, and snap-to-event buttons over the
 * filtration's criticalValues (the moments something actually changes).
 *
 * Controlled; owns nothing. Moving it changes what is DRAWN — persistence
 * was computed once and is already complete (SPEC.md §1.5).
 */
import { useMemo } from 'react';
import type { BallFiltration } from '../filtration/types';

export interface ScaleControlProps {
  /**
   * A BALL filtration: this control reads out the drawn RADIUS that t implies,
   * which only the ball conventions have (SPEC.md §1.3). The non-ball
   * constructions need their own readout, so they are a type error here rather
   * than a radius invented for a wing.
   */
  filtration: BallFiltration;
  t: number;
  onChange: (t: number) => void;
  label?: string;
  disabled?: boolean;
  className?: string;
  id?: string;
}

const CONVENTION_TEXT = {
  rips: 'Vietoris–Rips · t is edge length · ball radius t/2',
  cech: 'Čech · t is the ball radius',
  alpha: 'alpha · t is squared radius · ball radius √(t + wᵢ) per point',
} as const;

const fmt = (x: number) => x.toFixed(3);

export function ScaleControl({
  filtration,
  t,
  onChange,
  label = 'Scale',
  disabled = false,
  className,
  id = 'scale-control',
}: ScaleControlProps) {
  const { criticalValues, tMax, convention, cloud } = filtration;
  const tMin = Math.min(0, criticalValues.length > 0 ? criticalValues[0] : 0);
  const domain = tMax - tMin || 1;
  const clamped = Math.min(Math.max(t, tMin), tMax);

  const { nextCv, prevCv } = useMemo(() => {
    let next: number | null = null;
    let prev: number | null = null;
    for (const cv of criticalValues) {
      if (cv > clamped && next === null) next = cv;
      if (cv < clamped) prev = cv;
    }
    return { nextCv: next, prevCv: prev };
  }, [criticalValues, clamped]);

  // The radius the current t implies on screen. Per-point under weights:
  // show the range, because "the" radius does not exist for a weighted cloud.
  const radiusText = useMemo(() => {
    const n = cloud.weights.length;
    if (n === 0) return '—';
    let lo = Infinity;
    let hi = -Infinity;
    for (let i = 0; i < n; i++) {
      const r = filtration.radiusAt(i, clamped);
      if (r < lo) lo = r;
      if (r > hi) hi = r;
    }
    return hi - lo > 1e-12 ? `${fmt(lo)} – ${fmt(hi)} (per point)` : fmt(lo);
  }, [filtration, cloud, clamped]);

  return (
    <div className={className} data-testid="scale-control" data-convention={convention}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <label
          htmlFor={id}
          style={{ fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase' }}
        >
          {label}
        </label>
        <span
          data-testid="scale-control-t"
          style={{ fontFamily: 'ui-monospace, monospace', fontSize: 12 }}
        >
          t = {fmt(clamped)}
        </span>
      </div>

      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <button
          type="button"
          data-testid="scale-control-prev"
          aria-label="Snap to previous event"
          disabled={disabled || prevCv === null}
          onClick={() => prevCv !== null && onChange(prevCv)}
        >
          ⟨
        </button>
        <input
          id={id}
          type="range"
          min={tMin}
          max={tMax}
          step={domain / 200}
          value={clamped}
          disabled={disabled}
          aria-label={label}
          aria-valuetext={`t ${fmt(clamped)} (${convention} convention)`}
          onChange={(e) => onChange(Number.parseFloat(e.target.value))}
          style={{ flex: 1 }}
        />
        <button
          type="button"
          data-testid="scale-control-next"
          aria-label="Snap to next event"
          disabled={disabled || nextCv === null}
          onClick={() => nextCv !== null && onChange(nextCv)}
        >
          ⟩
        </button>
      </div>

      <p
        data-testid="scale-control-convention"
        style={{
          fontSize: 10,
          opacity: 0.7,
          margin: '4px 0 0',
          fontFamily: 'ui-monospace, monospace',
        }}
      >
        {CONVENTION_TEXT[convention]}
      </p>
      <p
        data-testid="scale-control-radius"
        style={{
          fontSize: 10,
          opacity: 0.7,
          margin: '2px 0 0',
          fontFamily: 'ui-monospace, monospace',
        }}
      >
        drawn radius at t: {radiusText}
      </p>
    </div>
  );
}
