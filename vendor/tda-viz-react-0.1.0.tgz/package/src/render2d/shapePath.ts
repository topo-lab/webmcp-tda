/**
 * The growing shape as SVG path data (SPEC.md §1.1, §4.1).
 *
 * One subpath per shape, all of them appended into ONE `<path>` that is filled
 * ONCE with `fill-rule: nonzero`. That is what makes the drawing the union
 * X_t = ⋃ᵢ S_i(t) rather than n translucent shapes: overlapping shapes filled
 * separately double-count their intersections, and the intersections are
 * exactly the regions the complex is about (SPEC.md §4.1, §8 Q4).
 *
 * Nothing here computes a scale law. Every function takes a `GrowingShape` that
 * `filtration.shapeAt(i, t)` already scaled to t (SPEC.md §3.1); this module
 * only projects and writes path commands. Re-deriving the scale here is how a
 * picture ends up disagreeing with the barcode beside it.
 *
 * WINDING. Under nonzero winding, two overlapping subpaths of OPPOSITE
 * orientation cancel and punch a hole. Circles, ellipses and rectangles are
 * emitted with a fixed handedness below. The wing hexagon's handedness is fixed
 * by the mathematics — its signed area is a continuous, nowhere-zero function
 * of the unit normal α, so it cannot change sign as α rotates — and the code
 * normalizes it anyway rather than resting the union on that argument.
 */
import type { GrowingShape } from '../filtration/types';
import type { Projection2D } from './project';

/** Round to 2 decimals: sub-pixel precision, much shorter path strings. */
const r2 = (v: number) => Math.round(v * 100) / 100;

/**
 * A full circle as two half arcs, `sweep-flag` 0 on both (one handedness for
 * every disc). `A` is used rather than a `<circle>` element so every shape kind
 * lands in the same single path.
 */
function circleSubpath(cx: number, cy: number, r: number): string {
  const x0 = r2(cx - r);
  const x1 = r2(cx + r);
  const y = r2(cy);
  const rr = r2(r);
  return `M${x0} ${y}A${rr} ${rr} 0 0 0 ${x1} ${y}A${rr} ${rr} 0 0 0 ${x0} ${y}Z`;
}

/**
 * A rotated full ellipse, as two half arcs with the same `sweep-flag` as the
 * disc above, so a mixed drawing could not cancel.
 *
 * `rotationDeg` is the on-screen rotation of the ellipse's first semi-axis. The
 * caller flips the sign of the data angle because SVG's y axis points down —
 * this is exactly what the engine's own review page does
 * (`examples/review/render2d.mjs`: `deg = -atan2(frame[0][1], frame[0][0])`).
 */
function ellipseSubpath(
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  rotationDeg: number,
): string {
  const rad = (rotationDeg * Math.PI) / 180;
  const dx = Math.cos(rad) * rx;
  const dy = Math.sin(rad) * rx;
  const x0 = r2(cx - dx);
  const y0 = r2(cy - dy);
  const x1 = r2(cx + dx);
  const y1 = r2(cy + dy);
  const a = `A${r2(rx)} ${r2(ry)} ${r2(rotationDeg)} 0 0`;
  return `M${x0} ${y0}${a} ${x1} ${y1}${a} ${x0} ${y0}Z`;
}

/** Signed area of a pixel-space polygon; sign is its handedness. */
function signedArea(pts: readonly (readonly [number, number])[]): number {
  let sum = 0;
  for (let i = 0; i < pts.length; i++) {
    const [x0, y0] = pts[i];
    const [x1, y1] = pts[(i + 1) % pts.length];
    sum += x0 * y1 - x1 * y0;
  }
  return sum / 2;
}

/**
 * A closed polygon, forced to negative signed area so it winds the same way as
 * the arcs above. Concavity is fine: a simple concave polygon has winding
 * number 1 throughout its interior, which is what the wing needs.
 */
function polygonSubpath(pts: readonly (readonly [number, number])[]): string {
  const ordered = signedArea(pts) > 0 ? [...pts].reverse() : pts;
  return ordered.map(([x, y], i) => `${i === 0 ? 'M' : 'L'}${r2(x)} ${r2(y)}`).join('') + 'Z';
}

/**
 * Subpath for one already-scaled shape, or `null` when the shape has no area at
 * this t — a ball of radius 0, a box that has not grown off its point yet. Null
 * is not "skip a detail": drawing a dot for a shape that does not exist yet
 * would be fiction, and the shapes are monotone in t so nothing that appears
 * ever disappears (SPEC.md §1.1).
 *
 * 3D clouds project by dropping z, matching `projectCloud` — an orthographic
 * top-down view. For a ball and for an axis-aligned box that projection is the
 * shape's exact silhouette. For a 3D ellipsoid it is NOT: the ellipse spanned
 * by `frame[0]`, `frame[1]` is a central slice, not the outline, so a 3D
 * ellipsoid filtration is refused by the caller rather than drawn as a slice
 * (see <Field2D>).
 */
export function shapeSubpath(shape: GrowingShape, projection: Projection2D): string | null {
  const { px, py, pxPerUnit } = projection;
  switch (shape.kind) {
    case 'ball': {
      const r = shape.radius * pxPerUnit;
      if (!(r > 0)) return null;
      return circleSubpath(px(shape.center[0]), py(shape.center[1]), r);
    }
    case 'ellipsoid': {
      const rx = shape.semiAxes[0] * pxPerUnit;
      const ry = shape.semiAxes[1] * pxPerUnit;
      if (!(rx > 0) || !(ry > 0)) return null;
      const frame0 = shape.frame[0];
      // Screen y points down, so the data angle flips sign.
      const deg = (-Math.atan2(frame0[1], frame0[0]) * 180) / Math.PI;
      return ellipseSubpath(px(shape.center[0]), py(shape.center[1]), rx, ry, deg);
    }
    case 'wing': {
      if (!(shape.wingLength > 0)) return null;
      return polygonSubpath(shape.outline.map((p) => [px(p[0]), py(p[1])] as const));
    }
    case 'box': {
      const x0 = px(shape.lower[0]);
      const x1 = px(shape.upper[0]);
      // py flips: the data upper bound is the smaller screen y.
      const y0 = py(shape.upper[1]);
      const y1 = py(shape.lower[1]);
      if (!(x1 - x0 > 0) || !(y1 - y0 > 0)) return null;
      return polygonSubpath([
        [x0, y0],
        [x1, y0],
        [x1, y1],
        [x0, y1],
      ]);
    }
  }
}

/**
 * The whole union at t, as one path string: `shapeAt` for every INPUT POINT
 * (SPEC.md §3.1 — shapes grow around input points in every construction the
 * engine offers, even where the complex's vertices are subsets).
 */
export function unionPath(
  shapeAt: (i: number, t: number) => GrowingShape,
  pointCount: number,
  t: number,
  projection: Projection2D,
): string {
  let d = '';
  for (let i = 0; i < pointCount; i++) {
    const sub = shapeSubpath(shapeAt(i, t), projection);
    if (sub) d += sub;
  }
  return d;
}
