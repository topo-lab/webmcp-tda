/**
 * <Field2D>: the space X_t itself — ⋃ᵢ S_i(t) as ONE merged region
 * (SPEC.md §4.1). This is the primary surface: the user moves t and watches the
 * space grow.
 *
 * WHATEVER SHAPE GROWS. The shape is whatever `filtration.shapeAt(i, t)`
 * returns, already scaled to t (SPEC.md §1.1): discs for the ball
 * constructions, ellipses fitted from a local PCA frame, the wing's concave
 * hexagon, axis-aligned boxes on the π grid. This component switches on
 * `shapeKind` exhaustively and re-derives no scale law — that re-derivation is
 * how a picture ends up disagreeing with the barcode beside it (SPEC.md §1.3).
 * Radii and semi-axes are PER POINT (SPEC.md §1.2): heavier points have larger
 * balls at every t.
 *
 * UNION, NOT n SHAPES. Every shape is one subpath of a single SVG `<path>`,
 * filled once with `fill-rule: nonzero`. n translucent shapes would
 * double-count every overlap, and the overlaps are exactly the regions the
 * complex is about. Declarative SVG rather than canvas (SPEC.md §8 Q1): one
 * merged path is one DOM node, so the node-count objection to SVG does not
 * apply, and rotated ellipses and concave hexagons are one path command each.
 *
 * WHAT IT WILL NOT DRAW. When `shapesAvailable` is false — today only a box
 * filtration built without its boxes — this draws no shapes and shows the
 * filtration's own reason (SPEC.md §1.6). A 3D ellipsoid filtration is refused
 * for a different reason: dropping z would draw the ellipse of frame[0],
 * frame[1], which is a central slice and not the ellipsoid's outline.
 *
 * Wings are always drawn, in both normal modes: `computeWingGeometry` hands back
 * the outline the builder used, including for normals the engine estimated from
 * k, so no shape here is ever a re-estimate. Which normal a hexagon came from
 * travels with it as `WingShape.normalSource`.
 *
 * The scale convention is read from the filtration and DISPLAYED — a picture
 * that does not name its convention can silently contradict the barcode.
 */
import { useMemo } from 'react';
import type { Filtration, RadiusConvention } from '../filtration/types';
import { projectCloud } from './project';
import { unionPath } from './shapePath';

export interface Field2DProps {
  /**
   * Any filtration. `shapeKind` decides what is drawn, and `shapeAt` supplies
   * it already scaled to t — so this surface never has to know which
   * construction produced the shape (SPEC.md §3.1).
   */
  filtration: Filtration;
  /** Current scale. Filters what is drawn; never triggers a recompute (SPEC.md §1.5). */
  t: number;
  width?: number;
  height?: number;
  padding?: number;
  color?: string;
  /** Uniform opacity of the union region. */
  opacity?: number;
  /** Outline of the union. Off by default: the region is the subject. */
  strokeColor?: string;
  className?: string;
  'aria-label'?: string;
}

/** What t means, per convention (SPEC.md §1.3). Displayed, never assumed. */
const CONVENTION_LABEL: Record<RadiusConvention, string> = {
  rips: 'Vietoris–Rips convention: t is edge length; ball radius t/2',
  cech: 'Čech convention: t is the ball radius; drawn directly',
  alpha: 'alpha convention: t is squared radius; ball radius √(t + wᵢ) per point',
  'ellipsoid-2r':
    'ellipsoid convention: t is TWICE the ellipsoid radius; semi-axes (t/2)·profile along the fitted frame',
  'wing-eps': 'wing convention: t is the wing scale ε; spine half-length q·t, wing edges t at ±θ',
  'box-step': 'box convention: t is step × π; the box drawn is the engine’s box at step ⌊t/π⌋',
};

/**
 * Why a drawing of the shapes would be dishonest, or null when it would not.
 * Two sources: the filtration says its geometry does not exist, or this
 * top-down 2D surface cannot show the shape without distorting it.
 */
function shapeRefusal(filtration: Filtration): string | null {
  if (!filtration.shapesAvailable) {
    return (
      filtration.shapesUnavailableReason ??
      'this filtration reports that its growing shapes are unavailable'
    );
  }
  if (filtration.shapeKind === 'ellipsoid' && filtration.cloud.dimension === 3) {
    return (
      'a 3D ellipsoid does not project to the ellipse of frame[0], frame[1]: that is a ' +
      'central slice, not the outline. The complex is drawn; use <Field3D> from ' +
      'tda-viz-react/3d for the shapes.'
    );
  }
  return null;
}

export function Field2D({
  filtration,
  t,
  width = 320,
  height = 320,
  padding = 16,
  color = '#2563eb',
  opacity = 0.28,
  strokeColor,
  className,
  'aria-label': ariaLabel = 'Union of the growing shapes at the current scale',
}: Field2DProps) {
  const { cloud, convention, shapeKind } = filtration;

  const projection = useMemo(
    () => projectCloud(cloud.points, cloud.dimension, width, height, padding),
    [cloud, width, height, padding],
  );

  const refusal = shapeRefusal(filtration);

  // ONE path string for the whole union. Rebuilt when t moves — which is
  // display work on a finished filtration, never a recompute (SPEC.md §1.5).
  const d = useMemo(() => {
    if (refusal) return '';
    const pointCount = cloud.points.length / cloud.dimension;
    return unionPath((i, at) => filtration.shapeAt(i, at), pointCount, t, projection);
  }, [filtration, cloud, t, projection, refusal]);

  return (
    <div
      className={className}
      data-testid="field-2d"
      data-convention={convention}
      data-shape-kind={shapeKind}
      data-shapes-drawn={refusal ? 'false' : 'true'}
    >
      <svg
        role="img"
        aria-label={ariaLabel}
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        style={{ display: 'block' }}
      >
        {d && (
          <path
            data-testid="field-2d-union"
            d={d}
            fill={color}
            fillOpacity={opacity}
            // nonzero, never evenodd: under even-odd every overlap would punch
            // a hole in the union (SPEC.md §4.1).
            fillRule="nonzero"
            stroke={strokeColor ?? 'none'}
            strokeWidth={strokeColor ? 0.8 : 0}
          />
        )}
      </svg>
      <p
        data-testid="field-2d-convention"
        style={{
          fontSize: 10,
          opacity: 0.65,
          margin: '4px 0 0',
          fontFamily: 'ui-monospace, monospace',
        }}
      >
        {CONVENTION_LABEL[convention]}
      </p>
      {refusal && (
        <p
          data-testid="field-2d-shapes-unavailable"
          style={{
            fontSize: 10,
            color: '#b45309',
            margin: '2px 0 0',
            fontFamily: 'ui-monospace, monospace',
          }}
        >
          shapes not drawn: {refusal}
        </p>
      )}
    </div>
  );
}
