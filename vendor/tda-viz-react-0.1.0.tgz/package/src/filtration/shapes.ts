/**
 * The scale laws: what the growing shape looks like at t (SPEC.md §1.1, §1.3).
 *
 * Pure functions, exported so a renderer can reuse the exact arithmetic the
 * filtration uses instead of re-deriving it (that re-derivation is how a
 * picture ends up disagreeing with the homology beside it). Each one is
 * monotone in t, so nothing ever shrinks as t grows.
 *
 * HEADLESS layer: no renderer imports (SPEC.md §2).
 */
import type { BallConvention } from './types';

/** Ball radius at t (SPEC.md §1.3). `weight` is 0 for unweighted points. */
export function ballRadiusAt(convention: BallConvention, t: number, weight: number): number {
  switch (convention) {
    case 'rips':
      return Math.max(t, 0) / 2;
    case 'cech':
      return Math.max(t, 0);
    case 'alpha':
      // Squared radius t + wᵢ (SPEC.md §1.2). A vertex enters the filtration
      // at t = -wᵢ; below that its ball does not exist yet, so the radius
      // clamps to 0 rather than going imaginary. The k-fold cover reaches this
      // branch with weight 0, giving √t.
      return Math.sqrt(Math.max(t + weight, 0));
  }
}

/**
 * Ellipsoid semi-axis LENGTHS at t, from the unit profile of
 * `computeEllipsoidGeometry`.
 *
 * The engine's filtration values are TWICE the birth radius (the
 * Rips-comparable scale), so at value t the ellipsoid has semi-axes
 * (t/2)·semiAxes — tda-wasm `EllipsoidGeometry`, verbatim.
 */
export function ellipsoidSemiAxesAt(unitSemiAxes: readonly number[], t: number): number[] {
  const scale = Math.max(t, 0) / 2;
  return unitSemiAxes.map((a) => scale * a);
}

/**
 * The (q, θ)-wing outline at scale ε = t: a concave hexagon, one polygon per
 * point, in outline order A, B, C, D, C', B'.
 *
 * NOT a re-derivation. `unitOutline` is the outline tda-wasm's
 * `computeWingGeometry` returns — the six offsets of the same `unit_wing()` the
 * birth solver intersects, with the build's q and θ already baked in — and the
 * whole of the scale law is
 *
 *     vertex[v][d] = center[d] + max(t, 0) · unitOutline[v][d]
 *
 * because the wing is homothetic about x (the homothety-monotonicity note in
 * `wing_complex.hpp`). Rebuilding the hexagon here from (q, θ, α) would be a
 * second implementation of the engine's geometry, and a picture that disagrees
 * with the barcode by one sign is exactly what that duplication produces.
 *
 * At t ≤ 0 every vertex collapses onto the point: a wing that has not grown yet
 * is not drawn (SPEC.md §1.1), it is not flipped.
 *
 * @param center 2D point x, copied through from the engine record
 * @param unitOutline the engine's six unit-scale offsets from x
 */
export function wingOutlineAt(
  center: readonly number[],
  unitOutline: readonly (readonly number[])[],
  t: number,
): number[][] {
  const eps = Math.max(t, 0);
  return unitOutline.map((offset) => offset.map((component, d) => center[d] + eps * component));
}

/**
 * Which grown box to draw at t: the last COMPLETED growth step, i.e. the
 * largest j with j·π ≤ t, clamped to [0, steps].
 *
 * Boxes exist only on the grid (tda-wasm `BoxFiltrationResult.boxes`), so
 * this is a lookup, not an interpolation — an interpolated box would be a
 * shape the filtration never contained. Monotone in t, hence X_s ⊆ X_t
 * (SPEC.md §1.1).
 */
export function boxStepAt(t: number, step: number, steps: number): number {
  if (!(t > 0)) return 0;
  // Grid values arrive as sums of doubles, so j·π can land a hair under t's
  // own representation; nudge before flooring so t = j·π selects step j.
  const raw = Math.floor(t / step + 1e-9);
  return Math.min(Math.max(raw, 0), steps);
}
