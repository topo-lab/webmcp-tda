/**
 * The filtration layer contract (SPEC.md §3.1) — the central abstraction.
 *
 * v2 of this contract generalises the shape that grows. v1 assumed every
 * complex grows a BALL around every input point, which three of the engine's
 * constructions simply do not: the ellipsoid complexes grow ellipsoids from a
 * local PCA frame, the wing complex grows a concave hexagon around an
 * estimated normal, and the box filtration grows an axis-aligned box in whole
 * steps of π. A fourth, the k-fold cover, keeps balls but moves the vertices:
 * a vertex of the order-k mosaic is a k-SUBSET of the input, not a point.
 *
 * So the contract now carries, per filtration:
 *   - `shapeKind` + `shapeAt(i, t)`: the growing shape at scale t, already
 *     scaled (SPEC.md §1.1). `radiusAt` survives, on ball filtrations only.
 *   - `unitShape(i)` (ellipsoid, wing) and `boxesAtStep(step)` (box): the same
 *     geometry BEFORE t scales it, for renderers that upload once and scale on
 *     the GPU (SPEC.md §1.5). A shape law lives in this layer either way.
 *   - `guarantee`: machine-readable 'nerve' | 'flag' plus the exact chip text
 *     (SPEC.md §1.4). Labelling is the library's job, not the consumer's.
 *   - `quantization`: non-null exactly when filtration values live on a grid
 *     (the box filtration), so an axis can say so and nobody compares two
 *     diagrams at different π.
 *   - `vertexKind` / `vertexSubsets` / `vertexPositions`: vertex identity, so
 *     a renderer can place the k-fold mosaic honestly.
 *
 * HEADLESS: this layer imports nothing from playcanvas/three/d3 (enforced
 * by ESLint `no-restricted-imports` and src/__tests__/lintBoundary.test.ts).
 */
import type { EllipsoidAxesMode, PersistencePair, Simplex, WingNormalSource } from 'tda-wasm';

export type { WingNormalSource };

/** A point cloud with per-point weights. Unweighted = all zeros (SPEC.md §1.2). */
export interface WeightedCloud {
  /** Flat coordinates, length n·dimension. */
  points: number[];
  /** One weight per point; all 0 for unweighted. Must be ≥ 0 (engine constraint). */
  weights: number[];
  dimension: 2 | 3;
}

/**
 * Conventions whose growing shape is a BALL, so a single radius describes it
 * (SPEC.md §1.3):
 *
 *   rips  — t is edge length; ball radius t/2
 *   cech  — t is the ball radius; drawn directly
 *   alpha — t is squared radius; ball radius √(t + wᵢ), per point
 *
 * The k-fold cover shares the `alpha` convention: its filtration values are
 * squared radii too and it refuses weighted input, so the drawn radius is
 * √t exactly. What differs there is vertex identity, not the radius law —
 * see `vertexKind`.
 */
export type BallConvention = 'rips' | 'cech' | 'alpha';

/**
 * Conventions whose growing shape is NOT a ball, so no radius describes it
 * (SPEC.md §1.3):
 *
 *   ellipsoid-2r — t is TWICE the ellipsoid radius (the Rips-comparable scale
 *                  the engine emits); semi-axes are (t/2)·profile along the
 *                  fitted frame. Both ellipsoid complexes use it, so their
 *                  values are comparable to each other and to a Rips edge
 *                  length — but NOT to `computeCechComplex`, which emits the
 *                  radius itself (halve these to compare).
 *   wing-eps     — t is the wing scale ε itself: spine half-length q·t,
 *                  wing edges of length t at ±θ.
 *   box-step     — t is step·π: the box at t is the box of the last completed
 *                  growth step, and every filtration value is a multiple of π
 *                  (see `quantization`).
 */
export type ShapeConvention = 'ellipsoid-2r' | 'wing-eps' | 'box-step';

/**
 * Which geometry the picture draws at scale t (SPEC.md §1.3). Naming it is
 * mandatory: a wrong scale law silently produces a picture that disagrees
 * with the homology beside it. The name is historical — it is the scale
 * convention, and only three of its members imply a radius.
 */
export type RadiusConvention = BallConvention | ShapeConvention;

/** Which of the engine's constructions produced a filtration. */
export type FiltrationComplexType =
  'rips' | 'cech' | 'alpha' | 'kfold' | 'ellipsoid-rips' | 'ellipsoid-cech' | 'wing' | 'box';

// ── The growing shape (SPEC.md §1.1) ─────────────────────────────────────

export type GrowingShapeKind = 'ball' | 'ellipsoid' | 'wing' | 'box';

/** B(pᵢ, r) — the v1 case, still the common one. */
export interface BallShape {
  readonly kind: 'ball';
  /** Centre, length `cloud.dimension`: the input point itself. */
  readonly center: readonly number[];
  /** Radius at t under the filtration's convention. Never negative. */
  readonly radius: number;
}

/**
 * The anisotropic ellipsoid of `computeEllipsoidGeometry`, scaled to t.
 *
 * Point x lies inside iff Σₐ (⟨x − center, frame[a]⟩ / semiAxes[a])² ≤ 1.
 */
export interface EllipsoidShape {
  readonly kind: 'ellipsoid';
  /** Centre: the input point itself, not the neighbourhood mean. */
  readonly center: readonly number[];
  /** Orthonormal local frame, one row per axis, descending local variance. */
  readonly frame: readonly (readonly number[])[];
  /** Semi-axis LENGTHS at t — already scaled by t/2, not the unit profile. */
  readonly semiAxes: readonly number[];
}

/**
 * The (q, θ)-wing at scale ε = t: a concave hexagon in R², two parallelograms
 * sharing the normal spine.
 *
 * EXACT, not a transcription. Every vertex is `center + t · unitOutline[v]`,
 * where `unitOutline` is the outline tda-wasm's `computeWingGeometry` returns —
 * the same `unit_wing()` the birth solver intersects. This library does not
 * re-derive the hexagon from (q, θ, α); that re-derivation is the drift the
 * geometry API exists to prevent.
 *
 * Outline order is the engine's: A, B, C, D, C', B', with
 * A = x + q t α and D = x − q t α the spine endpoints and B/C/B'/C' the wing
 * corners at ±θ from the spine direction −α (osculating-centre side).
 */
export interface WingShape {
  readonly kind: 'wing';
  /** x, the input point. */
  readonly center: readonly number[];
  /** α, the unit normal the complex was built with (Eq. 3.1). */
  readonly normal: readonly number[];
  /**
   * How `normal` was obtained, straight from the engine. `'supplied'` is an
   * exact caller-provided normal; `'osculating'` is the engine's own
   * circle fit; `'tangent'` means the fit was singular or the |κ| clamp fired,
   * so the wing is drawn from a weaker estimate. A reviewer should be able to
   * see which, because a wing is exactly as trustworthy as the normal that
   * produced its births.
   */
  readonly normalSource: WingNormalSource;
  /** Spine half-length q·t. */
  readonly spineHalfLength: number;
  /** Wing-edge length t. */
  readonly wingLength: number;
  /** Wing angle θ, radians, in (0, π/2]. */
  readonly theta: number;
  /** The concave hexagon, in outline order A, B, C, D, C', B'. */
  readonly outline: readonly (readonly number[])[];
}

/**
 * One grown axis-aligned box of the box filtration — an EXACT engine record,
 * not an interpolation. Boxes exist only on the grid, so the shape at t is
 * the box of step ⌊t/π⌋ (`step` below), which is what makes the filtration
 * monotone in t.
 */
export interface BoxShape {
  readonly kind: 'box';
  readonly lower: readonly number[];
  readonly upper: readonly number[];
  /** The growth step this box belongs to: t rounded DOWN to the π grid. */
  readonly step: number;
}

export type GrowingShape = BallShape | EllipsoidShape | WingShape | BoxShape;

// ── The UNSCALED shape (SPEC.md §1.1: the shapes are homothetic in t) ─────

/**
 * The t-INVARIANT geometry of a homothetic shape: everything about S_i that does
 * not move when t does. `unitShape(i)` returns it, and `shapeAt(i, t)` is this
 * record scaled by t under the filtration's convention (§1.3).
 *
 * This exists because a GPU renderer uploads per-instance data ONCE and scales
 * it in the vertex shader from a `t` uniform (SPEC.md §1.5), so it needs the
 * unscaled record. Recovering it by evaluating `shapeAt` at the t where the
 * scale factor happens to be 1 works — it is exact under `ellipsoid-2r` at
 * t = 2 — but it is a trick that encodes the scale law at the call site, which
 * is the one thing this layer exists to keep in one place.
 *
 * Only the two homothetic-with-a-frame shapes have one. A ball's t-invariant
 * data is its centre and weight, which `cloud` already carries and `radiusAt`
 * already interprets; a box has no unit shape at all, because boxes are grown
 * per step rather than scaled — see `BoxFiltration.boxesAtStep`.
 */
export interface EllipsoidProfile {
  readonly kind: 'ellipsoid';
  /** Centre: the input point itself. */
  readonly center: readonly number[];
  /** The FIXED orthonormal frame, one row per axis, descending local variance. */
  readonly frame: readonly (readonly number[])[];
  /**
   * The UNIT semi-axis profile the engine fitted: descending, `semiAxes[0] === 1`.
   * `shapeAt(i, t).semiAxes[a] === (t/2) · semiAxes[a]` exactly (§1.3).
   */
  readonly semiAxes: readonly number[];
}

/** The wing at unit scale: the engine's own six offsets, before any scaling. */
export interface WingProfile {
  readonly kind: 'wing';
  /** x, the input point. */
  readonly center: readonly number[];
  /** α, the unit normal the complex was built with (Eq. 3.1). */
  readonly normal: readonly number[];
  /** Where `normal` came from. See `WingShape.normalSource`. */
  readonly normalSource: WingNormalSource;
  /**
   * Radius of the fitted osculating circle, `1 / |κ|`. `Infinity` when nothing
   * was fitted (supplied normals) or the fit was singular.
   */
  readonly curvatureRadius: number;
  /**
   * Mean distance to the k nearest neighbours — the length scale the engine's
   * |κ| clamp compares `curvatureRadius` against, so the ratio of the two shows
   * how close this point came to the `'tangent'` fallback. `Infinity` for
   * supplied normals.
   */
  readonly neighborhoodScale: number;
  /**
   * Six offsets from `center` at unit scale, order A, B, C, D, C', B'. The
   * `q` and `theta` of the build are already baked in, so
   * `shapeAt(i, t).outline[v][d] === center[d] + max(t, 0) · outline[v][d]`.
   */
  readonly outline: readonly (readonly number[])[];
}

/** The unscaled shape of whichever filtration has one. */
export type UnitShape = EllipsoidProfile | WingProfile;

// ── Honest labelling (SPEC.md §1.4) ──────────────────────────────────────

/**
 * What the complex on screen IS, mechanically checkable:
 *
 *   'nerve' — a nerve lemma applies, so the complex is homotopy equivalent to
 *             the union of the shapes at every scale.
 *   'flag'  — the flag complex of the pairwise-intersection graph. A simplex
 *             here is NOT a claim that its shapes share a common point.
 */
export type ComplexGuaranteeKind = 'nerve' | 'flag';

/**
 * The guarantee a filtration carries. `label` is the exact chip text, fixed
 * by tda-wasm SPEC FR-6 and asserted verbatim by tests: inflating a flag
 * complex to a nerve (or downgrading the box filtration's nerve) is a spec
 * violation, not a wording preference.
 */
export interface ComplexGuarantee {
  readonly kind: ComplexGuaranteeKind;
  readonly label: string;
}

// ── Quantization (SPEC.md §1.3) ──────────────────────────────────────────

/**
 * Present when filtration values are grid values rather than measurements —
 * the box filtration, whose boxes grow in whole steps of π.
 *
 * A renderer must say so: a bar of length π is one step long, and a
 * bottleneck distance between diagrams at different π mostly measures the
 * grids (tda-wasm `computeBoxFiltration`, "QUANTIZATION").
 */
export interface FiltrationQuantization {
  /** π: the growth increment AND the filtration grid spacing. */
  readonly step: number;
  /** m: the number of steps taken. Values live in {0, π, …, m·π}. */
  readonly steps: number;
}

/** Vertex identity (SPEC.md §3.1): what a vertex id of `simplices` means. */
export type VertexKind = 'point' | 'subset';

// ── The filtration ───────────────────────────────────────────────────────

/**
 * Everything every filtration carries. Built ONCE per (cloud, weights,
 * params); queried every animation frame. Moving t filters what is drawn —
 * it never recomputes (SPEC.md §1.5).
 *
 * Two index spaces, deliberately separate:
 *   - INPUT POINT i ∈ [0, n): what `shapeAt` and `radiusAt` take. The shapes
 *     grow around input points in every construction the engine offers.
 *   - VERTEX v ∈ [0, vertexCount): what `simplices[].vertices` contain, and
 *     what `vertexPosition` takes. Equal to the point index unless
 *     `vertexKind` is 'subset' (the k-fold cover).
 */
interface FiltrationBase {
  readonly cloud: WeightedCloud;
  readonly convention: RadiusConvention;
  readonly complexType: FiltrationComplexType;
  /** Machine-readable guarantee + the exact chip text (SPEC.md §1.4). */
  readonly guarantee: ComplexGuarantee;
  readonly maxSimplexDimension: number;

  /** All simplices with their filtration values, sorted ascending. */
  readonly simplices: readonly Simplex[];
  /** Persistence pairs, Nerve-filtered (SPEC.md §1.6). Computed once. */
  readonly pairs: readonly PersistencePair[];
  /** Raw pairs before filtering, for inspection only. */
  readonly rawPairs: readonly PersistencePair[];
  /** Largest finite filtration value present. */
  readonly tMax: number;
  /** Events: the distinct filtration values, for snapping t to changes. */
  readonly criticalValues: readonly number[];
  /** Non-null exactly when filtration values are grid values (box). */
  readonly quantization: FiltrationQuantization | null;

  /** Which shape grows. Discriminates this union. */
  readonly shapeKind: GrowingShapeKind;
  /**
   * False when the engine did not hand over the geometry needed to draw the
   * shape honestly, in which case `shapeAt` THROWS instead of inventing it. One
   * case remains: a box filtration built with `retainBoxes: false`, whose boxes
   * the engine never returned. A renderer checks this once and draws the complex
   * alone rather than a fabricated shape.
   *
   * The wing used to be the other case. It is not any more: `computeWingGeometry`
   * returns the wings the builder actually used — including the normals it
   * estimated internally from k — so every wing filtration is drawable, exactly,
   * and provenance travels with each wing as `WingShape.normalSource` instead of
   * as a refusal.
   */
  readonly shapesAvailable: boolean;
  /** Why `shapesAvailable` is false, for display. Null when it is true. */
  readonly shapesUnavailableReason: string | null;

  /** What a vertex id means. */
  readonly vertexKind: VertexKind;
  /** Number of distinct vertex ids the complex uses. */
  readonly vertexCount: number;
  /**
   * `vertexSubsets[v]` is the sorted k-subset of INPUT indices that vertex v
   * stands for. Non-null exactly when `vertexKind` is 'subset'.
   */
  readonly vertexSubsets: readonly (readonly number[])[] | null;
  /**
   * Flat drawing positions of the vertices, length vertexCount·dimension —
   * the input points themselves, or the barycentre of each subset for the
   * k-fold mosaic. Allocation-free for renderers.
   */
  readonly vertexPositions: readonly number[];
  /** Position of vertex v, length `cloud.dimension`. */
  vertexPosition(v: number): readonly number[];

  /** Simplices present at t: filtration ≤ t. O(log n) via the sorted array. */
  simplicesAt(t: number): readonly Simplex[];
  /** Classes alive at t: birth ≤ t < death. */
  aliveAt(t: number): readonly PersistencePair[];
  /** Betti numbers at t, honesty-sliced to resolvable degrees. */
  bettiAt(t: number): number[];
}

/**
 * A filtration that grows balls: rips, Čech, (weighted) alpha, and the k-fold
 * cover, whose balls sit on the input points while its vertices are subsets.
 */
export interface BallFiltration extends FiltrationBase {
  readonly shapeKind: 'ball';
  readonly convention: BallConvention;
  readonly shapesAvailable: true;
  readonly shapesUnavailableReason: null;
  /** Ball radius of input point i at t, per §1.3. Never NaN (weights ≥ 0). */
  radiusAt(i: number, t: number): number;
  shapeAt(i: number, t: number): BallShape;
}

/** A filtration that grows ellipsoids: ellipsoid-rips and ellipsoid-Čech. */
export interface EllipsoidFiltration extends FiltrationBase {
  readonly shapeKind: 'ellipsoid';
  readonly convention: 'ellipsoid-2r';
  readonly shapesAvailable: true;
  readonly shapesUnavailableReason: null;
  /** The fitting the complex itself used, so shapes and complex agree. */
  readonly ellipsoid: {
    /** k, the local PCA neighbourhood (counts the point itself). */
    readonly neighborhoodSize: number;
    /** Tangent-to-normal ratio q ≥ 1, or 'pca' for local singular values. */
    readonly axesMode: EllipsoidAxesMode;
  };
  shapeAt(i: number, t: number): EllipsoidShape;
  /** The fitted ellipsoid before t scales it (frame + UNIT profile). */
  unitShape(i: number): EllipsoidProfile;
}

/** A filtration that grows 2D wings (flag / Rips-type, never a nerve). */
export interface WingFiltration extends FiltrationBase {
  readonly shapeKind: 'wing';
  readonly convention: 'wing-eps';
  readonly shapesAvailable: true;
  readonly shapesUnavailableReason: null;
  readonly wing: {
    /** Spine half-length / wing-length ratio q ∈ [0, 1]. */
    readonly q: number;
    /** Wing angle θ ∈ (0, π/2], radians. */
    readonly theta: number;
    /**
     * Flat unit normals, length 2n: the ones the builder ACTUALLY used, read
     * back from `computeWingGeometry`. Supplied normals come back normalised;
     * estimated ones come back as the engine fitted them. Feeding this array
     * back in as `normals` rebuilds the identical complex.
     */
    readonly normals: readonly number[];
    /**
     * Per point, where its normal came from. Present so a caller can see at a
     * glance how much of a cloud fell back to the PCA tangent — those wings are
     * drawn from a weaker estimate, and so are their births.
     */
    readonly normalSources: readonly WingNormalSource[];
  };
  shapeAt(i: number, t: number): WingShape;
  /** The engine's unit wing: six offsets from the point, with (q, θ) baked in. */
  unitShape(i: number): WingProfile;
}

/** A filtration that grows axis-aligned boxes on a π grid. */
export interface BoxFiltration extends FiltrationBase {
  readonly shapeKind: 'box';
  readonly convention: 'box-step';
  /** Always non-null here: box values ARE grid values. */
  readonly quantization: FiltrationQuantization;
  readonly box: {
    /** Growth aggressiveness the boxes were grown with. */
    readonly alpha: number;
    /** Last step at which an edge was born: the last interesting scale. */
    readonly maxBirthStep: number;
  };
  shapeAt(i: number, t: number): BoxShape;
  /**
   * Every grown box of ONE step, in input-point order — the engine hands back
   * `(steps + 1) × n` records and this is one of its rows.
   *
   * A renderer that uploads all steps once (the GPU path: resident geometry,
   * `uStep = ⌊t/π⌋` selecting which instances draw) wants them a step at a time;
   * without this it has to call `shapeAt(i, s · π)` in a double loop and rely on
   * the step arithmetic coming out right at every call site. `step` is an index
   * into `[0, quantization.steps]`, not a t value.
   *
   * Throws when `shapesAvailable` is false (`retainBoxes: false`), exactly as
   * `shapeAt` does.
   */
  boxesAtStep(step: number): readonly BoxShape[];
}

/**
 * The filtration as a queryable object (SPEC.md §3.1), discriminated by
 * `shapeKind`. A renderer that draws shapes switches on it exhaustively;
 * a renderer that draws balls takes `BallFiltration` and cannot be handed a
 * wing by mistake.
 */
export type Filtration = BallFiltration | EllipsoidFiltration | WingFiltration | BoxFiltration;
