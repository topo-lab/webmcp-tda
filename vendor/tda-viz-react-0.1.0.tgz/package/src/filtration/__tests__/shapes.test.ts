// @vitest-environment node
//
// The scale laws (SPEC.md §1.1, §1.3): what the growing shape looks like at t.
// Every law must be monotone in t — a display that shrinks as t grows is lying
// about the filtration.
//
// The wing law is now a SCALING of the engine's own unit outline
// (`computeWingGeometry`), so what is testable here is the scaling and nothing
// about the hexagon's construction: the shape of the wing is the engine's fact,
// checked against the real engine in the integration suites. The offsets below
// are recorded engine output for exactly that reason.
import { describe, expect, it } from 'vitest';
import { CIRCLE12_WING } from '../../__fixtures__/realFiltrations';
import { ballRadiusAt, boxStepAt, ellipsoidSemiAxesAt, wingOutlineAt } from '../shapes';

describe('ballRadiusAt: one law per ball convention (SPEC.md §1.3)', () => {
  it('rips: t is edge length, so the radius is t/2 (two balls touch at t)', () => {
    expect(ballRadiusAt('rips', 1, 0)).toBeCloseTo(0.5, 12);
    expect(ballRadiusAt('rips', 0.4, 0)).toBeCloseTo(0.2, 12);
  });

  it('cech: t IS the radius', () => {
    expect(ballRadiusAt('cech', 0.75, 0)).toBeCloseTo(0.75, 12);
  });

  it('alpha: t is a squared radius, per point via the weight', () => {
    expect(ballRadiusAt('alpha', 0, 0.5)).toBeCloseTo(Math.sqrt(0.5), 12);
    expect(ballRadiusAt('alpha', 0.5, 0.5)).toBeCloseTo(1, 12);
    // The k-fold cover reaches this branch unweighted: radius = √t.
    expect(ballRadiusAt('alpha', 0.36, 0)).toBeCloseTo(0.6, 12);
  });

  it('never goes imaginary or negative below a vertex birth', () => {
    expect(ballRadiusAt('alpha', -1, 0)).toBe(0);
    expect(ballRadiusAt('rips', -1, 0)).toBe(0);
    expect(ballRadiusAt('cech', -1, 0)).toBe(0);
  });

  it('is non-decreasing in t for every convention (SPEC.md §1.1)', () => {
    for (const convention of ['rips', 'cech', 'alpha'] as const) {
      let previous = -Infinity;
      for (let t = -1; t <= 3; t += 0.125) {
        const r = ballRadiusAt(convention, t, 0.25);
        expect(r).toBeGreaterThanOrEqual(previous);
        previous = r;
      }
    }
  });
});

describe('ellipsoidSemiAxesAt: t is TWICE the radius (tda-wasm EllipsoidGeometry)', () => {
  const profile = [1, 0.5];

  it('scales the unit profile by t/2, so t = 2 gives the profile itself', () => {
    expect(ellipsoidSemiAxesAt(profile, 2)).toEqual([1, 0.5]);
    expect(ellipsoidSemiAxesAt(profile, 1)).toEqual([0.5, 0.25]);
    expect(ellipsoidSemiAxesAt(profile, 0.4)).toEqual([0.2, 0.1]);
  });

  it('keeps the axis RATIO fixed: only the scale moves with t', () => {
    const a = ellipsoidSemiAxesAt(profile, 0.7);
    const b = ellipsoidSemiAxesAt(profile, 2.3);
    expect(a[0] / a[1]).toBeCloseTo(b[0] / b[1], 12);
  });

  it('collapses to a point at t <= 0 instead of inverting', () => {
    expect(ellipsoidSemiAxesAt(profile, 0)).toEqual([0, 0]);
    expect(ellipsoidSemiAxesAt(profile, -3)).toEqual([0, 0]);
  });
});

describe('wingOutlineAt: the engine\u2019s unit outline, scaled by t', () => {
  // Recorded computeWingGeometry output for point 0 of the 12-point circle
  // fixture (q = 1/3, \u03b8 = \u03c0/2): the six offsets A, B, C, D, C\u2032, B\u2032 that the
  // birth solver itself intersects.
  const record = CIRCLE12_WING.wing.geometry[0];
  const center = record.point;
  const unit = record.outline;

  it('is exactly center + t\u00b7offset, to double precision, at every vertex', () => {
    // The property the geometry API exists for: no re-derivation stands between
    // the engine's outline and the polygon on screen, so this is `toBe` and not
    // `toBeCloseTo`.
    for (const t of [0.25, 0.5, 1, 2.75]) {
      const outline = wingOutlineAt(center, unit, t);
      expect(outline).toHaveLength(6);
      outline.forEach((vertex, v) => {
        expect(vertex).toHaveLength(2);
        for (let d = 0; d < 2; d++) {
          expect(vertex[d]).toBe(center[d] + t * unit[v][d]);
        }
      });
    }
  });

  it('is homothetic about x: the wing at 2t is the wing at t scaled by 2', () => {
    // wing_complex.hpp's homothety-monotonicity note, which is what makes
    // pairwise births single values and the filtration a filtration.
    const one = wingOutlineAt(center, unit, 0.5);
    const two = wingOutlineAt(center, unit, 1);
    for (let v = 0; v < 6; v++) {
      for (let d = 0; d < 2; d++) {
        expect(two[v][d]).toBeCloseTo(center[d] + 2 * (one[v][d] - center[d]), 12);
      }
    }
  });

  it('degenerates to the point itself at t <= 0 rather than flipping', () => {
    for (const t of [0, -1]) {
      for (const vertex of wingOutlineAt(center, unit, t)) {
        expect(vertex).toEqual([...center]);
      }
    }
  });

  it('carries no shape law of its own: zero offsets draw the point', () => {
    // Nothing in this function knows what a wing looks like. Hand it six zero
    // offsets and it returns six copies of the point \u2014 the hexagon is the
    // engine's fact and this is only the scaling.
    const zeros = Array.from({ length: 6 }, () => [0, 0]);
    for (const vertex of wingOutlineAt([2, 5], zeros, 3)) {
      expect(vertex).toEqual([2, 5]);
    }
  });
});

describe('boxStepAt: the box at t is the box of the LAST COMPLETED step', () => {
  it('selects step j exactly at the grid value j\u00b7\u03c0', () => {
    expect(boxStepAt(0, 0.25, 5)).toBe(0);
    expect(boxStepAt(0.25, 0.25, 5)).toBe(1);
    expect(boxStepAt(0.5, 0.25, 5)).toBe(2);
    expect(boxStepAt(1.25, 0.25, 5)).toBe(5);
  });

  it('rounds DOWN between grid values: never a box the filtration never had', () => {
    expect(boxStepAt(0.24, 0.25, 5)).toBe(0);
    expect(boxStepAt(0.49, 0.25, 5)).toBe(1);
  });

  it('clamps below 0 and above the last step, so nothing ever shrinks', () => {
    expect(boxStepAt(-4, 0.25, 5)).toBe(0);
    expect(boxStepAt(99, 0.25, 5)).toBe(5);
  });

  it('is non-decreasing in t', () => {
    let previous = -1;
    for (let t = -0.5; t < 2; t += 0.05) {
      const step = boxStepAt(t, 0.25, 5);
      expect(step).toBeGreaterThanOrEqual(previous);
      previous = step;
    }
  });

  it('survives the float sum of grid values (3 \u00d7 0.1 is not 0.3)', () => {
    const step = 0.1;
    expect(boxStepAt(step + step + step, step, 10)).toBe(3);
  });
});
