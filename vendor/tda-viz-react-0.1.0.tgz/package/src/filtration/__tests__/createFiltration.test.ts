// @vitest-environment node
//
// The Filtration object (SPEC.md §3.1): built once, queried per frame.
// Every fixture here is recorded output of the REAL engine
// (src/__fixtures__/realFiltrations.ts) — no invented simplices or pairs.
import { describe, expect, it } from 'vitest';
import {
  CIRCLE24_ALPHA,
  CIRCLE50_RIPS_CAP2,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';

const weighted = () => recordedFiltration(WEIGHTED3_ALPHA);
const circleAlpha = () => recordedFiltration(CIRCLE24_ALPHA);
const triRips = () => recordedFiltration(TRIANGLE_RIPS);
const triCech = () => recordedFiltration(TRIANGLE_CECH);
const honesty = () => recordedFiltration(CIRCLE50_RIPS_CAP2);

describe('createFiltration: simplices', () => {
  it('exposes simplices sorted ascending by filtration value', () => {
    const f = weighted();
    for (let i = 1; i < f.simplices.length; i++) {
      expect(f.simplices[i].filtration).toBeGreaterThanOrEqual(f.simplices[i - 1].filtration);
    }
  });

  it('keeps every engine simplex (never drops, never invents)', () => {
    const f = weighted();
    expect(f.simplices).toHaveLength(WEIGHTED3_ALPHA.simplices.length);
  });
});

describe('createFiltration: radiusAt (SPEC.md §1.3 — one test per convention)', () => {
  it('rips: t is edge length, radius is t/2', () => {
    const f = triRips();
    expect(f.convention).toBe('rips');
    expect(f.radiusAt(0, 1)).toBeCloseTo(0.5, 10);
    expect(f.radiusAt(2, 0.4)).toBeCloseTo(0.2, 10);
  });

  it('cech: t is the ball radius, radius is t', () => {
    const f = triCech();
    expect(f.convention).toBe('cech');
    expect(f.radiusAt(0, 0.5)).toBeCloseTo(0.5, 10);
    expect(f.radiusAt(1, 0.57735)).toBeCloseTo(0.57735, 10);
  });

  it('alpha: t is squared radius, radius is sqrt(t + w_i) PER POINT', () => {
    const f = weighted();
    expect(f.convention).toBe('alpha');
    // At t = 0 the heavy point (w = 0.5) already has radius sqrt(0.5); the
    // light points are still points. This is SPEC.md §7 story 2's opening frame.
    expect(f.radiusAt(0, 0)).toBeCloseTo(Math.sqrt(0.5), 10);
    expect(f.radiusAt(1, 0)).toBe(0);
    expect(f.radiusAt(2, 0)).toBe(0);
    expect(f.radiusAt(0, 0.5)).toBeCloseTo(1, 10);
    expect(f.radiusAt(1, 0.5)).toBeCloseTo(Math.sqrt(0.5), 10);
  });

  it('alpha: never NaN — a ball not yet born (t < -w_i) has radius 0', () => {
    const f = weighted();
    // The weighted vertex enters the filtration at t = -w (GUDHI convention);
    // below a light point's birth the radius is 0, not imaginary.
    expect(f.radiusAt(1, -0.25)).toBe(0);
    expect(f.radiusAt(0, -0.25)).toBeCloseTo(Math.sqrt(0.25), 10);
  });

  it('rips/cech: negative t clamps to radius 0, never negative', () => {
    expect(triRips().radiusAt(0, -1)).toBe(0);
    expect(triCech().radiusAt(0, -1)).toBe(0);
  });
});

describe('createFiltration: simplicesAt', () => {
  it('returns exactly the simplices with filtration <= t (inclusive)', () => {
    const f = triCech();
    expect(f.simplicesAt(-1)).toHaveLength(0);
    expect(f.simplicesAt(0)).toHaveLength(3); // vertices
    expect(f.simplicesAt(0.4999)).toHaveLength(3);
    expect(f.simplicesAt(0.5)).toHaveLength(6); // + 3 edges, boundary inclusive
    expect(f.simplicesAt(0.577)).toHaveLength(6);
    expect(f.simplicesAt(0.57735)).toHaveLength(7); // + the triangle
    expect(f.simplicesAt(99)).toHaveLength(7);
  });

  it('is monotone: moving t forward never removes a simplex (SPEC.md §1.1)', () => {
    const f = circleAlpha();
    let prev = 0;
    for (const t of f.criticalValues) {
      const count = f.simplicesAt(t).length;
      expect(count).toBeGreaterThan(prev);
      prev = count;
    }
    expect(prev).toBe(f.simplices.length);
  });

  it('memoizes per-frame queries: same t yields the same array instance', () => {
    const f = circleAlpha();
    expect(f.simplicesAt(0.5)).toBe(f.simplicesAt(0.5));
  });
});

describe('createFiltration: pairs and honesty (SPEC.md §1.6)', () => {
  it('nerve-filters pairs: the 150 real spurious H2 pairs are in rawPairs, not pairs', () => {
    const f = honesty();
    expect(f.rawPairs.filter((p) => p.dimension === 2)).toHaveLength(150);
    expect(f.pairs.filter((p) => p.dimension === 2)).toHaveLength(0);
    expect(f.pairs.filter((p) => p.dimension === 0)).toHaveLength(50);
    expect(f.pairs.filter((p) => p.dimension === 1)).toHaveLength(1);
  });

  it('aliveAt: birth <= t < death, death-exclusive', () => {
    const f = weighted();
    // t = 0: both light components (die 0.657556 / 0.765625) + the essential one.
    expect(f.aliveAt(0)).toHaveLength(3);
    // Immediately at a death value the class is gone.
    const alive = f.aliveAt(0.657556);
    expect(alive.some((p) => p.death === 0.657556)).toBe(false);
    expect(alive).toHaveLength(2);
    // t = 0.9: essential component + the loop (born 0.89, dies 1.085557).
    const at09 = f.aliveAt(0.9);
    expect(at09).toHaveLength(2);
    expect(at09.some((p) => p.dimension === 1)).toBe(true);
  });

  it('aliveAt includes essential classes at every t past their birth', () => {
    const f = weighted();
    expect(f.aliveAt(1e9).filter((p) => p.death === Infinity)).toHaveLength(1);
  });

  it('bettiAt is honesty-sliced: a 2D cloud at cap 2 never reports a beta_2', () => {
    const f = honesty();
    const betti = f.bettiAt(0.6);
    expect(betti).toEqual([1, 1]);
    expect(betti).toHaveLength(2); // beta_2 withheld, not zeroed
  });

  it('bettiAt tracks the filtration through time', () => {
    const f = weighted();
    expect(f.bettiAt(0)).toEqual([3, 0]);
    expect(f.bettiAt(0.8)).toEqual([1, 0]);
    expect(f.bettiAt(0.9)).toEqual([1, 1]);
    expect(f.bettiAt(1.2)).toEqual([1, 0]);
  });
});

describe('createFiltration: criticalValues and tMax', () => {
  it('criticalValues are the distinct filtration values, sorted', () => {
    const f = triCech();
    expect([...f.criticalValues]).toEqual([0, 0.5, 0.57735]);
  });

  it('weighted vertices enter at t = -w: criticalValues include negative t', () => {
    const f = weighted();
    expect(f.criticalValues[0]).toBe(-0.5);
  });

  it('tMax is the largest finite filtration value', () => {
    expect(triCech().tMax).toBeCloseTo(0.57735, 6);
    expect(weighted().tMax).toBeCloseTo(1.085557, 6);
  });

  it('stepping through criticalValues changes the complex exactly once per step (SPEC.md §7 story 4)', () => {
    const f = circleAlpha();
    const cvs = f.criticalValues;
    for (let i = 1; i < cvs.length; i++) {
      const before = f.simplicesAt(cvs[i - 1]).length;
      // Nothing changes strictly between two critical values...
      const mid = (cvs[i - 1] + cvs[i]) / 2;
      expect(f.simplicesAt(mid).length).toBe(before);
      // ...and something changes AT each critical value.
      expect(f.simplicesAt(cvs[i]).length).toBeGreaterThan(before);
    }
  });
});

describe('createFiltration: empty cloud is a real state', () => {
  it('handles zero simplices and zero pairs without inventing anything', () => {
    const f = recordedFiltration({
      name: 'EMPTY',
      cloud: { points: [], weights: [], dimension: 2 },
      complexType: 'rips',
      convention: 'rips',
      maxSimplexDimension: 2,
      simplices: [],
      rawPairs: [],
    });
    expect(f.simplices).toHaveLength(0);
    expect(f.pairs).toHaveLength(0);
    expect(f.simplicesAt(1)).toHaveLength(0);
    expect(f.aliveAt(1)).toHaveLength(0);
    expect(f.bettiAt(1)).toEqual([0, 0]);
    expect(f.tMax).toBe(0);
    expect(f.criticalValues).toHaveLength(0);
  });
});
