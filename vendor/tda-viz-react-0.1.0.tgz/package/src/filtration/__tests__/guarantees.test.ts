// @vitest-environment node
//
// Honest labelling is a LIBRARY guarantee, not a consumer's job (SPEC.md §1.4).
// The chip text is fixed by tda-wasm SPEC FR-6 and is asserted here character
// for character: inflating a flag complex to a nerve, or downgrading the box
// filtration's nerve, is a spec violation and must fail the build.
import { describe, expect, it } from 'vitest';
import {
  COMPLEX_GUARANTEES,
  FLAG_COMPLEX_TYPES,
  NERVE_COMPLEX_TYPES,
  complexGuarantee,
} from '../guarantees';
import type { FiltrationComplexType } from '../types';

const ALL_TYPES: FiltrationComplexType[] = [
  'rips',
  'cech',
  'alpha',
  'kfold',
  'ellipsoid-rips',
  'ellipsoid-cech',
  'wing',
  'box',
];

describe('COMPLEX_GUARANTEES: the exact chip text (tda-wasm SPEC FR-6, verbatim)', () => {
  it.each([
    ['rips', 'flag', 'flag complex (Rips-type)'],
    ['ellipsoid-rips', 'flag', 'flag complex (Rips-type)'],
    ['wing', 'flag', 'flag complex (Rips-type)'],
    ['cech', 'nerve', 'true nerve (Cech)'],
    ['ellipsoid-cech', 'nerve', 'true nerve (ellipsoidal Cech)'],
    ['kfold', 'nerve', 'exact (order-k Delaunay nerve)'],
    ['box', 'nerve', 'nerve (= flag, by Helly for boxes); step-quantized'],
    ['alpha', 'nerve', 'alpha complex (exact combinatorics)'],
  ] as const)('%s is a %s labelled "%s"', (complexType, kind, label) => {
    const guarantee = complexGuarantee(complexType);
    expect(guarantee.kind).toBe(kind);
    expect(guarantee.label).toBe(label);
  });

  it('covers every complex type the library can build, with no extras', () => {
    expect(Object.keys(COMPLEX_GUARANTEES).sort()).toEqual([...ALL_TYPES].sort());
    for (const t of ALL_TYPES) expect(complexGuarantee(t)).toBeDefined();
  });

  it('is frozen: a consumer cannot relabel a construction at runtime', () => {
    expect(Object.isFrozen(COMPLEX_GUARANTEES)).toBe(true);
    expect(Object.isFrozen(COMPLEX_GUARANTEES.rips)).toBe(true);
  });
});

describe('a flag complex is NEVER labelled a nerve (SPEC.md §1.4)', () => {
  it.each(FLAG_COMPLEX_TYPES)('%s carries kind "flag"', (complexType) => {
    expect(complexGuarantee(complexType).kind).toBe('flag');
  });

  it.each(FLAG_COMPLEX_TYPES)('%s never says "nerve", "Cech" or "exact" in its label', (t) => {
    // Pairwise intersection is strictly weaker than a common point, so a
    // triangle here is not a claim about three shapes overlapping. Any of
    // these words in the chip would be that claim.
    const { label } = complexGuarantee(t);
    expect(label).not.toMatch(/nerve/i);
    expect(label).not.toMatch(/[čc]ech/i);
    expect(label).not.toMatch(/exact/i);
  });

  it('partitions the menu: every type is either flag or nerve, never both', () => {
    const flag = new Set<string>(FLAG_COMPLEX_TYPES);
    const nerve = new Set<string>(NERVE_COMPLEX_TYPES);
    for (const t of ALL_TYPES) {
      expect(flag.has(t) !== nerve.has(t)).toBe(true);
      expect(complexGuarantee(t).kind).toBe(flag.has(t) ? 'flag' : 'nerve');
    }
  });
});

describe('the box filtration keeps BOTH halves of its tag', () => {
  it('says nerve AND says step-quantized — the quantization half is not optional', () => {
    const { kind, label } = complexGuarantee('box');
    expect(kind).toBe('nerve');
    expect(label).toContain('nerve');
    expect(label).toContain('Helly');
    expect(label).toContain('step-quantized');
  });
});
