// @vitest-environment node
//
// The v2 filtration record over the whole complex menu (SPEC.md §3.1, §5):
// growing shapes that are not balls, vertices that are not points, and
// filtration values that live on a grid.
//
// Every fixture here is recorded output of the REAL engine
// (src/__fixtures__/realFiltrations.ts) — no invented simplices, no invented
// geometry, no invented normals.
import { describe, expect, it } from 'vitest';
import type { WingGeometry } from 'tda-wasm';
import {
  CIRCLE12_WING,
  CIRCLE12_WING_ESTIMATED_NORMALS,
  ELLIPSE_ELLIPSOID_CECH,
  ELLIPSE_ELLIPSOID_RIPS,
  JITTERED8_KFOLD2,
  RING6_BOX,
  TRIANGLE_RIPS,
  type RecordedWingFiltration,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { createFiltration } from '../createFiltration';

const ellipsoidFlag = () => recordedFiltration(ELLIPSE_ELLIPSOID_RIPS);
const ellipsoidNerve = () => recordedFiltration(ELLIPSE_ELLIPSOID_CECH);
const wing = () => recordedFiltration(CIRCLE12_WING);
const wingEstimated = () => recordedFiltration(CIRCLE12_WING_ESTIMATED_NORMALS);
const box = () => recordedFiltration(RING6_BOX);
const kfold = () => recordedFiltration(JITTERED8_KFOLD2);

describe('the record labels itself: guarantee, convention, shape kind', () => {
  it.each([
    ['ellipsoid-rips', ellipsoidFlag, 'flag', 'ellipsoid-2r', 'ellipsoid'],
    ['ellipsoid-cech', ellipsoidNerve, 'nerve', 'ellipsoid-2r', 'ellipsoid'],
    ['wing', wing, 'flag', 'wing-eps', 'wing'],
    ['box', box, 'nerve', 'box-step', 'box'],
    ['kfold', kfold, 'nerve', 'alpha', 'ball'],
  ] as const)(
    '%s: %s guarantee, %s convention, %s shape',
    (type, make, kind, convention, shape) => {
      const f = make();
      expect(f.complexType).toBe(type);
      expect(f.guarantee.kind).toBe(kind);
      expect(f.convention).toBe(convention);
      expect(f.shapeKind).toBe(shape);
    },
  );

  it('carries the verbatim chip text so a renderer never composes one', () => {
    expect(ellipsoidFlag().guarantee.label).toBe('flag complex (Rips-type)');
    expect(ellipsoidNerve().guarantee.label).toBe('true nerve (ellipsoidal Cech)');
    expect(wing().guarantee.label).toBe('flag complex (Rips-type)');
    expect(box().guarantee.label).toBe('nerve (= flag, by Helly for boxes); step-quantized');
    expect(kfold().guarantee.label).toBe('exact (order-k Delaunay nerve)');
  });
});

describe('radiusAt exists for balls ONLY (SPEC.md §1.3)', () => {
  it('is present on every ball filtration, including the k-fold cover', () => {
    const rips = recordedFiltration(TRIANGLE_RIPS);
    expect(typeof rips.radiusAt).toBe('function');
    expect(typeof kfold().radiusAt).toBe('function');
  });

  it('is ABSENT on ellipsoid, wing and box filtrations — no radius exists there', () => {
    for (const f of [ellipsoidFlag(), wing(), box()]) {
      expect('radiusAt' in f).toBe(false);
    }
  });
});

describe('ellipsoid filtrations: per-point frame and semi-axes, scaled to t', () => {
  it('grows the engine\u2019s own fitted ellipsoid: semi-axes (t/2)\u00b7profile', () => {
    const f = ellipsoidFlag();
    const fitted = ELLIPSE_ELLIPSOID_RIPS.ellipsoid.geometry[3];
    for (const t of [0.4, 1, 2, 3.2]) {
      const shape = f.shapeAt(3, t);
      expect(shape.kind).toBe('ellipsoid');
      expect(shape.center).toEqual(fitted.center);
      expect(shape.frame).toEqual(fitted.frame);
      shape.semiAxes.forEach((a, axis) => {
        expect(a).toBeCloseTo((t / 2) * fitted.semiAxes[axis], 12);
      });
    }
  });

  it('is anisotropic: the two semi-axes differ, and their ratio is t-invariant', () => {
    const f = ellipsoidFlag();
    const small = f.shapeAt(2, 0.5);
    const large = f.shapeAt(2, 2.5);
    expect(small.semiAxes[0]).toBeGreaterThan(small.semiAxes[1]);
    expect(small.semiAxes[0] / small.semiAxes[1]).toBeCloseTo(
      large.semiAxes[0] / large.semiAxes[1],
      12,
    );
  });

  it('centres on the input point, not on the neighbourhood mean', () => {
    const f = ellipsoidFlag();
    const { points } = f.cloud;
    for (const i of [0, 5, 11]) {
      const shape = f.shapeAt(i, 1);
      expect(shape.center[0]).toBeCloseTo(points[i * 2], 6);
      expect(shape.center[1]).toBeCloseTo(points[i * 2 + 1], 6);
    }
  });

  it('exposes the UNSCALED profile, which is what a GPU renderer uploads', () => {
    const f = ellipsoidFlag();
    ELLIPSE_ELLIPSOID_RIPS.ellipsoid.geometry.forEach((fitted, i) => {
      const unit = f.unitShape(i);
      expect(unit.kind).toBe('ellipsoid');
      expect(unit.center).toEqual(fitted.center);
      expect(unit.frame).toEqual(fitted.frame);
      // The engine's UNIT profile: descending, first axis 1, nothing scaled.
      expect(unit.semiAxes).toEqual(fitted.semiAxes);
      expect(unit.semiAxes[0]).toBe(1);
      // And the law that connects the two, which is why `shapeAt(i, 2)` used to
      // be able to stand in for this: (t/2)·profile at t = 2 IS the profile.
      expect(f.shapeAt(i, 2).semiAxes).toEqual([...unit.semiAxes]);
      for (const t of [0.4, 1.3]) {
        f.shapeAt(i, t).semiAxes.forEach((a, axis) => {
          expect(a).toBeCloseTo((t / 2) * unit.semiAxes[axis], 12);
        });
      }
    });
  });

  it('never shrinks as t grows (SPEC.md §1.1)', () => {
    const f = ellipsoidFlag();
    let previous = -1;
    for (let t = 0; t < 3; t += 0.25) {
      const a = f.shapeAt(0, t).semiAxes[0];
      expect(a).toBeGreaterThanOrEqual(previous);
      previous = a;
    }
  });

  it('shares the scale with the flag variant, and the nerve is never earlier', () => {
    // Same ellipsoids, same 2 x radius convention (tda-wasm: the 1-skeletons are
    // bit-identical, and from dimension 2 up the nerve is a SUBCOMPLEX of the
    // flag complex with births no earlier). Comparable value for value only
    // because both carry the same convention.
    const flag = ellipsoidFlag();
    const nerve = ellipsoidNerve();
    expect(nerve.convention).toBe(flag.convention);
    const flagBirth = new Map(
      flag.simplices.map((s) => [[...s.vertices].sort((a, b) => a - b).join(','), s.filtration]),
    );
    let strictlyLater = 0;
    for (const s of nerve.simplices) {
      const key = [...s.vertices].sort((a, b) => a - b).join(',');
      const flagValue = flagBirth.get(key);
      expect(flagValue).toBeDefined();
      expect(s.filtration).toBeGreaterThanOrEqual(flagValue! - 1e-9);
      if (s.filtration > flagValue! + 1e-9) strictlyLater++;
    }
    // The whole point of the nerve variant: some simplices really are later.
    expect(strictlyLater).toBeGreaterThan(0);
  });
});

describe('wing filtrations: the engine\u2019s own hexagon, scaled', () => {
  /** Recorded geometry with Infinity restored, exactly as createFiltration takes it. */
  const geometryOf = (rec: RecordedWingFiltration): WingGeometry[] =>
    rec.wing.geometry.map((g) => ({
      ...g,
      curvatureRadius: g.curvatureRadius ?? Infinity,
      neighborhoodScale: g.neighborhoodScale ?? Infinity,
    }));

  const fromGeometry = (geometry: WingGeometry[]) =>
    createFiltration({
      ...CIRCLE12_WING,
      rawPairs: [],
      wing: { q: CIRCLE12_WING.wing.q, theta: CIRCLE12_WING.wing.theta, geometry },
    });

  it('grows a six-vertex outline around the normal the complex was built with', () => {
    const f = wing();
    expect(f.wing.q).toBeCloseTo(1 / 3, 12);
    expect(f.wing.theta).toBeCloseTo(Math.PI / 2, 12);

    for (const t of [0.25, 0.5, 1]) {
      const shape = f.shapeAt(0, t);
      expect(shape.kind).toBe('wing');
      expect(shape.outline).toHaveLength(6);
      expect(shape.wingLength).toBeCloseTo(t, 12);
      expect(shape.spineHalfLength).toBeCloseTo(t / 3, 12);
      expect(shape.theta).toBeCloseTo(Math.PI / 2, 12);
      // Point 0 of the circle fixture is (1, 0) with the exact outward normal.
      expect(shape.center).toEqual([1, 0]);
      expect(shape.normal[0]).toBeCloseTo(1, 9);
      expect(shape.normal[1]).toBeCloseTo(0, 9);
      // A = x + q t alpha, D = x - q t alpha, read off the engine's outline.
      expect(shape.outline[0][0]).toBeCloseTo(1 + t / 3, 12);
      expect(shape.outline[3][0]).toBeCloseTo(1 - t / 3, 12);
    }
  });

  it('draws EXACTLY point + eps\u00b7outline[v] from the engine, to double precision', () => {
    // The reason computeWingGeometry exists: the polygon on screen is the
    // engine's unit wing scaled, with nothing re-derived in between. Bit
    // equality, not a tolerance \u2014 a tolerance here would hide a second
    // implementation of the hexagon.
    for (const rec of [CIRCLE12_WING, CIRCLE12_WING_ESTIMATED_NORMALS]) {
      const f = recordedFiltration(rec);
      for (const eps of [0.2, 0.5, 1, 3]) {
        rec.wing.geometry.forEach((g, i) => {
          const outline = f.shapeAt(i, eps).outline;
          expect(outline).toHaveLength(6);
          outline.forEach((vertex, v) => {
            for (let d = 0; d < 2; d++) {
              expect(vertex[d]).toBe(g.point[d] + eps * g.outline[v][d]);
            }
          });
        });
      }
    }
  });

  it('exposes the unit wing itself, so a renderer can scale it on the GPU', () => {
    const f = wing();
    CIRCLE12_WING.wing.geometry.forEach((g, i) => {
      const unit = f.unitShape(i);
      expect(unit.kind).toBe('wing');
      expect([...unit.center]).toEqual(g.point);
      expect([...unit.normal]).toEqual(g.normal);
      expect(unit.outline.map((o) => [...o])).toEqual(g.outline);
      // The scaled shape is this record times eps, by construction.
      const eps = 0.7;
      f.shapeAt(i, eps).outline.forEach((vertex, v) => {
        for (let d = 0; d < 2; d++) {
          expect(vertex[d]).toBe(unit.center[d] + eps * unit.outline[v][d]);
        }
      });
    });
  });

  it('reports where each normal came from, supplied or fitted', () => {
    const exact = wing();
    const estimated = wingEstimated();
    // Same cloud, same q and theta: the only difference is provenance.
    expect(new Set(exact.wing.normalSources)).toEqual(new Set(['supplied']));
    expect(new Set(estimated.wing.normalSources)).toEqual(new Set(['osculating']));
    expect(exact.shapeAt(0, 1).normalSource).toBe('supplied');
    expect(estimated.shapeAt(0, 1).normalSource).toBe('osculating');
    // Nothing was fitted for a supplied normal, so there is no curvature to
    // report; the estimated build carries both numbers the |kappa| clamp
    // compares, which is how a reviewer sees how close it came to the fallback.
    expect(exact.unitShape(0).curvatureRadius).toBe(Infinity);
    expect(exact.unitShape(0).neighborhoodScale).toBe(Infinity);
    expect(estimated.unitShape(0).curvatureRadius).toBeGreaterThan(0);
    expect(Number.isFinite(estimated.unitShape(0).neighborhoodScale)).toBe(true);
  });

  it('hands back the UNIT normals the builder used, in one flat array', () => {
    const f = wingEstimated();
    expect(f.wing.normals).toHaveLength(24);
    for (let i = 0; i < 12; i++) {
      expect(Math.hypot(f.wing.normals[i * 2], f.wing.normals[i * 2 + 1])).toBeCloseTo(1, 9);
    }
  });

  it('draws BOTH normal modes: an estimated normal is a weaker normal, not no shape', () => {
    for (const f of [wing(), wingEstimated()]) {
      expect(f.shapesAvailable).toBe(true);
      expect(f.shapesUnavailableReason).toBeNull();
      expect(() => f.shapeAt(0, 1)).not.toThrow();
      // The COMPLEX was always usable; now the shape is too.
      expect(f.simplices.length).toBeGreaterThan(0);
      expect(f.pairs.length).toBeGreaterThan(0);
    }
  });

  it('refuses geometry that is not six finite offsets, instead of a NaN polygon', () => {
    const withOutline = (outline: number[][]) => {
      const geometry = geometryOf(CIRCLE12_WING);
      geometry[0] = { ...geometry[0], outline };
      return () => fromGeometry(geometry);
    };
    expect(withOutline([[1, 0]])).toThrow(/6 finite 2D outline offsets/i);
    expect(withOutline(Array.from({ length: 6 }, () => [Number.NaN, 0]))).toThrow(
      /6 finite 2D outline offsets/i,
    );
  });

  it('refuses geometry recorded against a different cloud', () => {
    const geometry = geometryOf(CIRCLE12_WING);
    geometry[3] = { ...geometry[3], point: [geometry[3].point[0] + 0.5, geometry[3].point[1]] };
    expect(() => fromGeometry(geometry)).toThrow(/built from different clouds/i);
  });

  it('refuses a geometry array that does not cover every input point', () => {
    expect(() => fromGeometry(geometryOf(CIRCLE12_WING).slice(0, 5))).toThrow(
      /5 records for 12 input points/i,
    );
  });
});

describe('box filtrations: quantization is part of the contract (SPEC.md §1.3)', () => {
  it('exposes the grid: step \u03c0 and the number of steps', () => {
    const f = box();
    expect(f.quantization).not.toBeNull();
    expect(f.quantization.step).toBeCloseTo(0.25, 12);
    expect(f.quantization.steps).toBe(RING6_BOX.box.numSteps);
    expect(f.box.alpha).toBe(RING6_BOX.box.alpha);
    expect(f.box.maxBirthStep).toBe(RING6_BOX.box.maxBirthStep);
  });

  it('every filtration value IS a grid value — bar endpoints are not measurements', () => {
    const f = box();
    const step = f.quantization.step;
    for (const s of f.simplices) {
      const grid = Math.round(s.filtration / step);
      expect(Math.abs(s.filtration - grid * step)).toBeLessThan(1e-9);
    }
    for (const value of f.criticalValues) {
      expect(Math.abs(value / step - Math.round(value / step))).toBeLessThan(1e-9);
    }
  });

  it('every ball / ellipsoid / wing filtration has NO quantization (null, not 0)', () => {
    expect(recordedFiltration(TRIANGLE_RIPS).quantization).toBeNull();
    expect(ellipsoidFlag().quantization).toBeNull();
    expect(wing().quantization).toBeNull();
    expect(kfold().quantization).toBeNull();
  });

  it('hands back the engine\u2019s OWN box at the last completed step, never an interpolation', () => {
    const f = box();
    const step = f.quantization.step;
    const recorded = RING6_BOX.box.extents!;
    for (const [t, expectedStep] of [
      [0, 0],
      [step, 1],
      [1.99 * step, 1],
      [2 * step, 2],
      [999, RING6_BOX.box.numSteps],
    ] as const) {
      const shape = f.shapeAt(2, t);
      expect(shape.kind).toBe('box');
      expect(shape.step).toBe(expectedStep);
      expect(shape.lower).toEqual(recorded[expectedStep][2].lower);
      expect(shape.upper).toEqual(recorded[expectedStep][2].upper);
    }
  });

  it('grows monotonically: the box at t never loses ground as t increases', () => {
    const f = box();
    let lower = Infinity;
    let upper = -Infinity;
    for (let t = 0; t <= 2; t += 0.05) {
      const shape = f.shapeAt(1, t);
      expect(shape.lower[0]).toBeLessThanOrEqual(lower);
      expect(shape.upper[0]).toBeGreaterThanOrEqual(upper);
      lower = shape.lower[0];
      upper = shape.upper[0];
    }
  });

  it('starts as the degenerate pivot box: the input point itself at step 0', () => {
    const f = box();
    const shape = f.shapeAt(4, 0);
    expect(shape.lower).toEqual(shape.upper);
    expect(shape.lower[0]).toBeCloseTo(f.cloud.points[8], 6);
    expect(shape.lower[1]).toBeCloseTo(f.cloud.points[9], 6);
  });

  it('hands over one whole STEP of boxes, which is how the engine returned them', () => {
    const f = box();
    const recorded = RING6_BOX.box.extents!;
    const step = f.quantization.step;
    expect(recorded).toHaveLength(f.quantization.steps + 1);

    for (let s = 0; s < recorded.length; s++) {
      const boxes = f.boxesAtStep(s);
      expect(boxes).toHaveLength(recorded[s].length);
      boxes.forEach((drawn, i) => {
        expect(drawn.step).toBe(s);
        expect(drawn.lower).toEqual(recorded[s][i].lower);
        expect(drawn.upper).toEqual(recorded[s][i].upper);
        // The same record `shapeAt` returns at that step's t, without the caller
        // having to reproduce the grid arithmetic.
        expect(drawn).toEqual(f.shapeAt(i, s * step));
      });
    }
  });

  it('takes a STEP INDEX, not a t value, and says so when handed the wrong one', () => {
    const f = box();
    const last = f.quantization.steps;
    expect(() => f.boxesAtStep(last)).not.toThrow();
    expect(() => f.boxesAtStep(last + 1)).toThrow(/step .* out of range/i);
    expect(() => f.boxesAtStep(-1)).toThrow(/step .* out of range/i);
    // 0.25 is a valid t and never a valid step.
    expect(() => f.boxesAtStep(f.quantization.step)).toThrow(/STEP INDEX, not a t value/i);
  });

  it('reports a retainBoxes: false build as undrawable, keeping the quantization', () => {
    const f = createFiltration({
      ...RING6_BOX,
      rawPairs: [],
      box: { ...RING6_BOX.box, extents: null },
    });
    expect(f.shapesAvailable).toBe(false);
    expect(f.shapesUnavailableReason).toMatch(/retainBoxes/i);
    expect(() => f.shapeAt(0, 1)).toThrow(/retainBoxes/i);
    expect(() => f.boxesAtStep(0)).toThrow(/retainBoxes/i);
    // Quantization is a property of the filtration, not of the retained boxes.
    expect(f.quantization.step).toBeCloseTo(0.25, 12);
  });
});

describe('k-fold cover: the vertices are k-SUBSETS, not points (SPEC.md §3.1)', () => {
  it('says so in the record, and hands over the subsets', () => {
    const f = kfold();
    expect(f.vertexKind).toBe('subset');
    expect(f.vertexSubsets).not.toBeNull();
    expect(f.vertexCount).toBe(JITTERED8_KFOLD2.vertexSubsets!.length);
    // 8 input points, 22 mosaic vertices: the two index spaces are different.
    expect(f.vertexCount).not.toBe(f.cloud.points.length / f.cloud.dimension);
    for (const subset of f.vertexSubsets!) {
      expect(subset).toHaveLength(2); // k = 2
      expect([...subset]).toEqual([...subset].sort((a, b) => a - b));
      for (const i of subset) {
        expect(i).toBeGreaterThanOrEqual(0);
        expect(i).toBeLessThan(f.cloud.points.length / f.cloud.dimension);
      }
    }
  });

  it('draws each vertex at the barycentre of its subset (the review page\u2019s law)', () => {
    const f = kfold();
    const { points, dimension } = f.cloud;
    f.vertexSubsets!.forEach((subset, v) => {
      const position = f.vertexPosition(v);
      for (let a = 0; a < dimension; a++) {
        const mean = subset.reduce((sum, i) => sum + points[i * dimension + a], 0) / subset.length;
        expect(position[a]).toBeCloseTo(mean, 12);
        expect(f.vertexPositions[v * dimension + a]).toBeCloseTo(mean, 12);
      }
    });
  });

  it('every simplex vertex id indexes the mosaic, not the cloud', () => {
    const f = kfold();
    for (const s of f.simplices) {
      for (const v of s.vertices) {
        expect(v).toBeGreaterThanOrEqual(0);
        expect(v).toBeLessThan(f.vertexCount);
      }
    }
  });

  it('grows BALLS around the input points at \u221at (squared-radius convention)', () => {
    const f = kfold();
    expect(f.radiusAt(0, 0.36)).toBeCloseTo(0.6, 12);
    const shape = f.shapeAt(0, 0.36);
    expect(shape.kind).toBe('ball');
    expect(shape.radius).toBeCloseTo(0.6, 12);
    expect(shape.center).toEqual(f.cloud.points.slice(0, 3));
    // One shape per INPUT point, not one per vertex.
    expect(() => f.shapeAt(f.cloud.points.length / 3 - 1, 1)).not.toThrow();
  });

  it('rejects an out-of-range vertex instead of returning NaN coordinates', () => {
    const f = kfold();
    expect(() => f.vertexPosition(f.vertexCount)).toThrow(/out of range/i);
    expect(() => f.vertexPosition(-1)).toThrow(/out of range/i);
  });

  it('rejects a VERTEX index handed to shapeAt: the two spaces are not swappable', () => {
    const f = kfold();
    const pointCount = f.cloud.points.length / 3;
    expect(f.vertexCount).toBeGreaterThan(pointCount);
    // A vertex id that is valid as a vertex but not as an input point must not
    // silently produce a ball centred on a half-read slice.
    expect(() => f.shapeAt(pointCount, 1)).toThrow(/input point .* out of range/i);
    expect(() => wing().shapeAt(99, 1)).toThrow(/input point 99 is out of range/i);
  });
});

describe('point-vertex filtrations keep the v1 identity', () => {
  it('vertexKind "point", no subsets, positions = the cloud itself', () => {
    const f = recordedFiltration(TRIANGLE_RIPS);
    expect(f.vertexKind).toBe('point');
    expect(f.vertexSubsets).toBeNull();
    expect(f.vertexCount).toBe(3);
    expect([...f.vertexPositions]).toEqual(f.cloud.points);
    expect(f.vertexPosition(2)).toEqual(f.cloud.points.slice(4, 6));
  });
});
