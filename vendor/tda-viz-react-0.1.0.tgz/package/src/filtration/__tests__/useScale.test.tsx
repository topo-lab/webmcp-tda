// The scale controller (SPEC.md §3.3): the single source of truth for t.
import { act, renderHook } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  TRIANGLE_CECH,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { useScale } from '../useScale';

const cech = recordedFiltration(TRIANGLE_CECH); // criticalValues [0, 0.5, 0.57735]
const weighted = recordedFiltration(WEIGHTED3_ALPHA); // first critical value -0.5

describe('useScale: t and setT', () => {
  it('starts at the beginning of the filtration (min of 0 and first critical value)', () => {
    const { result } = renderHook(() => useScale(cech));
    expect(result.current.t).toBe(0);
    const w = renderHook(() => useScale(weighted));
    // Weighted vertices enter at t = -w, so the filtration starts below 0.
    expect(w.result.current.t).toBe(-0.5);
  });

  it('setT sets and clamps to [tMin, tMax]', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.setT(0.3));
    expect(result.current.t).toBe(0.3);
    act(() => result.current.setT(99));
    expect(result.current.t).toBe(cech.tMax);
    act(() => result.current.setT(-99));
    expect(result.current.t).toBe(0);
  });
});

describe('useScale: snapping (the interesting moments are the changes)', () => {
  it('snapToNext jumps to the next critical value', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.snapToNext());
    expect(result.current.t).toBe(0.5);
    act(() => result.current.snapToNext());
    expect(result.current.t).toBe(0.57735);
    // No further event: stays put rather than inventing one.
    act(() => result.current.snapToNext());
    expect(result.current.t).toBe(0.57735);
  });

  it('snapToPrev jumps to the previous critical value', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.setT(0.55));
    act(() => result.current.snapToPrev());
    expect(result.current.t).toBe(0.5);
    act(() => result.current.snapToPrev());
    expect(result.current.t).toBe(0);
    act(() => result.current.snapToPrev());
    expect(result.current.t).toBe(0);
  });

  it('snapping from between two events lands exactly on an event, once per step', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.setT(0.51));
    const before = cech.simplicesAt(result.current.t).length;
    act(() => result.current.snapToNext());
    const after = cech.simplicesAt(result.current.t).length;
    expect(result.current.t).toBe(0.57735);
    expect(after).toBe(before + 1); // exactly the triangle appears
  });
});

describe('useScale: playback', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['requestAnimationFrame', 'cancelAnimationFrame', 'performance'] });
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  it('play advances t monotonically and pause stops it', () => {
    const { result } = renderHook(() => useScale(cech));
    expect(result.current.playing).toBe(false);
    act(() => result.current.play());
    expect(result.current.playing).toBe(true);
    act(() => void vi.advanceTimersByTime(500));
    const t1 = result.current.t;
    expect(t1).toBeGreaterThan(0);
    act(() => result.current.pause());
    expect(result.current.playing).toBe(false);
    act(() => void vi.advanceTimersByTime(500));
    expect(result.current.t).toBe(t1);
  });

  it('stops at tMax instead of running past the filtration', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.play());
    act(() => void vi.advanceTimersByTime(60_000));
    expect(result.current.t).toBe(cech.tMax);
    expect(result.current.playing).toBe(false);
  });

  it('play from the end restarts from the beginning', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.setT(cech.tMax));
    act(() => result.current.play());
    expect(result.current.t).toBe(0);
    expect(result.current.playing).toBe(true);
  });
});
