// @vitest-environment node
//
// The GridFiltration contract (SPEC.md §3.1b), on RECORDED engine output: what
// t does, what it does not do, and the honesty slice a grid gets.
import { describe, expect, it } from 'vitest';
import {
  DIAGONAL3_CUBICAL_T,
  DIAGONAL3_CUBICAL_V,
  TWOHOLE11X9_CUBICAL_T,
  TWORINGS10_CUBICAL_T,
  TWORINGS10_CUBICAL_T_SUPER,
  TWORINGS10_CUBICAL_V,
  WELLS24_CUBICAL_V,
  recordedGridFiltration,
} from '../../__fixtures__/realFiltrations';

describe('a grid filtration is a grid and a threshold, not a cloud and a shape', () => {
  const f = recordedGridFiltration(TWORINGS10_CUBICAL_T);

  it('says which domain it is over, so nothing has to crash to find out', () => {
    expect(f.domain).toBe('grid');
    expect(f.complexType).toBe('cubical');
    // The two facts the type exists to state: no cloud, and nothing grows.
    expect('cloud' in f).toBe(false);
    expect('shapeAt' in f).toBe(false);
    expect('convention' in f).toBe(false);
  });

  it('carries the grid it was built from, as a frozen copy of the right length', () => {
    expect(f.width).toBe(10);
    expect(f.height).toBe(10);
    expect(f.values).toBeInstanceOf(Float64Array);
    expect(f.values).toHaveLength(100);
    expect(f.valueAt(0, 0)).toBe(0);
    expect(f.valueAt(2, 2)).toBe(1); // the punched-out centre of the first ring
    expect(f.valueAt(9, 0)).toBe(1); // the high ground, top right
  });

  it('refuses a cell off the grid by name, rather than reading past the row', () => {
    expect(() => f.valueAt(10, 0)).toThrow(/off the grid: this filtration is 10 × 10/);
    expect(() => f.valueAt(0, -1)).toThrow(/off the grid/);
    expect(() => f.valueAt(1.5, 0)).toThrow(/off the grid/);
  });

  it('has no quantization: the values are the image’s own numbers', () => {
    expect(f.quantization).toBeNull();
  });

  it('lists the distinct values, ascending, as the only thresholds that matter', () => {
    expect(f.criticalValues).toEqual([0, 1]);
    expect(f.tMin).toBe(0);
    expect(f.tMax).toBe(1);
  });

  it('stops the Betti slice at β1, because a subset of the plane has no H2', () => {
    expect(f.maxSimplexDimension).toBe(2);
    expect(f.bettiAt(0)).toHaveLength(2);
    expect(f.rawPairs.every((p) => p.dimension < 2)).toBe(true);
  });
});

/**
 * The hand-computed 3 x 3 (0 2 2 / 2 0 2 / 2 2 0), replayed from the recording.
 * The argument is in buildFiltrationGrid.integration.test.ts, against the live
 * engine; this is the same claim held still so a renderer test can rest on it.
 */
describe('the two conventions are two filtrations of one array', () => {
  const t = recordedGridFiltration(DIAGONAL3_CUBICAL_T);
  const v = recordedGridFiltration(DIAGONAL3_CUBICAL_V);

  it('T joins the diagonal at the shared corner vertices: one component', () => {
    expect(t.bettiAt(0)).toEqual([1, 0]);
    expect(t.pairs).toHaveLength(1);
    expect(t.pairs[0]).toEqual({ dimension: 0, birth: 0, death: Infinity });
  });

  it('V has no diagonal edge to join them: three components until t = 2', () => {
    expect(v.bettiAt(0)).toEqual([3, 0]);
    expect(v.bettiAt(1.999)).toEqual([3, 0]);
    expect(v.bettiAt(2)).toEqual([1, 0]);
    expect(v.pairs.filter((p) => p.death === 2)).toHaveLength(2);
  });

  it('draws the SAME numbers, and says which cell they are on', () => {
    expect([...t.values]).toEqual([...v.values]);
    expect(t.guarantee.label).toContain('T-filtration');
    expect(v.guarantee.label).toContain('V-filtration');
    expect(t.guarantee.kind).toBe('cubical');
  });
});

describe('containsValue is the one place the direction is read', () => {
  const sub = recordedGridFiltration(TWORINGS10_CUBICAL_T);
  const sup = recordedGridFiltration(TWORINGS10_CUBICAL_T_SUPER);

  it('sublevel fills {f ≤ t}, sweeping up', () => {
    expect(sub.direction).toBe('sublevel');
    expect(sub.containsValue(0, 0)).toBe(true);
    expect(sub.containsValue(1, 0)).toBe(false);
    expect(sub.containsValue(1, 1)).toBe(true);
  });

  it('superlevel fills {f ≥ t}, sweeping down', () => {
    expect(sup.direction).toBe('superlevel');
    expect(sup.containsValue(1, 1)).toBe(true);
    expect(sup.containsValue(0, 1)).toBe(false);
    expect(sup.containsValue(0, 0)).toBe(true);
  });

  it('aliveAt and bettiAt run the same way the fill does', () => {
    // The bright set at t = 1 is the two 5x5 blocks and the two punched-out
    // centres. THREE pieces, not four: the blocks meet corner to corner, and
    // the vertex between them is a face of two bright pixels, so under the
    // T-construction it enters with them — the same diagonal contact that made
    // the dark rings one region under T is now making the bright blocks one.
    // The two centres are surrounded by dark and stay alone until t reaches 0.
    expect(sup.bettiAt(1)[0]).toBe(3);
    expect(sup.bettiAt(0)[0]).toBe(1);
    expect(sup.aliveAt(1)).toHaveLength(3);
    // and the classes run downward, in image units
    for (const p of sup.pairs) expect(p.birth >= p.death).toBe(true);
  });
});

describe('the picture the lesson rests on: two rings that touch at one corner', () => {
  const t = recordedGridFiltration(TWORINGS10_CUBICAL_T);
  const v = recordedGridFiltration(TWORINGS10_CUBICAL_V);

  it('both find the two loops; only V finds two components', () => {
    expect(t.bettiAt(0)).toEqual([1, 2]);
    expect(v.bettiAt(0)).toEqual([2, 2]);
    // The one bar that tells them apart: V carries an extra H0 that dies at 1.
    expect(v.pairs).toHaveLength(t.pairs.length + 1);
    expect(v.pairs.filter((p) => p.dimension === 0 && p.death === 1)).toHaveLength(1);
    expect(t.pairs.filter((p) => p.dimension === 0 && Number.isFinite(p.death))).toHaveLength(0);
  });

  it('and they agree once the bright value arrives', () => {
    expect(t.bettiAt(1)).toEqual([1, 0]);
    expect(v.bettiAt(1)).toEqual([1, 0]);
  });
});

describe('a non-square grid and a smooth field are read the same way', () => {
  it('11 × 9 is 11 wide and 9 tall, and has one region with two holes', () => {
    const f = recordedGridFiltration(TWOHOLE11X9_CUBICAL_T);
    expect([f.width, f.height]).toEqual([11, 9]);
    expect(f.values).toHaveLength(99);
    expect(f.bettiAt(0)).toEqual([1, 2]);
  });

  it('a smooth field has as many thresholds as it has distinct values', () => {
    const f = recordedGridFiltration(WELLS24_CUBICAL_V);
    expect(f.criticalValues.length).toBeGreaterThan(100);
    expect(f.criticalValues[0]).toBe(f.tMin);
    expect(f.criticalValues[f.criticalValues.length - 1]).toBe(f.tMax);
    // Ascending, always — `direction` says which end the sweep starts from.
    for (let i = 1; i < f.criticalValues.length; i++) {
      expect(f.criticalValues[i]).toBeGreaterThan(f.criticalValues[i - 1]);
    }
    // Nothing is alive below the lowest value, and one class survives the top.
    expect(f.bettiAt(f.tMin - 1)).toEqual([0, 0]);
    expect(f.bettiAt(f.tMax)).toEqual([1, 0]);
  });
});
