// @vitest-environment node
//
// Corrupt or partial engine records must fail closed. A renderer synthesizing a
// missing shape would make the picture disagree with the persistence computed
// from the original engine output, so these are scientific-integrity checks,
// not merely defensive branches.
import type { PersistencePair, WingGeometry } from 'tda-wasm';
import { describe, expect, it } from 'vitest';
import {
  CIRCLE12_WING,
  ELLIPSE_ELLIPSOID_RIPS,
  RING6_BOX,
  TRIANGLE_RIPS,
  type RecordedPair,
  type RecordedWingGeometry,
} from '../../__fixtures__/realFiltrations';
import { createFiltration } from '../createFiltration';

/**
 * The fixtures record `death`/`curvatureRadius`/`neighborhoodScale` as `null`
 * for Infinity, because JSON cannot hold the real value (see realFiltrations.ts).
 * `createFiltration` takes engine output, which never carries that
 * serialization — restore it here rather than widening the engine-facing
 * types to accept `null`, which every non-test caller would then have to guard.
 */
function restorePairs(pairs: readonly RecordedPair[]): PersistencePair[] {
  return pairs.map((p) => ({ ...p, death: p.death ?? Infinity }));
}

function restoreWingGeometry(records: readonly RecordedWingGeometry[]): WingGeometry[] {
  return records.map((g) => ({
    ...g,
    curvatureRadius: g.curvatureRadius ?? Infinity,
    neighborhoodScale: g.neighborhoodScale ?? Infinity,
  }));
}

describe('filtration record integrity boundaries', () => {
  it('refuses a missing fitted ellipsoid rather than drawing an invented sphere', () => {
    const geometry = ELLIPSE_ELLIPSOID_RIPS.ellipsoid.geometry.slice(0, -1);
    const filtration = createFiltration({
      ...ELLIPSE_ELLIPSOID_RIPS,
      rawPairs: restorePairs(ELLIPSE_ELLIPSOID_RIPS.rawPairs),
      ellipsoid: { ...ELLIPSE_ELLIPSOID_RIPS.ellipsoid, geometry },
    });
    const missing = ELLIPSE_ELLIPSOID_RIPS.cloud.weights.length - 1;

    expect(() => filtration.shapeAt(missing, 1)).toThrow(/no fitted ellipsoid/);
    expect(() => filtration.unitShape(missing)).toThrow(/no fitted ellipsoid/);
  });

  it('refuses non-finite wing geometry before any frame can produce a NaN polygon', () => {
    const geometry = restoreWingGeometry(
      CIRCLE12_WING.wing.geometry.map((record, index) =>
        index === 2 ? { ...record, normal: [NaN, record.normal[1]] } : record,
      ),
    );

    expect(() =>
      createFiltration({
        ...CIRCLE12_WING,
        rawPairs: restorePairs(CIRCLE12_WING.rawPairs),
        wing: { ...CIRCLE12_WING.wing, geometry },
      }),
    ).toThrow(/finite 2D point and normal/);
  });

  it('refuses a missing retained box instead of interpolating between steps', () => {
    const extents = RING6_BOX.box.extents!.map((row) => row.map((box) => ({ ...box })));
    const step = 1;
    const point = extents[step].length - 1;
    extents[step] = extents[step].slice(0, -1);
    const filtration = createFiltration({
      ...RING6_BOX,
      rawPairs: restorePairs(RING6_BOX.rawPairs),
      box: { ...RING6_BOX.box, extents },
    });

    expect(() => filtration.shapeAt(point, RING6_BOX.box.stepSize * step)).toThrow(
      /no box for input point/,
    );
  });

  it('keeps infinite sentinel simplices out of the finite scale calibration', () => {
    const finiteMaximum = Math.max(...TRIANGLE_RIPS.simplices.map((s) => s.filtration));
    const filtration = createFiltration({
      ...TRIANGLE_RIPS,
      rawPairs: restorePairs(TRIANGLE_RIPS.rawPairs),
      simplices: [
        ...TRIANGLE_RIPS.simplices,
        { vertices: [0, 1, 2], filtration: Infinity },
      ],
    });

    expect(filtration.tMax).toBe(finiteMaximum);
    expect(filtration.criticalValues.every(Number.isFinite)).toBe(true);
    expect(filtration.simplicesAt(finiteMaximum)).toHaveLength(TRIANGLE_RIPS.simplices.length);
    expect(filtration.simplicesAt(Infinity)).toHaveLength(TRIANGLE_RIPS.simplices.length + 1);
  });
});
