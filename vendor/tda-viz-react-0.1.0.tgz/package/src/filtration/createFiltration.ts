/**
 * Constructs the Filtration object (SPEC.md §3.1) from engine output.
 *
 * This is a pure data structure: it never computes topology and never
 * synthesizes a simplex or a pair (SPEC.md §1.6). It is built by
 * `buildFiltration` (src/engine) from a live engine run, or by
 * `recordedFiltration` (src/__fixtures__) from recorded engine output.
 *
 * The one thing it DOES compute is the scale law — the growing shape at t
 * (src/filtration/shapes.ts) — and the barycentres of k-fold mosaic vertices,
 * both of which are arithmetic on engine output rather than topology.
 */
import type {
  BoxExtent,
  EllipsoidAxesMode,
  EllipsoidGeometry,
  PersistencePair,
  Simplex,
  WingGeometry,
  WingNormalSource,
} from 'tda-wasm';
import { isRealHomologyDim, reliableBettiLength, reliableBettiSlice } from '../state/honesty';
import { complexGuarantee } from './guarantees';
import { ballRadiusAt, boxStepAt, ellipsoidSemiAxesAt, wingOutlineAt } from './shapes';
import type {
  BallConvention,
  BallFiltration,
  BallShape,
  BoxFiltration,
  BoxShape,
  EllipsoidFiltration,
  EllipsoidProfile,
  EllipsoidShape,
  Filtration,
  FiltrationComplexType,
  FiltrationQuantization,
  WeightedCloud,
  WingFiltration,
  WingProfile,
  WingShape,
} from './types';

interface CreateFiltrationInputBase {
  cloud: WeightedCloud;
  complexType: FiltrationComplexType;
  maxSimplexDimension: number;
  /** Engine simplices, any order; sorted internally. */
  simplices: readonly Simplex[];
  /** Engine persistence pairs, unfiltered. Nerve filtering happens HERE. */
  rawPairs: readonly PersistencePair[];
  /**
   * k-fold cover only: `vertexSubsets[v]` is the sorted k-subset of input
   * indices that vertex v of the complex stands for (the engine's
   * `mosaicVertices`). Omit for the usual case, where a vertex IS a point.
   */
  vertexSubsets?: readonly (readonly number[])[];
}

/** rips / Čech / (weighted) alpha / k-fold: the growing shape is a ball. */
export interface CreateBallFiltrationInput extends CreateFiltrationInputBase {
  convention: BallConvention;
}

/** ellipsoid-rips / ellipsoid-Čech: per-point frame and semi-axes. */
export interface CreateEllipsoidFiltrationInput extends CreateFiltrationInputBase {
  convention: 'ellipsoid-2r';
  ellipsoid: {
    /** `computeEllipsoidGeometry` output, one record per input point. */
    geometry: readonly EllipsoidGeometry[];
    neighborhoodSize: number;
    axesMode: EllipsoidAxesMode;
  };
}

/** wing: a 2D concave hexagon per point, around a unit normal. */
export interface CreateWingFiltrationInput extends CreateFiltrationInputBase {
  convention: 'wing-eps';
  wing: {
    q: number;
    theta: number;
    /**
     * `computeWingGeometry` output, one record per input point: the normal the
     * builder used, where it came from, and the six unit-scale outline offsets.
     * Required — the wing polygon IS these offsets scaled, and there is no
     * fallback that rebuilds them from (q, θ, α) without risking a different
     * wing than the one whose births the complex recorded.
     */
    geometry: readonly WingGeometry[];
  };
}

/** box: axis-aligned boxes on the π grid, straight from the engine. */
export interface CreateBoxFiltrationInput extends CreateFiltrationInputBase {
  convention: 'box-step';
  box: {
    /** π: the growth increment and the filtration grid spacing. */
    stepSize: number;
    /** m: the number of growth steps taken. */
    numSteps: number;
    alpha: number;
    maxBirthStep: number;
    /** `extents[step][i]`, the engine's own boxes, or null if not retained. */
    extents: readonly (readonly BoxExtent[])[] | null;
  };
}

export type CreateFiltrationInput =
  | CreateBallFiltrationInput
  | CreateEllipsoidFiltrationInput
  | CreateWingFiltrationInput
  | CreateBoxFiltrationInput;

/** Index of the last element with filtration <= t, plus one (binary search). */
function upperBound(values: Float64Array, t: number): number {
  let lo = 0;
  let hi = values.length;
  while (lo < hi) {
    const mid = (lo + hi) >>> 1;
    if (values[mid] <= t) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}

const WING_OUTLINE_VERTICES = 6;

/**
 * Frozen copy of `computeWingGeometry` output, checked against the cloud.
 *
 * Nothing here is computed — the engine's records are the geometry — but they
 * are checked, because every later drawing is `point + t · outline[v]` and a
 * short record or a non-finite offset would come out as a NaN polygon rather
 * than as an error. The `point` comparison is exact on purpose: the engine
 * copies the input point through unchanged, so a mismatch means the geometry and
 * the complex were built from different clouds.
 */
function freezeWingGeometry(
  geometry: readonly WingGeometry[],
  cloud: WeightedCloud,
): readonly WingGeometry[] {
  const pointCount = cloud.points.length / cloud.dimension;
  if (geometry.length !== pointCount) {
    throw new Error(
      `wing geometry has ${geometry.length} records for ${pointCount} input points: ` +
        'computeWingGeometry returns one record per point, and a partial array would ' +
        'silently leave wings undrawn',
    );
  }
  const finite2D = (v: readonly number[] | undefined): boolean =>
    Array.isArray(v) && v.length === 2 && v.every((c) => Number.isFinite(c));

  return Object.freeze(
    geometry.map((g, i) => {
      if (!finite2D(g.point) || !finite2D(g.normal)) {
        throw new Error(
          `wing geometry at point ${i} must carry a finite 2D point and normal, got ` +
            `point ${JSON.stringify(g.point)}, normal ${JSON.stringify(g.normal)}`,
        );
      }
      for (let d = 0; d < 2; d++) {
        if (g.point[d] !== cloud.points[i * 2 + d]) {
          throw new Error(
            `wing geometry at point ${i} is centred on (${g.point.join(', ')}) but the cloud ` +
              `has (${cloud.points[i * 2]}, ${cloud.points[i * 2 + 1]}): the geometry and the ` +
              'complex were built from different clouds',
          );
        }
      }
      if (
        !Array.isArray(g.outline) ||
        g.outline.length !== WING_OUTLINE_VERTICES ||
        !g.outline.every(finite2D)
      ) {
        throw new Error(
          `wing geometry at point ${i} must carry ${WING_OUTLINE_VERTICES} finite 2D outline ` +
            `offsets (A, B, C, D, C', B'), got ${JSON.stringify(g.outline)}`,
        );
      }
      return Object.freeze({
        point: Object.freeze([...g.point]),
        normal: Object.freeze([...g.normal]),
        normalSource: g.normalSource,
        curvatureRadius: g.curvatureRadius,
        neighborhoodScale: g.neighborhoodScale,
        outline: Object.freeze(g.outline.map((offset) => Object.freeze([...offset]))),
      }) as WingGeometry;
    }),
  );
}

/** Barycentre positions for k-fold mosaic vertices; input points otherwise. */
function vertexPositionsOf(
  cloud: WeightedCloud,
  subsets: readonly (readonly number[])[] | null,
): readonly number[] {
  const { points, dimension } = cloud;
  if (!subsets) return Object.freeze([...points]);
  const out = new Array<number>(subsets.length * dimension).fill(0);
  for (let v = 0; v < subsets.length; v++) {
    const subset = subsets[v];
    for (const i of subset) {
      for (let a = 0; a < dimension; a++) out[v * dimension + a] += points[i * dimension + a];
    }
    for (let a = 0; a < dimension; a++) out[v * dimension + a] /= subset.length;
  }
  return Object.freeze(out);
}

/** Everything that does not depend on which shape grows. */
function createBase(input: CreateFiltrationInput) {
  const { cloud, convention, complexType, maxSimplexDimension } = input;

  const simplices: readonly Simplex[] = Object.freeze(
    [...input.simplices].sort((a, b) => a.filtration - b.filtration),
  );
  const filtrationValues = new Float64Array(simplices.length);
  for (let i = 0; i < simplices.length; i++) filtrationValues[i] = simplices[i].filtration;

  const rawPairs: readonly PersistencePair[] = Object.freeze([...input.rawPairs]);
  // Nerve filter (SPEC.md §1.6): points in R^d carry no homology in degree >= d.
  const pairs: readonly PersistencePair[] = Object.freeze(
    rawPairs.filter((p) => isRealHomologyDim(p.dimension, cloud.dimension)),
  );

  let tMax = 0;
  for (let i = simplices.length - 1; i >= 0; i--) {
    if (Number.isFinite(filtrationValues[i])) {
      tMax = filtrationValues[i];
      break;
    }
  }

  const criticalValues: readonly number[] = Object.freeze(
    [...new Set(filtrationValues)].filter(Number.isFinite).sort((a, b) => a - b),
  );

  const bettiLength = reliableBettiLength({ maxSimplexDimension, ambientDim: cloud.dimension });

  const subsets: readonly (readonly number[])[] | null = input.vertexSubsets
    ? Object.freeze(input.vertexSubsets.map((s) => Object.freeze([...s])))
    : null;
  const vertexPositions = vertexPositionsOf(cloud, subsets);
  const dimension = cloud.dimension;
  const vertexCount = vertexPositions.length / dimension;

  // simplicesAt runs every animation frame; memoize the last slice so a
  // paused t costs one binary search and zero allocations.
  let lastCount = -1;
  let lastSlice: readonly Simplex[] = Object.freeze([]);

  return {
    cloud,
    convention,
    complexType,
    guarantee: complexGuarantee(complexType),
    maxSimplexDimension,
    simplices,
    pairs,
    rawPairs,
    tMax,
    criticalValues,

    vertexKind: (subsets ? 'subset' : 'point') as 'subset' | 'point',
    vertexCount,
    vertexSubsets: subsets,
    vertexPositions,

    vertexPosition(v: number): readonly number[] {
      if (v < 0 || v >= vertexCount) {
        throw new Error(`vertex ${v} is out of range: this complex has ${vertexCount} vertices`);
      }
      return Object.freeze(vertexPositions.slice(v * dimension, (v + 1) * dimension));
    },

    simplicesAt(t: number): readonly Simplex[] {
      const count = upperBound(filtrationValues, t);
      if (count !== lastCount) {
        lastCount = count;
        lastSlice = Object.freeze(simplices.slice(0, count));
      }
      return lastSlice;
    },

    aliveAt(t: number): readonly PersistencePair[] {
      return pairs.filter((p) => p.birth <= t && t < p.death);
    },

    bettiAt(t: number): number[] {
      const betti = new Array<number>(bettiLength).fill(0);
      for (const p of pairs) {
        if (p.dimension < bettiLength && p.birth <= t && t < p.death) betti[p.dimension]++;
      }
      return reliableBettiSlice(betti, { maxSimplexDimension, ambientDim: cloud.dimension });
    },
  };
}

/**
 * Centre of INPUT POINT i, as a fresh frozen tuple. Range-checked: a shape
 * centred on a half-read slice would be geometry the cloud does not contain.
 */
function pointAt(cloud: WeightedCloud, i: number): readonly number[] {
  const { points, dimension } = cloud;
  const count = points.length / dimension;
  if (!Number.isInteger(i) || i < 0 || i >= count) {
    throw new Error(
      `input point ${i} is out of range: this cloud has ${count} points ` +
        '(shapeAt takes an INPUT POINT index, not a vertex index — see SPEC.md §3.1)',
    );
  }
  return Object.freeze(points.slice(i * dimension, (i + 1) * dimension));
}

export function createFiltration(input: CreateBallFiltrationInput): BallFiltration;
export function createFiltration(input: CreateEllipsoidFiltrationInput): EllipsoidFiltration;
export function createFiltration(input: CreateWingFiltrationInput): WingFiltration;
export function createFiltration(input: CreateBoxFiltrationInput): BoxFiltration;
export function createFiltration(input: CreateFiltrationInput): Filtration;
export function createFiltration(input: CreateFiltrationInput): Filtration {
  const base = createBase(input);
  const { cloud } = input;
  const weights = cloud.weights;

  if (input.convention === 'ellipsoid-2r') {
    const { geometry, neighborhoodSize, axesMode } = input.ellipsoid;
    const fitted = (i: number): EllipsoidGeometry => {
      const g = geometry[i];
      if (!g) {
        throw new Error(
          `no fitted ellipsoid for input point ${i}: the geometry has ${geometry.length} records`,
        );
      }
      return g;
    };
    const filtration: EllipsoidFiltration = {
      ...base,
      convention: input.convention,
      quantization: null,
      shapeKind: 'ellipsoid',
      shapesAvailable: true,
      shapesUnavailableReason: null,
      ellipsoid: Object.freeze({ neighborhoodSize, axesMode }),
      shapeAt(i: number, t: number): EllipsoidShape {
        const g = fitted(i);
        return {
          kind: 'ellipsoid',
          center: g.center,
          frame: g.frame,
          semiAxes: ellipsoidSemiAxesAt(g.semiAxes, t),
        };
      },
      unitShape(i: number): EllipsoidProfile {
        // The engine's fitting verbatim: frame and UNIT profile, nothing scaled.
        const g = fitted(i);
        return { kind: 'ellipsoid', center: g.center, frame: g.frame, semiAxes: g.semiAxes };
      },
    };
    return filtration;
  }

  if (input.convention === 'wing-eps') {
    const { q, theta } = input.wing;
    // The engine's own records, checked but never recomputed: the normal the
    // builder used, its provenance, and the unit outline every polygon scales.
    const geometry = freezeWingGeometry(input.wing.geometry, cloud);
    const normals: readonly number[] = Object.freeze(geometry.flatMap((g) => [...g.normal]));
    const normalSources: readonly WingNormalSource[] = Object.freeze(
      geometry.map((g) => g.normalSource),
    );
    const wingAt = (i: number): WingGeometry => {
      // Range-checked through pointAt so a vertex index handed to shapeAt is
      // refused by name rather than read as a half-slice of the cloud.
      pointAt(cloud, i);
      return geometry[i];
    };
    const filtration: WingFiltration = {
      ...base,
      convention: input.convention,
      quantization: null,
      shapeKind: 'wing',
      shapesAvailable: true,
      shapesUnavailableReason: null,
      wing: Object.freeze({ q, theta, normals, normalSources }),
      shapeAt(i: number, t: number): WingShape {
        const g = wingAt(i);
        const eps = Math.max(t, 0);
        return {
          kind: 'wing',
          center: g.point,
          normal: g.normal,
          normalSource: g.normalSource,
          spineHalfLength: q * eps,
          wingLength: eps,
          theta,
          outline: wingOutlineAt(g.point, g.outline, eps),
        };
      },
      unitShape(i: number): WingProfile {
        const g = wingAt(i);
        return {
          kind: 'wing',
          center: g.point,
          normal: g.normal,
          normalSource: g.normalSource,
          curvatureRadius: g.curvatureRadius,
          neighborhoodScale: g.neighborhoodScale,
          outline: g.outline,
        };
      },
    };
    return filtration;
  }

  if (input.convention === 'box-step') {
    const { stepSize, numSteps, alpha, maxBirthStep, extents } = input.box;
    const quantization: FiltrationQuantization = Object.freeze({ step: stepSize, steps: numSteps });
    const requireExtents = (): readonly (readonly BoxExtent[])[] => {
      if (!extents) {
        throw new Error(
          'this box filtration cannot produce shapes: it was built with ' +
            'retainBoxes: false. Check `shapesAvailable` first.',
        );
      }
      return extents;
    };
    const boxAt = (step: number, i: number): BoxShape => {
      const rows = requireExtents();
      const box = rows[step]?.[i];
      if (!box) {
        throw new Error(
          `no box for input point ${i} at step ${step}: the engine returned ` +
            `${rows.length} steps × ${rows[0]?.length ?? 0} boxes`,
        );
      }
      return { kind: 'box', lower: box.lower, upper: box.upper, step };
    };
    const filtration: BoxFiltration = {
      ...base,
      convention: input.convention,
      quantization,
      shapeKind: 'box',
      shapesAvailable: extents !== null,
      shapesUnavailableReason:
        extents === null
          ? 'the box filtration was built with retainBoxes: false, so the engine never ' +
            'returned the grown boxes; rebuild with retainBoxes to draw them'
          : null,
      box: Object.freeze({ alpha, maxBirthStep }),
      shapeAt(i: number, t: number): BoxShape {
        return boxAt(boxStepAt(t, stepSize, numSteps), i);
      },
      boxesAtStep(step: number): readonly BoxShape[] {
        const rows = requireExtents();
        if (!Number.isInteger(step) || step < 0 || step >= rows.length) {
          throw new Error(
            `box step ${step} is out of range: the engine returned ${rows.length} steps ` +
              `(0 … ${rows.length - 1}) — this takes a STEP INDEX, not a t value`,
          );
        }
        return Object.freeze(rows[step].map((_, i) => boxAt(step, i)));
      },
    };
    return filtration;
  }

  const convention = input.convention;
  const filtration: BallFiltration = {
    ...base,
    convention,
    quantization: null,
    shapeKind: 'ball',
    shapesAvailable: true,
    shapesUnavailableReason: null,

    radiusAt(i: number, t: number): number {
      return ballRadiusAt(convention, t, weights[i] ?? 0);
    },

    shapeAt(i: number, t: number): BallShape {
      return {
        kind: 'ball',
        center: pointAt(cloud, i),
        radius: ballRadiusAt(convention, t, weights[i] ?? 0),
      };
    },
  };
  return filtration;
}
