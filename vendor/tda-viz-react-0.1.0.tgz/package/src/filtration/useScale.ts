/**
 * useScale (SPEC.md §3.3): the single source of truth for t.
 *
 * snapToNext/snapToPrev jump between `criticalValues`, because the
 * interesting moments of a filtration are the moments something changes,
 * and a continuous slider skips over them.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import type { Filtration } from './types';

export interface UseScaleOptions {
  /** Starting t. Defaults to the start of the filtration (min of 0 and the first critical value). */
  initialT?: number;
  /** Seconds a full sweep from start to tMax takes when playing. Default 10. */
  playSeconds?: number;
}

export interface UseScaleResult {
  t: number;
  setT: (t: number) => void;
  play: () => void;
  pause: () => void;
  playing: boolean;
  snapToNext: () => void;
  snapToPrev: () => void;
}

export function useScale(filtration: Filtration, options: UseScaleOptions = {}): UseScaleResult {
  const { criticalValues, tMax } = filtration;
  const tMin = useMemo(
    () => Math.min(0, criticalValues.length > 0 ? criticalValues[0] : 0),
    [criticalValues],
  );
  const playSeconds = options.playSeconds ?? 10;

  const clamp = useCallback((value: number) => Math.min(Math.max(value, tMin), tMax), [tMin, tMax]);

  const [t, setTState] = useState(() => clamp(options.initialT ?? tMin));
  const [playing, setPlaying] = useState(false);

  const setT = useCallback((value: number) => setTState(clamp(value)), [clamp]);

  const play = useCallback(() => {
    setTState((prev) => (prev >= tMax ? tMin : prev));
    setPlaying(true);
  }, [tMax, tMin]);

  const pause = useCallback(() => setPlaying(false), []);

  const snapToNext = useCallback(() => {
    setTState((prev) => {
      for (const cv of criticalValues) if (cv > prev) return clamp(cv);
      return prev;
    });
  }, [criticalValues, clamp]);

  const snapToPrev = useCallback(() => {
    setTState((prev) => {
      for (let i = criticalValues.length - 1; i >= 0; i--) {
        if (criticalValues[i] < prev) return clamp(criticalValues[i]);
      }
      return prev;
    });
  }, [criticalValues, clamp]);

  useEffect(() => {
    if (!playing) return;
    const speed = (tMax - tMin) / playSeconds || 0;
    let raf = 0;
    let last: number | null = null;
    const step = (now: number) => {
      if (last !== null) {
        const dt = (now - last) / 1000;
        setTState((prev) => Math.min(prev + dt * speed, tMax));
      }
      last = now;
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [playing, playSeconds, tMax, tMin]);

  // Reaching the end stops playback; it does not loop silently.
  useEffect(() => {
    if (playing && t >= tMax) setPlaying(false);
  }, [playing, t, tMax]);

  return { t, setT, play, pause, playing, snapToNext, snapToPrev };
}
