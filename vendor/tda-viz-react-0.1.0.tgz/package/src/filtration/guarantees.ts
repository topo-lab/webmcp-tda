/**
 * Honest labelling as a library guarantee, not a consumer's job
 * (SPEC.md §1.4, §1.6).
 *
 * Every filtration carries a machine-readable guarantee kind and the exact
 * chip text. The wording is fixed by tda-wasm's SPEC FR-6 and is reproduced
 * here VERBATIM — it is the same text the engine's own review page shows
 * (tda-wasm `examples/review/panels.mjs`, CHIP_TEXT). Tests assert it
 * character for character, and assert that no flag complex is ever labelled
 * a nerve.
 *
 * The distinction is not a hedge. A nerve lemma makes the complex homotopy
 * equivalent to the union of the growing shapes at every scale, so the two
 * pictures on screen are the same space. A flag complex is the flag complex
 * of the pairwise-intersection graph: a triangle there is NOT a claim that
 * three shapes share a common point, and the source papers say so themselves
 * (Canova–Kališnik–Moser–Rieck–Žegarac Def. 2.2 for the ellipsoid complex;
 * Weng–Zhao Eq. 3.5 for the wing complex).
 *
 * HEADLESS layer: no renderer imports (SPEC.md §2).
 */
import type { ComplexGuarantee, ComplexGuaranteeKind, FiltrationComplexType } from './types';

/**
 * The labelled inventory. Every entry is a quotation, not a paraphrase.
 *
 * - rips / ellipsoid-rips / wing: flag complexes built from PAIRWISE
 *   intersections, which is what their source papers build and say they build.
 * - cech: the ordinary Euclidean Čech complex, the nerve of the ball cover.
 * - ellipsoid-cech: a true nerve — at every radius the sets are ellipsoids,
 *   hence convex, so every subfamily intersection is empty or contractible;
 *   the cover is good and the nerve lemma applies (Giunti–Hill–Ye).
 * - kfold: exact, because the Almost Nerve lemma (Edelsbrunner–Osang, SoCG
 *   2018) makes the persistence of the order-k mosaic EQUAL multicover
 *   persistence. What is exact is the homotopy type; the values are doubles.
 * - box: a nerve because axis-aligned boxes have the Helly property axiswise,
 *   so pairwise intersection already gives a common point
 *   (Alvarado–Gupta–Krishnamoorthy Lemma 2.24). The quantization half of the
 *   tag is not optional: bar endpoints are grid values.
 * - alpha: the nerve of the cover by ball ∩ power cell — convex pieces, so a
 *   good cover — with exact combinatorics from the regular triangulation.
 */
export const COMPLEX_GUARANTEES: Readonly<Record<FiltrationComplexType, ComplexGuarantee>> =
  Object.freeze({
    rips: Object.freeze<ComplexGuarantee>({ kind: 'flag', label: 'flag complex (Rips-type)' }),
    'ellipsoid-rips': Object.freeze<ComplexGuarantee>({
      kind: 'flag',
      label: 'flag complex (Rips-type)',
    }),
    wing: Object.freeze<ComplexGuarantee>({ kind: 'flag', label: 'flag complex (Rips-type)' }),
    cech: Object.freeze<ComplexGuarantee>({ kind: 'nerve', label: 'true nerve (Cech)' }),
    'ellipsoid-cech': Object.freeze<ComplexGuarantee>({
      kind: 'nerve',
      label: 'true nerve (ellipsoidal Cech)',
    }),
    kfold: Object.freeze<ComplexGuarantee>({
      kind: 'nerve',
      label: 'exact (order-k Delaunay nerve)',
    }),
    box: Object.freeze<ComplexGuarantee>({
      kind: 'nerve',
      label: 'nerve (= flag, by Helly for boxes); step-quantized',
    }),
    alpha: Object.freeze<ComplexGuarantee>({
      kind: 'nerve',
      label: 'alpha complex (exact combinatorics)',
    }),
  });

/**
 * The complexes built from pairwise intersections. Listed explicitly so a test
 * can fail if one of them is ever relabelled a nerve, rather than trusting the
 * table above to stay honest on its own.
 */
export const FLAG_COMPLEX_TYPES: readonly FiltrationComplexType[] = Object.freeze([
  'rips',
  'ellipsoid-rips',
  'wing',
]);

/** The complexes a nerve lemma covers. Complement of FLAG_COMPLEX_TYPES. */
export const NERVE_COMPLEX_TYPES: readonly FiltrationComplexType[] = Object.freeze([
  'cech',
  'ellipsoid-cech',
  'kfold',
  'box',
  'alpha',
]);

/**
 * The two classification bands, in reading order: the nerves first
 * (DESIGN.md §Layout, "the guarantee is the navigation architecture"). A
 * construction index groups constructions under these two headings, so
 * selecting one is always an act of reading its classification.
 */
export const BAND_ORDER: readonly ComplexGuaranteeKind[] = Object.freeze(['nerve', 'flag']);

/** The band headings, keyed by the guarantee kind the band collects. */
export const BAND_HEADING: Readonly<Record<ComplexGuaranteeKind, string>> = Object.freeze({
  nerve: 'COMMON INTERSECTION',
  flag: 'PAIRWISE INTERSECTION',
});

/** One line under each heading, saying what membership in the band means. */
export const BAND_RULE: Readonly<Record<ComplexGuaranteeKind, string>> = Object.freeze({
  nerve: 'a simplex enters when its shapes share a point',
  flag: 'a simplex enters when its shapes meet in pairs',
});

/** The guarantee for a complex type. Never invents one: the table is total. */
export function complexGuarantee(complexType: FiltrationComplexType): ComplexGuarantee {
  return COMPLEX_GUARANTEES[complexType];
}
