/**
 * Constructs the GridFiltration object (SPEC.md §3.1b) from engine output.
 *
 * The grid sibling of `createFiltration`, and a separate file for the same
 * reason `GridFiltration` is a separate type: almost nothing is shared. There
 * is no cloud to project, no shape law to evaluate, no simplex list to sort
 * and binary-search. What a grid filtration holds is the image itself, the
 * diagram the engine returned for it, and the one predicate that decides which
 * cells are inside at a threshold.
 *
 * Like `createFiltration`, this is a pure data structure: it never computes
 * topology and never synthesizes a pair (SPEC.md §1.6). It is built by
 * `buildFiltration` (src/engine) from a live engine run.
 */
import type { PersistencePair } from 'tda-wasm';
import { isRealHomologyDim, reliableBettiLength, reliableBettiSlice } from '../state/honesty';
import { gridGuarantee } from './guarantees';
import type { GridConstruction, GridDirection, GridFiltration } from './types';

/**
 * A 2D grid is a 2-complex and nothing higher, so this is the honest cap AND
 * the honest ambient dimension. Both, and for two different reasons: there are
 * no 3-cells to build (the cap), and a subset of the plane has no H2 (the
 * ambient bound). See `src/state/honesty.ts` — for a grid the two coincide, so
 * neither number is doing hidden work for the other.
 */
export const GRID_DIMENSION = 2;

/** Engine output for a cubical construction: the image and the diagram over it. */
export interface CreateGridFiltrationInput {
  /** Row-major values, length `width * height`. Validated by the caller. */
  values: Float64Array;
  width: number;
  height: number;
  construction: GridConstruction;
  direction: GridDirection;
  /**
   * Engine persistence pairs, ALREADY IN IMAGE UNITS and already in the
   * sweep's direction — a superlevel build negates them back before it gets
   * here, because the negation is the adapter's business and not this layer's
   * (src/engine/buildFiltration.ts).
   */
  rawPairs: readonly PersistencePair[];
}

/**
 * Build a `GridFiltration` (SPEC.md §3.1b) from engine output. Pure data, like
 * `createFiltration`: it never computes topology and never synthesizes a pair.
 */
export function createGridFiltration(input: CreateGridFiltrationInput): GridFiltration {
  const { width, height, construction, direction } = input;
  // A frozen copy: the caller's array must not be able to change the picture
  // (or the diagram's meaning) after the build.
  const values = Float64Array.from(input.values);

  const rawPairs: readonly PersistencePair[] = Object.freeze([...input.rawPairs]);
  // Honesty filter (SPEC.md §1.6): a subset of the plane carries no homology
  // in degree >= 2. The T-construction's cells go up to dimension 2, so the
  // engine can and does emit an H2 row; it is always empty, and dropping it
  // here means nothing downstream has to know that.
  const pairs: readonly PersistencePair[] = Object.freeze(
    rawPairs.filter((p) => isRealHomologyDim(p.dimension, GRID_DIMENSION)),
  );

  let tMin = Infinity;
  let tMax = -Infinity;
  for (const v of values) {
    if (v < tMin) tMin = v;
    if (v > tMax) tMax = v;
  }

  const criticalValues: readonly number[] = Object.freeze(
    [...new Set(values)].sort((a, b) => a - b),
  );

  const bettiLength = reliableBettiLength({
    maxSimplexDimension: GRID_DIMENSION,
    ambientDim: GRID_DIMENSION,
  });

  const sublevel = direction === 'sublevel';
  /** Has the sweep reached `value` by the time it is at t? */
  const reached = (value: number, t: number): boolean => (sublevel ? value <= t : value >= t);

  const filtration: GridFiltration = {
    domain: 'grid',
    complexType: 'cubical',
    construction,
    direction,
    values,
    width,
    height,
    guarantee: gridGuarantee(construction),
    maxSimplexDimension: GRID_DIMENSION,
    pairs,
    rawPairs,
    tMin,
    tMax,
    criticalValues,
    quantization: null,

    valueAt(x: number, y: number): number {
      if (
        !Number.isInteger(x) ||
        !Number.isInteger(y) ||
        x < 0 ||
        y < 0 ||
        x >= width ||
        y >= height
      ) {
        throw new Error(
          `grid cell (${x}, ${y}) is off the grid: this filtration is ${width} × ${height}`,
        );
      }
      return values[y * width + x];
    },

    containsValue(value: number, t: number): boolean {
      return reached(value, t);
    },

    // Born by t and not yet dead. Written through `reached` rather than as two
    // comparisons so the superlevel case cannot drift from the fill test that
    // draws it: a class is alive exactly while the sweep has reached its birth
    // and has not reached its death, whichever way the sweep runs.
    aliveAt(t: number): readonly PersistencePair[] {
      return pairs.filter((p) => reached(p.birth, t) && !reached(p.death, t));
    },

    bettiAt(t: number): number[] {
      const betti = new Array<number>(bettiLength).fill(0);
      for (const p of pairs) {
        if (p.dimension < bettiLength && reached(p.birth, t) && !reached(p.death, t)) {
          betti[p.dimension]++;
        }
      }
      return reliableBettiSlice(betti, {
        maxSimplexDimension: GRID_DIMENSION,
        ambientDim: GRID_DIMENSION,
      });
    },
  };
  return filtration;
}
