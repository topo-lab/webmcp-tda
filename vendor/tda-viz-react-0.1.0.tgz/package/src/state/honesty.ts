/**
 * Presentation rules for Betti numbers and truncated complexes
 * (SPEC.md §5 — correctness requirements, not style preferences).
 *
 * Ported from tda-explorer's `src/utils/homologyHonesty.ts`.
 *
 * A Rips (or Čech) complex capped at simplex dimension d has no (d+1)-simplices
 * to fill its top-dimensional cycles, so every unfilled d-boundary is counted
 * as a hole. That number is the correct homology of the truncated complex, but
 * it is not topology of the underlying space. By the Nerve theorem, a point
 * cloud in R^{ambient} also has no homology in degree >= ambient.
 *
 * Show β0 … β_{k-1} only, where k = min(cap, ambientDim). Never present the
 * withheld top-dimensional count as a void / loop / component.
 *
 * ON A GRID (SPEC.md §3.1b) the same two rules apply and, unusually, neither is
 * doing the other's work. A 2D cubical complex is COMPLETE — every square that
 * belongs in it is there — so there is no truncation artifact for the cap to
 * withhold; the cap is 2 because a 2D grid has no 3-cells, not because anything
 * was left out. And the ambient bound is 2 because a thresholded subset of the
 * plane has no H2. The two coincide at k = 2, so a grid reports β0 and β1, and
 * the H2 row the T-construction's binding can emit (its cells go up to
 * dimension 2) is dropped by `filterRealHomology` / `isRealHomologyDim` for the
 * ambient reason alone. `createGridFiltration` passes 2 for both, deliberately
 * and separately.
 *
 * TODO(SPEC.md §5): port `hiddenBettiNote` and `simplexCostHint` from
 * tda-explorer when the package grows user-facing messaging for withheld
 * dimensions.
 */
import type { PersistenceDiagram, PersistencePair, PersistenceResult } from 'tda-wasm';

/** Default cap on simplex dimension: enough for H0 and H1, cheap enough to be interactive. */
export const DEFAULT_MAX_SIMPLEX_DIMENSION = 2;
/** Lowest cap the library accepts: a 1-skeleton, so H0 only. */
export const MIN_MAX_SIMPLEX_DIMENSION = 1;
/** Highest cap the library accepts. Above this the complex stops being interactive. */
export const MAX_MAX_SIMPLEX_DIMENSION = 4;

/**
 * True when homology in `homologyDim` can be real for points in `ambientDim`
 * dimensions. By the Nerve theorem, points in R^d have no homology above
 * degree d-1, so only H_k with k < d should be displayed.
 */
export function isRealHomologyDim(homologyDim: number, ambientDim: number): boolean {
  return homologyDim < ambientDim;
}

/** The two bounds that decide how many Betti numbers may be shown. */
export interface ReliableBettiOptions {
  /** Highest simplex dimension the complex was (or will be) built to. */
  maxSimplexDimension: number;
  /** Ambient dimension of the point cloud (2 for circle, 3 for sphere/torus). */
  ambientDim: number;
}

/**
 * How many Betti numbers are safe to show, starting at β0.
 * Returns k such that β0 … β_{k-1} are reportable as topology.
 */
export function reliableBettiLength({
  maxSimplexDimension,
  ambientDim,
}: ReliableBettiOptions): number {
  const cap = Math.max(0, Math.floor(maxSimplexDimension));
  const ambient = Math.max(0, Math.floor(ambientDim));
  return Math.max(0, Math.min(cap, ambient));
}

/** Slice of `betti` that may be shown as topology (never the truncated top dim). */
export function reliableBettiSlice(
  betti: number[] | undefined,
  opts: ReliableBettiOptions,
): number[] {
  if (!betti || betti.length === 0) return [];
  return betti.slice(0, reliableBettiLength(opts));
}

/**
 * Drop homology classes that cannot be real for points in `ambientDim`
 * dimensions. By the Nerve theorem a point cloud in R^d has no homology above
 * degree d-1, so any H_k with k >= d is a truncation artifact.
 *
 * Recomputes persistence summary fields from the kept pairs so counts stay
 * consistent. The canonical regression: a 50-point 2D circle at cap 2 must
 * NOT report β₂ = 150.
 *
 * This function only ever *removes* computed pairs; it never invents any.
 */
export function filterRealHomology<
  R extends {
    persistence: PersistenceResult;
    diagram: PersistenceDiagram;
  },
>(result: R, ambientDim: number): R {
  const keep = (pair: PersistencePair) => isRealHomologyDim(pair.dimension, ambientDim);

  const diagramPairs = result.diagram.pairs.filter(keep);
  const byDimension = new Map<number, PersistencePair[]>();
  const essential: PersistencePair[] = [];
  for (const pair of diagramPairs) {
    if (!byDimension.has(pair.dimension)) byDimension.set(pair.dimension, []);
    byDimension.get(pair.dimension)!.push(pair);
    if (pair.death === Infinity) essential.push(pair);
  }

  const persistencePairs = result.persistence.pairs.filter(keep);
  const pairsByDimension: Record<number, number> = {};
  let essentialCount = 0;
  // A single pass, never a spread: `Math.max(...persistencePairs.map(...))`
  // passes one function argument per pair, and a truncation-artifact-heavy
  // input (hundreds of thousands of pairs at the dimension cap) blows the call
  // stack (`RangeError: Maximum call stack size exceeded`) well before it
  // blows any array-length limit.
  let dimension = 0;
  for (const pair of persistencePairs) {
    pairsByDimension[pair.dimension] = (pairsByDimension[pair.dimension] ?? 0) + 1;
    if (pair.death === Infinity) essentialCount++;
    if (pair.dimension > dimension) dimension = pair.dimension;
  }

  return {
    ...result,
    persistence: {
      ...result.persistence,
      pairs: persistencePairs,
      pairsByDimension,
      essentialCount,
      dimension,
    },
    diagram: { pairs: diagramPairs, byDimension, essential },
  };
}
