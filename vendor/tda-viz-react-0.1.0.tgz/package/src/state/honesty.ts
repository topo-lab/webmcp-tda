/**
 * Presentation rules for Betti numbers and truncated complexes
 * (SPEC.md §5 — correctness requirements, not style preferences).
 *
 * Ported from tda-explorer's `src/utils/homologyHonesty.ts`.
 *
 * A Rips (or Čech) complex capped at simplex dimension d has no (d+1)-simplices
 * to fill its top-dimensional cycles, so every unfilled d-boundary is counted
 * as a hole. That number is the correct homology of the truncated complex, but
 * it is not topology of the underlying space. By the Nerve theorem, a point
 * cloud in R^{ambient} also has no homology in degree >= ambient.
 *
 * Show β0 … β_{k-1} only, where k = min(cap, ambientDim). Never present the
 * withheld top-dimensional count as a void / loop / component.
 *
 * TODO(SPEC.md §5): port `hiddenBettiNote` and `simplexCostHint` from
 * tda-explorer when the package grows user-facing messaging for withheld
 * dimensions.
 */
import type { PersistenceDiagram, PersistencePair, PersistenceResult } from 'tda-wasm';

export const DEFAULT_MAX_SIMPLEX_DIMENSION = 2;
export const MIN_MAX_SIMPLEX_DIMENSION = 1;
export const MAX_MAX_SIMPLEX_DIMENSION = 4;

/**
 * True when homology in `homologyDim` can be real for points in `ambientDim`
 * dimensions. By the Nerve theorem, points in R^d have no homology above
 * degree d-1, so only H_k with k < d should be displayed.
 */
export function isRealHomologyDim(homologyDim: number, ambientDim: number): boolean {
  return homologyDim < ambientDim;
}

export interface ReliableBettiOptions {
  /** Highest simplex dimension the complex was (or will be) built to. */
  maxSimplexDimension: number;
  /** Ambient dimension of the point cloud (2 for circle, 3 for sphere/torus). */
  ambientDim: number;
}

/**
 * How many Betti numbers are safe to show, starting at β0.
 * Returns k such that β0 … β_{k-1} are reportable as topology.
 */
export function reliableBettiLength({
  maxSimplexDimension,
  ambientDim,
}: ReliableBettiOptions): number {
  const cap = Math.max(0, Math.floor(maxSimplexDimension));
  const ambient = Math.max(0, Math.floor(ambientDim));
  return Math.max(0, Math.min(cap, ambient));
}

/** Slice of `betti` that may be shown as topology (never the truncated top dim). */
export function reliableBettiSlice(
  betti: number[] | undefined,
  opts: ReliableBettiOptions,
): number[] {
  if (!betti || betti.length === 0) return [];
  return betti.slice(0, reliableBettiLength(opts));
}

/**
 * Drop homology classes that cannot be real for points in `ambientDim`
 * dimensions. By the Nerve theorem a point cloud in R^d has no homology above
 * degree d-1, so any H_k with k >= d is a truncation artifact.
 *
 * Recomputes persistence summary fields from the kept pairs so counts stay
 * consistent. The canonical regression: a 50-point 2D circle at cap 2 must
 * NOT report β₂ = 150.
 *
 * This function only ever *removes* computed pairs; it never invents any.
 */
export function filterRealHomology<
  R extends {
    persistence: PersistenceResult;
    diagram: PersistenceDiagram;
  },
>(result: R, ambientDim: number): R {
  const keep = (pair: PersistencePair) => isRealHomologyDim(pair.dimension, ambientDim);

  const diagramPairs = result.diagram.pairs.filter(keep);
  const byDimension = new Map<number, PersistencePair[]>();
  const essential: PersistencePair[] = [];
  for (const pair of diagramPairs) {
    if (!byDimension.has(pair.dimension)) byDimension.set(pair.dimension, []);
    byDimension.get(pair.dimension)!.push(pair);
    if (pair.death === Infinity) essential.push(pair);
  }

  const persistencePairs = result.persistence.pairs.filter(keep);
  const pairsByDimension: Record<number, number> = {};
  let essentialCount = 0;
  for (const pair of persistencePairs) {
    pairsByDimension[pair.dimension] = (pairsByDimension[pair.dimension] ?? 0) + 1;
    if (pair.death === Infinity) essentialCount++;
  }

  return {
    ...result,
    persistence: {
      ...result.persistence,
      pairs: persistencePairs,
      pairsByDimension,
      essentialCount,
      dimension: Math.max(...persistencePairs.map((pair) => pair.dimension), 0),
    },
    diagram: { pairs: diagramPairs, byDimension, essential },
  };
}
