/**
 * Headless state layer (SPEC.md §2): point cloud, params, results, honesty
 * filtering. Vanilla Zustand — usable without React (a future native shell
 * can drive it directly). React components bind via `useStore` in their own
 * layer.
 */
import { createStore } from 'zustand/vanilla';
import type { PipelineResult, TdaParams } from '../types/engine';
import { DEFAULT_MAX_SIMPLEX_DIMENSION, filterRealHomology } from './honesty';

export type ComputeStatus = 'idle' | 'computing' | 'ready' | 'error';

export const DEFAULT_TDA_PARAMS: TdaParams = Object.freeze({
  complexType: 'rips',
  maxEdgeLength: 1,
  maxSimplexDimension: DEFAULT_MAX_SIMPLEX_DIMENSION,
  coeffField: 2,
});

export interface TdaStateData {
  /** Flat coordinates [x0, y0, (z0,) x1, ...]. */
  points: number[];
  /** Ambient dimension of the cloud. */
  dimension: number;
  params: TdaParams;
  status: ComputeStatus;
  error: string | null;
  /** Unfiltered engine output — what was actually computed. */
  rawResult: PipelineResult | null;
  /** Honesty-filtered output — what may be presented (SPEC.md §5). */
  result: PipelineResult | null;
}

export interface TdaStateActions {
  setPoints: (points: number[], dimension: number) => void;
  setParams: (partial: Partial<TdaParams>) => void;
  startCompute: () => void;
  finishCompute: (raw: PipelineResult) => void;
  failCompute: (message: string) => void;
  reset: () => void;
}

export type TdaState = TdaStateData & TdaStateActions;

const INITIAL_DATA: TdaStateData = {
  points: [],
  dimension: 2,
  params: DEFAULT_TDA_PARAMS,
  status: 'idle',
  error: null,
  rawResult: null,
  result: null,
};

/** Results computed for other inputs are stale — clear, never display. */
const INVALIDATED = {
  status: 'idle' as const,
  error: null,
  rawResult: null,
  result: null,
};

export function createTdaStore(initial?: Partial<TdaStateData>) {
  return createStore<TdaState>()((set) => ({
    ...INITIAL_DATA,
    ...initial,
    setPoints: (points, dimension) => set({ points, dimension, ...INVALIDATED }),
    setParams: (partial) => set((s) => ({ params: { ...s.params, ...partial }, ...INVALIDATED })),
    startCompute: () => set({ status: 'computing', error: null }),
    finishCompute: (raw) =>
      set((s) => ({
        status: 'ready',
        error: null,
        rawResult: raw,
        result: filterRealHomology(raw, s.dimension),
      })),
    failCompute: (message) =>
      set({ status: 'error', error: message, rawResult: null, result: null }),
    reset: () => set({ ...INITIAL_DATA }),
  }));
}

export type TdaStore = ReturnType<typeof createTdaStore>;
