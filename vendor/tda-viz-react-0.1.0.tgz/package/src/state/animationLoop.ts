/**
 * The one animation loop an application built on this library is allowed to
 * hold (DESIGN.md §Motion, "Cost control").
 *
 * Several surfaces animating at once was the measured problem the library's
 * site redesign solved, and the fix is not a convention that components are
 * asked to respect — it is this module. There is a single module-level slot for
 * a live `requestAnimationFrame` loop, and `startAnimationLoop` CANCELS whatever
 * is in it before taking it. Two live loops are therefore not a bug a careless
 * caller can introduce; they are unrepresentable.
 *
 * Ownership is by token, not by id, so a late cleanup from an unmounted surface
 * cannot cancel the loop a newly mounted one has already started. React mounts
 * the next surface before it unmounts the previous one often enough for that to
 * matter, and in StrictMode it happens on every mount.
 *
 * Promoted from the site (`site/src/lib/animationLoop.ts`, 2026-09-02) so that
 * consumers — the TDA Explorer first — share the invariant instead of copying
 * the file. HEADLESS: this module imports nothing.
 */

/** Called once per frame with the seconds elapsed since the previous frame. */
export type AnimationTick = (deltaSeconds: number) => void;

interface LiveLoop {
  readonly token: object;
  readonly id: string;
  frame: number;
  last: number | null;
  readonly tick: AnimationTick;
}

let live: LiveLoop | null = null;

/** Which surface currently holds the loop, or null when nothing animates. */
export function activeLoopId(): string | null {
  return live ? live.id : null;
}

/**
 * Live loops. Zero or one, always — the invariant the tests assert, stated here
 * as a function so a test can assert it rather than infer it.
 */
export function activeLoopCount(): 0 | 1 {
  return live ? 1 : 0;
}

/**
 * Take the loop for `id`, stopping any other loop first. Returns the stop
 * function; calling it after another loop has taken over is a no-op.
 */
export function startAnimationLoop(id: string, tick: AnimationTick): () => void {
  stopAnimationLoop();
  const token = {};
  const loop: LiveLoop = { token, id, frame: 0, last: null, tick };
  const step = (now: number) => {
    if (live !== loop) return;
    const delta = loop.last === null ? 0 : Math.max(0, (now - loop.last) / 1000);
    loop.last = now;
    loop.tick(delta);
    if (live === loop) loop.frame = requestAnimationFrame(step);
  };
  live = loop;
  loop.frame = requestAnimationFrame(step);
  return () => {
    if (live && live.token === token) stopAnimationLoop();
  };
}

/** Stop the live loop, whatever it is. Safe to call when nothing is running. */
export function stopAnimationLoop(): void {
  if (!live) return;
  const stopping = live;
  live = null;
  cancelAnimationFrame(stopping.frame);
}
