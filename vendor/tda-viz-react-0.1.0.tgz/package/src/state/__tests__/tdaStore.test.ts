import { describe, expect, it } from 'vitest';
import type { PersistencePair } from 'tda-wasm';
import type { PipelineResult } from '../../types/engine';
import { DEFAULT_MAX_SIMPLEX_DIMENSION } from '../honesty';
import { DEFAULT_TDA_PARAMS, createTdaStore } from '../tdaStore';

function pair(dimension: number, birth: number, death: number): PersistencePair {
  return { dimension, birth, death };
}

function pipelineResult(pairs: PersistencePair[]): PipelineResult {
  const byDimension = new Map<number, PersistencePair[]>();
  const essential: PersistencePair[] = [];
  const pairsByDimension: Record<number, number> = {};
  let essentialCount = 0;
  for (const p of pairs) {
    if (!byDimension.has(p.dimension)) byDimension.set(p.dimension, []);
    byDimension.get(p.dimension)!.push(p);
    pairsByDimension[p.dimension] = (pairsByDimension[p.dimension] ?? 0) + 1;
    if (p.death === Infinity) {
      essential.push(p);
      essentialCount++;
    }
  }
  return {
    complex: { simplices: [], vertices: 0, dimension: -1, dimensionCounts: {} },
    persistence: {
      pairs,
      dimension: Math.max(...pairs.map((p) => p.dimension), 0),
      pairsByDimension,
      essentialCount,
    },
    diagram: { pairs, byDimension, essential },
  };
}

describe('createTdaStore (headless state layer, SPEC.md §2)', () => {
  it('is a vanilla zustand store — usable without React', () => {
    const store = createTdaStore();
    expect(typeof store.getState).toBe('function');
    expect(typeof store.subscribe).toBe('function');
  });

  it('starts idle with spec defaults', () => {
    const s = createTdaStore().getState();
    expect(s.points).toEqual([]);
    expect(s.dimension).toBe(2);
    expect(s.params).toEqual(DEFAULT_TDA_PARAMS);
    expect(s.params.maxSimplexDimension).toBe(DEFAULT_MAX_SIMPLEX_DIMENSION);
    expect(s.params.coeffField).toBe(2);
    expect(s.status).toBe('idle');
    expect(s.result).toBeNull();
    expect(s.rawResult).toBeNull();
    expect(s.error).toBeNull();
  });

  it('setPoints stores the cloud and invalidates stale results', () => {
    const store = createTdaStore();
    store.getState().finishCompute(pipelineResult([pair(0, 0, Infinity)]));
    store.getState().setPoints([0, 0, 1, 0, 0, 1], 2);
    const s = store.getState();
    expect(s.points).toEqual([0, 0, 1, 0, 0, 1]);
    expect(s.dimension).toBe(2);
    expect(s.status).toBe('idle');
    expect(s.result).toBeNull();
    expect(s.rawResult).toBeNull();
  });

  it('setParams merges partial params and invalidates stale results', () => {
    const store = createTdaStore();
    store.getState().finishCompute(pipelineResult([pair(0, 0, Infinity)]));
    store.getState().setParams({ complexType: 'cech', maxEdgeLength: 0.8 });
    const s = store.getState();
    expect(s.params.complexType).toBe('cech');
    expect(s.params.maxEdgeLength).toBe(0.8);
    expect(s.params.maxSimplexDimension).toBe(DEFAULT_MAX_SIMPLEX_DIMENSION);
    expect(s.result).toBeNull();
    expect(s.status).toBe('idle');
  });

  it('startCompute marks computing and clears prior error', () => {
    const store = createTdaStore();
    store.getState().failCompute('boom');
    store.getState().startCompute();
    const s = store.getState();
    expect(s.status).toBe('computing');
    expect(s.error).toBeNull();
  });

  it('finishCompute stores the raw result AND the honesty-filtered result', () => {
    const store = createTdaStore();
    store.getState().setPoints([0, 0, 1, 0, 0, 1], 2);
    const raw = pipelineResult([
      pair(0, 0, Infinity),
      pair(1, 0.4, 0.9),
      pair(2, 0.6, 0.7), // truncation artifact in ambient 2D — must be filtered
    ]);
    store.getState().finishCompute(raw);
    const s = store.getState();
    expect(s.status).toBe('ready');
    expect(s.rawResult).toBe(raw);
    expect(s.result).not.toBeNull();
    expect(s.result!.persistence.pairs.filter((p) => p.dimension >= 2)).toHaveLength(0);
    expect(s.rawResult!.persistence.pairs.filter((p) => p.dimension >= 2)).toHaveLength(1);
  });

  it('failCompute records the error as a real state (never a synthesized result)', () => {
    const store = createTdaStore();
    store.getState().startCompute();
    store.getState().failCompute('wasm exploded');
    const s = store.getState();
    expect(s.status).toBe('error');
    expect(s.error).toBe('wasm exploded');
    expect(s.result).toBeNull();
    expect(s.rawResult).toBeNull();
  });

  it('reset returns to the initial state', () => {
    const store = createTdaStore();
    store.getState().setPoints([1, 2], 2);
    store.getState().failCompute('x');
    store.getState().reset();
    const s = store.getState();
    expect(s.points).toEqual([]);
    expect(s.status).toBe('idle');
    expect(s.error).toBeNull();
  });
});
