/**
 * The one-loop invariant, asserted from the outside: by counting the
 * animation-frame callbacks pending on the global, not by trusting the
 * registry's own bookkeeping. A stray `requestAnimationFrame` that bypassed
 * the registry would show up here as a second pending callback.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  activeLoopCount,
  activeLoopId,
  startAnimationLoop,
  stopAnimationLoop,
} from '../animationLoop';

/** A controllable rAF that also reports how many callbacks are pending. */
function installFrameClock() {
  const pending = new Map<number, FrameRequestCallback>();
  let nextHandle = 1;
  let now = 0;

  vi.stubGlobal('requestAnimationFrame', (callback: FrameRequestCallback) => {
    const handle = nextHandle++;
    pending.set(handle, callback);
    return handle;
  });
  vi.stubGlobal('cancelAnimationFrame', (handle: number) => {
    pending.delete(handle);
  });

  return {
    get liveCallbacks() {
      return pending.size;
    },
    advance(ms = 16) {
      now += ms;
      const due = [...pending.entries()];
      pending.clear();
      for (const [, callback] of due) callback(now);
    },
    reset() {
      pending.clear();
    },
  };
}

let clock: ReturnType<typeof installFrameClock>;

beforeEach(() => {
  clock = installFrameClock();
});

afterEach(() => {
  stopAnimationLoop();
  clock.reset();
  vi.unstubAllGlobals();
});

describe('the animation loop registry', () => {
  it('starts empty and stops safely when nothing runs', () => {
    expect(activeLoopCount()).toBe(0);
    expect(activeLoopId()).toBeNull();
    expect(() => stopAnimationLoop()).not.toThrow();
    expect(clock.liveCallbacks).toBe(0);
  });

  it('holds at most one loop, whatever a caller does', () => {
    startAnimationLoop('a', () => {});
    expect(activeLoopCount()).toBe(1);
    expect(activeLoopId()).toBe('a');
    expect(clock.liveCallbacks).toBe(1);

    startAnimationLoop('b', () => {});
    expect(activeLoopCount()).toBe(1);
    expect(activeLoopId()).toBe('b');
    expect(clock.liveCallbacks).toBe(1);

    startAnimationLoop('c', () => {});
    startAnimationLoop('d', () => {});
    expect(activeLoopCount()).toBe(1);
    expect(clock.liveCallbacks).toBe(1);
  });

  it('stops the previous loop rather than leaving it ticking', () => {
    const first = vi.fn();
    startAnimationLoop('a', first);
    clock.advance();
    expect(first).toHaveBeenCalledTimes(1);

    startAnimationLoop('b', () => {});
    clock.advance();
    clock.advance();
    expect(first).toHaveBeenCalledTimes(1);
    expect(clock.liveCallbacks).toBe(1);
  });

  it('reports the seconds since the previous frame, and zero on the first', () => {
    const deltas: number[] = [];
    startAnimationLoop('a', (delta) => deltas.push(delta));
    clock.advance(16);
    clock.advance(32);
    clock.advance(8);
    expect(deltas[0]).toBe(0);
    expect(deltas[1]).toBeCloseTo(0.032);
    expect(deltas[2]).toBeCloseTo(0.008);
  });

  it('ignores a stale stop from a loop that has already been replaced', () => {
    const stopA = startAnimationLoop('a', () => {});
    startAnimationLoop('b', () => {});
    stopA();
    expect(activeLoopId()).toBe('b');
    expect(activeLoopCount()).toBe(1);
    expect(clock.liveCallbacks).toBe(1);
  });

  it('releases the frame when its own stop is called', () => {
    const stop = startAnimationLoop('a', () => {});
    stop();
    expect(activeLoopCount()).toBe(0);
    expect(clock.liveCallbacks).toBe(0);
  });

  it('does not re-request a frame after being stopped from inside its own tick', () => {
    startAnimationLoop('a', () => stopAnimationLoop());
    clock.advance();
    expect(activeLoopCount()).toBe(0);
    expect(clock.liveCallbacks).toBe(0);
  });
});
