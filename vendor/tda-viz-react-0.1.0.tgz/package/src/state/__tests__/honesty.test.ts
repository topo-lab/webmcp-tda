import { describe, expect, it } from 'vitest';
import type { PersistencePair } from 'tda-wasm';
import {
  DEFAULT_MAX_SIMPLEX_DIMENSION,
  MAX_MAX_SIMPLEX_DIMENSION,
  MIN_MAX_SIMPLEX_DIMENSION,
  filterRealHomology,
  isRealHomologyDim,
  reliableBettiLength,
  reliableBettiSlice,
} from '../honesty';

function pair(dimension: number, birth: number, death: number): PersistencePair {
  return { dimension, birth, death };
}

/** Build a minimal PipelineResult-shaped object from raw pairs. */
function resultFromPairs(pairs: PersistencePair[]) {
  const byDimension = new Map<number, PersistencePair[]>();
  const essential: PersistencePair[] = [];
  const pairsByDimension: Record<number, number> = {};
  let essentialCount = 0;
  for (const p of pairs) {
    if (!byDimension.has(p.dimension)) byDimension.set(p.dimension, []);
    byDimension.get(p.dimension)!.push(p);
    pairsByDimension[p.dimension] = (pairsByDimension[p.dimension] ?? 0) + 1;
    if (p.death === Infinity) {
      essential.push(p);
      essentialCount++;
    }
  }
  return {
    persistence: {
      pairs,
      dimension: Math.max(...pairs.map((p) => p.dimension), 0),
      pairsByDimension,
      essentialCount,
    },
    diagram: { pairs, byDimension, essential },
  };
}

describe('constants (ported from tda-explorer homologyHonesty.ts)', () => {
  it('defaults maxSimplexDimension to 2 (SPEC.md §5)', () => {
    expect(DEFAULT_MAX_SIMPLEX_DIMENSION).toBe(2);
  });

  it('bounds the simplex-dimension cap', () => {
    expect(MIN_MAX_SIMPLEX_DIMENSION).toBe(1);
    expect(MAX_MAX_SIMPLEX_DIMENSION).toBe(4);
  });
});

describe('isRealHomologyDim (Nerve theorem)', () => {
  it('allows H_k only for k < ambient dimension', () => {
    expect(isRealHomologyDim(0, 2)).toBe(true);
    expect(isRealHomologyDim(1, 2)).toBe(true);
    expect(isRealHomologyDim(2, 2)).toBe(false);
    expect(isRealHomologyDim(2, 3)).toBe(true);
    expect(isRealHomologyDim(3, 3)).toBe(false);
  });
});

describe('reliableBettiLength / reliableBettiSlice', () => {
  it('shows min(cap, ambientDim) Betti numbers', () => {
    expect(reliableBettiLength({ maxSimplexDimension: 2, ambientDim: 2 })).toBe(2);
    expect(reliableBettiLength({ maxSimplexDimension: 2, ambientDim: 3 })).toBe(2);
    expect(reliableBettiLength({ maxSimplexDimension: 3, ambientDim: 3 })).toBe(3);
    expect(reliableBettiLength({ maxSimplexDimension: 1, ambientDim: 3 })).toBe(1);
  });

  it('never goes negative on junk input', () => {
    expect(reliableBettiLength({ maxSimplexDimension: -1, ambientDim: 2 })).toBe(0);
    expect(reliableBettiLength({ maxSimplexDimension: 2, ambientDim: -1 })).toBe(0);
  });

  it('CANONICAL REGRESSION: a 50-point 2D circle at cap 2 must NOT report beta_2 = 150', () => {
    // Real engine output for the 50-point unit circle, Rips, maxEdge 0.6, cap 2
    // (verified against tda-wasm): betti = [1, 1, 150]. The 150 is a truncation
    // artifact, not topology (SPEC.md §5).
    const rawBetti = [1, 1, 150];
    const shown = reliableBettiSlice(rawBetti, { maxSimplexDimension: 2, ambientDim: 2 });
    expect(shown).toEqual([1, 1]);
    expect(shown).not.toContain(150);
  });

  it('returns [] for missing betti (empty is a real state, never synthesized)', () => {
    expect(reliableBettiSlice(undefined, { maxSimplexDimension: 2, ambientDim: 2 })).toEqual([]);
    expect(reliableBettiSlice([], { maxSimplexDimension: 2, ambientDim: 2 })).toEqual([]);
  });
});

describe('filterRealHomology (Nerve filtering, SPEC.md §5)', () => {
  it('CANONICAL REGRESSION: drops all 150 spurious H_2 pairs for 2D data', () => {
    const spurious = Array.from({ length: 150 }, (_, i) => pair(2, 0.6 + i * 0.001, 0.7));
    const real = [pair(0, 0, Infinity), pair(0, 0, 0.12), pair(1, 0.13, Infinity)];
    const raw = resultFromPairs([...real, ...spurious]);

    const filtered = filterRealHomology(raw, 2);

    expect(filtered.persistence.pairs.filter((p) => p.dimension >= 2)).toHaveLength(0);
    expect(filtered.diagram.pairs.filter((p) => p.dimension >= 2)).toHaveLength(0);
    expect(filtered.persistence.pairsByDimension[2]).toBeUndefined();
    expect(filtered.diagram.byDimension.has(2)).toBe(false);
    // Kept pairs are untouched.
    expect(filtered.persistence.pairs).toHaveLength(3);
  });

  it('recomputes summary fields from kept pairs so counts stay consistent', () => {
    const raw = resultFromPairs([
      pair(0, 0, Infinity),
      pair(1, 0.2, 0.5),
      pair(2, 0.6, Infinity), // spurious AND essential — must not leak into counts
    ]);
    const filtered = filterRealHomology(raw, 2);
    expect(filtered.persistence.essentialCount).toBe(1);
    expect(filtered.persistence.dimension).toBe(1);
    expect(filtered.diagram.essential).toHaveLength(1);
    expect(filtered.diagram.essential[0]!.dimension).toBe(0);
  });

  it('keeps H_2 for 3D ambient data (real voids are reportable)', () => {
    const raw = resultFromPairs([pair(0, 0, Infinity), pair(2, 0.3, 0.9)]);
    const filtered = filterRealHomology(raw, 3);
    expect(filtered.persistence.pairs).toHaveLength(2);
    expect(filtered.diagram.byDimension.has(2)).toBe(true);
  });

  it('never invents pairs: empty input stays empty', () => {
    const filtered = filterRealHomology(resultFromPairs([]), 2);
    expect(filtered.persistence.pairs).toHaveLength(0);
    expect(filtered.diagram.pairs).toHaveLength(0);
    expect(filtered.persistence.essentialCount).toBe(0);
  });
});
