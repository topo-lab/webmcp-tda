import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CIRCLE24_ALPHA,
  CIRCLE50_RIPS_CAP2,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { Barcode } from './Barcode';

/**
 * A barcode draws one horizontal line per persistence pair, from the scale
 * at which a feature is born to the scale at which it dies. Long bars are
 * structure; bars hugging zero length are noise.
 *
 * The barcode is a SUMMARY of the filtration (SPEC §4.3) — it already
 * contains every t, which is why moving the playhead never recomputes
 * anything. It takes a `Filtration` and draws exactly `filtration.pairs`,
 * the Nerve-filtered set; truncation artifacts stay in `rawPairs` and cannot
 * reach this chart. Every story uses recorded REAL GUDHI output.
 */
const meta = {
  title: 'Summaries/Barcode',
  component: Barcode,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Birth-to-death intervals for each homology class. Colour encodes homology degree: H₀ components (blue), H₁ loops (orange).',
      },
    },
  },
} satisfies Meta<typeof Barcode>;

export default meta;
type Story = StoryObj<typeof meta>;

const circleAlpha = recordedFiltration(CIRCLE24_ALPHA);
const circleRips = recordedFiltration(CIRCLE50_RIPS_CAP2);
const weighted = recordedFiltration(WEIGHTED3_ALPHA);

const empty = recordedFiltration({
  name: 'EMPTY',
  cloud: { points: [], weights: [], dimension: 2 },
  complexType: 'rips',
  convention: 'rips',
  maxSimplexDimension: 2,
  simplices: [],
  rawPairs: [],
});

/**
 * The canonical teaching example under the alpha filtration: 24 circle
 * points give 24 H₀ components that merge at the first critical value
 * (sin²(π/24)), and one H₁ loop that survives until t = 1 — the squared
 * circumradius, where the balls reach the center and the hole fills.
 */
export const RealCircleAlpha: Story = { args: { filtration: circleAlpha } };

/**
 * The same data with the playhead at t. The playhead is the current DRAWING
 * scale — the bars are complete; t indexes into them (SPEC §1.5).
 */
export const WithPlayhead: Story = { args: { filtration: circleAlpha, t: 0.5 } };

/**
 * A weighted filtration starts below zero: the heavy vertex (w = 0.5) enters
 * at t = −w, so its essential H₀ bar begins at −0.5. The axis reaches down
 * to the true start instead of clipping the bar's birth.
 */
export const WeightedNegativeBirth: Story = { args: { filtration: weighted, t: 0 } };

/**
 * Honesty regression on display: the raw engine output for this Rips
 * filtration contains 150 spurious H₂ pairs (2D cloud, cap 2 — truncation
 * artifacts, not topology). They are in `rawPairs`; this chart draws the 51
 * Nerve-filtered pairs and can never show them.
 */
export const HonestyFiltered: Story = {
  args: { filtration: circleRips, t: 0.3, height: 320 },
};

/**
 * Classes that never die (death = ∞) are *essential*. They are marked as
 * essential rather than silently clipped to the axis limit, which would
 * read as a feature that died exactly at the edge of the window.
 */
export const EssentialClasses: Story = { args: { filtration: weighted } };

/**
 * Empty is a real state with a real rendering: no pairs, no bars — never
 * placeholder bars (SPEC §1.6).
 */
export const Empty: Story = { args: { filtration: empty } };

/** Custom palette, for embedding in a themed surface. */
export const CustomPalette: Story = {
  args: {
    filtration: circleAlpha,
    t: 0.4,
    colors: ['#0ea5e9', '#f43f5e', '#22c55e', '#a855f7'],
  },
};
