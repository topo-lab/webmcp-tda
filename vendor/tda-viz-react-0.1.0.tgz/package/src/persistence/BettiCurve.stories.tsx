import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CIRCLE24_ALPHA,
  CIRCLE50_RIPS_CAP2,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { BettiCurve } from './BettiCurve';

/**
 * β_k as a function of the scale: how many classes of each degree are alive
 * at each t. Drawn as a step function because Betti numbers are integers
 * that change at discrete events (the criticalValues) — never smoothed.
 *
 * A summary of the filtration (SPEC §4.3). It samples `filtration.bettiAt`,
 * which is honesty-sliced (SPEC §1.6): a 2D cloud at cap 2 exposes β₀ and β₁
 * only, so the 150 spurious H₂ pairs in the honesty fixture's raw output
 * cannot appear here no matter what a caller passes. The x-axis names the
 * radius convention, because "0.5" means different pictures under rips
 * (radius 0.25) and čech (radius 0.5). All stories use recorded REAL GUDHI
 * output.
 */
const meta = {
  title: 'Summaries/BettiCurve',
  component: BettiCurve,
  tags: ['autodocs'],
} satisfies Meta<typeof BettiCurve>;

export default meta;
type Story = StoryObj<typeof meta>;

const circleAlpha = recordedFiltration(CIRCLE24_ALPHA);
const circleRips = recordedFiltration(CIRCLE50_RIPS_CAP2);
const weighted = recordedFiltration(WEIGHTED3_ALPHA);

/**
 * The circle's signature: β₀ drops from 24 to 1 at the first critical value,
 * β₁ rises to 1 at the same moment (the ring closes) and drops at t = 1
 * (the hole fills).
 */
export const RealCircleAlpha: Story = { args: { filtration: circleAlpha } };

/** The playhead marks the t the rest of the instrument is drawing. */
export const WithPlayhead: Story = { args: { filtration: circleAlpha, t: 0.5 } };

/**
 * The weighted cloud's story in Betti numbers: 3 components at t = 0, then
 * 2, then 1 as the heavy ball reaches each light point; β₁ blips to 1 on
 * [0.89, 1.086) while the triangle's hole is open.
 */
export const WeightedMerges: Story = { args: { filtration: weighted, t: 0.9 } };

/**
 * Honesty is structural here: this Rips filtration's raw output contains 150
 * H₂ pairs, but bettiAt only exposes resolvable degrees, so there is no β₂
 * series to draw.
 */
export const NoBeta2ForA2DCloud: Story = { args: { filtration: circleRips, t: 0.4 } };

/** A single degree in isolation. */
export const Beta1Only: Story = { args: { filtration: circleAlpha, dimensions: [1] } };
