import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CIRCLE24_ALPHA,
  CIRCLE50_RIPS_CAP2,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { PersistenceDiagram } from './PersistenceDiagram';

/**
 * The same pairs a barcode shows, plotted as (birth, death) points above the
 * diagonal. Distance from the diagonal is lifetime: structure floats high,
 * noise hugs the line. A summary of the filtration (SPEC §4.3), taking a
 * `Filtration` — never raw pairs.
 *
 * With a t, the crosshair splits the plane: classes alive at t (birth ≤ t <
 * death) lie left of the vertical line and above the horizontal one, and are
 * tagged `data-alive`. Essential classes (death = ∞) sit on a labelled rule
 * ABOVE the axis rather than at its limit — the axis limit would read as a
 * finite death. All stories use recorded REAL GUDHI output.
 */
const meta = {
  title: 'Summaries/PersistenceDiagram',
  component: PersistenceDiagram,
  tags: ['autodocs'],
} satisfies Meta<typeof PersistenceDiagram>;

export default meta;
type Story = StoryObj<typeof meta>;

const circleAlpha = recordedFiltration(CIRCLE24_ALPHA);
const circleRips = recordedFiltration(CIRCLE50_RIPS_CAP2);
const weighted = recordedFiltration(WEIGHTED3_ALPHA);

const empty = recordedFiltration({
  name: 'EMPTY',
  cloud: { points: [], weights: [], dimension: 2 },
  complexType: 'alpha',
  convention: 'alpha',
  maxSimplexDimension: 0,
  simplices: [],
  rawPairs: [],
});

/**
 * The 24-point circle under alpha: a tight cluster of H₀ deaths at the first
 * critical value, and the loop far above the diagonal at (0.017, 1) — the
 * lifetime gap IS the signal.
 */
export const RealCircleAlpha: Story = { args: { filtration: circleAlpha } };

/**
 * The crosshair at t = 0.5: the essential component and the loop are alive
 * (upper-left quadrant); everything short-lived is already dead and dimmed.
 */
export const CrosshairAtT: Story = { args: { filtration: circleAlpha, t: 0.5 } };

/**
 * The weighted cloud: the essential class was born at t = −0.5 (the heavy
 * vertex's entry), so the axes extend below zero rather than clipping it.
 */
export const WeightedNegativeBirth: Story = { args: { filtration: weighted, t: 0.9 } };

/**
 * 51 Nerve-filtered pairs of the 50-point Rips circle. The 150 spurious H₂
 * pairs in the raw output are structurally unreachable from this chart.
 */
export const HonestyFiltered: Story = { args: { filtration: circleRips } };

/** No pairs, no points — only the axes and the diagonal (a real state). */
export const Empty: Story = { args: { filtration: empty } };
