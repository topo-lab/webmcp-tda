/**
 * <BettiCurve>: a summary of the filtration (SPEC.md §4.3) — β_k as a
 * function of the scale, sampled from `filtration.bettiAt`, which is already
 * honesty-sliced to the degrees the complex can resolve (SPEC.md §1.6).
 *
 * Takes a Filtration, never raw pairs (SPEC.md §4). Drawn as a step function
 * because Betti numbers are integers that change at discrete events; it
 * never smooths, interpolates across a gap, or invents a class.
 */
import { useMemo } from 'react';
import type { PersistencePair } from 'tda-wasm';
import type { Filtration } from '../filtration/types';
import { DEFAULT_DIMENSION_COLORS } from './Barcode';

export interface BettiCurveProps {
  filtration: Filtration;
  /** Current scale; draws the playhead when provided. */
  t?: number;
  /** Which homology degrees to draw. Defaults to every resolvable degree. */
  dimensions?: number[];
  /** Samples across the domain. */
  samples?: number;
  width?: number;
  height?: number;
  padding?: number;
  colors?: readonly string[];
  className?: string;
  'aria-label'?: string;
}

/** Number of degree-k classes alive at scale s: birth <= s < death. */
export function bettiAt(pairs: readonly PersistencePair[], dim: number, s: number): number {
  let n = 0;
  for (const p of pairs) {
    if (p.dimension !== dim) continue;
    if (p.birth <= s && (!Number.isFinite(p.death) || p.death > s)) n++;
  }
  return n;
}

export function BettiCurve({
  filtration,
  t,
  dimensions,
  samples = 160,
  width = 360,
  height = 200,
  padding = 32,
  colors = DEFAULT_DIMENSION_COLORS,
  className,
  'aria-label': ariaLabel = 'Betti curve',
}: BettiCurveProps) {
  const { domainMin, domainMax } = useMemo(() => {
    const min = Math.min(
      0,
      filtration.criticalValues.length > 0 ? filtration.criticalValues[0] : 0,
    );
    return { domainMin: min, domainMax: Math.max(filtration.tMax, min + 1e-9, 1e-9) };
  }, [filtration]);

  const dims = useMemo(() => {
    const resolvable = filtration.bettiAt(domainMin).length;
    const all = Array.from({ length: resolvable }, (_, d) => d);
    if (!dimensions) return all;
    return dimensions.filter((d) => d < resolvable).sort((a, b) => a - b);
  }, [filtration, dimensions, domainMin]);

  const { series, peak } = useMemo(() => {
    const span = domainMax - domainMin;
    const grid: number[][] = [];
    for (let i = 0; i <= samples; i++) {
      grid.push(filtration.bettiAt(domainMin + (i / samples) * span));
    }
    const s = dims.map((d) => ({
      dim: d,
      pts: grid.map((betti, i) => ({
        t: domainMin + (i / samples) * span,
        v: betti[d] ?? 0,
      })),
    }));
    const hi = s.reduce((m, ser) => Math.max(m, ...ser.pts.map((p) => p.v)), 0);
    return { series: s, peak: hi > 0 ? hi : 1 };
  }, [filtration, dims, samples, domainMin, domainMax]);

  const innerW = Math.max(width - padding * 2, 1);
  const innerH = Math.max(height - padding * 2, 1);
  const span = domainMax - domainMin || 1;
  const x = (v: number) => padding + ((v - domainMin) / span) * innerW;
  const y = (v: number) => padding + innerH - (v / peak) * innerH;

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      role="img"
      aria-label={ariaLabel}
      data-testid="betti-curve"
    >
      <line
        x1={padding}
        y1={padding + innerH}
        x2={padding + innerW}
        y2={padding + innerH}
        stroke="#374151"
      />
      <line x1={padding} y1={padding} x2={padding} y2={padding + innerH} stroke="#374151" />

      {series.map((ser) => {
        // Step path: Betti numbers are integer-valued and change discretely.
        let d = '';
        ser.pts.forEach((p, i) => {
          if (i === 0) d += `M ${x(p.t)} ${y(p.v)}`;
          else d += ` L ${x(p.t)} ${y(ser.pts[i - 1].v)} L ${x(p.t)} ${y(p.v)}`;
        });
        return (
          <path
            key={ser.dim}
            d={d}
            fill="none"
            stroke={colors[ser.dim] ?? '#6b7280'}
            strokeWidth={1.8}
            data-testid="betti-series"
            data-dimension={ser.dim}
          />
        );
      })}

      {t !== undefined && (
        <line
          data-testid="betti-playhead"
          x1={x(Math.min(Math.max(t, domainMin), domainMax))}
          y1={padding - 4}
          x2={x(Math.min(Math.max(t, domainMin), domainMax))}
          y2={padding + innerH + 4}
          stroke="#ef4444"
          strokeDasharray="4 3"
        />
      )}

      <text x={padding - 6} y={padding + 4} fontSize={9} textAnchor="end" fill="#6b7280">
        {peak}
      </text>
      <text x={padding - 6} y={padding + innerH} fontSize={9} textAnchor="end" fill="#6b7280">
        0
      </text>
      <text
        x={padding + innerW / 2}
        y={height - 6}
        fontSize={10}
        textAnchor="middle"
        fill="#374151"
      >
        Filtration value ({filtration.convention} convention)
      </text>

      <g>
        {series.map((ser, i) => (
          <g key={`lg${ser.dim}`} transform={`translate(${padding + 8 + i * 44}, ${padding + 10})`}>
            <line
              x1={0}
              y1={0}
              x2={14}
              y2={0}
              stroke={colors[ser.dim] ?? '#6b7280'}
              strokeWidth={2.4}
            />
            <text x={18} y={3} fontSize={9} fill="#374151">
              β{ser.dim}
            </text>
          </g>
        ))}
      </g>
    </svg>
  );
}
