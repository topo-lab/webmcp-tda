/**
 * <PersistenceImage>: a summary of the filtration (SPEC.md §4.3) — the
 * diagram rendered as a Gaussian-kernel heatmap in (birth, lifetime)
 * coordinates, a vectorization suitable as input to machine learning.
 *
 * Honesty (SPEC.md §1.6): when an engine-computed grid is supplied it is
 * rendered verbatim and labelled data-source="engine". Otherwise a local
 * kernel rendering of `filtration.pairs` is used and labelled
 * data-source="local", so a viewer is never misled about which numbers came
 * from the engine (tda-wasm's own `computePersistenceImage` path is labelled
 * Experimental / manual C++ there).
 */
import { useMemo } from 'react';
import type { PersistencePair } from 'tda-wasm';
import type { Filtration } from '../filtration/types';

export interface PersistenceImageProps {
  filtration: Filtration;
  /** Precomputed row-major grid from the engine. Preferred over local rendering. */
  image?: number[];
  width?: number;
  height?: number;
  /** Grid resolution when rendering locally from the filtration's pairs. */
  resolution?: number;
  sigma?: number;
  /** Low→high colour ramp. */
  ramp?: readonly [string, string];
  className?: string;
  'aria-label'?: string;
}

/** Renders pairs into a (birth, lifetime) grid with a Gaussian kernel. */
export function renderKernel(
  pairs: readonly PersistencePair[],
  res: number,
  sigma: number,
): { grid: number[]; birthMax: number; lifeMax: number } {
  const finite = pairs.filter((p) => Number.isFinite(p.death));
  let birthMax = 0;
  let lifeMax = 0;
  for (const p of finite) {
    if (p.birth > birthMax) birthMax = p.birth;
    const life = p.death - p.birth;
    if (life > lifeMax) lifeMax = life;
  }
  if (birthMax <= 0) birthMax = 1;
  if (lifeMax <= 0) lifeMax = 1;

  const grid = new Array(res * res).fill(0);
  const twoSigmaSq = 2 * sigma * sigma;
  for (const p of finite) {
    const life = p.death - p.birth;
    // Weight by lifetime: long-lived features matter more than noise.
    const w = life / lifeMax;
    for (let iy = 0; iy < res; iy++) {
      const ly = ((iy + 0.5) / res) * lifeMax;
      for (let ix = 0; ix < res; ix++) {
        const bx = ((ix + 0.5) / res) * birthMax;
        const d2 = ((bx - p.birth) / birthMax) ** 2 + ((ly - life) / lifeMax) ** 2;
        grid[iy * res + ix] += w * Math.exp(-d2 / twoSigmaSq);
      }
    }
  }
  return { grid, birthMax, lifeMax };
}

function lerpColor(a: string, b: string, t: number): string {
  const pa = [1, 3, 5].map((i) => parseInt(a.slice(i, i + 2), 16));
  const pb = [1, 3, 5].map((i) => parseInt(b.slice(i, i + 2), 16));
  const c = pa.map((v, i) => Math.round(v + (pb[i] - v) * t));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}

export function PersistenceImage({
  filtration,
  image,
  width = 260,
  height = 260,
  resolution = 24,
  sigma = 0.18,
  ramp = ['#f8fafc', '#1d4ed8'],
  className,
  'aria-label': ariaLabel = 'Persistence image',
}: PersistenceImageProps) {
  const { grid, res, source } = useMemo(() => {
    if (image && image.length > 0) {
      const r = Math.round(Math.sqrt(image.length));
      return { grid: image, res: r, source: 'engine' as const };
    }
    return {
      grid: renderKernel(filtration.pairs, resolution, sigma).grid,
      res: resolution,
      source: 'local' as const,
    };
  }, [image, filtration, resolution, sigma]);

  const peak = useMemo(() => grid.reduce((m, v) => (v > m ? v : m), 0) || 1, [grid]);
  const cw = width / res;
  const ch = height / res;

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      role="img"
      aria-label={ariaLabel}
      data-testid="persistence-image"
      data-source={source}
    >
      {grid.map((v, i) => {
        const ix = i % res;
        const iy = Math.floor(i / res);
        return (
          <rect
            key={i}
            x={ix * cw}
            // row 0 is the low-lifetime end, drawn at the bottom
            y={height - (iy + 1) * ch}
            width={cw + 0.5}
            height={ch + 0.5}
            fill={lerpColor(ramp[0], ramp[1], Math.min(v / peak, 1))}
          />
        );
      })}
    </svg>
  );
}
