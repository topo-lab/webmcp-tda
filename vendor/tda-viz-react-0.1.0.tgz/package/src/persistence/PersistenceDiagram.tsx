/**
 * <PersistenceDiagram>: a summary of the filtration (SPEC.md §4.3) — the
 * pairs plotted as (birth, death) points above the diagonal. Distance from
 * the diagonal is lifetime, so structure sits high and noise hugs the line.
 *
 * Takes a Filtration, never raw pairs (SPEC.md §4): it plots exactly
 * `filtration.pairs`. Essential classes (death = ∞) are drawn on a clearly
 * labelled "essential" rule ABOVE the plot area rather than at the top of
 * the axis, because placing them at the axis limit would read as a class
 * that died at that finite scale. When t is provided, a crosshair marks it
 * and the classes alive at t (birth ≤ t < death) are tagged.
 */
import { useMemo } from 'react';
import type { Filtration } from '../filtration/types';
import { DEFAULT_DIMENSION_COLORS } from './Barcode';

export interface PersistenceDiagramProps {
  filtration: Filtration;
  /** Current scale; draws the birth/death crosshair when provided. */
  t?: number;
  width?: number;
  height?: number;
  padding?: number;
  pointRadius?: number;
  colors?: readonly string[];
  className?: string;
  'aria-label'?: string;
}

export function PersistenceDiagram({
  filtration,
  t,
  width = 320,
  height = 320,
  padding = 34,
  pointRadius = 3.5,
  colors = DEFAULT_DIMENSION_COLORS,
  className,
  'aria-label': ariaLabel = 'Persistence diagram',
}: PersistenceDiagramProps) {
  const pairs = filtration.pairs;

  const { axisMin, axisMax } = useMemo(() => {
    const min = Math.min(
      0,
      filtration.criticalValues.length > 0 ? filtration.criticalValues[0] : 0,
    );
    const max = Math.max(filtration.tMax, min + 1e-9, 1e-9);
    return { axisMin: min, axisMax: max };
  }, [filtration]);

  const innerW = Math.max(width - padding * 2, 1);
  const innerH = Math.max(height - padding * 2, 1);
  const span = axisMax - axisMin || 1;
  const x = (v: number) => padding + ((Math.min(v, axisMax) - axisMin) / span) * innerW;
  const y = (v: number) => padding + innerH - ((Math.min(v, axisMax) - axisMin) / span) * innerH;

  const finite = pairs.filter((p) => Number.isFinite(p.death));
  const essential = pairs.filter((p) => !Number.isFinite(p.death));
  const essentialY = padding * 0.55;

  const alive = (p: { birth: number; death: number }) =>
    t !== undefined && p.birth <= t && t < p.death;

  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => +(axisMin + f * span).toFixed(2));

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      role="img"
      aria-label={ariaLabel}
      data-testid="persistence-diagram"
    >
      {ticks.map((v) => (
        <g key={`t${v}`}>
          <line x1={x(v)} y1={padding} x2={x(v)} y2={padding + innerH} stroke="#e5e7eb" />
          <line x1={padding} y1={y(v)} x2={padding + innerW} y2={y(v)} stroke="#e5e7eb" />
          <text x={x(v)} y={height - padding + 14} fontSize={9} textAnchor="middle" fill="#6b7280">
            {v}
          </text>
          <text x={padding - 6} y={y(v) + 3} fontSize={9} textAnchor="end" fill="#6b7280">
            {v}
          </text>
        </g>
      ))}

      {/* the diagonal: birth = death, zero lifetime */}
      <line
        x1={x(axisMin)}
        y1={y(axisMin)}
        x2={x(axisMax)}
        y2={y(axisMax)}
        stroke="#9ca3af"
        strokeDasharray="4 4"
        data-testid="diagonal"
      />

      {essential.length > 0 && (
        <>
          <line
            x1={padding}
            y1={essentialY}
            x2={padding + innerW}
            y2={essentialY}
            stroke="#9ca3af"
            strokeDasharray="2 3"
          />
          <text
            x={padding + innerW}
            y={essentialY - 5}
            fontSize={9}
            textAnchor="end"
            fill="#6b7280"
          >
            essential (death = ∞)
          </text>
        </>
      )}

      {t !== undefined && (
        <g data-testid="diagram-playhead">
          {/* classes alive at t satisfy birth <= t < death: left of the
              vertical line and above the horizontal one */}
          <line
            x1={x(t)}
            y1={padding}
            x2={x(t)}
            y2={padding + innerH}
            stroke="#ef4444"
            strokeDasharray="4 3"
            strokeOpacity={0.7}
          />
          <line
            x1={padding}
            y1={y(t)}
            x2={padding + innerW}
            y2={y(t)}
            stroke="#ef4444"
            strokeDasharray="4 3"
            strokeOpacity={0.7}
          />
        </g>
      )}

      {finite.map((p, i) => (
        <circle
          key={`f${i}`}
          data-testid="diagram-point"
          data-dimension={p.dimension}
          data-alive={alive(p) ? 'true' : undefined}
          cx={x(p.birth)}
          cy={y(p.death)}
          r={pointRadius}
          fill={colors[p.dimension] ?? '#6b7280'}
          fillOpacity={t === undefined || alive(p) ? 0.82 : 0.3}
        />
      ))}

      {essential.map((p, i) => (
        <circle
          key={`e${i}`}
          data-testid="diagram-point"
          data-essential="true"
          data-dimension={p.dimension}
          data-alive={alive(p) ? 'true' : undefined}
          cx={x(p.birth)}
          cy={essentialY}
          r={pointRadius}
          fill={colors[p.dimension] ?? '#6b7280'}
          stroke="#111827"
          strokeWidth={1}
        />
      ))}

      <text
        x={padding + innerW / 2}
        y={height - 4}
        fontSize={10}
        textAnchor="middle"
        fill="#374151"
      >
        Birth
      </text>
      <text
        x={10}
        y={padding + innerH / 2}
        fontSize={10}
        textAnchor="middle"
        fill="#374151"
        transform={`rotate(-90, 10, ${padding + innerH / 2})`}
      >
        Death
      </text>
    </svg>
  );
}
