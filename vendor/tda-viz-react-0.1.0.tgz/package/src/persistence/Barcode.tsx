/**
 * <Barcode>: a summary of the filtration (SPEC.md §4.3) — one horizontal bar
 * per persistence pair, birth to death, with a playhead at the current t.
 * Secondary surface: the filtration IS the object; this chart indexes it.
 *
 * Takes a Filtration, never raw pairs (SPEC.md §4): it draws exactly
 * `filtration.pairs` — the Nerve-filtered set — and never invents a bar.
 * Essential classes (death = ∞) are marked as essential rather than being
 * given a fake death time.
 *
 * Takes a filtration over EITHER domain (SPEC.md §3.1b). A grid filtration
 * carries `pairs`, `criticalValues` and `tMax` like any other, and the bars of
 * an image's sublevel diagram are the same object as the bars of a Rips one.
 * A SUPERLEVEL grid sweeps downward, so its pairs run birth ≥ death; a bar is
 * therefore drawn between the two endpoints rather than from the first to the
 * second, which is the interval the class is alive over either way and is
 * identical to the old arithmetic whenever birth ≤ death.
 */
import { useMemo } from 'react';
import type { AnyFiltration } from '../filtration/types';

/** Default per-dimension colors: H0, H1, H2, H3. */
export const DEFAULT_DIMENSION_COLORS = ['#2563eb', '#ea580c', '#16a34a', '#9333ea'] as const;

/** Props for `<Barcode>`. */
export interface BarcodeProps {
  filtration: AnyFiltration;
  /** Current scale; draws the playhead when provided. Filters nothing — the bars are complete. */
  t?: number;
  width?: number;
  height?: number;
  padding?: number;
  /** Bar colors indexed by homology dimension (cycled if exceeded). */
  colors?: readonly string[];
  className?: string;
  'aria-label'?: string;
}

function compareDeaths(a: number, b: number): number {
  if (a === b) return 0;
  return a < b ? -1 : 1;
}

/**
 * One horizontal bar per persistence pair, birth to death, with a playhead at
 * the current t (SPEC.md §4.3). Draws exactly `filtration.pairs` and never
 * invents a bar; essential classes are marked, not given a fake death.
 */
export function Barcode({
  filtration,
  t,
  width = 480,
  height = 240,
  padding = 16,
  colors = DEFAULT_DIMENSION_COLORS,
  className,
  'aria-label': ariaLabel = 'Persistence barcode',
}: BarcodeProps) {
  const { sorted, domainMin, domainMax } = useMemo(() => {
    const sortedPairs = [...filtration.pairs].sort(
      (a, b) => a.dimension - b.dimension || a.birth - b.birth || compareDeaths(a.death, b.death),
    );
    // Weighted vertices are born at t = -w (SPEC.md §1.2), so the axis must
    // reach below zero when the filtration does.
    const min = Math.min(
      0,
      filtration.criticalValues.length > 0 ? filtration.criticalValues[0] : 0,
    );
    const max = Math.max(filtration.tMax, t ?? -Infinity, min + 1e-9);
    return { sorted: sortedPairs, domainMin: min, domainMax: max };
  }, [filtration, t]);

  const innerWidth = Math.max(1, width - 2 * padding);
  const innerHeight = Math.max(1, height - 2 * padding);
  const span = domainMax - domainMin || 1;
  const x = (v: number) => padding + ((Math.min(v, domainMax) - domainMin) / span) * innerWidth;

  const rowHeight = sorted.length > 0 ? innerHeight / sorted.length : innerHeight;
  const barThickness = Math.min(12, Math.max(2, rowHeight * 0.6));

  return (
    <svg
      role="img"
      aria-label={ariaLabel}
      viewBox={`0 0 ${width} ${height}`}
      width={width}
      height={height}
      className={className}
      data-empty={sorted.length === 0 ? 'true' : undefined}
    >
      {sorted.map((pair, i) => {
        const essential = !Number.isFinite(pair.death);
        // Essential bars run to the EDGE of the plot on the side the sweep is
        // heading — a convention, marked via data-essential, never a fabricated
        // death value. An ascending filtration's essential class runs right; a
        // superlevel grid's runs left, because its death is -∞.
        const runsLeft = pair.death === -Infinity;
        const x0 = essential
          ? runsLeft
            ? padding
            : x(pair.birth)
          : x(Math.min(pair.birth, pair.death));
        const x1 = essential
          ? runsLeft
            ? x(pair.birth)
            : padding + innerWidth
          : x(Math.max(pair.birth, pair.death));
        const y = padding + i * rowHeight + (rowHeight - barThickness) / 2;
        return (
          <rect
            key={i}
            data-testid="tda-bar"
            data-dimension={pair.dimension}
            data-essential={essential ? 'true' : undefined}
            x={x0}
            y={y}
            width={Math.max(x1 - x0, 0)}
            height={barThickness}
            fill={colors[pair.dimension % colors.length]}
            opacity={essential ? 1 : 0.85}
          />
        );
      })}
      {t !== undefined && (
        <line
          data-testid="barcode-playhead"
          x1={x(t)}
          x2={x(t)}
          y1={padding / 2}
          y2={height - padding / 2}
          stroke="currentColor"
          strokeWidth={1}
          strokeDasharray="4 3"
        />
      )}
    </svg>
  );
}
