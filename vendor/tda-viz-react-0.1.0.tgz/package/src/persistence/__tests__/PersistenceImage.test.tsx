// <PersistenceImage> re-keyed on (filtration, t) — SPEC.md §4.3, with the
// v1 provenance behaviour intact (engine vs local grids are labelled).
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { WEIGHTED3_ALPHA, recordedFiltration } from '../../__fixtures__/realFiltrations';
import { PersistenceImage, renderKernel } from '../PersistenceImage';

const weighted = recordedFiltration(WEIGHTED3_ALPHA);

describe('renderKernel', () => {
  it('produces a res x res grid', () => {
    const { grid } = renderKernel([{ dimension: 1, birth: 0.2, death: 0.9 }], 8, 0.2);
    expect(grid).toHaveLength(64);
  });

  it('ignores essential classes, which have no finite lifetime', () => {
    const { grid } = renderKernel([{ dimension: 1, birth: 0.2, death: Infinity }], 6, 0.2);
    expect(grid.every((v) => v === 0)).toBe(true);
  });

  it('weights a long-lived class above a short-lived one', () => {
    const long = renderKernel([{ dimension: 1, birth: 0, death: 1 }], 8, 0.25);
    const short = renderKernel(
      [
        { dimension: 1, birth: 0, death: 1 },
        { dimension: 1, birth: 0, death: 0.05 },
      ],
      8,
      0.25,
    );
    // adding a near-diagonal class must not exceed the long-lived peak
    expect(Math.max(...short.grid)).toBeGreaterThanOrEqual(Math.max(...long.grid));
  });
});

describe('<PersistenceImage> provenance (never mislead about engine output)', () => {
  it('labels a locally rendered grid as local, not engine output', () => {
    render(<PersistenceImage filtration={weighted} resolution={6} />);
    expect(screen.getByTestId('persistence-image')).toHaveAttribute('data-source', 'local');
  });

  it('labels a supplied engine grid as engine output and renders it verbatim', () => {
    const { container } = render(<PersistenceImage filtration={weighted} image={[0, 1, 2, 3]} />);
    expect(screen.getByTestId('persistence-image')).toHaveAttribute('data-source', 'engine');
    expect(container.querySelectorAll('rect')).toHaveLength(4);
  });

  it('renders the filtration pairs locally when no engine grid is supplied', () => {
    const { container } = render(<PersistenceImage filtration={weighted} resolution={5} />);
    expect(container.querySelectorAll('rect')).toHaveLength(25);
  });
});
