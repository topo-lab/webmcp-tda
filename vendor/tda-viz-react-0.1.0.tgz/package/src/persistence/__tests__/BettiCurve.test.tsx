// <BettiCurve> re-keyed on (filtration, t) — SPEC.md §4.3. Sampled from
// filtration.bettiAt, so honesty slicing is structural, not a caller duty.
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  CIRCLE50_RIPS_CAP2,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { BettiCurve, bettiAt } from '../BettiCurve';

const weighted = recordedFiltration(WEIGHTED3_ALPHA);
const honesty = recordedFiltration(CIRCLE50_RIPS_CAP2);

const PAIRS = [
  { dimension: 0, birth: 0, death: Infinity },
  { dimension: 0, birth: 0, death: 0.5 },
  { dimension: 1, birth: 0.2, death: 1.0 },
];

describe('bettiAt (pure utility over pairs)', () => {
  it('counts classes alive on [birth, death)', () => {
    expect(bettiAt(PAIRS, 0, 0)).toBe(2);
    expect(bettiAt(PAIRS, 0, 0.6)).toBe(1);
  });

  it('treats death as exclusive so a class is dead at exactly its death', () => {
    expect(bettiAt(PAIRS, 1, 0.999)).toBe(1);
    expect(bettiAt(PAIRS, 1, 1.0)).toBe(0);
  });

  it('keeps essential classes alive at every scale', () => {
    expect(bettiAt(PAIRS, 0, 10_000)).toBe(1);
  });

  it('returns zero for a degree with no classes', () => {
    expect(bettiAt(PAIRS, 2, 0.5)).toBe(0);
  });
});

describe('<BettiCurve>', () => {
  it('draws one series per resolvable homology degree', () => {
    render(<BettiCurve filtration={weighted} />);
    expect(screen.getAllByTestId('betti-series')).toHaveLength(2); // beta_0, beta_1
  });

  it('never draws a beta_2 series for a 2D cloud at cap 2 (honesty is structural)', () => {
    render(<BettiCurve filtration={honesty} />);
    const dims = screen.getAllByTestId('betti-series').map((s) => s.getAttribute('data-dimension'));
    expect(dims).toEqual(['0', '1']); // the 150 raw H2 pairs cannot reach this chart
  });

  it('honours an explicit dimensions list', () => {
    render(<BettiCurve filtration={weighted} dimensions={[1]} />);
    const series = screen.getAllByTestId('betti-series');
    expect(series).toHaveLength(1);
    expect(series[0]).toHaveAttribute('data-dimension', '1');
  });

  it('shows a playhead only when t is supplied', () => {
    const { rerender } = render(<BettiCurve filtration={weighted} />);
    expect(screen.queryByTestId('betti-playhead')).toBeNull();
    rerender(<BettiCurve filtration={weighted} t={0.4} />);
    expect(screen.getByTestId('betti-playhead')).toBeInTheDocument();
  });

  it('names the convention on the axis so the scale is not ambiguous', () => {
    render(<BettiCurve filtration={weighted} />);
    expect(screen.getByTestId('betti-curve').textContent).toMatch(/alpha convention/);
  });

  it('renders an empty filtration without throwing', () => {
    const empty = recordedFiltration({
      name: 'EMPTY',
      cloud: { points: [], weights: [], dimension: 2 },
      complexType: 'rips',
      convention: 'rips',
      maxSimplexDimension: 2,
      simplices: [],
      rawPairs: [],
    });
    render(<BettiCurve filtration={empty} />);
    expect(screen.getByTestId('betti-curve')).toBeInTheDocument();
  });
});
