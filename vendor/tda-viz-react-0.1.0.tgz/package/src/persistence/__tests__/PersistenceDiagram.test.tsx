// <PersistenceDiagram> re-keyed on (filtration, t) — SPEC.md §4.3.
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { WEIGHTED3_ALPHA, recordedFiltration } from '../../__fixtures__/realFiltrations';
import { PersistenceDiagram } from '../PersistenceDiagram';

// Real engine output: two finite H0 (deaths 0.657556 / 0.765625), one
// essential H0 (born -0.5), one H1 (0.89 → 1.085557).
const weighted = recordedFiltration(WEIGHTED3_ALPHA);

const empty = recordedFiltration({
  name: 'EMPTY',
  cloud: { points: [], weights: [], dimension: 2 },
  complexType: 'alpha',
  convention: 'alpha',
  maxSimplexDimension: 0,
  simplices: [],
  rawPairs: [],
});

describe('<PersistenceDiagram>', () => {
  it('plots one point per pair', () => {
    render(<PersistenceDiagram filtration={weighted} />);
    expect(screen.getAllByTestId('diagram-point')).toHaveLength(4);
  });

  it('renders nothing but axes for an empty filtration (a real state)', () => {
    render(<PersistenceDiagram filtration={empty} />);
    expect(screen.queryAllByTestId('diagram-point')).toHaveLength(0);
    expect(screen.getByTestId('diagonal')).toBeInTheDocument();
  });

  it('marks essential classes instead of clipping them to the axis', () => {
    render(<PersistenceDiagram filtration={weighted} />);
    const essential = screen
      .getAllByTestId('diagram-point')
      .filter((p) => p.getAttribute('data-essential') === 'true');
    expect(essential).toHaveLength(1);
    expect(essential[0]).toHaveAttribute('data-dimension', '0');
  });

  it('places a longer-lived class further above the diagonal', () => {
    render(<PersistenceDiagram filtration={weighted} />);
    const finiteH0 = screen
      .getAllByTestId('diagram-point')
      .filter(
        (p) =>
          p.getAttribute('data-dimension') === '0' && p.getAttribute('data-essential') !== 'true',
      );
    const cys = finiteH0.map((p) => Number(p.getAttribute('cy'))).sort((a, b) => a - b);
    // Same birth (0), different deaths: the longer-lived point sits higher.
    expect(cys[0]).toBeLessThan(cys[1]);
  });

  it('tags each point with its homology degree', () => {
    render(<PersistenceDiagram filtration={weighted} />);
    const dims = screen
      .getAllByTestId('diagram-point')
      .map((n) => n.getAttribute('data-dimension'));
    expect(dims.filter((d) => d === '0')).toHaveLength(3);
    expect(dims.filter((d) => d === '1')).toHaveLength(1);
  });

  it('draws the t crosshair only when t is provided, and tags alive classes', () => {
    const { rerender } = render(<PersistenceDiagram filtration={weighted} t={0.9} />);
    expect(screen.getByTestId('diagram-playhead')).toBeInTheDocument();
    // At t=0.9: the essential H0 and the H1 loop (0.89 <= 0.9 < 1.085557) are alive.
    const alive = screen
      .getAllByTestId('diagram-point')
      .filter((p) => p.getAttribute('data-alive') === 'true');
    expect(alive).toHaveLength(2);
    rerender(<PersistenceDiagram filtration={weighted} />);
    expect(screen.queryByTestId('diagram-playhead')).not.toBeInTheDocument();
  });
});
