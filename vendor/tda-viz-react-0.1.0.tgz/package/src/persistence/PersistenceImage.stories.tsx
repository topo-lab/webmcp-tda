import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CIRCLE24_ALPHA,
  CIRCLE50_RIPS_CAP2,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { PersistenceImage } from './PersistenceImage';

/**
 * A persistence image turns a diagram into a fixed-size grid of numbers,
 * which is what makes persistence usable as input to machine learning:
 * diagrams have varying cardinality, but a grid does not.
 *
 * Axes are (birth, lifetime), not (birth, death), and each class is weighted
 * by its lifetime so long-lived structure dominates short-lived noise.
 *
 * A summary of the filtration (SPEC §4.3), taking a `Filtration`. Provenance
 * is explicit: `data-source="engine"` when handed a grid computed by
 * tda-wasm, `data-source="local"` when this component rendered the kernel
 * itself — the engine's own vectorization is labelled Experimental / manual
 * C++, so a viewer is never left guessing which numbers they are looking at.
 */
const meta = {
  title: 'Summaries/PersistenceImage',
  component: PersistenceImage,
  tags: ['autodocs'],
} satisfies Meta<typeof PersistenceImage>;

export default meta;
type Story = StoryObj<typeof meta>;

const circleAlpha = recordedFiltration(CIRCLE24_ALPHA);
const circleRips = recordedFiltration(CIRCLE50_RIPS_CAP2);

const empty = recordedFiltration({
  name: 'EMPTY',
  cloud: { points: [], weights: [], dimension: 2 },
  complexType: 'alpha',
  convention: 'alpha',
  maxSimplexDimension: 0,
  simplices: [],
  rawPairs: [],
});

/** Locally rendered from the alpha circle. The loop is the bright spot at high lifetime. */
export const RealCircleAlpha: Story = { args: { filtration: circleAlpha, resolution: 28 } };

/** A tighter kernel resolves individual classes; a wider one blurs them together. */
export const NarrowKernel: Story = {
  args: { filtration: circleAlpha, resolution: 28, sigma: 0.07 },
};

export const WideKernel: Story = {
  args: { filtration: circleAlpha, resolution: 28, sigma: 0.4 },
};

/** Coarse grid: what a small feature vector actually preserves. */
export const LowResolution: Story = { args: { filtration: circleRips, resolution: 10 } };

/**
 * A grid supplied by the engine is rendered verbatim and marked
 * `data-source="engine"`, distinguishable from a local approximation.
 */
export const FromEngineGrid: Story = {
  args: {
    filtration: circleAlpha,
    image: Array.from({ length: 256 }, (_, i) => {
      const x = (i % 16) / 16;
      const y = Math.floor(i / 16) / 16;
      return Math.exp(-(((x - 0.3) ** 2 + (y - 0.7) ** 2) / 0.03));
    }),
  },
};

/** No finite-lifetime classes means an empty field, not a decorative texture. */
export const Empty: Story = { args: { filtration: empty, resolution: 16 } };

/** Alternate ramp for embedding in a themed surface. */
export const CustomRamp: Story = {
  args: { filtration: circleAlpha, resolution: 24, ramp: ['#fff7ed', '#c2410c'] },
};
