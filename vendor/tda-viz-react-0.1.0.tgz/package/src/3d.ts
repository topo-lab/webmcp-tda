/**
 * tda-viz-react/3d — the PlayCanvas 3D entry (SPEC.md §2/§4).
 *
 * Kept separate so a 2D-only consumer never pulls PlayCanvas into their
 * bundle. Everything here renders inside a <PlayCanvasStage> container.
 */
export {
  PlayCanvasStage,
  usePlayCanvas,
  PlayCanvasContext,
  type PlayCanvasStageProps,
  type PlayCanvasContextValue,
} from './render3d/PlayCanvasStage';
export {
  Field3D,
  APPROXIMATION_LABEL,
  APPROXIMATION_LABELS,
  type Field3DFiltration,
  type Field3DProps,
} from './render3d/Field3D';
export { Nerve3D, computeTriangleNormals, type Nerve3DProps } from './render3d/Nerve3D';
export { PointCloud3D, pointsToPositions, type PointCloud3DProps } from './render3d/PointCloud3D';
export { CycleHighlight3D, type CycleHighlight3DProps } from './render3d/CycleHighlight3D';
export {
  DepthSlice3D,
  type DepthSlice3DProps,
  type DepthSlicePlane,
} from './render3d/DepthSlice3D';
export { KFoldCover3D, type KFoldCover3DProps } from './render3d/KFoldCover3D';
export {
  kthNearestDistanceSquared,
  kthNearestCentreIndex,
  insideKFoldCover,
  cloudBounds,
  boxTriangles,
  coverEpsilon,
  MAX_COVER_CENTRES,
  MAX_COVER_K,
  COVER_MAX_STEPS,
  type CoverBounds,
} from './render3d/kfoldCover';
export {
  coveringDepthAt,
  cloudBoundingRadius,
  cloudCentroid,
  sliceFrame,
  slicePoint,
  MAX_DEPTH_SLICE_CENTRES,
  type SliceFrame,
} from './render3d/depthSlice';
export { parseColor, destroyEntity } from './render3d/utils';
