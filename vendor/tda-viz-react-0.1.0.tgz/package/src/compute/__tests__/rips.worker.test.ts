// @vitest-environment jsdom
//
// The dedicated worker is a runtime boundary: Float64Array input is
// transferred in, while a structured-clone-safe pipeline comes back out. These
// tests execute the worker module itself with a tiny worker-global harness. The
// topology engine is mocked here because the real WASM pipeline is already
// checked independently in pipeline.integration.test.ts.
import { afterEach, describe, expect, it, vi } from 'vitest';
import type { RipsPipelineRequest, RipsPipelineResponse } from '../workerTypes';

const workerControl = vi.hoisted(() => ({
  failNextInit: false,
  failNextCompute: false,
  instances: [] as Array<{
    initializeCalls: Array<Record<string, unknown>>;
    ripsCalls: Array<[number[], number, number, number]>;
    persistenceCalls: Array<[unknown[], number]>;
  }>,
  pairs: [
    { dimension: 0, birth: 0, death: Infinity },
    { dimension: 0, birth: 0, death: 0.5 },
    { dimension: 1, birth: 0.7, death: 0.9 },
  ],
}));

vi.mock('tda-wasm', () => ({
  GudhiPersistentCohomology: class {
    initializeCalls: Array<Record<string, unknown>> = [];
    ripsCalls: Array<[number[], number, number, number]> = [];
    persistenceCalls: Array<[unknown[], number]> = [];

    constructor() {
      workerControl.instances.push(this);
    }

    async initialize(options: Record<string, unknown>) {
      this.initializeCalls.push(options);
      if (workerControl.failNextInit) {
        workerControl.failNextInit = false;
        throw new Error('mock init failure');
      }
    }

    computeRipsComplex(points: number[], dimension: number, edge: number, cap: number) {
      this.ripsCalls.push([points, dimension, edge, cap]);
      if (workerControl.failNextCompute) {
        workerControl.failNextCompute = false;
        throw new Error('mock compute failure');
      }
      return {
        simplices: [
          { vertices: [0], filtration: 0 },
          { vertices: [1], filtration: 0 },
          { vertices: [0, 1], filtration: 0.5 },
        ],
        vertices: 2,
        dimension: 1,
        dimensionCounts: { 0: 2, 1: 1 },
      };
    }

    computePersistence(simplices: unknown[], coeffField: number) {
      this.persistenceCalls.push([simplices, coeffField]);
      return {
        pairs: workerControl.pairs,
        dimension: 1,
        pairsByDimension: { 0: 2, 1: 1 },
        essentialCount: 1,
      };
    }
  },
}));

type MessageListener = (event: { data: RipsPipelineRequest }) => void;

const request = (id: number, wasmUrl?: string): RipsPipelineRequest => ({
  type: 'rips-pipeline',
  id,
  points: new Float64Array([0, 0, 1, 0, 0, 1]),
  dimension: 2,
  maxEdgeLength: 1,
  maxSimplexDimension: 2,
  coeffField: 2,
  wasmUrl,
});

async function loadWorker() {
  // Reset both the worker's module-level enginePromise and its mocked WASM
  // module. Importing the control after the reset gives us the exact module
  // instance the vi.mock factory below supplies to rips.worker.
  vi.resetModules();
  workerControl.failNextInit = false;
  workerControl.failNextCompute = false;
  workerControl.instances = [];
  let listener: MessageListener | null = null;
  const postMessage = vi.fn<(message: RipsPipelineResponse) => void>();

  vi.stubGlobal(
    'addEventListener',
    vi.fn((type: string, callback: MessageListener) => {
      if (type === 'message') listener = callback;
    }),
  );
  vi.stubGlobal('postMessage', postMessage);

  await import('../rips.worker');
  if (!listener) throw new Error('worker did not install its message listener');
  return { listener: listener as MessageListener, postMessage };
}

async function waitForMessage(postMessage: ReturnType<typeof vi.fn>, count: number) {
  await vi.waitFor(() => expect(postMessage).toHaveBeenCalledTimes(count));
  return postMessage.mock.calls[count - 1]![0] as RipsPipelineResponse;
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('rips worker protocol', () => {
  it('returns the same complex, persistence pairs, and diagram from transferred coordinates', async () => {
    const { listener, postMessage } = await loadWorker();
    listener({ data: request(7, '/assets/persistent_cohomology.wasm') });

    const response = await waitForMessage(postMessage, 1);
    expect(response.type).toBe('result');
    if (response.type !== 'result') throw new Error(response.error);
    expect(response.id).toBe(7);
    expect(response.result.persistence.pairs).toEqual(workerControl.pairs);
    expect(response.result.diagram.pairs).toEqual(workerControl.pairs);
    expect(response.result.diagram.byDimension.get(1)).toHaveLength(1);
    expect(response.result.diagram.essential).toHaveLength(1);

    const gudhi = workerControl.instances[0]!;
    expect(gudhi.ripsCalls).toEqual([[[0, 0, 1, 0, 0, 1], 2, 1, 2]]);
    expect(gudhi.persistenceCalls).toEqual([[expect.any(Array), 2]]);
    const options = gudhi.initializeCalls[0]! as {
      locateFile(path: string): string;
    };
    expect(options.locateFile('persistent_cohomology.wasm')).toBe(
      '/assets/persistent_cohomology.wasm',
    );
    expect(options.locateFile('worker-helper.mjs')).toBe('worker-helper.mjs');
  });

  it('initializes one engine for multiple jobs and preserves request identity', async () => {
    const { listener, postMessage } = await loadWorker();
    listener({ data: request(11) });
    await waitForMessage(postMessage, 1);
    listener({ data: request(12) });
    const second = await waitForMessage(postMessage, 2);

    expect(workerControl.instances).toHaveLength(1);
    expect(workerControl.instances[0]!.initializeCalls).toHaveLength(1);
    expect(second).toMatchObject({ type: 'result', id: 12 });
  });

  it('reports a compute failure without fabricating a partial result', async () => {
    const { listener, postMessage } = await loadWorker();
    workerControl.failNextCompute = true;
    listener({ data: request(21) });

    expect(await waitForMessage(postMessage, 1)).toEqual({
      type: 'error',
      id: 21,
      error: 'mock compute failure',
    });
  });

  it('retries initialization after a failed module load', async () => {
    const { listener, postMessage } = await loadWorker();
    workerControl.failNextInit = true;
    listener({ data: request(31) });
    expect(await waitForMessage(postMessage, 1)).toMatchObject({ type: 'error', id: 31 });

    listener({ data: request(32) });
    expect(await waitForMessage(postMessage, 2)).toMatchObject({ type: 'result', id: 32 });
    expect(workerControl.instances).toHaveLength(2);
  });

  it('ignores messages from another protocol', async () => {
    const { listener, postMessage } = await loadWorker();
    listener({ data: { type: 'not-tda' } as unknown as RipsPipelineRequest });
    await Promise.resolve();
    expect(postMessage).not.toHaveBeenCalled();
    expect(workerControl.instances).toHaveLength(0);
  });
});
