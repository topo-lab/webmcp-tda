import { beforeEach, describe, expect, it, vi } from 'vitest';
// The factory routes 'tda-wasm' to our manual mock; importing the mock file
// directly yields the SAME module instance, so mockControl steers the mock
// the code under test sees.
import { CANNED_PAIRS, mockControl } from '../../../__mocks__/tda-wasm';
import type { RipsPipelineRequest, RipsPipelineResponse } from '../workerTypes';
import { TdaEngine } from '../TdaEngine';

vi.mock('tda-wasm', () => import('../../../__mocks__/tda-wasm'));

const DEFAULT_PARAMS = {
  complexType: 'rips' as const,
  maxEdgeLength: 1,
  maxSimplexDimension: 2,
  coeffField: 2,
};

const SQUARE_2D = [0, 0, 1, 0, 1, 1, 0, 1];

/** Minimal fake Worker capturing requests and answering on demand. */
class FakeWorker {
  listeners = new Map<string, Array<(event: unknown) => void>>();
  requests: RipsPipelineRequest[] = [];
  terminated = false;
  autoRespond: ((req: RipsPipelineRequest) => RipsPipelineResponse) | null = null;

  addEventListener(type: string, listener: (event: unknown) => void) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type)!.push(listener);
  }

  postMessage(request: RipsPipelineRequest) {
    this.requests.push(request);
    if (this.autoRespond) {
      const response = this.autoRespond(request);
      queueMicrotask(() => this.emit('message', { data: response }));
    }
  }

  terminate() {
    this.terminated = true;
  }

  emit(type: string, event: unknown) {
    for (const listener of this.listeners.get(type) ?? []) listener(event);
  }
}

function workerResult() {
  return {
    complex: { simplices: [], vertices: 4, dimension: 1, dimensionCounts: { 0: 4 } },
    persistence: {
      pairs: [{ dimension: 0, birth: 0, death: Infinity }],
      dimension: 0,
      pairsByDimension: { 0: 1 },
      essentialCount: 1,
    },
    diagram: {
      pairs: [{ dimension: 0, birth: 0, death: Infinity }],
      byDimension: new Map([[0, [{ dimension: 0, birth: 0, death: Infinity }]]]),
      essential: [{ dimension: 0, birth: 0, death: Infinity }],
    },
  };
}

beforeEach(() => {
  mockControl.reset();
  vi.clearAllMocks();
});

describe('TdaEngine.initialize', () => {
  it('initializes the underlying wrapper exactly once for concurrent calls', async () => {
    const engine = new TdaEngine({ createWorker: null });
    await Promise.all([engine.initialize(), engine.initialize(), engine.initialize()]);
    expect(mockControl.instances).toHaveLength(1);
    expect(mockControl.instances[0]!.initialize).toHaveBeenCalledTimes(1);
    expect(engine.isReady()).toBe(true);
  });

  it('surfaces init failure and allows retry', async () => {
    mockControl.failNextInit = true;
    const engine = new TdaEngine({ createWorker: null });
    await expect(engine.initialize()).rejects.toThrow(/mock init failure/);
    expect(engine.isReady()).toBe(false);
    await engine.initialize(); // retry succeeds
    expect(engine.isReady()).toBe(true);
  });
});

describe('TdaEngine.computeComplex dispatch', () => {
  it('throws before initialization (computing without wasm is an error state)', () => {
    const engine = new TdaEngine({ createWorker: null });
    expect(() => engine.computeComplex(SQUARE_2D, 2, DEFAULT_PARAMS)).toThrow(/initialize/i);
  });

  it('routes rips to computeRipsComplex with the exact params', async () => {
    const engine = new TdaEngine({ createWorker: null });
    await engine.initialize();
    engine.computeComplex(SQUARE_2D, 2, { ...DEFAULT_PARAMS, maxEdgeLength: 0.6 });
    const gudhi = mockControl.instances[0]!;
    expect(gudhi.computeRipsComplex).toHaveBeenCalledWith(SQUARE_2D, 2, 0.6, 2);
  });

  it('routes cech to computeCechComplex (maxEdgeLength acts as maxRadius)', async () => {
    const engine = new TdaEngine({ createWorker: null });
    await engine.initialize();
    engine.computeComplex(SQUARE_2D, 2, {
      ...DEFAULT_PARAMS,
      complexType: 'cech',
      maxEdgeLength: 0.8,
    });
    const gudhi = mockControl.instances[0]!;
    expect(gudhi.computeCechComplex).toHaveBeenCalledWith(SQUARE_2D, 2, 0.8, 2);
  });

  it('refuses alpha here: the weighted path (and its z=0 embedding) lives in buildFiltration', async () => {
    const engine = new TdaEngine({ createWorker: null });
    await engine.initialize();
    expect(() =>
      engine.computeComplex([1, 2, 3, 4], 2, { ...DEFAULT_PARAMS, complexType: 'alpha' }),
    ).toThrow(/buildFiltration/);
    expect(mockControl.instances[0]!.computeWeightedAlphaComplex).not.toHaveBeenCalled();
  });

  it('passes already-embedded weighted points straight to the wasm wrapper', async () => {
    const engine = new TdaEngine({ createWorker: null });
    await engine.initialize();
    const pts = [
      { x: 1, y: 2, z: 0, weight: 0.5 },
      { x: 3, y: 4, z: 0, weight: 0 },
    ];
    engine.computeWeightedAlphaComplex(pts);
    expect(mockControl.instances[0]!.computeWeightedAlphaComplex).toHaveBeenCalledWith(pts);
  });
});

describe('TdaEngine.computePipeline', () => {
  it('returns complex + persistence + diagram built from the same pairs', async () => {
    const engine = new TdaEngine({ createWorker: null });
    await engine.initialize();
    const result = engine.computePipeline(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(result.complex.simplices.length).toBeGreaterThan(0);
    expect(result.persistence.pairs).toEqual(CANNED_PAIRS);
    expect(result.diagram.pairs).toEqual(CANNED_PAIRS);
    expect(result.diagram.byDimension.get(0)).toHaveLength(3);
    expect(result.diagram.essential).toHaveLength(1);
  });
});

describe('TdaEngine.computePipelineAsync (worker dispatch + fallback)', () => {
  it('falls back to the main thread when no Worker is available', async () => {
    const engine = new TdaEngine({ createWorker: null });
    await engine.initialize();
    const result = await engine.computePipelineAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(result.persistence.pairs).toEqual(CANNED_PAIRS);
    expect(mockControl.instances[0]!.computeRipsComplex).toHaveBeenCalledTimes(1);
  });

  it('uses the worker for rips when available (main thread untouched)', async () => {
    const worker = new FakeWorker();
    worker.autoRespond = (req) => ({ type: 'result', id: req.id, result: workerResult() });
    const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
    await engine.initialize();

    const result = await engine.computePipelineAsync(SQUARE_2D, 2, DEFAULT_PARAMS);

    expect(worker.requests).toHaveLength(1);
    expect(worker.requests[0]!.type).toBe('rips-pipeline');
    expect(Array.from(worker.requests[0]!.points)).toEqual(SQUARE_2D);
    expect(result.persistence.essentialCount).toBe(1);
    expect(mockControl.instances[0]!.computeRipsComplex).not.toHaveBeenCalled();
  });

  it('falls back to the main thread when the worker reports a job error', async () => {
    const worker = new FakeWorker();
    worker.autoRespond = (req) => ({ type: 'error', id: req.id, error: 'worker exploded' });
    const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
    await engine.initialize();

    const result = await engine.computePipelineAsync(SQUARE_2D, 2, DEFAULT_PARAMS);

    expect(result.persistence.pairs).toEqual(CANNED_PAIRS);
    expect(mockControl.instances[0]!.computeRipsComplex).toHaveBeenCalledTimes(1);
  });

  it('disables the worker and falls back after a worker-level error event', async () => {
    const worker = new FakeWorker();
    const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
    await engine.initialize();

    const pending = engine.computePipelineAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    worker.emit('error', { message: 'worker crashed', error: new Error('worker crashed') });

    const result = await pending;
    expect(result.persistence.pairs).toEqual(CANNED_PAIRS);
    expect(worker.terminated).toBe(true);
  });

  it('runs non-rips complexes on the main thread (documented v1 limitation)', async () => {
    const worker = new FakeWorker();
    const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
    await engine.initialize();
    await engine.computePipelineAsync(SQUARE_2D, 2, { ...DEFAULT_PARAMS, complexType: 'cech' });
    expect(worker.requests).toHaveLength(0);
    expect(mockControl.instances[0]!.computeCechComplex).toHaveBeenCalledTimes(1);
  });
});

describe('TdaEngine.dispose', () => {
  it('terminates the worker and disposes the wrapper', async () => {
    const worker = new FakeWorker();
    const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
    await engine.initialize();
    worker.autoRespond = (req) => ({ type: 'result', id: req.id, result: workerResult() });
    await engine.computePipelineAsync(SQUARE_2D, 2, DEFAULT_PARAMS); // spins up the worker
    engine.dispose();
    expect(worker.terminated).toBe(true);
    expect(mockControl.instances[0]!.dispose).toHaveBeenCalled();
    expect(engine.isReady()).toBe(false);
  });
});
