// @vitest-environment node
//
// Integration test against the REAL tda-wasm engine (no mocks). This is the
// canonical honesty regression from SPEC.md §5 run end to end:
//
//   a 50-point 2D circle at cap 2 must NOT report beta_2 = 150.
//
// The raw engine output genuinely contains 150 spurious H_2 pairs at
// maxEdgeLength 0.6 (verified against tda-wasm directly) — the package's job
// is to withhold them, not to pretend they are not computed.
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { TdaEngine } from '../TdaEngine';
import { filterRealHomology, reliableBettiSlice } from '../../state/honesty';

const TIMEOUT = 60_000;

function circlePoints(n: number): number[] {
  const pts: number[] = [];
  for (let i = 0; i < n; i++) {
    const t = (2 * Math.PI * i) / n;
    pts.push(Math.cos(t), Math.sin(t));
  }
  return pts;
}

const PARAMS = {
  complexType: 'rips' as const,
  maxEdgeLength: 0.6,
  maxSimplexDimension: 2,
  coeffField: 2,
};

describe('real-wasm pipeline: 50-point circle, Rips, cap 2', () => {
  const engine = new TdaEngine({ createWorker: null });
  const points = circlePoints(50);

  beforeAll(async () => {
    await engine.initialize();
  }, TIMEOUT);

  afterAll(() => {
    engine.dispose();
  });

  it(
    'raw engine output contains exactly the 150 spurious H_2 pairs',
    () => {
      const raw = engine.computePipeline(points, 2, PARAMS);
      expect(raw.persistence.pairsByDimension[0]).toBe(50);
      expect(raw.persistence.pairsByDimension[1]).toBe(1); // the circle's loop
      expect(raw.persistence.pairsByDimension[2]).toBe(150); // the artifact
    },
    TIMEOUT,
  );

  it(
    'CANONICAL REGRESSION: honesty filtering drops every H_k with k >= ambient dim',
    () => {
      const raw = engine.computePipeline(points, 2, PARAMS);
      const filtered = filterRealHomology(raw, 2);
      expect(filtered.persistence.pairs.filter((p) => p.dimension >= 2)).toHaveLength(0);
      expect(filtered.persistence.pairsByDimension[2]).toBeUndefined();
      expect(filtered.diagram.byDimension.has(2)).toBe(false);
      // The real topology survives: one component + one loop are essential.
      expect(filtered.persistence.pairsByDimension[1]).toBe(1);
      expect(filtered.persistence.pairsByDimension[0]).toBe(50);
    },
    TIMEOUT,
  );

  it(
    'CANONICAL REGRESSION: reliable Betti slice never reports beta_2 = 150',
    () => {
      const raw = engine.computePipeline(points, 2, PARAMS);
      const betti = engine.computeBettiNumbers(raw.complex.simplices, 0.6, 2);
      expect(betti.betti).toEqual([1, 1, 150]); // raw truth: the artifact is real output
      const shown = reliableBettiSlice(betti.betti, {
        maxSimplexDimension: PARAMS.maxSimplexDimension,
        ambientDim: 2,
      });
      expect(shown).toEqual([1, 1]); // ...and this is what may be presented
    },
    TIMEOUT,
  );

  it(
    'computePipelineAsync falls back to the main thread in Node (no Worker) with identical results',
    async () => {
      const result = await engine.computePipelineAsync(points, 2, PARAMS);
      expect(result.persistence.pairsByDimension[2]).toBe(150);
    },
    TIMEOUT,
  );
});
