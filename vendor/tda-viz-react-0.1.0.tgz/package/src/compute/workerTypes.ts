import type { PipelineResult } from '../types/engine';

/**
 * Message protocol between TdaEngine and the Rips worker.
 * Mirrors tda-explorer's GudhiCompute.worker contract: only Rips runs
 * off-thread in v1 (SPEC.md §8, open question 3 — inherited limitation,
 * labeled here).
 */
export interface RipsPipelineRequest {
  type: 'rips-pipeline';
  id: number;
  /** Transferred, not copied. */
  points: Float64Array;
  dimension: number;
  maxEdgeLength: number;
  maxSimplexDimension: number;
  coeffField: number;
  /** Optional URL for persistent_cohomology.wasm inside the worker. */
  wasmUrl?: string;
}

export type RipsPipelineResponse =
  | { type: 'result'; id: number; result: PipelineResult }
  | { type: 'error'; id: number; error: string };
