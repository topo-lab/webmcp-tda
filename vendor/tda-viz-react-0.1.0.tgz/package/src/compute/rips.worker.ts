/**
 * Module worker running the Rips pipeline off the main thread.
 * Owns its own GudhiPersistentCohomology instance (wasm modules are not
 * shareable across threads).
 */
import { GudhiPersistentCohomology } from 'tda-wasm';
import { buildPersistenceDiagram } from './diagram';
import type { RipsPipelineRequest, RipsPipelineResponse } from './workerTypes';

// Typed view of the dedicated-worker global scope without pulling the
// `webworker` lib into the whole compilation (which conflicts with DOM).
const scope = globalThis as unknown as {
  addEventListener(type: 'message', listener: (event: { data: RipsPipelineRequest }) => void): void;
  postMessage(message: RipsPipelineResponse): void;
};

let enginePromise: Promise<GudhiPersistentCohomology> | null = null;

function getEngine(wasmUrl?: string): Promise<GudhiPersistentCohomology> {
  if (!enginePromise) {
    enginePromise = (async () => {
      const gudhi = new GudhiPersistentCohomology();
      await gudhi.initialize(
        wasmUrl ? { locateFile: (path: string) => (path.endsWith('.wasm') ? wasmUrl : path) } : {},
      );
      return gudhi;
    })().catch((error) => {
      enginePromise = null;
      throw error;
    });
  }
  return enginePromise;
}

async function handleRequest(request: RipsPipelineRequest): Promise<void> {
  if (request?.type !== 'rips-pipeline') return;
  try {
    const gudhi = await getEngine(request.wasmUrl);
    const complex = gudhi.computeRipsComplex(
      Array.from(request.points),
      request.dimension,
      request.maxEdgeLength,
      request.maxSimplexDimension,
    );
    const persistence = gudhi.computePersistence(complex.simplices, request.coeffField);
    scope.postMessage({
      type: 'result',
      id: request.id,
      result: { complex, persistence, diagram: buildPersistenceDiagram(persistence.pairs) },
    });
  } catch (error) {
    scope.postMessage({
      type: 'error',
      id: request.id,
      error: error instanceof Error ? error.message : String(error),
    });
  }
}

scope.addEventListener('message', (event) => {
  void handleRequest(event.data);
});
