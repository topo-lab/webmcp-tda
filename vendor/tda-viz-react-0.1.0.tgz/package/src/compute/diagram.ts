import type { PersistenceDiagram, PersistencePair } from 'tda-wasm';

/**
 * Group persistence pairs into a diagram (byDimension + essential).
 * Same shape as tda-wasm's `createPersistenceDiagram`; implemented locally so
 * the compute layer's output shape is testable without the wasm module.
 */
export function buildPersistenceDiagram(pairs: PersistencePair[]): PersistenceDiagram {
  const byDimension = new Map<number, PersistencePair[]>();
  const essential: PersistencePair[] = [];
  for (const pair of pairs) {
    if (!byDimension.has(pair.dimension)) byDimension.set(pair.dimension, []);
    byDimension.get(pair.dimension)!.push(pair);
    if (pair.death === Infinity) essential.push(pair);
  }
  return { pairs, byDimension, essential };
}
