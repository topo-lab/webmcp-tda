/**
 * Headless compute layer (SPEC.md §2): wasm init, worker dispatch,
 * complex + persistence. No React, no PlayCanvas, no d3 — enforced by lint.
 *
 * Patterns (embind lifetime, worker-with-fallback) follow tda-explorer's
 * GudhiService, the working reference. Embind vector lifetime itself is
 * handled inside tda-wasm's typed wrapper (delete on all paths via
 * try/finally), which this engine builds on rather than re-implementing.
 */
import { GudhiPersistentCohomology } from 'tda-wasm';
import type {
  BettiNumbers,
  BoxFiltrationResult,
  EllipsoidAxesMode,
  EllipsoidGeometry,
  KFoldCoverResult,
  ModuleOptions,
  PersistenceResult,
  Point3D,
  Simplex,
  WingGeometry,
} from 'tda-wasm';
import type { ComplexResult, PipelineResult, TdaParams } from '../types/engine';
import { buildPersistenceDiagram } from './diagram';
import type { RipsPipelineRequest, RipsPipelineResponse } from './workerTypes';

export interface TdaEngineOptions {
  /** Passed through to GudhiPersistentCohomology.initialize (locateFile etc.). */
  moduleOptions?: ModuleOptions;
  /** URL of persistent_cohomology.wasm, forwarded to the Rips worker. */
  wasmUrl?: string;
  /**
   * Worker factory. `undefined` = default module-worker factory;
   * `null` = disable workers entirely (everything runs on the calling thread).
   * Injectable for tests and for hosts with unusual worker setups.
   */
  createWorker?: (() => Worker | null) | null;
}

function defaultWorkerFactory(): Worker | null {
  if (typeof Worker === 'undefined') return null;
  try {
    return new Worker(new URL('./rips.worker.ts', import.meta.url), { type: 'module' });
  } catch {
    return null;
  }
}

interface WorkerJob {
  resolve: (result: PipelineResult | null) => void;
  reject: (error: Error) => void;
}

export class TdaEngine {
  private readonly options: TdaEngineOptions;
  private gudhi: GudhiPersistentCohomology | null = null;
  private initPromise: Promise<void> | null = null;

  private ripsWorker: Worker | null = null;
  private ripsWorkerUnavailable = false;
  private requestId = 0;
  private jobs = new Map<number, WorkerJob>();

  constructor(options: TdaEngineOptions = {}) {
    this.options = options;
  }

  /** Idempotent and concurrency-safe: the wasm module loads exactly once. */
  initialize(): Promise<void> {
    if (this.initPromise) return this.initPromise;
    this.initPromise = (async () => {
      const gudhi = new GudhiPersistentCohomology();
      try {
        await gudhi.initialize(this.options.moduleOptions ?? {});
      } catch (error) {
        this.initPromise = null;
        throw error instanceof Error ? error : new Error(String(error));
      }
      this.gudhi = gudhi;
    })();
    return this.initPromise;
  }

  isReady(): boolean {
    return this.gudhi !== null && this.gudhi.isInitialized();
  }

  private ensureReady(): GudhiPersistentCohomology {
    if (!this.gudhi || !this.gudhi.isInitialized()) {
      throw new Error('TdaEngine is not ready. Call initialize() first.');
    }
    return this.gudhi;
  }

  // ── Complex construction ────────────────────────────────────────────

  computeComplex(points: number[], dimension: number, params: TdaParams): ComplexResult {
    const gudhi = this.ensureReady();
    switch (params.complexType) {
      case 'rips':
        return gudhi.computeRipsComplex(
          points,
          dimension,
          params.maxEdgeLength,
          params.maxSimplexDimension,
        );
      case 'cech':
        return gudhi.computeCechComplex(
          points,
          dimension,
          params.maxEdgeLength,
          params.maxSimplexDimension,
        );
      case 'alpha':
        // Weighted alpha takes weighted 3D points, and the z=0 embedding for
        // 2D clouds lives in the engine adapter (SPEC.md §3.2) and nowhere
        // else. Route alpha through buildFiltration.
        throw new Error(
          'alpha complexes take weighted points: use buildFiltration (src/engine) ' +
            'or computeWeightedAlphaComplex(points: Point3D[]) directly.',
        );
      default: {
        const exhausted: never = params.complexType;
        throw new Error(`Unknown complex type: ${String(exhausted)}`);
      }
    }
  }

  /**
   * Weighted alpha complex from weighted 3D points (SPEC.md §5 — the only
   * weighted path, and therefore the primary complex). Callers provide
   * already-embedded Point3D[]; the z=0 embedding of 2D clouds belongs to
   * the engine adapter (buildFiltration), not here.
   */
  computeWeightedAlphaComplex(points: Point3D[]): ComplexResult {
    return this.ensureReady().computeWeightedAlphaComplex(points);
  }

  // ── The complex menu (SPEC.md §5) ────────────────────────────────────
  //
  // Thin pass-throughs: the adapter (src/engine/buildFiltration) owns the
  // validation and the filtration record, and this class owns nothing but the
  // wasm handle. Every one of these is unweighted-only at the binding.

  /**
   * k-fold cover: the order-k Delaunay mosaic filtered by SQUARED radius.
   * 3D and unweighted only. Vertex ids index `mosaicVertices` — a vertex is a
   * k-subset of the input, NOT a point.
   */
  computeKFoldCoverComplex(
    points: number[],
    k: number,
    maxSquaredRadius?: number,
    maxSimplexDimension?: number,
  ): KFoldCoverResult {
    return this.ensureReady().computeKFoldCoverComplex(
      points,
      k,
      maxSquaredRadius,
      maxSimplexDimension,
    );
  }

  /** Rips-type ellipsoid complex: a FLAG complex. Filtration = 2 × radius. */
  computeEllipsoidRipsComplex(
    points: number[],
    dimension: number,
    neighborhoodSize: number,
    axesMode: EllipsoidAxesMode,
    maxSimplexDimension?: number,
    maxFiltration?: number,
  ): ComplexResult {
    return this.ensureReady().computeEllipsoidRipsComplex(
      points,
      dimension,
      neighborhoodSize,
      axesMode,
      maxSimplexDimension,
      maxFiltration,
    );
  }

  /** Ellipsoidal Čech complex: a true NERVE. Same scale as the flag variant. */
  computeEllipsoidCechComplex(
    points: number[],
    dimension: number,
    neighborhoodSize: number,
    axesMode: EllipsoidAxesMode,
    maxSimplexDimension?: number,
    maxFiltration?: number,
  ): ComplexResult {
    return this.ensureReady().computeEllipsoidCechComplex(
      points,
      dimension,
      neighborhoodSize,
      axesMode,
      maxSimplexDimension,
      maxFiltration,
    );
  }

  /**
   * The fitted ellipsoids themselves, for drawing. Same fitting as the
   * complexes above, so the shapes and the simplices always agree.
   */
  computeEllipsoidGeometry(
    points: number[],
    dimension: number,
    neighborhoodSize: number,
    axesMode: EllipsoidAxesMode,
  ): EllipsoidGeometry[] {
    return this.ensureReady().computeEllipsoidGeometry(
      points,
      dimension,
      neighborhoodSize,
      axesMode,
    );
  }

  /** 2D wing complex: a FLAG complex, never a nerve. */
  computeWingComplex(
    points2d: number[],
    q: number,
    theta: number,
    normalsOrK: number[] | number,
    maxSimplexDimension?: number,
    maxEps?: number,
  ): ComplexResult {
    return this.ensureReady().computeWingComplex(
      points2d,
      q,
      theta,
      normalsOrK,
      maxSimplexDimension,
      maxEps,
    );
  }

  /**
   * The wings themselves, for drawing. Resolves normals exactly as
   * `computeWingComplex` does — supplied normals come back normalised, a scalar
   * k comes back estimated by the builder's own osculating-circle fit — so the
   * drawn wing is always the wing whose births are on the barcode.
   */
  computeWingGeometry(
    points2d: number[],
    q: number,
    theta: number,
    normalsOrK: number[] | number,
  ): WingGeometry[] {
    return this.ensureReady().computeWingGeometry(points2d, q, theta, normalsOrK);
  }

  /**
   * Box filtration: a nerve (= flag, by Helly for boxes), STEP-QUANTIZED —
   * every filtration value is an exact multiple of `stepSize`.
   */
  computeBoxFiltration(
    points: number[],
    dimension: number,
    stepSize: number,
    alpha: number,
    maxSteps?: number,
    maxSimplexDimension?: number,
    includeBoxes?: boolean,
  ): BoxFiltrationResult {
    return this.ensureReady().computeBoxFiltration(
      points,
      dimension,
      stepSize,
      alpha,
      maxSteps,
      maxSimplexDimension,
      includeBoxes,
    );
  }

  // ── Persistence ─────────────────────────────────────────────────────

  computePersistence(simplices: Simplex[], coeffField = 2): PersistenceResult {
    return this.ensureReady().computePersistence(simplices, coeffField);
  }

  computeBettiNumbers(simplices: Simplex[], filtrationValue: number, coeffField = 2): BettiNumbers {
    return this.ensureReady().computeBettiNumbers(simplices, filtrationValue, coeffField);
  }

  // ── Pipeline ────────────────────────────────────────────────────────

  /** Synchronous pipeline on the calling thread. */
  computePipeline(points: number[], dimension: number, params: TdaParams): PipelineResult {
    const complex = this.computeComplex(points, dimension, params);
    const persistence = this.computePersistence(complex.simplices, params.coeffField);
    return { complex, persistence, diagram: buildPersistenceDiagram(persistence.pairs) };
  }

  /**
   * Pipeline with worker dispatch: Rips runs in a module worker when one is
   * available, falling back to the main thread on any worker failure.
   * Alpha and Čech are main-thread in v1 (SPEC.md §8, open question 3 —
   * inherited limitation, labeled).
   */
  async computePipelineAsync(
    points: number[],
    dimension: number,
    params: TdaParams,
  ): Promise<PipelineResult> {
    if (params.complexType === 'rips') {
      try {
        const workerResult = await this.computeRipsInWorker(points, dimension, params);
        if (workerResult) return workerResult;
      } catch {
        // Worker failed mid-job; fall back to the main thread below.
      }
    }
    return this.computePipeline(points, dimension, params);
  }

  // ── Worker plumbing (GudhiService pattern) ──────────────────────────

  private getWorker(): Worker | null {
    if (this.ripsWorkerUnavailable) return null;
    if (this.ripsWorker) return this.ripsWorker;
    if (this.options.createWorker === null) return null;

    try {
      const worker = (this.options.createWorker ?? defaultWorkerFactory)();
      if (!worker) {
        this.ripsWorkerUnavailable = true;
        return null;
      }
      worker.addEventListener('message', this.handleWorkerMessage as unknown as EventListener);
      worker.addEventListener('error', this.handleWorkerError as unknown as EventListener);
      this.ripsWorker = worker;
      return worker;
    } catch (error) {
      this.disableWorker(error);
      return null;
    }
  }

  private handleWorkerMessage = (event: { data: RipsPipelineResponse }) => {
    const response = event.data;
    const job = this.jobs.get(response.id);
    if (!job) return;
    this.jobs.delete(response.id);
    if (response.type === 'result') {
      job.resolve(response.result);
      return;
    }
    job.reject(new Error(response.error));
  };

  private handleWorkerError = (event: { message?: string; error?: unknown }) => {
    this.disableWorker(event.error ?? new Error(event.message ?? 'Worker error'));
  };

  private disableWorker(error: unknown): void {
    this.ripsWorkerUnavailable = true;
    if (this.ripsWorker) {
      this.ripsWorker.terminate();
      this.ripsWorker = null;
    }
    const err = error instanceof Error ? error : new Error(String(error));
    for (const job of this.jobs.values()) {
      job.reject(err);
    }
    this.jobs.clear();
  }

  private computeRipsInWorker(
    points: number[],
    dimension: number,
    params: TdaParams,
  ): Promise<PipelineResult | null> {
    const worker = this.getWorker();
    if (!worker) return Promise.resolve(null);

    const id = ++this.requestId;
    const pointArray = new Float64Array(points);
    const request: RipsPipelineRequest = {
      type: 'rips-pipeline',
      id,
      points: pointArray,
      dimension,
      maxEdgeLength: params.maxEdgeLength,
      maxSimplexDimension: params.maxSimplexDimension,
      coeffField: params.coeffField,
      wasmUrl: this.options.wasmUrl,
    };

    return new Promise<PipelineResult | null>((resolve, reject) => {
      this.jobs.set(id, { resolve, reject });
      try {
        worker.postMessage(request, [pointArray.buffer]);
      } catch (error) {
        this.jobs.delete(id);
        this.disableWorker(error);
        resolve(null);
      }
    });
  }

  // ── Lifecycle ───────────────────────────────────────────────────────

  dispose(): void {
    if (this.ripsWorker) {
      this.ripsWorker.terminate();
      this.ripsWorker = null;
    }
    this.jobs.clear();
    this.ripsWorkerUnavailable = false;
    this.gudhi?.dispose();
    this.gudhi = null;
    this.initPromise = null;
  }
}
