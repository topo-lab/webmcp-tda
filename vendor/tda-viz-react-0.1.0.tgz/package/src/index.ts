/**
 * tda-viz-react — main entry (SPEC.md v2).
 *
 * The object of study is the FILTRATION: the one-parameter family of spaces
 * X_t you get by growing a ball around every point, with per-point radii
 * under weights. Build it once with `buildFiltration`, move t with
 * `useScale`, draw the space with <Field2D> and its nerve with <Nerve2D>;
 * the barcode/diagram/Betti views are summaries (SPEC.md §4.3), not the
 * subject.
 *
 * Deliberately free of PlayCanvas: 3D components live under the separate
 * `tda-viz-react/3d` entry (SPEC.md §2), and `npm run check:isolation`
 * verifies this entry's dependency graph never reaches playcanvas.
 */

// ── The filtration layer (the contract, SPEC.md §3) ───────────────────
export type {
  BallConvention,
  BallFiltration,
  BallShape,
  BoxFiltration,
  BoxShape,
  ComplexGuarantee,
  ComplexGuaranteeKind,
  EllipsoidFiltration,
  EllipsoidProfile,
  EllipsoidShape,
  Filtration,
  FiltrationComplexType,
  FiltrationQuantization,
  GrowingShape,
  GrowingShapeKind,
  RadiusConvention,
  ShapeConvention,
  UnitShape,
  VertexKind,
  WeightedCloud,
  WingFiltration,
  WingNormalSource,
  WingProfile,
  WingShape,
} from './filtration/types';
export {
  BAND_HEADING,
  BAND_ORDER,
  BAND_RULE,
  COMPLEX_GUARANTEES,
  FLAG_COMPLEX_TYPES,
  NERVE_COMPLEX_TYPES,
  complexGuarantee,
} from './filtration/guarantees';
export { ballRadiusAt, boxStepAt, ellipsoidSemiAxesAt, wingOutlineAt } from './filtration/shapes';
export {
  createFiltration,
  type CreateBallFiltrationInput,
  type CreateBoxFiltrationInput,
  type CreateEllipsoidFiltrationInput,
  type CreateFiltrationInput,
  type CreateWingFiltrationInput,
} from './filtration/createFiltration';
export { useScale, type UseScaleOptions, type UseScaleResult } from './filtration/useScale';

// ── The engine adapter (one build per (cloud, weights, params), §3.2) ──
export {
  buildFiltration,
  type AlphaFiltrationParams,
  type BallFiltrationParams,
  type BoxFiltrationParams,
  type CechFiltrationParams,
  type EllipsoidFiltrationParams,
  type FiltrationParams,
  type KFoldFiltrationParams,
  type RipsFiltrationParams,
  type WingFiltrationParams,
  type WitnessFiltrationParams,
} from './engine/buildFiltration';

// ── Types (mirror of the SPEC.md §5 engine surface) ───────────────────
export * from './types/engine';

// ── State (headless) ──────────────────────────────────────────────────
export {
  DEFAULT_MAX_SIMPLEX_DIMENSION,
  MAX_MAX_SIMPLEX_DIMENSION,
  MIN_MAX_SIMPLEX_DIMENSION,
  filterRealHomology,
  isRealHomologyDim,
  reliableBettiLength,
  reliableBettiSlice,
  type ReliableBettiOptions,
} from './state/honesty';
export {
  activeLoopCount,
  activeLoopId,
  startAnimationLoop,
  stopAnimationLoop,
  type AnimationTick,
} from './state/animationLoop';
export {
  DEFAULT_TDA_PARAMS,
  createTdaStore,
  type ComputeStatus,
  type TdaState,
  type TdaStateActions,
  type TdaStateData,
  type TdaStore,
} from './state/tdaStore';

// ── Compute (headless: wasm init + worker plumbing) ───────────────────
export { TdaEngine, type TdaEngineOptions } from './compute/TdaEngine';
export { buildPersistenceDiagram } from './compute/diagram';
export type { RipsPipelineRequest, RipsPipelineResponse } from './compute/workerTypes';

// ── React hooks + provider ────────────────────────────────────────────
export {
  TdaContext,
  TdaProvider,
  type TdaContextValue,
  type TdaProviderProps,
} from './hooks/TdaProvider';
export { useTda, useTdaEngine } from './hooks/useTda';

// ── The stage: 2D primary surface (SPEC.md §4.1) ──────────────────────
export { Field2D, type Field2DProps } from './render2d/Field2D';
export { Nerve2D, type Nerve2DProps } from './render2d/Nerve2D';
export { ScaleControl, type ScaleControlProps } from './render2d/ScaleControl';
export { PointCloud2D, type PointCloud2DProps } from './render2d/PointCloud2D';
export { projectCloud, type Projection2D } from './render2d/project';
export { shapeSubpath, unionPath } from './render2d/shapePath';

// ── Honest labelling as a component (SPEC.md §1.4) ────────────────────
export {
  GuaranteeChip,
  QUANTIZATION_WARNING,
  type GuaranteeChipProps,
} from './render2d/GuaranteeChip';
export {
  ConstructionIndex,
  DEFAULT_BAND_COLORS,
  constructionTabId,
  type ConstructionIndexEntry,
  type ConstructionIndexProps,
} from './render2d/ConstructionIndex';

// ── Summaries (2D SVG regardless of cloud dimension, SPEC.md §4.3) ────
export { Barcode, DEFAULT_DIMENSION_COLORS, type BarcodeProps } from './persistence/Barcode';
export { PersistenceDiagram, type PersistenceDiagramProps } from './persistence/PersistenceDiagram';
export { BettiCurve, bettiAt, type BettiCurveProps } from './persistence/BettiCurve';
export {
  PersistenceImage,
  renderKernel,
  type PersistenceImageProps,
} from './persistence/PersistenceImage';
