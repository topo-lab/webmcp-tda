/**
 * <KFoldCover3D>: the k-fold cover itself, as a SOLID region of space you can
 * orbit (SPEC.md §4.6).
 *
 * Lives ONLY under `tda-viz-react/3d` and must be rendered inside a
 * <PlayCanvasStage>, beside <PointCloud3D>, <Field3D> and <Nerve3D>.
 *
 * WHY IT EXISTS, AND WHY IT IS NOT <DepthSlice3D>. A k-fold cover is
 * inherently three-dimensional: it is the set of points covered by at least k
 * of the balls of radius √t. <DepthSlice3D> paints that region's cross-section
 * on ONE plane, exactly, which is enough to read a merge time off a scrub bar
 * and not enough to see the shape of the thing merging. At k = 4 on a Barlow
 * packing the region is a family of lobes around the tetrahedral holes; they
 * open at t = 0.375 and then join — through a shared FACE for HCP (t ≈ 0.670)
 * or only through a shared EDGE for FCC (t ≈ 0.7525). That is a fact about
 * solids meeting in R³, and a disc drawn on a plane is not a picture of it.
 *
 * EXACT, NOT A BLOB. The surface is the isosurface of an exact function, found
 * by sphere tracing, not a marching-cubes mesh of a smoothed field and not a
 * metaball approximation. The identity that makes this both exact and cheap
 * (derived in ./kfoldCover.ts):
 *
 *     depth(x) ≥ k   ⇔   d₍ₖ₎(x) ≤ √t   ⇔   d₍ₖ₎(x)² ≤ t
 *
 * where d₍ₖ₎ is the k-th smallest distance to the centres. So:
 *
 *   - the region is the sublevel set { d₍ₖ₎ ≤ √t } and its boundary is the
 *     isosurface d₍ₖ₎ = √t;
 *   - d₍ₖ₎ is 1-Lipschitz, so `d₍ₖ₎(x) − √t` is a safe sphere-tracing step and
 *     the march converges to the surface from outside without overshooting;
 *   - the outward normal at a boundary point is (x − c₍ₖ₎)/|x − c₍ₖ₎| with
 *     c₍ₖ₎ the k-th nearest centre — ANALYTIC, no finite differences.
 *
 * `insideKFoldCover` / `kthNearestDistanceSquared` (./kfoldCover.ts) are the
 * ORACLE for the GLSL and the WGSL below: the same partial selection in
 * TypeScript, tested against brute force and against the motif geometry, and
 * the shader is its transcription. Change one and you must change all three.
 *
 * THE UNION SHELL. Pass `colorUnion` and the same shader traces the k = 1
 * surface too — the plain union of the balls, which is what <Field3D> draws as
 * an approximation and what this draws exactly — as a translucent shell in
 * front of the opaque cover. It is the SAME machinery with k = 1, which is the
 * point: the union is the one-fold cover, and seeing the lobes inside it is
 * seeing what k buys.
 *
 * DEPTH IS WRITTEN FROM THE HIT POINT. The box this shader is painted on is a
 * proxy; the surface is somewhere inside it. Both passes write `gl_FragDepth`
 * (`@builtin(frag_depth)` on WebGPU) from the traced hit, so <Nerve3D> edges
 * and <PointCloud3D> points in the same stage occlude and are occluded
 * correctly instead of being sorted against a box wall.
 *
 * GPU-DRIVEN SCALE (SPEC.md §1.5): the centres are uploaded ONCE per cloud, as
 * a uniform array. Moving t writes ONE uniform per pass and re-uploads nothing.
 */
import { useEffect, useMemo, useState } from 'react';
import * as pc from 'playcanvas';
import type { Filtration } from '../filtration/types';
import { usePlayCanvas } from './PlayCanvasStage';
import {
  COVER_MAX_STEPS,
  MAX_COVER_CENTRES,
  MAX_COVER_K,
  boxTriangles,
  cloudBounds,
  coverEpsilon,
  type CoverBounds,
} from './kfoldCover';
import { destroyEntity, deviceIsLive, parseColor } from './utils';

/** Props for `<KFoldCover3D>`. */
export interface KFoldCover3DProps {
  /** A k-fold cover filtration on a 3D cloud. Anything else throws. */
  filtration: Filtration;
  /** Current scale: the SQUARED radius, the k-fold cover's own filtration value. */
  t: number;
  /**
   * Cover multiplicity to draw. Defaults to the filtration's own
   * `coverMultiplicity` — the k it was BUILT at — so the surface and the
   * complex beside it are about the same construction unless the caller
   * deliberately says otherwise. Must be an integer in [1, 8].
   */
  k?: number;
  /** Surface colour of the k-fold cover, as a hex literal. */
  colorCover: string;
  /**
   * Surface colour of the ONE-fold cover — the plain union of the balls. Given,
   * a translucent shell of the union is drawn in front of the k-fold surface;
   * omitted, only the k-fold surface is drawn.
   */
  colorUnion?: string;
  /** Opacity of that union shell. Default 0.18. */
  unionOpacity?: number;
  /**
   * Specular exponent of the two-light model. 0 disables the highlight.
   * Default 24.
   */
  shininess?: number;
}

/** Default opacity of the union shell: present, and never competing with the cover. */
const DEFAULT_UNION_OPACITY = 0.18;

/** Default specular exponent. Light is not palette — this is a number, not a token. */
const DEFAULT_SHININESS = 24;

/**
 * The refusal (SPEC.md §1.6). Thrown, not logged: the k-fold cover is the
 * region covered at least k times, and a construction with no multiplicity has
 * no such region. Tracing a Rips complex's ball count would produce a surface
 * that looks like this picture while meaning nothing about the complex drawn
 * beside it.
 */
function assertKFoldIn3D(filtration: Filtration): void {
  if (filtration.complexType !== 'kfold' || filtration.vertexKind !== 'subset') {
    throw new Error(
      `<KFoldCover3D> needs a k-fold cover filtration (complexType 'kfold', vertexKind ` +
        `'subset'), got complexType '${filtration.complexType}' with vertexKind ` +
        `'${filtration.vertexKind}'. The k-fold cover is the region covered at least k ` +
        'times; for the union of the growing shapes of any other construction, use <Field3D>.',
    );
  }
  if (filtration.cloud.dimension !== 3) {
    throw new Error(
      `<KFoldCover3D> needs a 3D cloud, got dimension ${filtration.cloud.dimension}. ` +
        'A 2D k-fold cover is a region of the plane, which <Field2D> already draws as a ' +
        'merged region; there is no solid to orbit.',
    );
  }
}

/**
 * The k this component will draw, and the reason it is allowed to.
 *
 * The filtration records its own k (`coverMultiplicity`, added to the contract
 * with this component); an explicit prop overrides it, which is what lets a
 * story show k = 1 and k = 4 of the SAME filtration side by side.
 */
function resolveK(filtration: Filtration, k: number | undefined): number {
  const resolved = k ?? filtration.coverMultiplicity;
  if (resolved === null || resolved === undefined) {
    throw new Error(
      '<KFoldCover3D> could not determine k: the filtration carries no `coverMultiplicity` ' +
        'and no `k` prop was given. Pass k explicitly.',
    );
  }
  if (!Number.isInteger(resolved) || resolved < 1 || resolved > MAX_COVER_K) {
    throw new Error(
      `<KFoldCover3D> supports k in [1, ${MAX_COVER_K}], got ${resolved}. The k smallest ` +
        'squared distances are selected in registers, in an array the fragment shader ' +
        `declares as float[${MAX_COVER_K}] (MAX_COVER_K in src/render3d/kfoldCover.ts).`,
    );
  }
  return resolved;
}

/**
 * Flat xyz centres of the balls: the INPUT points, not the mosaic vertices.
 *
 * The k-fold cover's vertices are k-subsets and its `vertexPositions` are their
 * barycentres — useful for drawing the mosaic (<Nerve3D> does), and wrong here.
 * The balls whose overlaps define the region grow around the input points.
 */
function centresOf(filtration: Filtration): Float32Array {
  const { points } = filtration.cloud;
  const count = points.length / 3;
  if (count > MAX_COVER_CENTRES) {
    throw new Error(
      `<KFoldCover3D> traces against at most ${MAX_COVER_CENTRES} ball centres, got ${count}. ` +
        'The k-th nearest distance is evaluated per sphere-tracing step from a uniform array ' +
        'of that size; tracing a prefix of the cloud instead would draw a surface that is ' +
        'not the cloud’s. Raising the ceiling means moving the centres into a float texture ' +
        '(see MAX_COVER_CENTRES in ./kfoldCover.ts).',
    );
  }
  const out = new Float32Array(count * 3);
  for (let i = 0; i < count * 3; i++) out[i] = points[i]!;
  return out;
}

/**
 * Set a shader parameter that the shader declares as an ARRAY, under the name
 * the engine will actually look it up by.
 *
 * THE TRAP is the same one <DepthSlice3D> documents at length: a material
 * parameter binds by NAME through `device.scope`, and for an array uniform
 * that name carries a `[0]` suffix on BOTH backends — WebGL2 takes it from
 * `gl.getActiveUniform().name` (playcanvas@2.21.4
 * `platform/graphics/webgl/webgl-shader-input.js:47`) and WebGPU from
 * `UniformFormat`, whose constructor is `this.name = count ? name + "[0]" :
 * name` (`platform/graphics/uniform-buffer-format.js:117-118`, resolved at
 * `:242`). `setParameter('uCentres', ...)` writes a scope slot NOTHING reads,
 * on either backend, and the array stays zero-initialised in the shader — for
 * this component, every centre at the origin, which traces one sphere at the
 * world origin instead of the cover.
 *
 * Both spellings are set, for the same reason <DepthSlice3D> sets both.
 */
function setArrayParameter(material: pc.ShaderMaterial, name: string, value: Float32Array) {
  material.setParameter(`${name}[0]`, value);
  material.setParameter(name, value);
}

// ── The shaders ──────────────────────────────────────────────────────────

/**
 * The vertex shader carries the world position of the box surface, and nothing
 * else. The ray is reconstructed in the fragment shader from `view_position`
 * and that position: both lie on the ray, so `normalize(vWorld - view_position)`
 * IS the ray direction, and the front and back faces of the box give the same
 * direction because they are collinear with the eye.
 *
 * `view_position` is the engine's own per-camera uniform
 * (`scene/renderer/renderer.js:207`, `dispatchViewPos`), and it is declared in
 * the VIEW uniform buffer format (`renderer.js:509`) so the WebGPU shader
 * processor routes it to the view bind group rather than making a mesh uniform
 * of it. `matrix_viewProjectionInverse` is NOT set by the renderer in
 * playcanvas 2.21.4 — only the TAA render pass resolves that name — so a shader
 * that asked for it would silently receive an identity matrix.
 */
const COVER_VS = /* glsl */ `
attribute vec3 aPosition;

uniform mat4 matrix_model;
uniform mat4 matrix_viewProjection;

varying vec3 vWorld;

void main(void) {
    vec4 world = matrix_model * vec4(aPosition, 1.0);
    vWorld = world.xyz;
    gl_Position = matrix_viewProjection * world;
}
`;

/**
 * The tracing shader.
 *
 * EXACT TRANSCRIPTION of `kthNearestDistanceSquared` (./kfoldCover.ts), which
 * is its oracle: squared distances throughout the selection, the same
 * insert-and-shift over the k best, and a non-strict comparison at the surface
 * so a point exactly on the boundary is inside.
 *
 * The march is `d₍ₖ₎(x) − √t`, which is 1-Lipschitz, so it never steps past
 * the surface. The step count is capped at COVER_MAX_STEPS and a ray that has
 * not landed by then is DISCARDED, not drawn at its last position: a guessed
 * hit would put surface where the mathematics does not.
 *
 * `gl_FragDepth` comes from the hit point through `matrix_viewProjection`, so
 * the surface occludes and is occluded like ordinary geometry. On WebGL2 that
 * matrix is the OpenGL-convention projection (clip z in [−w, w]), hence the
 * ×0.5 + 0.5; the WGSL below does NOT apply it, because on WebGPU the engine
 * multiplies in its own depth-range matrix first
 * (`Camera.applyShaderProjectionTransform`, `scene/camera.js:153`) and clip z
 * already arrives in [0, w].
 */
const COVER_FS = /* glsl */ `
#include "gammaPS"

varying vec3 vWorld;

uniform vec3 view_position;
uniform mat4 matrix_viewProjection;

uniform vec4 uCentres[${MAX_COVER_CENTRES}];
uniform float uCentreCount;
uniform float uK;
uniform float uT;
uniform vec3 uBoxMin;
uniform vec3 uBoxMax;
uniform vec3 uColor;
uniform float uOpacity;
uniform float uShininess;
uniform float uEpsilon;

const float COVER_FAR = 3.0e38;

// d_(k)(p)^2: the k-th smallest squared distance from p to the centres.
// Partial selection in registers, never a sort — the k best are held in
// ascending order and each candidate is either rejected or inserted by
// walking down from slot k-1 and shifting.
float kthNearestSq(vec3 p, int kk) {
    float best[${MAX_COVER_K}];
    for (int j = 0; j < ${MAX_COVER_K}; j++) best[j] = COVER_FAR;
    int n = int(uCentreCount + 0.5);
    for (int i = 0; i < ${MAX_COVER_CENTRES}; i++) {
        if (i >= n) break;
        vec3 dv = p - uCentres[i].xyz;
        float d2 = dot(dv, dv);
        if (d2 >= best[kk - 1]) continue;
        for (int j = 0; j < ${MAX_COVER_K}; j++) {
            int idx = kk - 1 - j;
            if (idx < 0) break;
            if (idx > 0 && best[idx - 1] > d2) {
                best[idx] = best[idx - 1];
            } else {
                best[idx] = d2;
                break;
            }
        }
    }
    return best[kk - 1];
}

// The k-th nearest centre itself: the FURTHEST of the k nearest, so the one
// that attains d_(k). One extra pass, run once at the hit point, which is why
// the trace above does not carry indices.
vec3 kthNearestCentre(vec3 p, int kk, float s) {
    vec3 found = p;
    float bestD2 = -1.0;
    int n = int(uCentreCount + 0.5);
    for (int i = 0; i < ${MAX_COVER_CENTRES}; i++) {
        if (i >= n) break;
        vec3 dv = p - uCentres[i].xyz;
        float d2 = dot(dv, dv);
        if (d2 <= s && d2 >= bestD2) {
            bestD2 = d2;
            found = uCentres[i].xyz;
        }
    }
    return found;
}

void main(void) {
    // t <= 0: no ball has been born, so the region is empty (k >= 2) or a
    // finite set of points (k = 1). Either way it has no surface to draw.
    if (uT <= 0.0) discard;

    int kk = int(uK + 0.5);
    vec3 ro = view_position;
    vec3 rd = normalize(vWorld - ro);

    // Slab intersection with the tracing box. Division by a zero component
    // yields +/-infinity, which min/max order correctly.
    vec3 invD = 1.0 / rd;
    vec3 ta = (uBoxMin - ro) * invD;
    vec3 tb = (uBoxMax - ro) * invD;
    vec3 tlo = min(ta, tb);
    vec3 thi = max(ta, tb);
    float tEnter = max(max(tlo.x, tlo.y), max(tlo.z, 0.0));
    float tExit = min(thi.x, min(thi.y, thi.z));
    if (tExit < tEnter) discard;

    float radius = sqrt(uT);
    float march = tEnter;
    bool hit = false;
    for (int i = 0; i < ${COVER_MAX_STEPS}; i++) {
        vec3 p = ro + rd * march;
        float d = sqrt(kthNearestSq(p, kk)) - radius;
        if (d < uEpsilon) { hit = true; break; }
        march += d;
        if (march > tExit) break;
    }
    if (!hit) discard;

    vec3 hitP = ro + rd * march;
    float s = kthNearestSq(hitP, kk);
    vec3 c = kthNearestCentre(hitP, kk, s);
    vec3 nRaw = hitP - c;
    float nLen = length(nRaw);
    vec3 n = nLen > 1.0e-12 ? nRaw / nLen : -rd;
    // Inside the region the analytic normal points away from the eye; flip it
    // so the shading reads as a surface rather than as a black hole.
    if (dot(n, -rd) < 0.0) n = -n;

    vec3 viewDir = -rd;
    vec3 keyDir = normalize(vec3(0.45, 0.75, 0.55));
    vec3 fillDir = normalize(vec3(-0.5, -0.35, -0.6));
    float lit = 0.30
        + 0.85 * max(dot(n, keyDir), 0.0)
        + 0.22 * max(dot(n, fillDir), 0.0);
    float spec = 0.0;
    if (uShininess > 0.0) {
        vec3 half0 = normalize(keyDir + viewDir);
        spec = 0.35 * pow(max(dot(n, half0), 0.0), uShininess);
    }
    vec3 shaded = decodeGamma(uColor) * lit + vec3(spec);
    gl_FragColor = vec4(gammaCorrectOutput(shaded), uOpacity);

    vec4 clip = matrix_viewProjection * vec4(hitP, 1.0);
    gl_FragDepth = clip.z / clip.w * 0.5 + 0.5;
}
`;

/**
 * Exported for the shader-source tests: `NullGraphicsDevice` never compiles
 * GLSL/WGSL, so the load-bearing lines — the selection, the Lipschitz step and
 * the fragment depth — are pinned at source level instead.
 */
export const KFOLD_COVER_VERTEX_GLSL = COVER_VS;
export const KFOLD_COVER_FRAGMENT_GLSL = COVER_FS;

const COVER_VS_WGSL = /* wgsl */ `
attribute aPosition: vec3f;

uniform matrix_model: mat4x4f;
uniform matrix_viewProjection: mat4x4f;

varying vWorld: vec3f;

@vertex
fn vertexMain(input: VertexInput) -> VertexOutput {
    var output: VertexOutput;
    let world = uniform.matrix_model * vec4f(input.aPosition, 1.0);
    output.vWorld = world.xyz;
    output.position = uniform.matrix_viewProjection * world;
    return output;
}
`;

/**
 * Native WGSL for the WebGPU device. GLSL-only `ShaderMaterial` does not
 * compile on WebGPU in PlayCanvas 2.21.4 without glslang+twgsl, so both
 * languages ship — and both are transcriptions of the same oracle.
 *
 * `output.fragDepth` is what makes the processor add
 * `@builtin(frag_depth) fragDepth : f32` to the generated FragmentOutput
 * struct (`webgpu-shader-processor-wgsl.js:729-732`); it is written directly,
 * with no depth-range remap, because the engine already folded WebGPU's
 * [0, 1] clip range into `matrix_viewProjection` (`scene/camera.js:153`).
 */
const COVER_FS_WGSL = /* wgsl */ `
#include "gammaPS"

varying vWorld: vec3f;

uniform view_position: vec3f;
uniform matrix_viewProjection: mat4x4f;

uniform uCentres: array<vec4f, ${MAX_COVER_CENTRES}>;
uniform uCentreCount: f32;
uniform uK: f32;
uniform uT: f32;
uniform uBoxMin: vec3f;
uniform uBoxMax: vec3f;
uniform uColor: vec3f;
uniform uOpacity: f32;
uniform uShininess: f32;
uniform uEpsilon: f32;

const COVER_FAR: f32 = 3.0e38;

// d_(k)(p)^2 — the same partial selection as the GLSL and as the oracle.
fn kthNearestSq(p: vec3f, kk: i32) -> f32 {
    var best: array<f32, ${MAX_COVER_K}>;
    for (var j = 0; j < ${MAX_COVER_K}; j++) { best[j] = COVER_FAR; }
    let n = i32(uniform.uCentreCount + 0.5);
    for (var i = 0; i < ${MAX_COVER_CENTRES}; i++) {
        if (i >= n) { break; }
        let dv = p - uniform.uCentres[i].xyz;
        let d2 = dot(dv, dv);
        if (d2 >= best[kk - 1]) { continue; }
        for (var j = 0; j < ${MAX_COVER_K}; j++) {
            let idx = kk - 1 - j;
            if (idx < 0) { break; }
            if (idx > 0 && best[idx - 1] > d2) {
                best[idx] = best[idx - 1];
            } else {
                best[idx] = d2;
                break;
            }
        }
    }
    return best[kk - 1];
}

// The k-th nearest centre: the furthest of the k nearest.
fn kthNearestCentre(p: vec3f, kk: i32, s: f32) -> vec3f {
    var found = p;
    var bestD2 = -1.0;
    let n = i32(uniform.uCentreCount + 0.5);
    for (var i = 0; i < ${MAX_COVER_CENTRES}; i++) {
        if (i >= n) { break; }
        let dv = p - uniform.uCentres[i].xyz;
        let d2 = dot(dv, dv);
        if (d2 <= s && d2 >= bestD2) {
            bestD2 = d2;
            found = uniform.uCentres[i].xyz;
        }
    }
    return found;
}

@fragment
fn fragmentMain(input: FragmentInput) -> FragmentOutput {
    var output: FragmentOutput;
    output.color = vec4f(0.0);
    output.fragDepth = 1.0;

    if (uniform.uT <= 0.0) { discard; return output; }

    let kk = i32(uniform.uK + 0.5);
    let ro = uniform.view_position;
    let rd = normalize(input.vWorld - ro);

    let invD = vec3f(1.0) / rd;
    let ta = (uniform.uBoxMin - ro) * invD;
    let tb = (uniform.uBoxMax - ro) * invD;
    let tlo = min(ta, tb);
    let thi = max(ta, tb);
    let tEnter = max(max(tlo.x, tlo.y), max(tlo.z, 0.0));
    let tExit = min(thi.x, min(thi.y, thi.z));
    if (tExit < tEnter) { discard; return output; }

    let radius = sqrt(uniform.uT);
    var march = tEnter;
    var hit = false;
    for (var i = 0; i < ${COVER_MAX_STEPS}; i++) {
        let p = ro + rd * march;
        let d = sqrt(kthNearestSq(p, kk)) - radius;
        if (d < uniform.uEpsilon) { hit = true; break; }
        march += d;
        if (march > tExit) { break; }
    }
    if (!hit) { discard; return output; }

    let hitP = ro + rd * march;
    let s = kthNearestSq(hitP, kk);
    let c = kthNearestCentre(hitP, kk, s);
    let nRaw = hitP - c;
    let nLen = length(nRaw);
    var n = select(-rd, nRaw / max(nLen, 1.0e-12), nLen > 1.0e-12);
    if (dot(n, -rd) < 0.0) { n = -n; }

    let viewDir = -rd;
    let keyDir = normalize(vec3f(0.45, 0.75, 0.55));
    let fillDir = normalize(vec3f(-0.5, -0.35, -0.6));
    let lit = 0.30
        + 0.85 * max(dot(n, keyDir), 0.0)
        + 0.22 * max(dot(n, fillDir), 0.0);
    var spec = 0.0;
    if (uniform.uShininess > 0.0) {
        let half0 = normalize(keyDir + viewDir);
        spec = 0.35 * pow(max(dot(n, half0), 0.0), uniform.uShininess);
    }
    let shaded = decodeGamma3(uniform.uColor) * lit + vec3f(spec);
    output.color = vec4f(gammaCorrectOutput(shaded), uniform.uOpacity);

    let clip = uniform.matrix_viewProjection * vec4f(hitP, 1.0);
    output.fragDepth = clip.z / clip.w;
    return output;
}
`;

export const KFOLD_COVER_VERTEX_WGSL = COVER_VS_WGSL;
export const KFOLD_COVER_FRAGMENT_WGSL = COVER_FS_WGSL;

// ── The component ────────────────────────────────────────────────────────

/** Entity name of the opaque k-fold surface. */
const COVER_ENTITY = 'KFoldCoverSurface';
/** Entity name of the translucent one-fold (union) shell. */
const UNION_ENTITY = 'KFoldCoverUnionShell';

interface CoverMaterials {
  cover: pc.ShaderMaterial;
  union: pc.ShaderMaterial | null;
}

/**
 * One tracing material. The two passes differ ONLY in k, colour, opacity and
 * render state — the shader is the same, which is the claim: the union shell
 * is the k = 1 case of the k-fold cover, not a different picture.
 *
 * The cover pass is opaque and writes depth. The shell pass blends, and does
 * NOT write depth: it still depth-TESTS from its traced hit point, so it is
 * correctly hidden behind the opaque lobes, but it does not hide the points
 * and edges drawn after it.
 */
function createCoverMaterial(translucent: boolean): pc.ShaderMaterial {
  const mat = new pc.ShaderMaterial({
    uniqueName: translucent ? 'TdaKFoldCover3DShell' : 'TdaKFoldCover3D',
    attributes: { aPosition: pc.SEMANTIC_POSITION },
    vertexGLSL: COVER_VS,
    fragmentGLSL: COVER_FS,
    vertexWGSL: COVER_VS_WGSL,
    fragmentWGSL: COVER_FS_WGSL,
  });
  // Front faces are the OUTWARD ones (boxTriangles winds them counter-clockwise
  // from outside), so culling them rasterizes exactly one fragment per pixel
  // and keeps the box covering the screen when the camera moves inside it.
  mat.cull = pc.CULLFACE_FRONT;
  if (translucent) {
    mat.blendType = pc.BLEND_NORMAL;
    mat.depthWrite = false;
  } else {
    mat.blendType = pc.BLEND_NONE;
    mat.depthWrite = true;
  }
  mat.update();
  return mat;
}

/**
 * The k-fold cover as a solid region you can orbit (SPEC.md §4.6) — the
 * isosurface of an exact covering-depth function, not a blob. Must be rendered
 * inside a `<PlayCanvasStage>`.
 */
export function KFoldCover3D({
  filtration,
  t,
  k,
  colorCover,
  colorUnion,
  unionOpacity = DEFAULT_UNION_OPACITY,
  shininess = DEFAULT_SHININESS,
}: KFoldCover3DProps) {
  // Refused before anything is built (see the header): a filtration with no
  // covering multiplicity has no k-fold cover to trace.
  assertKFoldIn3D(filtration);
  const coverK = resolveK(filtration, k);

  const { app, rootEntity } = usePlayCanvas();
  // State, not a ref, so the cheap uniform effects below re-run exactly when
  // the materials are rebuilt — the same arrangement <Field3D> uses.
  const [materials, setMaterials] = useState<CoverMaterials | null>(null);

  const { cloud } = filtration;

  /** Uploaded ONCE per cloud; never re-uploaded when t moves. */
  const centres = useMemo(() => centresOf(filtration), [filtration]);

  /**
   * The tracing box: the cloud's bounding box grown by √tMax, the largest ball
   * radius this filtration can reach. Nothing outside it can be covered, so
   * the box is a bound and not a crop.
   */
  const bounds: CoverBounds = useMemo(
    () => cloudBounds(cloud.points, Math.sqrt(Math.max(filtration.tMax, 0))),
    [cloud.points, filtration.tMax],
  );

  const drawUnion = colorUnion !== undefined;

  useEffect(() => {
    if (!app || !rootEntity || centres.length === 0) return;

    const parent = new pc.Entity('KFoldCover3D', app);
    (parent as unknown as { userData: Record<string, unknown> }).userData = {
      // The claim this component makes, in the scene, next to the picture that
      // makes it (SPEC.md §1.6).
      exactness:
        'exact: the surface is the isosurface d_(k)(x) = sqrt(t), found by sphere tracing ' +
        'on the 1-Lipschitz function d_(k) with analytic normals ' +
        '(oracle: kthNearestDistanceSquared in src/render3d/kfoldCover.ts)',
      centreCount: centres.length / 3,
      k: coverK,
      maxSteps: COVER_MAX_STEPS,
      boxMin: [...bounds.min],
      boxMax: [...bounds.max],
      unionShell: drawUnion,
    };
    rootEntity.addChild(parent);

    const mesh = new pc.Mesh(app.graphicsDevice);
    mesh.setPositions(boxTriangles(bounds));
    mesh.update(pc.PRIMITIVE_TRIANGLES);

    const epsilon = coverEpsilon(bounds);
    // The centres: ONE upload, here. The array is always the full compiled
    // size so the uniform buffer WebGPU builds for it is completely written;
    // `uCentreCount` is what bounds the loops.
    const packed = new Float32Array(MAX_COVER_CENTRES * 4);
    const count = centres.length / 3;
    for (let i = 0; i < count; i++) {
      packed[i * 4] = centres[i * 3]!;
      packed[i * 4 + 1] = centres[i * 3 + 1]!;
      packed[i * 4 + 2] = centres[i * 3 + 2]!;
    }

    const built: pc.ShaderMaterial[] = [];
    const attach = (mat: pc.ShaderMaterial, name: string, kValue: number) => {
      setArrayParameter(mat, 'uCentres', packed);
      mat.setParameter('uCentreCount', count);
      mat.setParameter('uK', kValue);
      mat.setParameter('uBoxMin', [bounds.min[0], bounds.min[1], bounds.min[2]]);
      mat.setParameter('uBoxMax', [bounds.max[0], bounds.max[1], bounds.max[2]]);
      mat.setParameter('uEpsilon', epsilon);
      const meshInstance = new pc.MeshInstance(mesh, mat);
      // The box's own aabb is correct, but the stage never moves this entity
      // and the shader discards every ray that misses, so culling buys nothing
      // and can only drop the surface at grazing angles.
      meshInstance.cull = false;
      const child = new pc.Entity(name, app);
      child.addComponent('render', { meshInstances: [meshInstance] });
      parent.addChild(child);
      built.push(mat);
    };

    const coverMat = createCoverMaterial(false);
    attach(coverMat, COVER_ENTITY, coverK);

    // The union shell is the SAME shader at k = 1 — the one-fold cover — drawn
    // translucent in front. Added after the cover so the transparent pass
    // composites over the opaque one.
    let unionMat: pc.ShaderMaterial | null = null;
    if (drawUnion) {
      unionMat = createCoverMaterial(true);
      attach(unionMat, UNION_ENTITY, 1);
    }

    setMaterials({ cover: coverMat, union: unionMat });

    return () => {
      setMaterials(null);
      destroyEntity(parent, app);
      // Skipped when <PlayCanvasStage>'s cleanup already destroyed the
      // app/device first — React tears a deleted subtree down parent-first,
      // and the engine has already freed these with the device (see
      // `deviceIsLive`).
      if (deviceIsLive(app)) {
        for (const mat of built) mat.destroy();
        mesh.destroy();
      }
    };
  }, [app, rootEntity, centres, bounds, coverK, drawUnion]);

  // Scrubbing t: ONE uniform write per pass, no geometry work and no re-upload
  // of the centres (SPEC.md §1.5).
  useEffect(() => {
    if (!materials) return;
    materials.cover.setParameter('uT', t);
    materials.union?.setParameter('uT', t);
  }, [materials, t]);

  useEffect(() => {
    if (!materials) return;
    const cover = parseColor(colorCover);
    materials.cover.setParameter('uColor', [cover.r, cover.g, cover.b]);
    materials.cover.setParameter('uOpacity', 1);
    materials.cover.setParameter('uShininess', shininess);
    if (materials.union && colorUnion !== undefined) {
      const shell = parseColor(colorUnion);
      materials.union.setParameter('uColor', [shell.r, shell.g, shell.b]);
      materials.union.setParameter('uOpacity', unionOpacity);
      materials.union.setParameter('uShininess', shininess);
    }
  }, [materials, colorCover, colorUnion, unionOpacity, shininess]);

  return null;
}
