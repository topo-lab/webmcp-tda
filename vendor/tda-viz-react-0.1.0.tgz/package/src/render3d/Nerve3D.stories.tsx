import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  JITTERED8_KFOLD1,
  JITTERED8_KFOLD2,
  TETRA4_ALPHA,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { GuaranteeChip } from '../render2d/GuaranteeChip';
import { Field3D } from './Field3D';
import { Nerve3D } from './Nerve3D';
import { PlayCanvasStage } from './PlayCanvasStage';
import { PointCloud3D } from './PointCloud3D';

/**
 * The complex at scale t, in 3D: edges as line segments, triangles as a
 * translucent mesh. The whole complex is uploaded to the GPU once; t is a
 * shader uniform that decides which simplices are allowed to rasterize.
 *
 * Tetrahedra are NEVER filled. The alpha complex of four tetrahedron
 * vertices contains a genuine 3-simplex (it enters at t = 0.75 in the
 * fixture below), but drawing it solid would hide the very cavity an H₂
 * class describes — the one feature a 3D view exists to show. Only its
 * boundary triangles are drawn.
 *
 * Every simplex is recorded output of the real GUDHI engine; t filters the
 * display and never rebuilds the complex (SPEC §1.5).
 */
const meta = {
  title: '3D/Nerve3D',
  component: Nerve3D,
  decorators: [
    (Story) => (
      <div style={{ width: 480, height: 360 }}>
        <PlayCanvasStage cameraPosition={[2.4, 1.8, 2.4]} fov={50}>
          <Story />
        </PlayCanvasStage>
      </div>
    ),
  ],
  tags: ['autodocs'],
} satisfies Meta<typeof Nerve3D>;

export default meta;
type Story = StoryObj<typeof meta>;

const tetra = recordedFiltration(TETRA4_ALPHA);
const weighted = recordedFiltration(WEIGHTED3_ALPHA);

/** Below the first edge (t < 0.25): four disconnected vertices. */
export const VerticesOnly: Story = {
  args: { filtration: tetra, t: 0.1 },
  render: (args) => (
    <>
      <PointCloud3D points={tetra.cloud.points} dimension={3} size={0.06} />
      <Nerve3D {...args} />
    </>
  ),
};

/** The three edges through the origin vertex appear at t = 0.25. */
export const FirstEdges: Story = {
  args: { filtration: tetra, t: 0.25 },
  render: (args) => (
    <>
      <PointCloud3D points={tetra.cloud.points} dimension={3} size={0.06} />
      <Nerve3D {...args} />
    </>
  ),
};

/**
 * t = 0.75: the full boundary — 6 edges and 4 triangles. The 3-simplex has
 * also entered the filtration here, but it is drawn hollow on purpose.
 */
export const FullBoundaryNeverSolid: Story = {
  args: { filtration: tetra, t: 0.75 },
  render: (args) => (
    <>
      <PointCloud3D points={tetra.cloud.points} dimension={3} size={0.06} />
      <Nerve3D {...args} />
    </>
  ),
};

/** The nerve over the field: the balls that generate each simplex, together. */
export const OverField: Story = {
  args: { filtration: weighted, t: 0.8 },
  render: (args) => (
    <>
      <PointCloud3D points={weighted.cloud.points} dimension={2} size={0.06} />
      <Field3D filtration={weighted} t={0.8} opacity={0.12} />
      <Nerve3D {...args} />
    </>
  ),
};

/** Triangles suppressed to inspect the 1-skeleton. */
export const EdgesOnly: Story = {
  args: { filtration: tetra, t: 0.75, showTriangles: false },
};

// ── The k-fold cover: vertices that are SUBSETS (SPEC.md §3.1) ───────────

const kfold1 = recordedFiltration(JITTERED8_KFOLD1);
const kfold2 = recordedFiltration(JITTERED8_KFOLD2);

/**
 * The order-2 mosaic of 8 jittered lattice points. Its 22 vertices are
 * 2-SUBSETS of the input, drawn as cube markers at the barycentre of each pair
 * — never at an input point. The spheres are the balls of the cover, growing at
 * √t around the input points, so the scene holds two different kinds of object
 * and says which is which: the chip carries the vertex count against the point
 * count, and the entity's userData repeats it for a reader with no DOM.
 */
export const KFoldSubsetVertices: Story = {
  args: { filtration: kfold2, t: 0.6 },
  render: (args) => (
    <>
      <PointCloud3D points={kfold2.cloud.points} dimension={3} size={0.03} color="#94a3b8" />
      <Field3D filtration={kfold2} t={args.t} opacity={0.1} />
      <Nerve3D {...args} vertexSize={0.06} />
    </>
  ),
  decorators: [
    (Story) => (
      <div style={{ display: 'flex', gap: 16 }}>
        <div style={{ width: 420, height: 360 }}>
          <PlayCanvasStage cameraPosition={[2.6, 2, 2.6]} targetPosition={[0.5, 0.5, 0.5]} fov={50}>
            <Story />
          </PlayCanvasStage>
        </div>
        <GuaranteeChip filtration={kfold2} />
      </div>
    ),
  ],
};

/**
 * The same cloud at k = 1. Every subset is a singleton, so the markers sit
 * exactly on the input points and the filtration reproduces the alpha complex —
 * which is the engine's own claim about k = 1, and the contrast that makes the
 * k = 2 picture legible.
 */
export const KFoldK1IsAlpha: Story = {
  args: { filtration: kfold1, t: 0.6 },
  render: (args) => (
    <>
      <PointCloud3D points={kfold1.cloud.points} dimension={3} size={0.03} color="#94a3b8" />
      <Nerve3D {...args} vertexSize={0.06} />
    </>
  ),
  decorators: [
    (Story) => (
      <div style={{ display: 'flex', gap: 16 }}>
        <div style={{ width: 420, height: 360 }}>
          <PlayCanvasStage cameraPosition={[2.6, 2, 2.6]} targetPosition={[0.5, 0.5, 0.5]} fov={50}>
            <Story />
          </PlayCanvasStage>
        </div>
        <GuaranteeChip filtration={kfold1} />
      </div>
    ),
  ],
};
