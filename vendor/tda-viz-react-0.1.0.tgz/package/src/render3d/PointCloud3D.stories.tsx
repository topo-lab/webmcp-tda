import type { Meta, StoryObj } from '@storybook/react-vite';
import { PlayCanvasStage } from './PlayCanvasStage';
import { PointCloud3D } from './PointCloud3D';

function torus(n: number, R = 1, r = 0.35): number[] {
  const pts: number[] = [];
  for (let i = 0; i < n; i++) {
    const u = Math.random() * 2 * Math.PI;
    const v = Math.random() * 2 * Math.PI;
    pts.push(
      (R + r * Math.cos(v)) * Math.cos(u),
      (R + r * Math.cos(v)) * Math.sin(u),
      r * Math.sin(v),
    );
  }
  return pts;
}

function circle2D(n: number): number[] {
  const pts: number[] = [];
  for (let i = 0; i < n; i++) {
    const t = (2 * Math.PI * i) / n;
    pts.push(Math.cos(t), Math.sin(t));
  }
  return pts;
}

const meta = {
  title: '3D/PointCloud3D',
  component: PointCloud3D,
  decorators: [
    (Story) => (
      <div style={{ width: 480, height: 360 }}>
        <PlayCanvasStage cameraPosition={[0, 0, 3.2]}>
          <Story />
        </PlayCanvasStage>
      </div>
    ),
  ],
  tags: ['autodocs'],
} satisfies Meta<typeof PointCloud3D>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Torus: Story = {
  args: {
    points: torus(1500),
    dimension: 3,
    size: 0.03,
  },
};

/** 2D data embedded at z=0 — display-only counterpart of the adapter's rule. */
export const EmbeddedCircle: Story = {
  args: {
    points: circle2D(50),
    dimension: 2,
    color: '#f59e0b',
    size: 0.05,
  },
};

/**
 * The weight glyph (SPEC §4.2): with `weights`, points render as instanced
 * sphere markers whose radius scales with √wᵢ — the heavy point (w = 0.5)
 * reads as heavy before any ball is drawn. Markers, not balls: <Field3D>
 * draws the true radii √(t + wᵢ).
 */
export const WeightGlyph: Story = {
  args: {
    points: [0, 0, 2, 0, 1, 1.6],
    dimension: 2,
    weights: [0.5, 0, 0],
    size: 0.06,
    color: '#f59e0b',
  },
};
