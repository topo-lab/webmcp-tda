import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CUBE8_BOX_3D,
  SPIRAL16_ELLIPSOID_RIPS_3D,
  TETRA4_ALPHA,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { GuaranteeChip } from '../render2d/GuaranteeChip';
import { Field3D } from './Field3D';
import { PlayCanvasStage } from './PlayCanvasStage';
import { PointCloud3D } from './PointCloud3D';

/**
 * The union of the growing shapes in 3D, as instanced geometry rendered via
 * PlayCanvas: spheres with per-point radii from `filtration.radiusAt`,
 * ellipsoids oriented by their fitted frame, or the box filtration's own grown
 * boxes. Under the weighted alpha filtration the sphere around pᵢ has radius
 * √(t + wᵢ), so heavier points carry visibly larger spheres at every t.
 *
 * The shape law always lives in the shader as a transcription of the
 * filtration's, so scrubbing t is one uniform write and never a re-upload: an
 * ellipsoid carries its UNIT profile and frame and is scaled by (t/2) on the
 * GPU; a box filtration uploads every step's boxes and selects one with
 * `uStep = ⌊t/π⌋`, because a box between grid values is a shape the filtration
 * never contained.
 *
 * The wing complex is absent on purpose: it is 2D only, in the engine and in
 * the mathematics, so `<Field3D>` refuses a wing filtration with an error
 * rather than extruding a hexagon nobody has defined.
 *
 * HONESTY LABEL (SPEC §8 Q2): every one of these is an APPROXIMATION of X_t.
 * Overlapping translucent instances double-count their intersections instead of
 * merging into a single surface.
 */
const meta = {
  title: '3D/Field3D',
  component: Field3D,
  decorators: [
    (Story) => (
      <div style={{ width: 480, height: 360 }}>
        <PlayCanvasStage cameraPosition={[2.6, 2.0, 2.6]} fov={50}>
          <Story />
        </PlayCanvasStage>
      </div>
    ),
  ],
  tags: ['autodocs'],
} satisfies Meta<typeof Field3D>;

export default meta;
type Story = StoryObj<typeof meta>;

const weighted = recordedFiltration(WEIGHTED3_ALPHA);
const tetra = recordedFiltration(TETRA4_ALPHA);

/**
 * The weighted cloud at t = 0: only the heavy point (w = 0.5) has a ball,
 * radius √0.5 ≈ 0.707. The light points have radius √0 = 0 — no sphere is
 * drawn for them, because a ball of radius zero is not a ball.
 */
export const WeightedAtZero: Story = {
  args: { filtration: weighted, t: 0 },
  render: (args) => (
    <>
      <PointCloud3D points={weighted.cloud.points} dimension={2} size={0.06} />
      <Field3D {...args} />
    </>
  ),
};

/** All three balls exist at t = 0.5, still with different radii (1 vs √0.5). */
export const WeightedMid: Story = {
  args: { filtration: weighted, t: 0.5 },
  render: (args) => (
    <>
      <PointCloud3D points={weighted.cloud.points} dimension={2} size={0.06} />
      <Field3D {...args} />
    </>
  ),
};

/** A true 3D cloud (regular tetrahedron): balls grow off the z = 0 plane. */
export const Tetrahedron: Story = {
  args: { filtration: tetra, t: 0.15 },
  render: (args) => (
    <>
      <PointCloud3D points={tetra.cloud.points} dimension={3} size={0.06} />
      <Field3D {...args} />
    </>
  ),
};

/** Higher opacity makes the double-counted overlaps visible — the reason this is labeled approximate. */
export const ApproximationVisible: Story = {
  args: { filtration: tetra, t: 0.3, opacity: 0.45 },
};

// ── The complex menu in 3D (SPEC.md §4.1) ────────────────────────────────

const ellipsoid3d = recordedFiltration(SPIRAL16_ELLIPSOID_RIPS_3D);
const box3d = recordedFiltration(CUBE8_BOX_3D);

/**
 * Ellipsoids fitted on a tilted 3D curve, at t = 0.8. Each is the unit sphere
 * scaled by (t/2)·profile along its own PCA frame — a scaled, oriented sphere
 * instance, which is the cheap correct move. This is the filtration `<Field2D>`
 * refuses: seen from above, the ellipse of frame[0], frame[1] is a central
 * slice, not the outline.
 */
export const Ellipsoids: Story = {
  args: { filtration: ellipsoid3d, t: 0.8, opacity: 0.3 },
  render: (args) => (
    <>
      <PointCloud3D points={ellipsoid3d.cloud.points} dimension={3} size={0.03} color="#94a3b8" />
      <Field3D {...args} />
    </>
  ),
  decorators: [
    (Story) => (
      <div style={{ display: 'flex', gap: 16 }}>
        <div style={{ width: 420, height: 360 }}>
          <PlayCanvasStage cameraPosition={[3.2, 2.4, 3.2]} fov={50}>
            <Story />
          </PlayCanvasStage>
        </div>
        <GuaranteeChip filtration={ellipsoid3d} />
      </div>
    ),
  ],
};

/** The same ellipsoids at twice the scale: the anisotropy grows, the frames do not turn. */
export const EllipsoidsGrown: Story = {
  args: { filtration: ellipsoid3d, t: 1.6, opacity: 0.3 },
  render: (args) => (
    <>
      <PointCloud3D points={ellipsoid3d.cloud.points} dimension={3} size={0.03} color="#94a3b8" />
      <Field3D {...args} />
    </>
  ),
};

/**
 * A 3D box filtration at step 2 (t = 0.5, π = 0.25): the engine's own grown
 * boxes, looked up on the grid. Scrub between 0.5 and 0.749 and nothing moves —
 * that is the honest behaviour, not a stuck slider.
 */
export const BoxesAtStepTwo: Story = {
  args: { filtration: box3d, t: 0.5, opacity: 0.25 },
  render: (args) => (
    <>
      <PointCloud3D points={box3d.cloud.points} dimension={3} size={0.03} color="#94a3b8" />
      <Field3D {...args} />
    </>
  ),
  decorators: [
    (Story) => (
      <div style={{ display: 'flex', gap: 16 }}>
        <div style={{ width: 420, height: 360 }}>
          <PlayCanvasStage cameraPosition={[3, 2.4, 3]} targetPosition={[0.5, 0.5, 0.5]} fov={50}>
            <Story />
          </PlayCanvasStage>
        </div>
        <GuaranteeChip filtration={box3d} />
      </div>
    ),
  ],
};
