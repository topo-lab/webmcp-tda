/**
 * The covering-depth arithmetic behind `<DepthSlice3D>` — pure TypeScript, no
 * engine, no React.
 *
 * WHY IT IS A SEPARATE MODULE. `<DepthSlice3D>` paints a plane on the GPU:
 * every fragment counts the balls that contain it. jsdom cannot read those
 * pixels back, so the count itself is factored out here and tested exhaustively
 * against brute force (src/render3d/__tests__/DepthSlice3D.test.tsx).
 *
 * `coveringDepthAt` IS THE ORACLE FOR THE GLSL/WGSL. The fragment shader in
 * DepthSlice3D.tsx runs the identical formula, term for term:
 *
 *     depth(x) = #{ i : |x - cᵢ|² ≤ t }
 *
 * — squared distances, no square roots, and a NON-STRICT comparison, so a point
 * exactly on a ball's boundary is inside it. If either side of that pair ever
 * changes, both must change together; the shader is a transcription of this
 * function and nothing else.
 *
 * WHY DEPTH, NOT THE UNION. For a k-fold cover filtration the union of the
 * balls is the 1-fold cover — it is not the object the complex is about. The
 * k-fold cover is the region covered at least k times, and the only honest way
 * to draw it is to evaluate the count.
 *
 * HEADLESS: this module imports nothing from playcanvas. It lives under
 * src/render3d only because it exists to serve `<DepthSlice3D>`.
 */

/**
 * How many ball centres the compiled fragment shader can hold.
 *
 * The centres travel as one `vec4[256]` uniform array — 256 uniform vectors,
 * comfortably inside the fragment uniform budget of every WebGL2 and WebGPU
 * device in use (ANGLE/D3D11 reports 1024 fragment uniform vectors; Metal and
 * desktop GL more), and far above the clouds this draws: 8 points for the
 * motifs, 48 for the site's lattices, 64 for the Explorer, 150 for the review
 * gallery that this component transcribes.
 *
 * Above this the component THROWS rather than silently counting a prefix of the
 * cloud, which would produce a picture that is wrong in exactly the way the
 * component exists to avoid. Raising the ceiling means moving the centres into
 * a float texture and sampling it with `texelFetch`/`textureLoad`; the count
 * itself would not change, because it is this function.
 */
export const MAX_DEPTH_SLICE_CENTRES = 256;

/**
 * The covering depth at `point`: how many of the balls of squared radius
 * `tSquared` centred on `centres` contain it.
 *
 * `centres` is flat xyz, length 3n. `tSquared` is the k-fold cover's own
 * filtration value — its convention is `alpha` on an unweighted cloud, so the
 * ball around every input point has radius √t exactly and the membership test
 * is `|x - cᵢ|² ≤ t` with no per-point weight term.
 *
 * A negative `tSquared` is depth 0 everywhere: no ball has been born yet.
 * Boundary points count as inside (`≤`, not `<`) — the same choice the shader
 * makes, and the same one the reference implementation made.
 */
export function coveringDepthAt(
  point: readonly number[],
  centres: ArrayLike<number>,
  tSquared: number,
): number {
  if (!(tSquared >= 0)) return 0;
  const x = point[0] ?? 0;
  const y = point[1] ?? 0;
  const z = point[2] ?? 0;
  const n = Math.floor(centres.length / 3);
  let depth = 0;
  for (let i = 0; i < n; i++) {
    const dx = x - centres[i * 3]!;
    const dy = y - centres[i * 3 + 1]!;
    const dz = z - centres[i * 3 + 2]!;
    if (dx * dx + dy * dy + dz * dz <= tSquared) depth++;
  }
  return depth;
}

/** An orthonormal frame of the slice plane: `u` and `v` span it, `n` is normal. */
export interface SliceFrame {
  readonly u: [number, number, number];
  readonly v: [number, number, number];
  readonly n: [number, number, number];
}

/**
 * A right-handed orthonormal frame whose third axis is `normal`.
 *
 * The in-plane axes are arbitrary — nothing about the picture depends on which
 * two perpendicular directions are chosen, because the depth field is defined
 * on the plane, not on its parameterisation. The seed axis is whichever of x
 * or y is less aligned with the normal, so the cross product never degenerates.
 *
 * Throws on a zero-length normal: there is no plane to draw, and normalising
 * it would hand the caller a frame of NaNs.
 */
export function sliceFrame(normal: readonly number[]): SliceFrame {
  const nx = normal[0] ?? 0;
  const ny = normal[1] ?? 0;
  const nz = normal[2] ?? 0;
  const len = Math.sqrt(nx * nx + ny * ny + nz * nz);
  if (!(len > 1e-12)) {
    throw new Error(
      `<DepthSlice3D>: the slice plane normal [${nx}, ${ny}, ${nz}] has zero length, ` +
        'so it defines no plane. Pass a non-zero normal.',
    );
  }
  const n: [number, number, number] = [nx / len, ny / len, nz / len];
  const seed: [number, number, number] = Math.abs(n[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0];
  // u = normalize(seed - (seed·n) n)
  const d = seed[0] * n[0] + seed[1] * n[1] + seed[2] * n[2];
  let ux = seed[0] - d * n[0];
  let uy = seed[1] - d * n[1];
  let uz = seed[2] - d * n[2];
  const ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
  ux /= ul;
  uy /= ul;
  uz /= ul;
  const u: [number, number, number] = [ux, uy, uz];
  // v = n × u, so (u, v, n) is right-handed and orthonormal.
  const v: [number, number, number] = [
    n[1] * uz - n[2] * uy,
    n[2] * ux - n[0] * uz,
    n[0] * uy - n[1] * ux,
  ];
  return { u, v, n };
}

/** Centroid of a flat 3D coordinate array. `[0, 0, 0]` for an empty cloud. */
export function cloudCentroid(points: readonly number[]): [number, number, number] {
  const n = Math.floor(points.length / 3);
  if (n === 0) return [0, 0, 0];
  let x = 0;
  let y = 0;
  let z = 0;
  for (let i = 0; i < n; i++) {
    x += points[i * 3]!;
    y += points[i * 3 + 1]!;
    z += points[i * 3 + 2]!;
  }
  return [x / n, y / n, z / n];
}

/** Largest distance from `centre` to any point of a flat 3D coordinate array. */
export function cloudBoundingRadius(points: readonly number[], centre: readonly number[]): number {
  const n = Math.floor(points.length / 3);
  let max = 0;
  for (let i = 0; i < n; i++) {
    const dx = points[i * 3]! - (centre[0] ?? 0);
    const dy = points[i * 3 + 1]! - (centre[1] ?? 0);
    const dz = points[i * 3 + 2]! - (centre[2] ?? 0);
    const d = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (d > max) max = d;
  }
  return max;
}

/**
 * The world point at plane coordinates (a, b) of a slice: `origin + a·u + b·v`.
 *
 * Exists so a test can walk the same plane the shader rasterizes without
 * re-deriving the parameterisation at the call site.
 */
export function slicePoint(
  origin: readonly number[],
  frame: SliceFrame,
  a: number,
  b: number,
): [number, number, number] {
  return [
    (origin[0] ?? 0) + a * frame.u[0] + b * frame.v[0],
    (origin[1] ?? 0) + a * frame.u[1] + b * frame.v[1],
    (origin[2] ?? 0) + a * frame.u[2] + b * frame.v[2],
  ];
}
