/**
 * <CycleHighlight3D>: draws one cycle — an ordered list of vertex indices — as a
 * closed loop using PlayCanvas, so a bar on the barcode and a shape on the stage
 * are visibly the same object.
 *
 * Lives ONLY under `tda-viz-react/3d` (SPEC.md §3/§4).
 *
 * Honesty (SPEC.md §5): this renders a cycle it is GIVEN. It does not derive
 * generators. tda-wasm does not currently expose volume-optimal or
 * stable-volume generators, so callers must supply the vertex ring from
 * something that actually knows it.
 */
import { useEffect, useMemo, useRef } from 'react';
import * as pc from 'playcanvas';
import { usePlayCanvas } from './PlayCanvasStage';
import { pointsToPositions } from './PointCloud3D';
import {
  createInstancingVertexBuffer,
  createSphereMesh,
  createUnlitMaterial,
  destroyEntity,
  parseColor,
} from './utils';

export interface CycleHighlight3DProps {
  points: number[];
  /** Ordered vertex indices forming the cycle. */
  cycle: number[];
  dimension?: 2 | 3;
  /** Close the ring by joining the last vertex back to the first. */
  closed?: boolean;
  color?: string;
  /** Also mark the participating vertices. */
  showVertices?: boolean;
}

export function CycleHighlight3D({
  points,
  cycle,
  dimension = 3,
  closed = true,
  color = '#f43f5e',
  showVertices = true,
}: CycleHighlight3DProps) {
  const { app, rootEntity } = usePlayCanvas();
  const entityRef = useRef<pc.Entity | null>(null);

  const positions = useMemo(() => pointsToPositions(points, dimension), [points, dimension]);
  const vertexCount = positions.length / 3;

  const valid = useMemo(
    () => cycle.filter((v) => Number.isInteger(v) && v >= 0 && v < vertexCount),
    [cycle, vertexCount],
  );

  useEffect(() => {
    if (!app || !rootEntity || valid.length < 2) return;

    const parent = new pc.Entity('CycleHighlight3D', app);
    rootEntity.addChild(parent);
    entityRef.current = parent;

    const lineVerts: number[] = [];
    const ring = closed && valid.length > 2 ? [...valid, valid[0]!] : valid;

    for (let i = 0; i < ring.length - 1; i++) {
      const a = ring[i]!;
      const b = ring[i + 1]!;
      lineVerts.push(
        positions[a * 3]!,
        positions[a * 3 + 1]!,
        positions[a * 3 + 2]!,
        positions[b * 3]!,
        positions[b * 3 + 1]!,
        positions[b * 3 + 2]!,
      );
    }

    const parsedCol = parseColor(color);
    const lineMesh = new pc.Mesh(app.graphicsDevice);
    lineMesh.setPositions(lineVerts);
    lineMesh.update(pc.PRIMITIVE_LINES);

    const lineMat = createUnlitMaterial(parsedCol);
    const lineInstance = new pc.MeshInstance(lineMesh, lineMat);
    const lineEntity = new pc.Entity('CycleLines', app);
    lineEntity.addComponent('render', {
      meshInstances: [lineInstance],
    });
    parent.addChild(lineEntity);

    // Optional vertex marker spheres
    let sphereMesh: pc.Mesh | null = null;
    let sphereMat: pc.StandardMaterial | null = null;
    let vb: pc.VertexBuffer | null = null;

    if (showVertices && valid.length > 0) {
      sphereMesh = createSphereMesh(app.graphicsDevice, 12);

      sphereMat = new pc.StandardMaterial();
      sphereMat.diffuse = parsedCol;
      sphereMat.emissive = parsedCol;
      sphereMat.emissiveIntensity = 0.5;
      sphereMat.update();

      const matrixData = new Float32Array(valid.length * 16);
      const mat = new pc.Mat4();
      const markerRadius = 0.04;

      for (let i = 0; i < valid.length; i++) {
        const v = valid[i]!;
        const px = positions[v * 3]!;
        const py = positions[v * 3 + 1]!;
        const pz = positions[v * 3 + 2]!;
        mat.setTRS(
          new pc.Vec3(px, py, pz),
          pc.Quat.IDENTITY,
          new pc.Vec3(markerRadius, markerRadius, markerRadius),
        );

        const raw = mat.data;
        for (let m = 0; m < 16; m++) {
          matrixData[i * 16 + m] = raw[m]!;
        }
      }

      vb = createInstancingVertexBuffer(app.graphicsDevice, matrixData, valid.length);
      const sphereInstance = new pc.MeshInstance(sphereMesh, sphereMat);
      sphereInstance.setInstancing(vb);

      const sphereEntity = new pc.Entity('CycleVertexMarkers', app);
      sphereEntity.addComponent('render', {
        meshInstances: [sphereInstance],
      });
      parent.addChild(sphereEntity);
    }

    return () => {
      destroyEntity(parent);
      lineMat.destroy();
      lineMesh.destroy();
      sphereMat?.destroy();
      sphereMesh?.destroy();
      vb?.destroy();
      entityRef.current = null;
    };
  }, [app, rootEntity, valid, closed, positions, color, showVertices]);

  return null;
}
