/**
 * <Nerve3D>: the simplices present at scale t, rendered via PlayCanvas — edges
 * as line segments, triangles as a transparent double-sided mesh.
 * Takes (filtration, t) per SPEC.md §4.
 *
 * Lives ONLY under `tda-viz-react/3d` (SPEC.md §2/§4) so PlayCanvas never
 * enters the main entry. Must be rendered inside a <PlayCanvasStage>.
 *
 * GPU-DRIVEN SCALE (SPEC.md §1.5): both meshes are built ONCE, from
 * `filtration.simplices` — every simplex the complex will ever contain, not
 * `simplicesAt(t)`. Each vertex carries its simplex's filtration (birth) value
 * in an `aBirth` attribute, and the vertex shader pushes a simplex outside the
 * clip volume while `aBirth > uT`. Moving t writes one uniform; it never
 * rebuilds geometry. Because every vertex of a simplex carries the same birth
 * value, a primitive is always wholly drawn or wholly clipped, and because the
 * test is monotone in uT nothing can vanish as t grows (SPEC.md §1.1).
 *
 * VERTEX IDENTITY (SPEC.md §3.1): the geometry is built from
 * `filtration.vertexPositions`, NOT from `cloud.points`. They coincide for every
 * `vertexKind: 'point'` filtration and differ for the k-fold cover, whose
 * vertices are k-SUBSETS of the input drawn at their barycentres — there are
 * more of them than there are points, so reading the cloud would place simplices
 * on the wrong objects and silently drop the rest. When the vertices ARE
 * subsets this component also draws them, as cube markers distinct from
 * <PointCloud3D>'s spheres, because a ball on an input point and a vertex
 * standing for a set of them are two different objects in one scene
 * (SPEC.md §8 Q5).
 *
 * Honesty (SPEC.md §4.1): tetrahedra are NEVER filled — a solid 3-simplex
 * would hide the very cavity an H₂ class describes.
 */
import { useEffect, useMemo, useState } from 'react';
import * as pc from 'playcanvas';
import type { Filtration } from '../filtration/types';
import { usePlayCanvas } from './PlayCanvasStage';
import { pointsToPositions } from './PointCloud3D';
import {
  SHADE_GLSL,
  SHADE_WGSL,
  createBoxMesh,
  createInstanceStreamBuffer,
  destroyEntity,
  parseColor,
} from './utils';

export interface Nerve3DProps {
  filtration: Filtration;
  /** Current scale. Filters what is drawn; never triggers a recompute (SPEC.md §1.5). */
  t: number;
  showEdges?: boolean;
  showTriangles?: boolean;
  /**
   * Draw a marker per vertex. Defaults to ON when the vertices are SUBSETS —
   * nothing else in the scene sits at a barycentre — and OFF otherwise, where
   * <PointCloud3D> already draws the cloud.
   */
  showVertices?: boolean;
  /** Marker edge length in world units. */
  vertexSize?: number;
  edgeColor?: string;
  triangleColor?: string;
  vertexColor?: string;
  triangleOpacity?: number;
}

export function computeTriangleNormals(positions: number[]): number[] {
  const normals = new Array(positions.length).fill(0);
  const v0 = new pc.Vec3();
  const v1 = new pc.Vec3();
  const v2 = new pc.Vec3();
  const e1 = new pc.Vec3();
  const e2 = new pc.Vec3();
  const n = new pc.Vec3();

  for (let i = 0; i < positions.length; i += 9) {
    v0.set(positions[i]!, positions[i + 1]!, positions[i + 2]!);
    v1.set(positions[i + 3]!, positions[i + 4]!, positions[i + 5]!);
    v2.set(positions[i + 6]!, positions[i + 7]!, positions[i + 8]!);

    e1.sub2(v1, v0);
    e2.sub2(v2, v0);
    n.cross(e1, e2).normalize();

    // Assign normal to all 3 vertices
    normals[i] = n.x;
    normals[i + 1] = n.y;
    normals[i + 2] = n.z;

    normals[i + 3] = n.x;
    normals[i + 4] = n.y;
    normals[i + 5] = n.z;

    normals[i + 6] = n.x;
    normals[i + 7] = n.y;
    normals[i + 8] = n.z;
  }
  return normals;
}

/** Per-vertex birth stream. Location 8 — clear of POSITION (0) and NORMAL (1). */
const SEMANTIC_BIRTH = pc.SEMANTIC_ATTR8;

/**
 * Clip position for a simplex that has not been born yet. x, y and z all
 * exceed w, so every vertex of the primitive falls outside the frustum on
 * several planes at once and the primitive is discarded before rasterization.
 * Not a zero-area triangle: a degenerate primitive can still light up pixels
 * along its edges on some drivers.
 */
const UNBORN_CLIP_GLSL = /* glsl */ `
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
`;

const UNBORN_CLIP_WGSL = /* wgsl */ `
        output.position = vec4f(2.0, 2.0, 2.0, 1.0);
`;

const EDGE_VS = /* glsl */ `
attribute vec3 aPosition;
attribute float aBirth;

uniform mat4 matrix_model;
uniform mat4 matrix_viewProjection;
uniform float uT;

void main(void) {
    if (aBirth > uT) {
${UNBORN_CLIP_GLSL}
    } else {
        gl_Position = matrix_viewProjection * matrix_model * vec4(aPosition, 1.0);
    }
}
`;

const EDGE_FS = /* glsl */ `
#include "gammaPS"

uniform vec3 uColor;
uniform float uOpacity;

void main(void) {
    gl_FragColor = vec4(gammaCorrectOutput(decodeGamma(uColor)), uOpacity);
}
`;

const TRIANGLE_VS = /* glsl */ `
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute float aBirth;

uniform mat4 matrix_model;
uniform mat4 matrix_viewProjection;
uniform mat3 matrix_normal;
uniform float uT;

varying vec3 vNormal;

void main(void) {
    vNormal = matrix_normal * aNormal;
    if (aBirth > uT) {
${UNBORN_CLIP_GLSL}
    } else {
        gl_Position = matrix_viewProjection * matrix_model * vec4(aPosition, 1.0);
    }
}
`;

const TRIANGLE_FS = /* glsl */ `
${SHADE_GLSL}

varying vec3 vNormal;

uniform vec3 uColor;
uniform float uOpacity;

void main(void) {
    gl_FragColor = vec4(gammaCorrectOutput(tdaShade(uColor, vNormal)), uOpacity);
}
`;

const EDGE_VS_WGSL = /* wgsl */ `
attribute aPosition: vec3f;
attribute aBirth: f32;

uniform matrix_model: mat4x4f;
uniform matrix_viewProjection: mat4x4f;
uniform uT: f32;

@vertex
fn vertexMain(input: VertexInput) -> VertexOutput {
    var output: VertexOutput;
    if (input.aBirth > uniform.uT) {
${UNBORN_CLIP_WGSL}
    } else {
        output.position = uniform.matrix_viewProjection * uniform.matrix_model * vec4f(input.aPosition, 1.0);
    }
    return output;
}
`;

const EDGE_FS_WGSL = /* wgsl */ `
#include "gammaPS"

uniform uColor: vec3f;
uniform uOpacity: f32;

@fragment
fn fragmentMain(input: FragmentInput) -> FragmentOutput {
    var output: FragmentOutput;
    output.color = vec4f(gammaCorrectOutput(decodeGamma3(uniform.uColor)), uniform.uOpacity);
    return output;
}
`;

const TRIANGLE_VS_WGSL = /* wgsl */ `
attribute aPosition: vec3f;
attribute aNormal: vec3f;
attribute aBirth: f32;

uniform matrix_model: mat4x4f;
uniform matrix_viewProjection: mat4x4f;
uniform matrix_normal: mat3x3f;
uniform uT: f32;

varying vNormal: vec3f;

@vertex
fn vertexMain(input: VertexInput) -> VertexOutput {
    var output: VertexOutput;
    output.vNormal = uniform.matrix_normal * input.aNormal;
    if (input.aBirth > uniform.uT) {
${UNBORN_CLIP_WGSL}
    } else {
        output.position = uniform.matrix_viewProjection * uniform.matrix_model * vec4f(input.aPosition, 1.0);
    }
    return output;
}
`;

const TRIANGLE_FS_WGSL = /* wgsl */ `
${SHADE_WGSL}

varying vNormal: vec3f;

uniform uColor: vec3f;
uniform uOpacity: f32;

@fragment
fn fragmentMain(input: FragmentInput) -> FragmentOutput {
    var output: FragmentOutput;
    output.color = vec4f(gammaCorrectOutput(tdaShade(uniform.uColor, input.vNormal)), uniform.uOpacity);
    return output;
}
`;

/**
 * Vertex markers: one instanced cube per VERTEX (not per point), clipped by the
 * same `aBirth > uT` test so a mosaic vertex appears exactly at its own birth.
 * xyz is the vertex position — a subset's barycentre — and w its birth value.
 */
const VERTEX_VS = /* glsl */ `
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec4 aInstanceVertex;

uniform mat4 matrix_model;
uniform mat4 matrix_viewProjection;
uniform mat3 matrix_normal;
uniform float uT;
uniform float uSize;

varying vec3 vNormal;

void main(void) {
    vNormal = matrix_normal * aNormal;
    if (aInstanceVertex.w > uT) {
${UNBORN_CLIP_GLSL}
    } else {
        vec3 local = aInstanceVertex.xyz + aPosition * uSize;
        gl_Position = matrix_viewProjection * matrix_model * vec4(local, 1.0);
    }
}
`;

const VERTEX_VS_WGSL = /* wgsl */ `
attribute aPosition: vec3f;
attribute aNormal: vec3f;
attribute aInstanceVertex: vec4f;

uniform matrix_model: mat4x4f;
uniform matrix_viewProjection: mat4x4f;
uniform matrix_normal: mat3x3f;
uniform uT: f32;
uniform uSize: f32;

varying vNormal: vec3f;

@vertex
fn vertexMain(input: VertexInput) -> VertexOutput {
    var output: VertexOutput;
    output.vNormal = uniform.matrix_normal * input.aNormal;
    if (input.aInstanceVertex.w > uniform.uT) {
${UNBORN_CLIP_WGSL}
    } else {
        let local = input.aInstanceVertex.xyz + input.aPosition * uniform.uSize;
        output.position = uniform.matrix_viewProjection * uniform.matrix_model * vec4f(local, 1.0);
    }
    return output;
}
`;

/**
 * Exported for the shader-source tests: NullGraphicsDevice never compiles
 * GLSL/WGSL, so the clip comparison is pinned at source level instead
 * (src/render3d/__tests__/Nerve3D.test.tsx).
 */
export const VERTEX_VERTEX_GLSL = VERTEX_VS;
export const VERTEX_VERTEX_WGSL = VERTEX_VS_WGSL;
export const EDGE_VERTEX_GLSL = EDGE_VS;
export const TRIANGLE_VERTEX_GLSL = TRIANGLE_VS;
export const EDGE_VERTEX_WGSL = EDGE_VS_WGSL;
export const TRIANGLE_VERTEX_WGSL = TRIANGLE_VS_WGSL;

/** Opacity of the 1-skeleton. Matches the pre-GPU unlit edge material. */
const EDGE_OPACITY = 0.75;

interface NerveGpu {
  edgeEntity: pc.Entity | null;
  edgeMaterial: pc.ShaderMaterial | null;
  triEntity: pc.Entity | null;
  triMaterial: pc.ShaderMaterial | null;
  vertexEntity: pc.Entity | null;
  vertexMaterial: pc.ShaderMaterial | null;
}

/** Per-instance stream for the vertex markers: xyz = position, w = birth. */
const SEMANTIC_INSTANCE_VERTEX = pc.SEMANTIC_ATTR13;

export function Nerve3D({
  filtration,
  t,
  showEdges = true,
  showTriangles = true,
  showVertices,
  vertexSize = 0.05,
  edgeColor = '#fb923c',
  triangleColor = '#fdba74',
  vertexColor = '#a78bfa',
  triangleOpacity = 0.25,
}: Nerve3DProps) {
  const { app, rootEntity } = usePlayCanvas();
  // State, not a ref: the cheap uniform / visibility effects below must re-run
  // when the GPU objects are actually rebuilt, and at no other time.
  const [gpu, setGpu] = useState<NerveGpu | null>(null);

  const { cloud, simplices, vertexKind, vertexCount } = filtration;
  /**
   * VERTEX positions, not cloud points (SPEC.md §3.1). For the k-fold cover
   * these are the barycentres of the mosaic's k-subsets, and there are more of
   * them than there are input points.
   */
  const positions = useMemo(
    () => pointsToPositions(filtration.vertexPositions, cloud.dimension),
    [filtration, cloud.dimension],
  );
  const isSubset = vertexKind === 'subset';
  const drawVertices = showVertices ?? isSubset;

  /**
   * ALL simplices, not simplicesAt(t): the geometry is the whole complex and
   * `t` only decides what the shader lets through.
   */
  const geometry = useMemo(() => {
    const edgeVerts: number[] = [];
    const edgeBirths: number[] = [];
    const triVerts: number[] = [];
    const triBirths: number[] = [];
    /**
     * Marker instances: xyz + the vertex's OWN birth, read off its 0-simplex.
     * A vertex with no 0-simplex is not in the complex, so it gets no marker —
     * inventing a birth for it would put an object on screen the filtration
     * never contained.
     */
    const vertexInstances: number[] = [];

    const push = (target: number[], v: number) => {
      target.push(positions[v * 3]!, positions[v * 3 + 1]!, positions[v * 3 + 2]!);
    };

    for (const s of simplices) {
      if (s.vertices.length === 1) {
        const v = s.vertices[0];
        if (v !== undefined && v < vertexCount) {
          push(vertexInstances, v);
          vertexInstances.push(s.filtration);
        }
      } else if (s.vertices.length === 2) {
        const [a, b] = s.vertices;
        if (a !== undefined && b !== undefined && a < vertexCount && b < vertexCount) {
          push(edgeVerts, a);
          push(edgeVerts, b);
          edgeBirths.push(s.filtration, s.filtration);
        }
      } else if (s.vertices.length === 3) {
        // 2-simplices only: 3-simplices are deliberately not solids (SPEC.md §4.1).
        const [a, b, c] = s.vertices;
        if (
          a !== undefined &&
          b !== undefined &&
          c !== undefined &&
          a < vertexCount &&
          b < vertexCount &&
          c < vertexCount
        ) {
          push(triVerts, a);
          push(triVerts, b);
          push(triVerts, c);
          triBirths.push(s.filtration, s.filtration, s.filtration);
        }
      }
    }

    return {
      edgeVerts,
      edgeBirths,
      triVerts,
      triBirths,
      triNormals: computeTriangleNormals(triVerts),
      vertexInstances: new Float32Array(vertexInstances),
    };
  }, [simplices, positions, vertexCount]);

  // Build ONCE per (app, cloud, complex). Nothing here depends on t, on the
  // colors, or on the show* flags.
  useEffect(() => {
    if (!app || !rootEntity) return;

    const parent = new pc.Entity('Nerve3D', app);
    // There is no DOM here to carry a caption, so the scene states what its
    // vertices are (SPEC.md §1.6: the label travels with the object).
    (parent as unknown as { userData: Record<string, string | number> }).userData = {
      vertexKind,
      vertexCount,
      pointCount: cloud.points.length / cloud.dimension,
      ...(isSubset
        ? {
            vertices:
              'a vertex is a SUBSET of the input, drawn at its barycentre — not an input point',
          }
        : {}),
    };
    rootEntity.addChild(parent);

    const disposables: Array<{ destroy: () => void }> = [];
    const built: NerveGpu = {
      edgeEntity: null,
      edgeMaterial: null,
      triEntity: null,
      triMaterial: null,
      vertexEntity: null,
      vertexMaterial: null,
    };

    if (geometry.triVerts.length > 0) {
      const triMesh = new pc.Mesh(app.graphicsDevice);
      triMesh.setPositions(geometry.triVerts);
      triMesh.setNormals(geometry.triNormals);
      triMesh.setVertexStream(SEMANTIC_BIRTH, geometry.triBirths, 1);
      triMesh.update(pc.PRIMITIVE_TRIANGLES);

      const triMaterial = new pc.ShaderMaterial({
        uniqueName: 'TdaNerve3DTriangles',
        attributes: {
          aPosition: pc.SEMANTIC_POSITION,
          aNormal: pc.SEMANTIC_NORMAL,
          aBirth: SEMANTIC_BIRTH,
        },
        vertexGLSL: TRIANGLE_VS,
        fragmentGLSL: TRIANGLE_FS,
        vertexWGSL: TRIANGLE_VS_WGSL,
        fragmentWGSL: TRIANGLE_FS_WGSL,
      });
      triMaterial.blendType = pc.BLEND_NORMAL;
      triMaterial.cull = pc.CULLFACE_NONE; // Double sided
      triMaterial.depthWrite = false;
      triMaterial.update();

      const triInstance = new pc.MeshInstance(triMesh, triMaterial);
      // The aabb covers the whole complex while the shader may be showing a
      // fraction of it. That bound is never too small, but the engine has no
      // way to know the shader only removes geometry, so skip culling here.
      triInstance.cull = false;

      const triEntity = new pc.Entity('NerveTriangles', app);
      triEntity.addComponent('render', { meshInstances: [triInstance] });
      parent.addChild(triEntity);

      built.triEntity = triEntity;
      built.triMaterial = triMaterial;
      disposables.push(triMesh, triMaterial);
    }

    if (geometry.edgeVerts.length > 0) {
      const edgeMesh = new pc.Mesh(app.graphicsDevice);
      edgeMesh.setPositions(geometry.edgeVerts);
      edgeMesh.setVertexStream(SEMANTIC_BIRTH, geometry.edgeBirths, 1);
      edgeMesh.update(pc.PRIMITIVE_LINES);

      const edgeMaterial = new pc.ShaderMaterial({
        uniqueName: 'TdaNerve3DEdges',
        attributes: {
          aPosition: pc.SEMANTIC_POSITION,
          aBirth: SEMANTIC_BIRTH,
        },
        vertexGLSL: EDGE_VS,
        fragmentGLSL: EDGE_FS,
        vertexWGSL: EDGE_VS_WGSL,
        fragmentWGSL: EDGE_FS_WGSL,
      });
      edgeMaterial.blendType = pc.BLEND_NORMAL;
      edgeMaterial.depthWrite = false;
      edgeMaterial.update();

      const edgeInstance = new pc.MeshInstance(edgeMesh, edgeMaterial);
      edgeInstance.cull = false;

      const edgeEntity = new pc.Entity('NerveEdges', app);
      edgeEntity.addComponent('render', { meshInstances: [edgeInstance] });
      parent.addChild(edgeEntity);

      built.edgeEntity = edgeEntity;
      built.edgeMaterial = edgeMaterial;
      disposables.push(edgeMesh, edgeMaterial);
    }

    if (geometry.vertexInstances.length > 0) {
      const count = geometry.vertexInstances.length / 4;
      const markerMesh = createBoxMesh(app.graphicsDevice);

      const vertexMaterial = new pc.ShaderMaterial({
        uniqueName: 'TdaNerve3DVertices',
        attributes: {
          aPosition: pc.SEMANTIC_POSITION,
          aNormal: pc.SEMANTIC_NORMAL,
          aInstanceVertex: SEMANTIC_INSTANCE_VERTEX,
        },
        vertexGLSL: VERTEX_VS,
        fragmentGLSL: TRIANGLE_FS,
        vertexWGSL: VERTEX_VS_WGSL,
        fragmentWGSL: TRIANGLE_FS_WGSL,
      });
      vertexMaterial.update();

      const vb = createInstanceStreamBuffer(
        app.graphicsDevice,
        geometry.vertexInstances,
        count,
        SEMANTIC_INSTANCE_VERTEX,
        4,
      );

      const markerInstance = new pc.MeshInstance(markerMesh, vertexMaterial);
      // Same reasoning as the other two: the CPU aabb is the unit cube at the
      // origin, and the real extent is produced in the vertex shader.
      markerInstance.setInstancing(vb);
      markerInstance.cull = false;

      const vertexEntity = new pc.Entity('NerveVertices', app);
      vertexEntity.addComponent('render', { meshInstances: [markerInstance] });
      parent.addChild(vertexEntity);

      built.vertexEntity = vertexEntity;
      built.vertexMaterial = vertexMaterial;
      disposables.push(vb, markerMesh, vertexMaterial);
    }

    setGpu(built);

    return () => {
      setGpu(null);
      destroyEntity(parent);
      for (const d of disposables) d.destroy();
    };
    // The marker layer is built whether or not it is shown, so toggling
    // `showVertices` only flips `enabled` — the same rule the edge and triangle
    // layers follow. It costs 16 bytes per vertex, strictly less than the edge
    // buffer already uploaded for the same complex.
  }, [app, rootEntity, geometry, cloud, vertexKind, vertexCount, isSubset]);

  // Scrubbing t: ONE uniform write per material, no geometry work (SPEC.md §1.5).
  useEffect(() => {
    if (!gpu) return;
    gpu.edgeMaterial?.setParameter('uT', t);
    gpu.triMaterial?.setParameter('uT', t);
    gpu.vertexMaterial?.setParameter('uT', t);
  }, [gpu, t]);

  useEffect(() => {
    if (!gpu) return;
    const edge = parseColor(edgeColor);
    gpu.edgeMaterial?.setParameter('uColor', [edge.r, edge.g, edge.b]);
    gpu.edgeMaterial?.setParameter('uOpacity', EDGE_OPACITY);

    const tri = parseColor(triangleColor);
    gpu.triMaterial?.setParameter('uColor', [tri.r, tri.g, tri.b]);
    gpu.triMaterial?.setParameter('uOpacity', triangleOpacity);

    const vert = parseColor(vertexColor);
    gpu.vertexMaterial?.setParameter('uColor', [vert.r, vert.g, vert.b]);
    // Markers are opaque: a vertex is a definite object, not a cloud.
    gpu.vertexMaterial?.setParameter('uOpacity', 1);
  }, [gpu, edgeColor, triangleColor, triangleOpacity, vertexColor]);

  useEffect(() => {
    if (!gpu) return;
    gpu.vertexMaterial?.setParameter('uSize', vertexSize);
  }, [gpu, vertexSize]);

  // Toggling a layer hides it; it never rebuilds it.
  useEffect(() => {
    if (!gpu) return;
    if (gpu.edgeEntity) gpu.edgeEntity.enabled = showEdges;
    if (gpu.triEntity) gpu.triEntity.enabled = showTriangles;
    if (gpu.vertexEntity) gpu.vertexEntity.enabled = drawVertices;
  }, [gpu, showEdges, showTriangles, drawVertices]);

  return null;
}
