/**
 * <Nerve3D>: the complex, uploaded once and clipped in the vertex shader.
 *
 * Mounted for real into a null-device `pc.Application` (see ./harness). The
 * whole point of the GPU-driven design is that geometry does NOT depend on t,
 * so these tests upload at one t and assert the full complex is present.
 *
 * Fixtures are recorded GUDHI output (SPEC.md §1.6) — no simplex here was
 * written by hand.
 */
import { describe, expect, it } from 'vitest';
import * as pc from 'playcanvas';
import {
  EDGE_VERTEX_GLSL,
  EDGE_VERTEX_WGSL,
  Nerve3D,
  TRIANGLE_VERTEX_GLSL,
  TRIANGLE_VERTEX_WGSL,
  VERTEX_VERTEX_GLSL,
  VERTEX_VERTEX_WGSL,
  computeTriangleNormals,
} from '../Nerve3D';
import {
  CIRCLE24_ALPHA,
  JITTERED8_KFOLD2,
  TETRA4_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import {
  entity,
  findEntity,
  instancingFloats,
  meshInstance,
  numberParam,
  renderStage,
  vertexStream,
} from './harness';

const tetra = recordedFiltration(TETRA4_ALPHA); // 4 pts, 6 edges, 4 triangles, 1 tetrahedron
const circle = recordedFiltration(CIRCLE24_ALPHA); // 24 pts, a much bigger 2D complex
const kfold = recordedFiltration(JITTERED8_KFOLD2); // 8 points, 22 SUBSET vertices

const EDGES = 'NerveEdges';
const TRIS = 'NerveTriangles';
const VERTS = 'NerveVertices';

const edgesOf = (f: typeof tetra) => f.simplices.filter((s) => s.vertices.length === 2);
const trianglesOf = (f: typeof tetra) => f.simplices.filter((s) => s.vertices.length === 3);

describe('computeTriangleNormals (pure helper, no engine)', () => {
  it('gives every vertex of a triangle the face normal', () => {
    const normals = computeTriangleNormals([0, 0, 0, 1, 0, 0, 0, 1, 0]);
    expect(normals).toHaveLength(9);
    expect(normals[2]).toBeCloseTo(1, 6);
    expect(normals[5]).toBeCloseTo(1, 6);
    expect(normals[8]).toBeCloseTo(1, 6);
  });

  it('returns an empty array for no triangles', () => {
    expect(computeTriangleNormals([])).toEqual([]);
  });
});

describe('<Nerve3D> uploads the WHOLE complex, not simplicesAt(t)', () => {
  it.each([
    ['TETRA4_ALPHA', tetra],
    ['CIRCLE24_ALPHA', circle],
  ] as const)('%s: edge mesh holds 2 vertices per 1-simplex', (_name, filtration) => {
    // t=-1 is below every birth in both fixtures: at this t nothing is visible,
    // yet every edge must still be resident on the GPU.
    const stage = renderStage(<Nerve3D filtration={filtration} t={-1} />);
    const mesh = meshInstance(stage.root, EDGES).mesh;

    const edges = edgesOf(filtration);
    expect(edges.length).toBeGreaterThan(0);
    expect(mesh.vertexBuffer.numVertices).toBe(2 * edges.length);
    expect(mesh.primitive[0]!.type).toBe(pc.PRIMITIVE_LINES);
    expect(mesh.primitive[0]!.count).toBe(2 * edges.length);
  });

  it.each([
    ['TETRA4_ALPHA', tetra],
    ['CIRCLE24_ALPHA', circle],
  ] as const)('%s: triangle mesh holds 3 vertices per 2-simplex', (_name, filtration) => {
    const stage = renderStage(<Nerve3D filtration={filtration} t={-1} />);
    const mesh = meshInstance(stage.root, TRIS).mesh;

    const tris = trianglesOf(filtration);
    expect(tris.length).toBeGreaterThan(0);
    expect(mesh.vertexBuffer.numVertices).toBe(3 * tris.length);
    expect(mesh.primitive[0]!.type).toBe(pc.PRIMITIVE_TRIANGLES);
  });

  it('pins the tetrahedron fixture to its real counts: 6 edges, 4 triangles', () => {
    expect(edgesOf(tetra)).toHaveLength(6);
    expect(trianglesOf(tetra)).toHaveLength(4);

    const stage = renderStage(<Nerve3D filtration={tetra} t={99} />);
    expect(meshInstance(stage.root, EDGES).mesh.vertexBuffer.numVertices).toBe(12);
    expect(meshInstance(stage.root, TRIS).mesh.vertexBuffer.numVertices).toBe(12);
  });

  it('places every uploaded vertex at a real point of the cloud', () => {
    const stage = renderStage(<Nerve3D filtration={tetra} t={99} />);
    const positions = vertexStream(meshInstance(stage.root, EDGES).mesh, pc.SEMANTIC_POSITION, 3);

    const edges = edgesOf(tetra);
    for (let i = 0; i < edges.length; i++) {
      const [a, b] = edges[i]!.vertices as [number, number];
      for (const [slot, v] of [
        [0, a],
        [1, b],
      ] as const) {
        const base = (i * 2 + slot) * 3;
        expect(positions[base]).toBeCloseTo(tetra.cloud.points[v * 3]!, 6);
        expect(positions[base + 1]).toBeCloseTo(tetra.cloud.points[v * 3 + 1]!, 6);
        expect(positions[base + 2]).toBeCloseTo(tetra.cloud.points[v * 3 + 2]!, 6);
      }
    }
  });

  it('uploads the face normals computeTriangleNormals produced', () => {
    const stage = renderStage(<Nerve3D filtration={tetra} t={99} />);
    const mesh = meshInstance(stage.root, TRIS).mesh;
    const normals = vertexStream(mesh, pc.SEMANTIC_NORMAL, 3);
    const positions = vertexStream(mesh, pc.SEMANTIC_POSITION, 3);
    const expected = computeTriangleNormals(Array.from(positions));

    expect(normals).toHaveLength(expected.length);
    for (let i = 0; i < expected.length; i++) {
      expect(normals[i]).toBeCloseTo(expected[i]!, 5);
    }
  });
});

describe('<Nerve3D> aBirth stream (what the shader clips against)', () => {
  it.each([
    ['edges', EDGES, 2, edgesOf],
    ['triangles', TRIS, 3, trianglesOf],
  ] as const)(
    '%s: each vertex carries its own simplex birth value, in order',
    (_name, entityName, perSimplex, select) => {
      const stage = renderStage(<Nerve3D filtration={circle} t={0.5} />);
      const births = vertexStream(meshInstance(stage.root, entityName).mesh, pc.SEMANTIC_ATTR8);

      const simplices = select(circle);
      expect(births).toHaveLength(perSimplex * simplices.length);
      for (let i = 0; i < simplices.length; i++) {
        for (let k = 0; k < perSimplex; k++) {
          // Every vertex of a simplex shares one birth value, so `aBirth > uT`
          // clips a primitive wholly or not at all — never a torn triangle.
          expect(births[i * perSimplex + k]).toBeCloseTo(simplices[i]!.filtration, 5);
        }
      }
    },
  );

  it.each([
    ['edges', EDGES],
    ['triangles', TRIS],
  ] as const)('%s: the uploaded births are non-decreasing (SPEC.md §1.1)', (_name, entityName) => {
    // MONOTONICITY, CPU side. The shader's only test is `aBirth > uT`, which is
    // monotone in uT: raising t can flip a vertex from clipped to drawn but
    // never the reverse. Combined with the array below being sorted ascending —
    // Filtration.simplices is sorted, and the builder walks it in order — the
    // picture can only ever GAIN simplices as t grows. That is the whole of
    // SPEC.md §1.1 for this component, and both halves are checked here.
    const stage = renderStage(<Nerve3D filtration={circle} t={0.5} />);
    const births = vertexStream(meshInstance(stage.root, entityName).mesh, pc.SEMANTIC_ATTR8);

    expect(births.length).toBeGreaterThan(0);
    for (let i = 1; i < births.length; i++) {
      expect(births[i]!).toBeGreaterThanOrEqual(births[i - 1]!);
    }
  });
});

describe('<Nerve3D> honesty: tetrahedra are never filled (SPEC.md §4.1)', () => {
  it('ignores 4-vertex simplices entirely', () => {
    const tetrahedra = tetra.simplices.filter((s) => s.vertices.length === 4);
    expect(tetrahedra).toHaveLength(1); // it IS in the mathematical complex...

    const stage = renderStage(<Nerve3D filtration={tetra} t={99} />);
    const parent = entity(stage.root, 'Nerve3D');

    // ...and it contributes no geometry: only the edge, triangle and vertex
    // layers exist, and the triangle mesh holds exactly the 4 two-faces. A
    // filled 3-simplex would hide the very cavity an H₂ class describes.
    expect(parent.children.map((c) => c.name).sort()).toEqual([EDGES, VERTS, TRIS].sort());
    expect(meshInstance(stage.root, TRIS).mesh.vertexBuffer.numVertices).toBe(
      3 * trianglesOf(tetra).length,
    );
  });
});

describe('<Nerve3D> subset vertices (SPEC.md §3.1: two index spaces)', () => {
  const subsets = JITTERED8_KFOLD2.vertexSubsets!;

  it('builds the complex from vertexPositions, not from cloud.points', () => {
    const stage = renderStage(<Nerve3D filtration={kfold} t={99} />);
    const positions = vertexStream(meshInstance(stage.root, EDGES).mesh, pc.SEMANTIC_POSITION, 3);

    // Reading cloud.points would place every simplex on one of 8 points; the
    // mosaic has 22 vertices, each at a subset's barycentre.
    expect(kfold.vertexCount).toBe(subsets.length);
    expect(kfold.vertexCount).toBeGreaterThan(8);

    const edges = edgesOf(kfold);
    for (let i = 0; i < edges.length; i++) {
      const [a, b] = edges[i]!.vertices as [number, number];
      for (const [slot, v] of [
        [0, a],
        [1, b],
      ] as const) {
        const base = (i * 2 + slot) * 3;
        const expected = kfold.vertexPosition(v);
        expect(positions[base]).toBeCloseTo(expected[0], 5);
        expect(positions[base + 1]).toBeCloseTo(expected[1], 5);
        expect(positions[base + 2]).toBeCloseTo(expected[2], 5);
      }
    }
  });

  it('draws each mosaic vertex as a marker at its subset\u2019s barycentre', () => {
    const stage = renderStage(<Nerve3D filtration={kfold} t={99} />);
    const mi = meshInstance(stage.root, VERTS);
    const data = instancingFloats(mi);
    const zeroSimplices = kfold.simplices.filter((s) => s.vertices.length === 1);

    expect(data).toHaveLength(4 * zeroSimplices.length);
    zeroSimplices.forEach((s, i) => {
      const v = s.vertices[0]!;
      const members = subsets[v];
      let bx = 0;
      let by = 0;
      let bz = 0;
      for (const p of members) {
        bx += kfold.cloud.points[p * 3];
        by += kfold.cloud.points[p * 3 + 1];
        bz += kfold.cloud.points[p * 3 + 2];
      }
      expect(data[i * 4]).toBeCloseTo(bx / members.length, 5);
      expect(data[i * 4 + 1]).toBeCloseTo(by / members.length, 5);
      expect(data[i * 4 + 2]).toBeCloseTo(bz / members.length, 5);
      // w is the vertex's OWN birth, so a marker appears exactly when its
      // vertex enters the filtration — never earlier.
      expect(data[i * 4 + 3]).toBeCloseTo(s.filtration, 5);
    });
  });

  it('states in the scene what its vertices are (there is no DOM here)', () => {
    const stage = renderStage(<Nerve3D filtration={kfold} t={1} />);
    const userData = (
      entity(stage.root, 'Nerve3D') as unknown as { userData: Record<string, unknown> }
    ).userData;
    expect(userData.vertexKind).toBe('subset');
    expect(userData.vertexCount).toBe(kfold.vertexCount);
    expect(userData.pointCount).toBe(8);
    expect(String(userData.vertices)).toMatch(/SUBSET of the input, drawn at its barycentre/);
  });

  it('shows markers by default for subsets and hides them for points', () => {
    const subsetStage = renderStage(<Nerve3D filtration={kfold} t={1} />);
    expect(entity(subsetStage.root, VERTS).enabled).toBe(true);

    const pointStage = renderStage(<Nerve3D filtration={tetra} t={1} />);
    expect(entity(pointStage.root, VERTS).enabled).toBe(false);
    // A caller can still ask for point markers, and it is a toggle, not a rebuild.
    const mi = meshInstance(pointStage.root, VERTS);
    pointStage.rerender(<Nerve3D filtration={tetra} t={1} showVertices />);
    expect(entity(pointStage.root, VERTS).enabled).toBe(true);
    expect(meshInstance(pointStage.root, VERTS)).toBe(mi);
  });

  it('sizes markers by a uniform, so resizing rebuilds nothing', () => {
    const stage = renderStage(<Nerve3D filtration={kfold} t={1} vertexSize={0.04} />);
    const mi = meshInstance(stage.root, VERTS);
    expect(numberParam(mi.material, 'uSize')).toBeCloseTo(0.04, 6);
    stage.rerender(<Nerve3D filtration={kfold} t={1} vertexSize={0.08} />);
    expect(meshInstance(stage.root, VERTS)).toBe(mi);
    expect(numberParam(mi.material, 'uSize')).toBeCloseTo(0.08, 6);
  });
});

describe('<Nerve3D> scrubbing t rebuilds nothing (SPEC.md §1.5)', () => {
  it('keeps the same entities, meshes and vertex buffers, and only moves uT', () => {
    const stage = renderStage(<Nerve3D filtration={tetra} t={0.3} />);

    const edgeEntity = entity(stage.root, EDGES);
    const edgeMi = meshInstance(stage.root, EDGES);
    const edgeMesh = edgeMi.mesh;
    const edgeVb = edgeMesh.vertexBuffer;
    const triMi = meshInstance(stage.root, TRIS);
    const triMesh = triMi.mesh;
    const birthsBefore = Array.from(vertexStream(edgeMesh, pc.SEMANTIC_ATTR8));

    expect(numberParam(edgeMi.material, 'uT')).toBeCloseTo(0.3, 6);
    expect(numberParam(triMi.material, 'uT')).toBeCloseTo(0.3, 6);
    expect((edgeMi.material as pc.ShaderMaterial).shaderDesc?.vertexWGSL).toBe(EDGE_VERTEX_WGSL);
    expect((triMi.material as pc.ShaderMaterial).shaderDesc?.vertexWGSL).toBe(TRIANGLE_VERTEX_WGSL);

    stage.rerender(<Nerve3D filtration={tetra} t={0.8} />);

    expect(entity(stage.root, EDGES)).toBe(edgeEntity);
    expect(meshInstance(stage.root, EDGES)).toBe(edgeMi);
    expect(meshInstance(stage.root, EDGES).mesh).toBe(edgeMesh);
    expect(meshInstance(stage.root, EDGES).mesh.vertexBuffer).toBe(edgeVb);
    expect(meshInstance(stage.root, TRIS).mesh).toBe(triMesh);
    expect(Array.from(vertexStream(edgeMesh, pc.SEMANTIC_ATTR8))).toEqual(birthsBefore);

    expect(numberParam(edgeMi.material, 'uT')).toBeCloseTo(0.8, 6);
    expect(numberParam(triMi.material, 'uT')).toBeCloseTo(0.8, 6);
  });
});

describe('<Nerve3D> layer toggles hide, they do not rebuild', () => {
  it('showEdges=false only flips the edge entity enabled flag', () => {
    const stage = renderStage(<Nerve3D filtration={tetra} t={0.8} showEdges showTriangles />);

    const edgeEntity = entity(stage.root, EDGES);
    const edgeMesh = meshInstance(stage.root, EDGES).mesh;
    const edgeVb = edgeMesh.vertexBuffer;
    const triEntity = entity(stage.root, TRIS);
    expect(edgeEntity.enabled).toBe(true);

    stage.rerender(<Nerve3D filtration={tetra} t={0.8} showEdges={false} showTriangles />);

    expect(entity(stage.root, EDGES)).toBe(edgeEntity);
    expect(edgeEntity.enabled).toBe(false);
    expect(meshInstance(stage.root, EDGES).mesh).toBe(edgeMesh);
    expect(meshInstance(stage.root, EDGES).mesh.vertexBuffer).toBe(edgeVb);
    expect(edgeMesh.vertexBuffer.numVertices).toBe(2 * edgesOf(tetra).length);
    expect(triEntity.enabled).toBe(true);

    stage.rerender(<Nerve3D filtration={tetra} t={0.8} showEdges showTriangles={false} />);

    expect(edgeEntity.enabled).toBe(true);
    expect(triEntity.enabled).toBe(false);
    expect(entity(stage.root, TRIS)).toBe(triEntity);
  });

  it('tears the whole nerve down when it unmounts', () => {
    const stage = renderStage(<Nerve3D filtration={tetra} t={0.8} />);
    expect(findEntity(stage.root, 'Nerve3D')).not.toBeNull();

    stage.rerender(null);

    expect(findEntity(stage.root, 'Nerve3D')).toBeNull();
    expect(findEntity(stage.root, EDGES)).toBeNull();
    expect(findEntity(stage.root, TRIS)).toBeNull();
  });
});

describe('vertex shader source (GLSL/WGSL the null device never compiles)', () => {
  // The aBirth tests above pin the data; this pins the comparison that data
  // is fed into. `aBirth > uT` clips — the exact complement of simplicesAt's
  // `filtration <= t` — and a flipped or off-by-strictness comparison would
  // make simplices vanish as t grows (SPEC.md §1.1) or disagree with the 2D
  // views, invisibly to every null-device test.
  it('clips with strict aBirth > uT in both shaders', () => {
    for (const src of [EDGE_VERTEX_GLSL, TRIANGLE_VERTEX_GLSL]) {
      const flat = src.replace(/\s+/g, ' ');
      expect(flat).toContain('if (aBirth > uT)');
      expect(flat).not.toContain('aBirth < uT');
      expect(flat).not.toContain('aBirth >= uT');
    }
  });

  it('clips with the same strict aBirth > uT comparison in WGSL', () => {
    for (const src of [EDGE_VERTEX_WGSL, TRIANGLE_VERTEX_WGSL]) {
      const flat = src.replace(/\s+/g, ' ');
      expect(flat).toContain('if (input.aBirth > uniform.uT)');
      expect(flat).not.toContain('aBirth < uniform.uT');
      expect(flat).not.toContain('aBirth >= uniform.uT');
    }
  });

  it('clips a vertex marker by its own birth, with the same strict comparison', () => {
    expect(VERTEX_VERTEX_GLSL.replace(/\s+/g, ' ')).toContain('if (aInstanceVertex.w > uT)');
    expect(VERTEX_VERTEX_WGSL.replace(/\s+/g, ' ')).toContain(
      'if (input.aInstanceVertex.w > uniform.uT)',
    );
    // The marker's size is a uniform, not baked into the instance data, so
    // resizing it cannot become a geometry rebuild.
    expect(VERTEX_VERTEX_GLSL).toContain('aPosition * uSize');
    expect(VERTEX_VERTEX_WGSL).toContain('input.aPosition * uniform.uSize');
  });

  it('sends unborn simplices off the clip volume, identically in both languages', () => {
    // x, y and z all exceed w=1, so every vertex of the primitive is outside
    // the frustum on several planes and the primitive is discarded before
    // rasterization — not a degenerate triangle, which can still light up
    // edge pixels on some drivers.
    for (const src of [EDGE_VERTEX_GLSL, TRIANGLE_VERTEX_GLSL]) {
      expect(src.replace(/\s+/g, ' ')).toContain('gl_Position = vec4(2.0, 2.0, 2.0, 1.0);');
    }
    for (const src of [EDGE_VERTEX_WGSL, TRIANGLE_VERTEX_WGSL]) {
      expect(src.replace(/\s+/g, ' ')).toContain('output.position = vec4f(2.0, 2.0, 2.0, 1.0);');
    }
  });
});
