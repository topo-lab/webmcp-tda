/**
 * <Field3D>: the union of balls at scale t, as GPU-driven instanced spheres.
 *
 * Mounted for real into a null-device `pc.Application` (see ./harness). The
 * radius itself is computed in the vertex shader, so what is CPU-checkable —
 * and what these tests check — is the contract the shader runs on: the
 * per-instance stream (centre + weight, uploaded once) and the uniforms
 * (`uT`, `uConvention`, `uColor`, `uOpacity`).
 */
import { describe, expect, it } from 'vitest';
import * as pc from 'playcanvas';
import {
  APPROXIMATION_LABEL,
  APPROXIMATION_LABELS,
  BOX_VERTEX_GLSL,
  BOX_VERTEX_WGSL,
  ELLIPSOID_VERTEX_GLSL,
  ELLIPSOID_VERTEX_WGSL,
  FIELD_VERTEX_GLSL,
  FIELD_VERTEX_WGSL,
  Field3D,
  type Field3DFiltration,
} from '../Field3D';
import { SHADE_GLSL, SHADE_WGSL } from '../utils';
import {
  CIRCLE12_WING,
  CUBE8_BOX_3D,
  JITTERED8_KFOLD2,
  RING6_BOX,
  SPIRAL16_ELLIPSOID_RIPS_3D,
  TETRA4_ALPHA,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import {
  entity,
  findEntity,
  instancingBuffer,
  instancingFloats,
  meshInstance,
  numberParam,
  renderStage,
  shaderParam,
} from './harness';

const weighted = recordedFiltration(WEIGHTED3_ALPHA); // alpha, 2D, weights [0.5, 0, 0]
const tetra = recordedFiltration(TETRA4_ALPHA); // alpha, 3D, 4 points
const rips = recordedFiltration(TRIANGLE_RIPS);
const cech = recordedFiltration(TRIANGLE_CECH);
const ellipsoid3d = recordedFiltration(SPIRAL16_ELLIPSOID_RIPS_3D);
const box3d = recordedFiltration(CUBE8_BOX_3D);
const kfold = recordedFiltration(JITTERED8_KFOLD2);

const FIELD = 'Field3DInstanced';

describe('<Field3D> per-instance stream (uploaded once, never re-uploaded)', () => {
  it('holds every ball centre and its weight, one vec4 per point', () => {
    const stage = renderStage(<Field3D filtration={weighted} t={0.3} />);
    const mi = meshInstance(stage.root, FIELD);

    const count = weighted.cloud.weights.length;
    expect(count).toBe(3);
    expect(mi.instancingCount).toBe(count);
    expect(instancingBuffer(mi).numVertices).toBe(count);

    const format = instancingBuffer(mi).format;
    expect(format.elements.map((e) => e.name)).toEqual([pc.SEMANTIC_ATTR12]);
    expect(format.elements[0]!.numComponents).toBe(4);

    // xyz = centre (a 2D cloud embedded at z=0), w = the point's weight.
    expect(Array.from(instancingFloats(mi))).toEqual([
      0, 0, 0, 0.5, 2, 0, 0, 0, 1, 1.600000023841858, 0, 0,
    ]);
  });

  it('carries the true z of a 3D cloud', () => {
    const stage = renderStage(<Field3D filtration={tetra} t={0.5} />);
    const data = instancingFloats(meshInstance(stage.root, FIELD));

    expect(meshInstance(stage.root, FIELD).instancingCount).toBe(4);
    for (let i = 0; i < 4; i++) {
      expect(data[i * 4]).toBeCloseTo(tetra.cloud.points[i * 3]!, 6);
      expect(data[i * 4 + 1]).toBeCloseTo(tetra.cloud.points[i * 3 + 1]!, 6);
      expect(data[i * 4 + 2]).toBeCloseTo(tetra.cloud.points[i * 3 + 2]!, 6);
      expect(data[i * 4 + 3]).toBe(0); // unweighted
    }
  });

  it('draws nothing at all for an empty cloud', () => {
    const empty = recordedFiltration({
      ...WEIGHTED3_ALPHA,
      cloud: { points: [], weights: [], dimension: 2 },
      simplices: [],
      rawPairs: [],
    });
    const stage = renderStage(<Field3D filtration={empty} t={1} />);
    expect(findEntity(stage.root, 'Field3D')).toBeNull();
  });
});

describe('<Field3D> shader uniforms match the props', () => {
  it('publishes t, colour and opacity as material parameters', () => {
    const stage = renderStage(
      <Field3D filtration={weighted} t={0.42} color="#2563eb" opacity={0.37} />,
    );
    const material = meshInstance(stage.root, FIELD).material;

    expect(material).toBeInstanceOf(pc.ShaderMaterial);
    expect(numberParam(material, 'uT')).toBeCloseTo(0.42, 6);
    expect(numberParam(material, 'uOpacity')).toBeCloseTo(0.37, 6);
    expect(shaderParam(material, 'uColor')).toEqual([0x25 / 255, 0x63 / 255, 0xeb / 255]);
    expect((material as pc.ShaderMaterial).shaderDesc?.vertexWGSL).toBe(FIELD_VERTEX_WGSL);
    expect((material as pc.ShaderMaterial).shaderDesc?.fragmentWGSL).toBeTruthy();
  });

  it.each([
    ['rips', rips, 0],
    ['cech', cech, 1],
    ['alpha', weighted, 2],
  ] as const)('encodes the %s convention as uConvention=%s', (name, filtration, code) => {
    // The convention comes from the recorded filtration, not from a prop: the
    // shader's radiusFromT branches on it, so a mismatch would draw balls that
    // disagree with the homology beside them (SPEC.md §1.3).
    expect(filtration.convention).toBe(name);
    const stage = renderStage(<Field3D filtration={filtration} t={0.1} />);
    expect(numberParam(meshInstance(stage.root, FIELD).material, 'uConvention')).toBe(code);
  });
});

describe('<Field3D> honesty label (SPEC.md §8 Q2)', () => {
  it('declares on the entity itself that this is an approximation of the union', () => {
    const stage = renderStage(<Field3D filtration={weighted} t={0.3} />);
    const userData = (
      entity(stage.root, 'Field3D') as unknown as { userData: Record<string, string> }
    ).userData;

    expect(userData.approximation).toBe(APPROXIMATION_LABEL);
    expect(APPROXIMATION_LABEL).toMatch(/instanced spheres.*double-count/i);
    expect(userData.convention).toBe('alpha');
  });
});

describe('<Field3D> ellipsoids (SPEC.md §1.3: (t/2)·profile on a FIXED frame)', () => {
  const geometry = SPIRAL16_ELLIPSOID_RIPS_3D.ellipsoid.geometry;

  it('uploads centre, UNIT profile and two frame rows per ellipsoid', () => {
    const stage = renderStage(<Field3D filtration={ellipsoid3d} t={1.2} />);
    const mi = meshInstance(stage.root, FIELD);
    const format = instancingBuffer(mi).format;

    expect(format.elements.map((e) => e.name)).toEqual([
      pc.SEMANTIC_ATTR12,
      pc.SEMANTIC_ATTR13,
      pc.SEMANTIC_ATTR14,
      pc.SEMANTIC_ATTR15,
    ]);
    expect(mi.instancingCount).toBe(geometry.length);

    const data = instancingFloats(mi);
    geometry.forEach((g, i) => {
      const base = i * 16;
      for (let a = 0; a < 3; a++) {
        expect(data[base + a]).toBeCloseTo(g.center[a], 5);
        // The UNIT profile, not the scaled semi-axes: the shader multiplies by
        // t/2, so t is a uniform and the stream never moves (SPEC.md §1.5).
        expect(data[base + 4 + a]).toBeCloseTo(g.semiAxes[a], 5);
        expect(data[base + 8 + a]).toBeCloseTo(g.frame[0][a], 5);
        expect(data[base + 12 + a]).toBeCloseTo(g.frame[1][a], 5);
      }
    });
  });

  it('takes the profile from the filtration\u2019s unitShape, not from a guess', () => {
    const stage = renderStage(<Field3D filtration={ellipsoid3d} t={1.2} />);
    const data = instancingFloats(meshInstance(stage.root, FIELD));
    for (let i = 0; i < geometry.length; i++) {
      const unit = ellipsoid3d.unitShape(i);
      // (t/2)·profile at t = 2 IS the profile, which is why `shapeAt(i, 2)` could
      // stand in for the accessor; the equivalence is pinned so the accessor
      // cannot drift away from the scale law it is the unscaled end of.
      const viaShapeAt = ellipsoid3d.shapeAt(i, 2);
      for (let a = 0; a < 3; a++) {
        expect(unit.semiAxes[a]).toBe(viaShapeAt.semiAxes[a]);
        expect(data[i * 16 + 4 + a]).toBeCloseTo(unit.semiAxes[a], 5);
        expect(data[i * 16 + a]).toBeCloseTo(unit.center[a], 5);
      }
    }
  });

  it('scales with uT alone, so scrubbing rebuilds nothing', () => {
    const stage = renderStage(<Field3D filtration={ellipsoid3d} t={0.6} />);
    const mi = meshInstance(stage.root, FIELD);
    const vb = instancingBuffer(mi);
    const before = Array.from(instancingFloats(mi));
    expect(numberParam(mi.material, 'uT')).toBeCloseTo(0.6, 6);

    stage.rerender(<Field3D filtration={ellipsoid3d} t={1.8} />);

    expect(meshInstance(stage.root, FIELD)).toBe(mi);
    expect(instancingBuffer(mi)).toBe(vb);
    expect(Array.from(instancingFloats(mi))).toEqual(before);
    expect(numberParam(mi.material, 'uT')).toBeCloseTo(1.8, 6);
  });

  it('labels itself an approximation of the union, per shape', () => {
    const stage = renderStage(<Field3D filtration={ellipsoid3d} t={1} />);
    const userData = (
      entity(stage.root, 'Field3D') as unknown as { userData: Record<string, string> }
    ).userData;
    expect(userData.shapeKind).toBe('ellipsoid');
    expect(userData.approximation).toBe(APPROXIMATION_LABELS.ellipsoid);
    expect(userData.approximation).toMatch(/double-count/);
  });
});

describe('<Field3D> boxes (SPEC.md §1.3: a lookup on the grid, one uniform)', () => {
  const { stepSize, numSteps } = CUBE8_BOX_3D.box;
  const extents = CUBE8_BOX_3D.box.extents!;
  const pointCount = CUBE8_BOX_3D.cloud.points.length / 3;

  it('uploads EVERY step\u2019s boxes, each tagged with its step', () => {
    const stage = renderStage(<Field3D filtration={box3d} t={stepSize} />);
    const mi = meshInstance(stage.root, FIELD);

    expect(instancingBuffer(mi).format.elements.map((e) => e.name)).toEqual([
      pc.SEMANTIC_ATTR12,
      pc.SEMANTIC_ATTR13,
    ]);
    expect(mi.instancingCount).toBe(pointCount * (numSteps + 1));

    const data = instancingFloats(mi);
    for (let s = 0; s <= numSteps; s++) {
      for (let i = 0; i < pointCount; i++) {
        const base = (s * pointCount + i) * 8;
        const b = extents[s][i];
        for (let a = 0; a < 3; a++) {
          // Centre and extent of the ENGINE's box, not a box this renderer grew.
          expect(data[base + a]).toBeCloseTo((b.lower[a] + b.upper[a]) / 2, 5);
          expect(data[base + 4 + a]).toBeCloseTo(b.upper[a] - b.lower[a], 5);
        }
        expect(data[base + 3]).toBe(s);
      }
    }
  });

  it('selects the step with uStep = floor(t / π), never an interpolation', () => {
    const stage = renderStage(<Field3D filtration={box3d} t={stepSize} />);
    const mi = meshInstance(stage.root, FIELD);
    expect(numberParam(mi.material, 'uStep')).toBe(1);

    // Between grid values the SAME step stays selected: an interpolated box is
    // a shape the filtration never contained (SPEC.md §1.1).
    stage.rerender(<Field3D filtration={box3d} t={stepSize * 1.9} />);
    expect(numberParam(mi.material, 'uStep')).toBe(1);

    stage.rerender(<Field3D filtration={box3d} t={stepSize * 2} />);
    expect(numberParam(mi.material, 'uStep')).toBe(2);
    // ...and still the same buffer: the step is a uniform, not a re-upload.
    expect(meshInstance(stage.root, FIELD)).toBe(mi);
  });

  it('clamps to the last step the engine actually grew', () => {
    const stage = renderStage(<Field3D filtration={box3d} t={stepSize * (numSteps + 50)} />);
    expect(numberParam(meshInstance(stage.root, FIELD).material, 'uStep')).toBe(numSteps);
  });

  it('draws a 2D box filtration flat, in the plane where the shape lives', () => {
    const ring = recordedFiltration(RING6_BOX);
    const stage = renderStage(<Field3D filtration={ring} t={0.5} />);
    const data = instancingFloats(meshInstance(stage.root, FIELD));
    // z centre and z extent are both 0: a rectangle at z = 0, not a slab of
    // invented depth.
    expect(data[2]).toBe(0);
    expect(data[6]).toBe(0);
  });
});

describe('<Field3D> refuses what it cannot draw honestly (SPEC.md §1.6)', () => {
  it('throws for a wing filtration, naming why 3D wings do not exist', () => {
    const wing = recordedFiltration(CIRCLE12_WING) as unknown as Field3DFiltration;
    expect(() => renderStage(<Field3D filtration={wing} t={0.5} />)).toThrow(
      /wing complex is 2D only/,
    );
  });

  it('draws no geometry, and says why, when the engine kept no boxes', () => {
    const noBoxes = recordedFiltration({
      ...CUBE8_BOX_3D,
      box: { ...CUBE8_BOX_3D.box, extents: null },
    });
    expect(noBoxes.shapesAvailable).toBe(false);

    const stage = renderStage(<Field3D filtration={noBoxes} t={1} />);
    const parent = entity(stage.root, 'Field3D');
    expect(findEntity(stage.root, FIELD)).toBeNull();
    const userData = (parent as unknown as { userData: Record<string, string> }).userData;
    expect(userData.shapesUnavailable).toBe(noBoxes.shapesUnavailableReason);
    expect(userData.shapesUnavailable).toMatch(/retainBoxes/);
  });

  it('draws the k-fold cover\u2019s balls at \u221At around the INPUT points', () => {
    // The mosaic's vertices are subsets, but the SHAPES are balls on the points
    // (SPEC.md §1.3): the alpha radius law with weight 0.
    const stage = renderStage(<Field3D filtration={kfold} t={0.4} />);
    const mi = meshInstance(stage.root, FIELD);
    expect(mi.instancingCount).toBe(8);
    expect(numberParam(mi.material, 'uConvention')).toBe(2); // alpha
    const data = instancingFloats(mi);
    for (let i = 0; i < 8; i++) {
      expect(data[i * 4]).toBeCloseTo(kfold.cloud.points[i * 3], 5);
      expect(data[i * 4 + 3]).toBe(0); // unweighted, so the shader gives √t
    }
    expect(kfold.radiusAt(0, 0.4)).toBeCloseTo(Math.sqrt(0.4), 12);
  });
});

describe('<Field3D> scrubbing t rebuilds nothing (SPEC.md §1.5)', () => {
  it('keeps the same entity, mesh instance and vertex buffer, and only moves uT', () => {
    const stage = renderStage(<Field3D filtration={weighted} t={0.1} />);

    const before = {
      parent: entity(stage.root, 'Field3D'),
      renderEntity: entity(stage.root, FIELD),
      mi: meshInstance(stage.root, FIELD),
      mesh: meshInstance(stage.root, FIELD).mesh,
      vb: instancingBuffer(meshInstance(stage.root, FIELD)),
    };
    const streamBefore = Array.from(instancingFloats(before.mi));
    expect(numberParam(before.mi.material, 'uT')).toBeCloseTo(0.1, 6);

    stage.rerender(<Field3D filtration={weighted} t={0.9} />);

    expect(entity(stage.root, 'Field3D')).toBe(before.parent);
    expect(entity(stage.root, FIELD)).toBe(before.renderEntity);
    expect(meshInstance(stage.root, FIELD)).toBe(before.mi);
    expect(instancingBuffer(meshInstance(stage.root, FIELD))).toBe(before.vb);
    expect(meshInstance(stage.root, FIELD).mesh).toBe(before.mesh);
    expect(Array.from(instancingFloats(before.mi))).toEqual(streamBefore);

    expect(numberParam(before.mi.material, 'uT')).toBeCloseTo(0.9, 6);
  });
});

describe('vertex shader source (GLSL/WGSL the null device never compiles)', () => {
  // NullGraphicsDevice never compiles shaders, so a one-character mistake in
  // the radius formula would ship a picture that disagrees with the homology
  // (SPEC.md §1.3) while every headless test stays green. Pin the load-bearing
  // lines at source level: reformatting them is a conscious act that updates
  // this test. The uConvention→0/1/2 mapping itself is pinned by the
  // per-fixture uniform tests above.
  const src = FIELD_VERTEX_GLSL.replace(/\s+/g, ' ');
  const wgsl = FIELD_VERTEX_WGSL.replace(/\s+/g, ' ');

  it('transcribes radiusAt exactly, in CONVENTION_CODE branch order', () => {
    expect(src).toContain('if (uConvention < 0.5) return max(t, 0.0) * 0.5;'); // rips = 0
    expect(src).toContain('if (uConvention < 1.5) return max(t, 0.0);'); // cech = 1
    expect(src).toContain('return sqrt(max(t + w, 0.0));'); // alpha = 2
  });

  it('clips unborn balls (r <= 0) instead of drawing degenerate spheres', () => {
    // Field2D skips r <= 0 for the same honesty reason; the 3D counterpart is
    // an off-frustum clip position, not a zero-scaled sphere.
    expect(src).toContain('if (r <= 0.0)');
    expect(src).toContain('gl_Position = vec4(2.0, 2.0, 2.0, 1.0);');
  });

  it('transcribes the same radiusAt formulas in WGSL', () => {
    expect(wgsl).toContain('if (uniform.uConvention < 0.5)');
    expect(wgsl).toContain('return max(t, 0.0) * 0.5;');
    expect(wgsl).toContain('if (uniform.uConvention < 1.5)');
    expect(wgsl).toContain('return max(t, 0.0);');
    expect(wgsl).toContain('return sqrt(max(t + w, 0.0));');
  });

  it('clips unborn balls in WGSL with the same off-frustum position', () => {
    expect(wgsl).toContain('if (r <= 0.0)');
    expect(wgsl).toContain('output.position = vec4f(2.0, 2.0, 2.0, 1.0);');
  });

  it('scales ellipsoids by (t/2)·profile along the fitted frame, in both languages', () => {
    // The same law as ellipsoidSemiAxesAt, and the same reason to pin it: the
    // null device compiles nothing, so a dropped 0.5 would ship ellipsoids twice
    // the size of the ones on the barcode.
    for (const src of [ELLIPSOID_VERTEX_GLSL, ELLIPSOID_VERTEX_WGSL]) {
      const flat = src.replace(/\s+/g, ' ');
      expect(flat).toContain('* 0.5;');
      expect(flat).toContain('cross(f0, f1)');
      expect(flat).toContain('aInstanceAxes.xyz * s');
    }
    expect(ELLIPSOID_VERTEX_GLSL).toContain('float s = max(uT, 0.0) * 0.5;');
    expect(ELLIPSOID_VERTEX_WGSL).toContain('let s = max(uniform.uT, 0.0) * 0.5;');
  });

  it('selects a box by step equality, never by an interpolation, in both languages', () => {
    for (const src of [BOX_VERTEX_GLSL, BOX_VERTEX_WGSL]) {
      const flat = src.replace(/\s+/g, ' ');
      // Step equality (within half a step) — the box drawn is one the engine
      // grew. No lerp, mix or fract anywhere near the extent.
      expect(flat).toMatch(/abs\((input\.)?aInstanceBox\.w - (uniform\.)?uStep\) > 0\.5/);
      expect(flat).not.toMatch(/\bmix\(/);
      expect(flat).not.toMatch(/\bfract\(/);
    }
  });
});

describe('shared fragment prelude (SHADE_GLSL / SHADE_WGSL parity)', () => {
  // The fragment side is just as invisible to the null device as the vertex
  // side: a flipped front-facing test or a dropped gamma decode would invert
  // or brighten WebGPU-only shading while every headless test stays green.
  const glsl = SHADE_GLSL.replace(/\s+/g, ' ');
  const wgsl = SHADE_WGSL.replace(/\s+/g, ' ');

  it('flips the normal for back faces in both languages', () => {
    expect(glsl).toContain('if (!gl_FrontFacing) n = -n;');
    expect(wgsl).toContain('if (!pcFrontFacing) { n = -n; }');
  });

  it('decodes the sRGB colour through the engine gamma chunk in both languages', () => {
    expect(glsl).toContain('#include "gammaPS"');
    expect(wgsl).toContain('#include "gammaPS"');
    expect(glsl).toContain('decodeGamma(srgbColor)');
    // WGSL has no overloading: decodeGamma3 is the vec3 overload.
    expect(wgsl).toContain('decodeGamma3(srgbColor)');
  });

  it('uses the same three-term lighting rig in both languages', () => {
    for (const src of [glsl, wgsl]) {
      expect(src).toContain('0.85 * max(dot(n, keyDir), 0.0)');
      expect(src).toContain('0.22 * max(dot(n, fillDir), 0.0)');
    }
  });
});
