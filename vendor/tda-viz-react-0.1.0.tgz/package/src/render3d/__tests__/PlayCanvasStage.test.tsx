/**
 * <PlayCanvasStage>: the container every 3D component mounts into.
 *
 * Real engine, real scene graph, `pc.NullGraphicsDevice` (see ./harness).
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import * as pc from 'playcanvas';
import {
  PlayCanvasStage,
  usePlayCanvas,
  DEFAULT_DEVICE_TYPES,
  type PlayCanvasContextValue,
} from '../PlayCanvasStage';
import { entity, nullDevice, renderStage } from './harness';

/** Records the context value on every render it is given. */
function ContextProbe({ onRender }: { onRender: (v: PlayCanvasContextValue) => void }) {
  onRender(usePlayCanvas());
  return <div data-testid="probe" />;
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('<PlayCanvasStage> mounts children only once the engine exists', () => {
  it('renders children exactly once, always with a live app / camera / rootEntity', () => {
    const seen: PlayCanvasContextValue[] = [];
    const stage = renderStage(<ContextProbe onRender={(v) => seen.push(v)} />);

    expect(screen.getByTestId('probe')).toBeInTheDocument();
    expect(seen).toHaveLength(1);
    // The invariant: a child is NEVER rendered against the null context.
    for (const ctx of seen) {
      expect(ctx.app).toBe(stage.app);
      expect(ctx.camera).toBe(stage.camera);
      expect(ctx.rootEntity).toBe(stage.root);
      expect(ctx.deviceType).toBe(pc.DEVICETYPE_NULL);
    }
  });

  it('renders no children at all when the engine fails to come up', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const seen: PlayCanvasContextValue[] = [];

    render(
      <PlayCanvasStage
        createGraphicsDevice={() => {
          throw new Error('no graphics device in this environment');
        }}
      >
        <ContextProbe onRender={(v) => seen.push(v)} />
      </PlayCanvasStage>,
    );

    expect(seen).toHaveLength(0);
    expect(screen.queryByTestId('probe')).toBeNull();
    expect(warn).toHaveBeenCalled();
  });

  it('the seam path is synchronous: children mount after the first effect flush', () => {
    // render() flushes passive effects. If the seam awaited createGraphicsDevice
    // the way the default path does, `seen` would still be empty here and
    // every jsdom 3D test would have to waitFor the engine.
    const seen: PlayCanvasContextValue[] = [];
    render(
      <PlayCanvasStage createGraphicsDevice={nullDevice}>
        <ContextProbe onRender={(v) => seen.push(v)} />
      </PlayCanvasStage>,
    );

    expect(seen).toHaveLength(1);
    expect(seen[0]!.app).toBeInstanceOf(pc.AppBase);
    expect(seen[0]!.deviceType).toBe(pc.DEVICETYPE_NULL);
    expect(screen.getByTestId('probe')).toBeInTheDocument();
  });
});

describe('<PlayCanvasStage> scene graph', () => {
  it('exposes the real engine objects through context', () => {
    const stage = renderStage(null);

    expect(stage.app).toBeInstanceOf(pc.AppBase);
    expect(stage.app.graphicsDevice).toBeInstanceOf(pc.NullGraphicsDevice);

    expect(stage.camera.name).toBe('MainCamera');
    expect(stage.camera.camera).toBeTruthy();
    expect(stage.camera.parent).toBe(stage.app.root);

    expect(stage.root.name).toBe('TdaRootNode');
    expect(stage.root.parent).toBe(stage.app.root);
    expect(stage.root.children).toHaveLength(0);
  });

  it('builds the key light and the fill light described in the component', () => {
    const stage = renderStage(null);

    const key = entity(stage.app.root, 'DirectionalLight');
    const fill = entity(stage.app.root, 'FillLight');
    expect(key.light?.type).toBe('directional');
    expect(fill.light?.type).toBe('directional');
    expect(key.light?.intensity).toBeCloseTo(1.2, 5);
    expect(fill.light?.intensity).toBeCloseTo(0.5, 5);
  });
});

describe('<PlayCanvasStage> lifecycle', () => {
  it('destroys the application on unmount', () => {
    const stage = renderStage(null);
    const destroy = vi.spyOn(stage.app, 'destroy');

    expect(destroy).not.toHaveBeenCalled();
    stage.unmount();
    expect(destroy).toHaveBeenCalledTimes(1);
  });

  it('does NOT rebuild the engine when re-rendered with a new inline onAppReady', () => {
    // The regression this guards: an inline arrow prop is a new function on
    // every render of the consumer, so if onAppReady were an effect dependency
    // the whole engine would be torn down and rebuilt every frame.
    const ready = vi.fn();
    const tree = (cb: (a: pc.Application) => void) => (
      <PlayCanvasStage createGraphicsDevice={nullDevice} onAppReady={(a) => cb(a)}>
        <div data-testid="child" />
      </PlayCanvasStage>
    );

    const view = render(tree(ready));
    expect(ready).toHaveBeenCalledTimes(1);
    const app = ready.mock.calls[0]![0] as pc.Application;
    const rootEntity = entity(app.root, 'TdaRootNode');
    const destroy = vi.spyOn(app, 'destroy');

    // Re-render three times, each with a brand-new inline callback identity.
    view.rerender(tree(ready));
    view.rerender(tree(ready));
    view.rerender(tree(ready));

    expect(destroy).not.toHaveBeenCalled();
    expect(ready).toHaveBeenCalledTimes(1);
    expect(entity(app.root, 'TdaRootNode')).toBe(rootEntity);
    expect(screen.getByTestId('child')).toBeInTheDocument();

    view.unmount();
    expect(destroy).toHaveBeenCalledTimes(1);
  });
});

describe('<PlayCanvasStage> default graphics device', () => {
  it('pins the default deviceTypes order as WebGPU then WebGL2', () => {
    // Source-level pin: createGraphicsDevice is async and jsdom has neither
    // backend, so we do not call it. The engine mutates the array it is given
    // (appends NULL); the call site must pass a copy of this constant.
    expect(DEFAULT_DEVICE_TYPES).toEqual([pc.DEVICETYPE_WEBGPU, pc.DEVICETYPE_WEBGL2]);
    const src = readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), '../PlayCanvasStage.tsx'),
      'utf8',
    );
    expect(src).toContain('deviceTypes: [...DEFAULT_DEVICE_TYPES]');
  });
});
