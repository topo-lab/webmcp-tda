/**
 * <CycleHighlight3D>: one given cycle drawn as a ring of line segments, with
 * optional instanced vertex markers.
 *
 * Mounted for real into a null-device `pc.Application` (see ./harness); the
 * assertions read the line mesh and the marker instancing buffer.
 *
 * Honesty (SPEC.md §5): the component renders a cycle it is GIVEN. Nothing
 * here derives a generator, and nothing below invents one — the ring indices
 * are chosen over a recorded GUDHI cloud.
 */
import { describe, expect, it } from 'vitest';
import * as pc from 'playcanvas';
import { CycleHighlight3D } from '../CycleHighlight3D';
import { pointsToPositions } from '../PointCloud3D';
import { CIRCLE24_ALPHA } from '../../__fixtures__/realFiltrations';
import {
  findEntity,
  instancingBuffer,
  instancingFloats,
  meshInstance,
  renderStage,
} from './harness';

// Recorded GUDHI cloud (SPEC.md §1.6): 24 points on a circle, 2D.
const POINTS = CIRCLE24_ALPHA.cloud.points;
const POSITIONS = pointsToPositions(POINTS, 2);
const VERTEX_COUNT = POSITIONS.length / 3;

const HEXAGON = [0, 4, 8, 12, 16, 20];
const DIRTY = [0, 4, 999, -1, 8, 2.5, VERTEX_COUNT, 12, NaN];
const DIRTY_VALID = [0, 4, 8, 12];
const PAIR = [0, 12];
const NOTHING_LEFT = [99, -2, 1.5];

const LINES = 'CycleLines';
const MARKERS = 'CycleVertexMarkers';

function linePositions(root: pc.GraphNode): Float32Array {
  const mesh = meshInstance(root, LINES).mesh;
  const out = new Float32Array(mesh.vertexBuffer.numVertices * 3);
  mesh.getPositions(out);
  return out;
}

describe('<CycleHighlight3D> ring topology', () => {
  it('draws 2n line vertices for a closed ring of n vertices', () => {
    const stage = renderStage(
      <CycleHighlight3D points={POINTS} dimension={2} cycle={HEXAGON} closed />,
    );
    const mesh = meshInstance(stage.root, LINES).mesh;

    expect(mesh.vertexBuffer.numVertices).toBe(2 * HEXAGON.length);
    expect(mesh.primitive[0]!.type).toBe(pc.PRIMITIVE_LINES);
  });

  it('drops the wrap segment when closed=false: 2(n−1) vertices', () => {
    const stage = renderStage(
      <CycleHighlight3D points={POINTS} dimension={2} cycle={HEXAGON} closed={false} />,
    );

    expect(meshInstance(stage.root, LINES).mesh.vertexBuffer.numVertices).toBe(
      2 * (HEXAGON.length - 1),
    );
  });

  it('traces the real point coordinates, and closes back to the first vertex', () => {
    const stage = renderStage(
      <CycleHighlight3D points={POINTS} dimension={2} cycle={HEXAGON} closed />,
    );
    const verts = linePositions(stage.root);

    // Segment i joins ring[i] to ring[i+1], where ring = [...cycle, cycle[0]].
    const ring = [...HEXAGON, HEXAGON[0]!];
    for (let i = 0; i < ring.length - 1; i++) {
      for (const [slot, v] of [
        [0, ring[i]!],
        [1, ring[i + 1]!],
      ] as const) {
        const base = (i * 2 + slot) * 3;
        expect(verts[base]).toBeCloseTo(POSITIONS[v * 3]!, 6);
        expect(verts[base + 1]).toBeCloseTo(POSITIONS[v * 3 + 1]!, 6);
        expect(verts[base + 2]).toBe(0); // a 2D cloud, embedded at z=0
      }
    }
  });

  it('does not double a 2-vertex cycle back on itself', () => {
    // closed only wraps when there are more than 2 vertices; two points would
    // otherwise be drawn as the same segment twice.
    const stage = renderStage(
      <CycleHighlight3D points={POINTS} dimension={2} cycle={PAIR} closed />,
    );

    expect(meshInstance(stage.root, LINES).mesh.vertexBuffer.numVertices).toBe(2);
  });
});

describe('<CycleHighlight3D> index validation', () => {
  it('filters out-of-range, negative, non-integer and NaN indices', () => {
    const stage = renderStage(<CycleHighlight3D points={POINTS} dimension={2} cycle={DIRTY} />);
    const verts = linePositions(stage.root);

    expect(meshInstance(stage.root, LINES).mesh.vertexBuffer.numVertices).toBe(
      2 * DIRTY_VALID.length,
    );
    expect(meshInstance(stage.root, MARKERS).instancingCount).toBe(DIRTY_VALID.length);
    // The surviving ring is exactly the valid indices, in their original order.
    expect(verts[0]).toBeCloseTo(POSITIONS[DIRTY_VALID[0]! * 3]!, 6);
    expect(verts[3]).toBeCloseTo(POSITIONS[DIRTY_VALID[1]! * 3]!, 6);
  });

  it('renders nothing when fewer than 2 indices survive', () => {
    const stage = renderStage(
      <CycleHighlight3D points={POINTS} dimension={2} cycle={NOTHING_LEFT} />,
    );

    expect(findEntity(stage.root, 'CycleHighlight3D')).toBeNull();
    expect(stage.root.children).toHaveLength(0);
  });
});

describe('<CycleHighlight3D> vertex markers', () => {
  it('instances one marker sphere per valid vertex, centred on the point', () => {
    const stage = renderStage(
      <CycleHighlight3D points={POINTS} dimension={2} cycle={HEXAGON} showVertices />,
    );
    const mi = meshInstance(stage.root, MARKERS);

    expect(mi.instancingCount).toBe(HEXAGON.length);
    expect(instancingBuffer(mi).numVertices).toBe(HEXAGON.length);
    expect(instancingBuffer(mi).format.elements.map((e) => e.name)).toEqual([
      'ATTR11',
      'ATTR12',
      'ATTR14',
      'ATTR15',
    ]);

    // pc.Mat4 is column-major: translation lives at 12/13/14.
    const data = instancingFloats(mi);
    for (let i = 0; i < HEXAGON.length; i++) {
      const v = HEXAGON[i]!;
      expect(data[i * 16 + 12]).toBeCloseTo(POSITIONS[v * 3]!, 6);
      expect(data[i * 16 + 13]).toBeCloseTo(POSITIONS[v * 3 + 1]!, 6);
      expect(data[i * 16 + 14]).toBe(0);
      expect(data[i * 16]).toBeCloseTo(0.04, 6); // uniform marker radius
    }
  });

  it('builds no marker entity at all when showVertices=false', () => {
    const stage = renderStage(
      <CycleHighlight3D points={POINTS} dimension={2} cycle={HEXAGON} showVertices={false} />,
    );

    expect(findEntity(stage.root, MARKERS)).toBeNull();
    expect(findEntity(stage.root, LINES)).not.toBeNull();
  });
});

describe('<CycleHighlight3D> lifecycle', () => {
  it('removes its entity from the scene graph when it unmounts', () => {
    const stage = renderStage(<CycleHighlight3D points={POINTS} dimension={2} cycle={HEXAGON} />);
    expect(findEntity(stage.root, 'CycleHighlight3D')).not.toBeNull();

    stage.rerender(null);

    expect(findEntity(stage.root, 'CycleHighlight3D')).toBeNull();
    expect(findEntity(stage.root, LINES)).toBeNull();
    expect(findEntity(stage.root, MARKERS)).toBeNull();
  });
});
