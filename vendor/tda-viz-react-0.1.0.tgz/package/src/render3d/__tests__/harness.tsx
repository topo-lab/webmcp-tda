/**
 * Headless PlayCanvas harness for the render3d tests.
 *
 * These are NOT smoke tests: every case below mounts the real React components
 * into a real `pc.Application` and asserts against the real scene graph —
 * entities found by name, mesh vertex buffers, instancing data, material
 * parameters.
 *
 * The device is `pc.NullGraphicsDevice`, the engine's own no-op backend. jsdom
 * has no WebGL context, so the stage is handed the device through its
 * `createGraphicsDevice` test seam (`pc.Application` takes an
 * `options.graphicsDevice` and only builds a device of its own when that is
 * absent). The production path awaits `pc.createGraphicsDevice` with
 * WebGPU-then-WebGL2; the seam stays fully synchronous so these tests do
 * not have to `waitFor` the engine.
 * Everything above the device — entities, components, meshes, vertex buffers,
 * instancing, material parameters — is the ordinary engine code path, so what
 * these tests read back is what a browser would upload. Only rasterization and
 * real shader compilation are stubbed out, and nothing here asserts on pixels.
 */
import { render } from '@testing-library/react';
import type { ReactNode } from 'react';
import * as pc from 'playcanvas';
import { PlayCanvasStage } from '../PlayCanvasStage';

// jsdom ships no ResizeObserver and the stage observes its canvas with one.
// Installed on import so every test file that uses the harness gets it.
if (typeof globalThis.ResizeObserver === 'undefined') {
  class ResizeObserverStub {
    observe() {}
    unobserve() {}
    disconnect() {}
  }
  globalThis.ResizeObserver = ResizeObserverStub as unknown as typeof ResizeObserver;
}

/** The `createGraphicsDevice` seam value used by every 3D test. */
export function nullDevice(canvas: HTMLCanvasElement): pc.GraphicsDevice {
  return new pc.NullGraphicsDevice(canvas);
}

export interface StageHandle {
  app: pc.Application;
  /** The `TdaRootNode` entity every 3D component parents itself to. */
  root: pc.Entity;
  camera: pc.Entity;
  /** Re-render the SAME stage with different children (the stage is not rebuilt). */
  rerender: (children: ReactNode) => void;
  unmount: () => void;
}

/**
 * Mount a `<PlayCanvasStage>` on a null device and return the live engine
 * objects. Throws rather than returning nulls so a broken mount fails at the
 * point of breakage instead of as a confusing null-deref later.
 */
export function renderStage(children: ReactNode): StageHandle {
  const holder: { app: pc.Application | null } = { app: null };
  const tree = (kids: ReactNode) => (
    <PlayCanvasStage
      createGraphicsDevice={nullDevice}
      onAppReady={(a) => {
        holder.app = a;
      }}
    >
      {kids}
    </PlayCanvasStage>
  );

  const view = render(tree(children));
  const app = holder.app;
  if (!app) throw new Error('PlayCanvasStage never created an application');

  return {
    app,
    root: entity(app.root, 'TdaRootNode'),
    camera: entity(app.root, 'MainCamera'),
    rerender: (kids: ReactNode) => view.rerender(tree(kids)),
    unmount: () => view.unmount(),
  };
}

/** Find a descendant entity by name, failing loudly instead of returning null. */
export function entity(parent: pc.GraphNode, name: string): pc.Entity {
  const found = parent.findByName(name);
  if (!found) {
    throw new Error(`no entity named "${name}" under "${parent.name}"`);
  }
  return found as pc.Entity;
}

/** Like `entity`, but for asserting that something is absent. */
export function findEntity(parent: pc.GraphNode, name: string): pc.Entity | null {
  return (parent.findByName(name) as pc.Entity | null) ?? null;
}

/** The one mesh instance hanging off a named descendant's render component. */
export function meshInstance(parent: pc.GraphNode, name: string): pc.MeshInstance {
  const e = entity(parent, name);
  const instances = e.render?.meshInstances ?? [];
  if (instances.length !== 1) {
    throw new Error(`entity "${name}" has ${instances.length} mesh instances, expected 1`);
  }
  return instances[0]!;
}

/** The per-instance vertex buffer actually handed to the GPU, or throw. */
export function instancingBuffer(mi: pc.MeshInstance): pc.VertexBuffer {
  const vb = mi.instancingData?.vertexBuffer;
  if (!vb) throw new Error('mesh instance carries no instancing vertex buffer');
  return vb;
}

/** Read a per-instance vertex buffer back as the floats that were uploaded. */
export function instancingFloats(mi: pc.MeshInstance): Float32Array {
  return new Float32Array(instancingBuffer(mi).lock());
}

/** Read a mesh's float vertex stream (positions, normals, aBirth, ...). */
export function vertexStream(mesh: pc.Mesh, semantic: string, components = 1): Float32Array {
  const out = new Float32Array(mesh.vertexBuffer.numVertices * components);
  mesh.getVertexStream(semantic, out);
  return out;
}

/** Value of a shader parameter set on a material (`{ scopeId, data }`). */
export function shaderParam(material: pc.Material, name: string): unknown {
  const p = material.getParameter(name) as { data?: unknown } | undefined;
  return p?.data;
}

/** Numeric shader parameter, failing loudly if it was never set. */
export function numberParam(material: pc.Material, name: string): number {
  const v = shaderParam(material, name);
  if (typeof v !== 'number') {
    throw new Error(`shader parameter "${name}" is ${JSON.stringify(v)}, expected a number`);
  }
  return v;
}
