/**
 * Regression test for the WebGL2-only teardown crash (SPEC.md §3): unmounting
 * a whole `<PlayCanvasStage>` subtree must not throw, even though React tears
 * down a deleted subtree's passive effects PARENT-FIRST — `<PlayCanvasStage>`'s
 * own cleanup destroys the `pc.Application` (and its graphics device) before
 * `<PointCloud3D>`'s cleanup runs and tries to free its own vertex buffer,
 * material and mesh (see utils.ts's `deviceIsLive` doc for the full engine
 * mechanism).
 *
 * `./harness`'s `nullDevice()` uses the real engine `NullGraphicsDevice`,
 * whose vertex-buffer impl never touches a `gl` field at all, so it cannot
 * reproduce the crash by itself. This file reshapes that same device to
 * behave like a WebGL2 device for exactly the two things that matter: a `gl`
 * field that starts truthy and is nulled by `destroy()` (mirroring
 * `WebglGraphicsDevice.destroy()`), and a vertex-buffer `destroy()` that
 * dereferences it (mirroring `WebglBuffer.destroy(device)`). Without the
 * `deviceIsLive` guard in `PointCloud3D`'s cleanup, this test fails with the
 * exact `TypeError: Cannot read properties of null (reading 'deleteBuffer')`
 * from the bug report.
 */
import { render } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import * as pc from 'playcanvas';
import { PlayCanvasStage } from '../PlayCanvasStage';
import { PointCloud3D } from '../PointCloud3D';
import { nullDevice } from './harness';

/** Minimal shape of the WebGL vertex-buffer impl this test cares about. */
interface CrashingVertexBufferImpl {
  initialized: boolean;
  destroy: () => void;
  unlock: () => void;
  loseContext: () => void;
}

type CrashingDevice = pc.GraphicsDevice & {
  gl: { deleteBuffer: (id: unknown) => void } | null;
  createVertexBufferImpl: () => CrashingVertexBufferImpl;
};

/**
 * A `NullGraphicsDevice`, reshaped to reproduce the real WebGL2 crash: `gl`
 * starts as a truthy stub context and every vertex buffer's `destroy()`
 * dereferences `device.gl.deleteBuffer` exactly as
 * `platform/graphics/webgl/webgl-buffer.js`'s `WebglBuffer.destroy(device)`
 * does. `destroy()` nulls `gl` as its last step, exactly as
 * `platform/graphics/webgl/webgl-graphics-device.js`'s
 * `WebglGraphicsDevice.destroy()` does.
 */
function crashingWebglLikeDevice(canvas: HTMLCanvasElement): pc.GraphicsDevice {
  const device = nullDevice(canvas) as CrashingDevice;
  device.gl = { deleteBuffer: () => {} };

  const realDestroy = device.destroy.bind(device);
  device.destroy = () => {
    realDestroy();
    device.gl = null;
  };

  device.createVertexBufferImpl = () => ({
    initialized: true,
    destroy: () => {
      // The exact null-deref from the bug report:
      // `WebglBuffer.destroy(device)`'s `device.gl.deleteBuffer(this.bufferId)`.
      device.gl!.deleteBuffer(null);
    },
    unlock: () => {},
    loseContext: () => {},
  });

  return device;
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('<PlayCanvasStage> + <PointCloud3D> full-subtree teardown', () => {
  it('unmounts without throwing or logging, even though the device dies before the child cleanup runs', () => {
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

    const view = render(
      <PlayCanvasStage createGraphicsDevice={crashingWebglLikeDevice}>
        <PointCloud3D points={[0, 0, 0, 1, 1, 1]} />
      </PlayCanvasStage>,
    );

    expect(() => view.unmount()).not.toThrow();
    expect(errorSpy).not.toHaveBeenCalled();
  });
});
