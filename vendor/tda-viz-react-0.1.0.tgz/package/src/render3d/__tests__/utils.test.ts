// @vitest-environment node
import { describe, expect, it, vi } from 'vitest';
import * as pc from 'playcanvas';
import { createUnlitMaterial, destroyEntity, deviceIsLive, parseColor } from '../utils';

/** A `pc.AppBase`-shaped stub with a live WebGL2-looking device. */
function liveApp(): pc.AppBase {
  return { graphicsDevice: { isNull: false, gl: {} } } as unknown as pc.AppBase;
}

describe('3D colour contract', () => {
  it('expands short hex exactly and lets the explicit opacity override embedded alpha', () => {
    const short = parseColor('#369', 0.4);
    expect([short.r, short.g, short.b, short.a]).toEqual([
      0x33 / 255,
      0x66 / 255,
      0x99 / 255,
      0.4,
    ]);

    const embedded = parseColor('#ff800000', 0.75);
    expect(embedded.r).toBe(1);
    expect(embedded.g).toBeCloseTo(0x80 / 255, 12);
    expect(embedded.b).toBe(0);
    expect(embedded.a).toBe(0.75);
  });

  it.each(['', 'red', 'rgb(1, 2, 3)', '#12', '#xyzxyz'])(
    'falls back visibly to white for unsupported colour %j, never NaN',
    (input) => {
      const color = parseColor(input, 0.25);
      expect([color.r, color.g, color.b, color.a]).toEqual([1, 1, 1, 0.25]);
      expect([color.r, color.g, color.b, color.a].every(Number.isFinite)).toBe(true);
    },
  );

  it('disables depth writes for translucent material but not for opaque material', () => {
    const color = new pc.Color(0.2, 0.4, 0.6);
    const translucent = createUnlitMaterial(color, 0.3);
    const opaque = createUnlitMaterial(color);

    expect(translucent.opacity).toBe(0.3);
    expect(translucent.blendType).toBe(pc.BLEND_NORMAL);
    expect(translucent.depthWrite).toBe(false);
    expect(opaque.opacity).toBe(1);
    expect(opaque.depthWrite).toBe(true);
  });
});

describe('deviceIsLive', () => {
  it('is true for a live app with a WebGL2-shaped device', () => {
    expect(deviceIsLive(liveApp())).toBe(true);
  });

  it('is true for a live app whose device has no `gl` field at all (WebGPU)', () => {
    const app = { graphicsDevice: { isNull: false } } as unknown as pc.AppBase;
    expect(deviceIsLive(app)).toBe(true);
  });

  it('is false when the app itself is absent', () => {
    expect(deviceIsLive(null)).toBe(false);
    expect(deviceIsLive(undefined)).toBe(false);
  });

  it("is false when the app's graphicsDevice is null", () => {
    const app = { graphicsDevice: null } as unknown as pc.AppBase;
    expect(deviceIsLive(app)).toBe(false);
  });

  it('is false for a WebGL-shaped device whose `gl` has been nulled', () => {
    const app = { graphicsDevice: { isNull: false, gl: null } } as unknown as pc.AppBase;
    expect(deviceIsLive(app)).toBe(false);
  });

  it('is false when the device reports isNull (DEVICETYPE_NULL)', () => {
    const app = { graphicsDevice: { isNull: true, gl: {} } } as unknown as pc.AppBase;
    expect(deviceIsLive(app)).toBe(false);
  });
});

describe('destroyEntity', () => {
  it('accepts an absent optional entity and destroys a present one exactly once while the device is live', () => {
    const app = liveApp();
    expect(() => destroyEntity(null, app)).not.toThrow();
    expect(() => destroyEntity(undefined, app)).not.toThrow();

    const entity = new pc.Entity('temporary');
    const destroy = vi.spyOn(entity, 'destroy');
    destroyEntity(entity, app);
    expect(destroy).toHaveBeenCalledTimes(1);
  });

  it('skips destroy() once the device is gone, instead of crashing into it', () => {
    const deadApp = { graphicsDevice: null } as unknown as pc.AppBase;
    const entity = new pc.Entity('temporary');
    const destroy = vi.spyOn(entity, 'destroy');

    expect(() => destroyEntity(entity, deadApp)).not.toThrow();
    expect(destroy).not.toHaveBeenCalled();
    expect(() => destroyEntity(entity, null)).not.toThrow();
    expect(destroy).not.toHaveBeenCalled();
  });
});
