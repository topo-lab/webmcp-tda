/**
 * <DepthSlice3D> and its counting oracle.
 *
 * jsdom has no GPU and the harness's `pc.NullGraphicsDevice` never rasterizes,
 * so nothing here can read the slice's pixels back. The exactness claim is
 * therefore tested where it actually lives: `coveringDepthAt`, the pure
 * function the GLSL and WGSL fragment shaders transcribe. It is checked against
 * an INDEPENDENT brute force (unsquared distances, a different formulation) on
 * seeded clouds, and then against the two eight-sphere motifs whose depth-4
 * geometry is known in closed form.
 *
 * The component half is the ordinary render3d treatment (see ./harness): a real
 * `pc.Application`, a real scene graph, real material parameters.
 */
import { describe, expect, it } from 'vitest';
import {
  DEPTH_SLICE_FRAGMENT_GLSL,
  DEPTH_SLICE_FRAGMENT_WGSL,
  DepthSlice3D,
} from '../DepthSlice3D';
import {
  MAX_DEPTH_SLICE_CENTRES,
  cloudBoundingRadius,
  cloudCentroid,
  coveringDepthAt,
  sliceFrame,
  slicePoint,
} from '../depthSlice';
import type { Filtration } from '../../filtration/types';
import {
  JITTERED8_KFOLD2,
  TETRA4_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { entity, findEntity, meshInstance, numberParam, renderStage, shaderParam } from './harness';

// ── The independent brute force ──────────────────────────────────────────

/**
 * Deliberately NOT the implementation: real distances via `Math.hypot`,
 * compared against `√t`, and an explicit filter rather than a counting loop.
 * If `coveringDepthAt` and this ever disagree, one of them is wrong.
 */
function bruteForceDepth(point: number[], centres: number[], tSquared: number): number {
  if (tSquared < 0) return 0;
  const radius = Math.sqrt(tSquared);
  const triples: number[][] = [];
  for (let i = 0; i < centres.length; i += 3) triples.push(centres.slice(i, i + 3));
  return triples.filter(
    (c) => Math.hypot(point[0]! - c[0]!, point[1]! - c[1]!, point[2]! - c[2]!) <= radius,
  ).length;
}

/** Seeded PRNG, so "random" clouds are the same cloud on every run. */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let x = Math.imul(a ^ (a >>> 15), 1 | a);
    x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x;
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

function seededCloud(seed: number, n: number, spread = 2): number[] {
  const rnd = mulberry32(seed);
  const pts: number[] = [];
  for (let i = 0; i < n * 3; i++) pts.push((rnd() - 0.5) * spread);
  return pts;
}

// ── The two eight-sphere motifs ──────────────────────────────────────────
//
// Verbatim from wasm-tda-webapp/public/datasets/motif_{hcp,fcc}_8.json: eight
// unit-diameter spheres, a hexagonal layer of six with one sphere above and one
// below. HCP has the layers ECLIPSED (A B A), FCC STAGGERED (A B C). Jitter
// 2e-3, seeds 777 and 778 — which is why the closed-form values below are met
// to a tolerance rather than exactly.

const HCP_POINTS = [
  0.0007, -0.0019, -0.0012, 0.9985, 0.0005, -0.0005, 0.499, 0.867, 0.0005, -0.4989, 0.8668, 0.0014,
  0.4986, -0.8653, 0.0002, -0.4983, -0.8659, -0.0017, 0.5017, 0.2896, 0.8184, 0.4985, 0.2881,
  -0.8183,
];
/** HCP: the two tetrahedral holes share the FACE 0-1-2. */
const HCP_HOLES: [number[], number[]] = [
  [0, 1, 2, 6],
  [0, 1, 2, 7],
];

const FCC_POINTS = [
  -0.0019, 0.0004, 0.0014, 1.0007, 0.0007, 0.0013, 0.502, 0.8671, -0.0006, -0.5009, 0.8653, 0.0018,
  0.4996, -0.8674, -0.0016, -0.4996, -0.8673, 0, 0.5, 0.2875, 0.8185, 0.5014, -0.2888, -0.8169,
];
/** FCC: the two tetrahedral holes share only the EDGE 0-1. */
const FCC_HOLES: [number[], number[]] = [
  [0, 1, 2, 6],
  [0, 1, 4, 7],
];

const pointAt = (pts: number[], i: number) => [pts[i * 3]!, pts[i * 3 + 1]!, pts[i * 3 + 2]!];

/**
 * Circumcentre of a tetrahedron: the point equidistant from all four vertices,
 * i.e. the centre of the deepest part of the hole they surround. Solved from
 * the three linear equations |x − a|² = |x − b|² by Gaussian elimination.
 */
function circumcentre(p: number[][]): number[] {
  const [a, b, c, d] = p as [number[], number[], number[], number[]];
  const sq = (q: number[]) => q[0]! ** 2 + q[1]! ** 2 + q[2]! ** 2;
  const rows = [b, c, d].map((q, i) => [
    2 * (q[0]! - a[0]!),
    2 * (q[1]! - a[1]!),
    2 * (q[2]! - a[2]!),
    sq([b, c, d][i]!) - sq(a),
  ]);
  for (let i = 0; i < 3; i++) {
    let pivot = i;
    for (let j = i + 1; j < 3; j++) {
      if (Math.abs(rows[j]![i]!) > Math.abs(rows[pivot]![i]!)) pivot = j;
    }
    [rows[i], rows[pivot]] = [rows[pivot]!, rows[i]!];
    for (let j = 0; j < 3; j++) {
      if (j === i) continue;
      const f = rows[j]![i]! / rows[i]![i]!;
      for (let k = i; k < 4; k++) rows[j]![k]! -= f * rows[i]![k]!;
    }
  }
  return [rows[0]![3]! / rows[0]![0]!, rows[1]![3]! / rows[1]![1]!, rows[2]![3]! / rows[2]![2]!];
}

/** The smallest t on a fine grid at which `point` is covered at least `k` times. */
function birthT(point: number[], pts: number[], k: number, step = 0.0005, tMax = 2): number {
  for (let t = 0; t <= tMax; t += step) {
    if (coveringDepthAt(point, pts, t) >= k) return t;
  }
  return Infinity;
}

/**
 * The smallest t at which the whole segment between the two hole centres is
 * covered at least `k` times — i.e. at which the two depth-k regions have
 * merged into one. Sampled, exactly as a reader would read it off the picture.
 */
function mergeT(
  a: number[],
  b: number[],
  pts: number[],
  k: number,
  samples = 1001,
  step = 0.0005,
  tMax = 2,
): number {
  const segment: number[][] = [];
  for (let i = 0; i < samples; i++) {
    const s = i / (samples - 1);
    segment.push([
      a[0]! + s * (b[0]! - a[0]!),
      a[1]! + s * (b[1]! - a[1]!),
      a[2]! + s * (b[2]! - a[2]!),
    ]);
  }
  for (let t = 0; t <= tMax; t += step) {
    if (segment.every((x) => coveringDepthAt(x, pts, t) >= k)) return t;
  }
  return Infinity;
}

// ── The oracle ───────────────────────────────────────────────────────────

describe('coveringDepthAt (the oracle for the GLSL/WGSL)', () => {
  it('agrees with brute force everywhere on seeded clouds', () => {
    for (const seed of [1, 7, 12345, 987654]) {
      const centres = seededCloud(seed, 40);
      const probes = seededCloud(seed + 1000, 120, 3);
      for (let p = 0; p < probes.length; p += 3) {
        const point = [probes[p]!, probes[p + 1]!, probes[p + 2]!];
        for (const t of [0, 0.01, 0.05, 0.2, 0.5, 1, 2.5, 9]) {
          expect(coveringDepthAt(point, centres, t)).toBe(bruteForceDepth(point, centres, t));
        }
      }
    }
  });

  it('is exhaustively right on a small cloud over a dense t sweep', () => {
    const centres = seededCloud(42, 12);
    const probes = seededCloud(43, 40, 3);
    for (let p = 0; p < probes.length; p += 3) {
      const point = [probes[p]!, probes[p + 1]!, probes[p + 2]!];
      for (let t = 0; t <= 4; t += 0.02) {
        expect(coveringDepthAt(point, centres, t)).toBe(bruteForceDepth(point, centres, t));
      }
    }
  });

  it('counts a point exactly on a ball boundary as inside (<=, not <)', () => {
    // Distance 3 from the origin, so |x - c|^2 = 9 exactly.
    expect(coveringDepthAt([3, 0, 0], [0, 0, 0], 9)).toBe(1);
    expect(coveringDepthAt([3, 0, 0], [0, 0, 0], 9 - 1e-12)).toBe(0);
  });

  it('is depth 0 before any ball is born, and for a negative or NaN t', () => {
    const centres = [0, 0, 0, 1, 0, 0];
    expect(coveringDepthAt([0, 0, 0], centres, 0)).toBe(1);
    expect(coveringDepthAt([0.5, 0, 0], centres, 0)).toBe(0);
    expect(coveringDepthAt([0, 0, 0], centres, -1)).toBe(0);
    expect(coveringDepthAt([0, 0, 0], centres, Number.NaN)).toBe(0);
  });

  it('is depth 0 with no centres at all', () => {
    expect(coveringDepthAt([0, 0, 0], [], 100)).toBe(0);
  });

  it('reaches the full cloud size once t covers everything', () => {
    const centres = seededCloud(5, 30);
    expect(coveringDepthAt([0, 0, 0], centres, 100)).toBe(30);
  });
});

describe('the eight-sphere motifs (HCP eclipsed vs FCC staggered)', () => {
  const cases = [
    { name: 'HCP', pts: HCP_POINTS, holes: HCP_HOLES, merge: 0.67 },
    { name: 'FCC', pts: FCC_POINTS, holes: FCC_HOLES, merge: 0.75 },
  ];

  for (const { name, pts, holes, merge } of cases) {
    it(`${name}: both depth-4 regions open at t = 0.375, the squared circumradius`, () => {
      // Four unit-diameter spheres in mutual contact: their circumcentre is at
      // squared distance 3/8 from each centre, so depth 4 appears exactly there.
      for (const tet of holes) {
        const c = circumcentre(tet.map((i) => pointAt(pts, i)));
        expect(coveringDepthAt(c, pts, 0.375 + 0.02)).toBeGreaterThanOrEqual(4);
        expect(birthT(c, pts, 4)).toBeCloseTo(0.375, 1);
        expect(Math.abs(birthT(c, pts, 4) - 0.375)).toBeLessThan(0.02);
      }
    });

    it(`${name}: the two depth-4 regions merge at t ≈ ${merge}`, () => {
      const a = circumcentre(holes[0].map((i) => pointAt(pts, i)));
      const b = circumcentre(holes[1].map((i) => pointAt(pts, i)));
      // Below the merge the midpoint of the segment is not yet covered 4 times:
      // there really are two regions, not one drawn twice.
      const mid = [0, 1, 2].map((k) => (a[k]! + b[k]!) / 2);
      expect(coveringDepthAt(mid, pts, merge - 0.05)).toBeLessThan(4);
      expect(Math.abs(mergeT(a, b, pts, 4) - merge)).toBeLessThan(0.02);
    });
  }

  it('separates the two motifs: the eclipsed pair merges before the staggered one', () => {
    const m = (pts: number[], holes: [number[], number[]]) =>
      mergeT(
        circumcentre(holes[0].map((i) => pointAt(pts, i))),
        circumcentre(holes[1].map((i) => pointAt(pts, i))),
        pts,
        4,
      );
    expect(m(HCP_POINTS, HCP_HOLES)).toBeLessThan(m(FCC_POINTS, FCC_HOLES));
  });
});

// ── The plane helpers ────────────────────────────────────────────────────

describe('slice-plane geometry', () => {
  it('builds an orthonormal frame whose third axis is the given normal', () => {
    for (const n of [
      [0, 0, 1],
      [0, 0, -4],
      [1, 1, 1],
      [1, 0, 0],
      [-0.3, 0.8, 0.2],
    ]) {
      const { u, v, n: unit } = sliceFrame(n);
      const dot = (a: number[], b: number[]) => a[0]! * b[0]! + a[1]! * b[1]! + a[2]! * b[2]!;
      expect(dot(unit, unit)).toBeCloseTo(1, 12);
      expect(dot(u, u)).toBeCloseTo(1, 12);
      expect(dot(v, v)).toBeCloseTo(1, 12);
      expect(dot(u, v)).toBeCloseTo(0, 12);
      expect(dot(u, unit)).toBeCloseTo(0, 12);
      expect(dot(v, unit)).toBeCloseTo(0, 12);
      const len = Math.hypot(n[0]!, n[1]!, n[2]!);
      for (let k = 0; k < 3; k++) expect(unit[k]).toBeCloseTo(n[k]! / len, 12);
    }
  });

  it('refuses a zero normal rather than returning a frame of NaNs', () => {
    expect(() => sliceFrame([0, 0, 0])).toThrow(/zero length|no plane/i);
  });

  it('places a plane point at origin + a·u + b·v', () => {
    const frame = sliceFrame([0, 0, 1]);
    const p = slicePoint([1, 2, 3], frame, 2, -5);
    expect(p[2]).toBeCloseTo(3, 12);
    expect(Math.hypot(p[0] - 1, p[1] - 2)).toBeCloseTo(Math.hypot(2, 5), 12);
  });

  it('centroid and bounding radius of a flat 3D cloud', () => {
    const pts = [0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 2];
    const c = cloudCentroid(pts);
    expect(c).toEqual([0.5, 0.5, 0.5]);
    expect(cloudBoundingRadius(pts, c)).toBeCloseTo(Math.hypot(1.5, 0.5, 0.5), 12);
    expect(cloudCentroid([])).toEqual([0, 0, 0]);
    expect(cloudBoundingRadius([], [0, 0, 0])).toBe(0);
  });
});

// ── The shaders are transcriptions, not variations ───────────────────────

describe('the fragment shaders transcribe the oracle', () => {
  it('GLSL counts squared distances with a non-strict comparison', () => {
    expect(DEPTH_SLICE_FRAGMENT_GLSL).toContain('vec3 dv = vWorld - uCentres[i].xyz;');
    expect(DEPTH_SLICE_FRAGMENT_GLSL).toContain('if (dot(dv, dv) <= uT) depth++;');
    expect(DEPTH_SLICE_FRAGMENT_GLSL).not.toMatch(/sqrt|length\(/);
  });

  it('WGSL runs the same predicate', () => {
    expect(DEPTH_SLICE_FRAGMENT_WGSL).toContain('let dv = input.vWorld - uniform.uCentres[i].xyz;');
    expect(DEPTH_SLICE_FRAGMENT_WGSL).toContain('if (dot(dv, dv) <= uniform.uT) { depth += 1; }');
    expect(DEPTH_SLICE_FRAGMENT_WGSL).not.toMatch(/sqrt|length\(/);
  });

  it('both loop to the compiled centre ceiling and paint depth 0 transparent', () => {
    expect(DEPTH_SLICE_FRAGMENT_GLSL).toContain(`i < ${MAX_DEPTH_SLICE_CENTRES}`);
    expect(DEPTH_SLICE_FRAGMENT_WGSL).toContain(`i < ${MAX_DEPTH_SLICE_CENTRES}`);
    expect(DEPTH_SLICE_FRAGMENT_GLSL).toContain('gl_FragColor = vec4(0.0);');
    expect(DEPTH_SLICE_FRAGMENT_WGSL).toContain('output.color = vec4f(0.0);');
  });
});

// ── The component ────────────────────────────────────────────────────────

const KFOLD = recordedFiltration(JITTERED8_KFOLD2);
const RAMP: [string, string, string, string] = ['#dfe4f5', '#a3b0e6', '#6a7ad0', '#4450b4'];

describe('<DepthSlice3D> scene graph', () => {
  it('parents a quad under the stage root', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    const parent = findEntity(stage.root, 'DepthSlice3D');
    expect(parent).not.toBeNull();
    expect(parent!.parent).toBe(stage.root);
    const mi = meshInstance(stage.root, 'DepthSliceQuad');
    // Two triangles, six vertices: a quad, not a tessellated surface. The
    // count is per fragment, so the geometry carries none of the work.
    expect(mi.mesh.vertexBuffer.numVertices).toBe(6);
    stage.unmount();
  });

  it('declares its exactness claim and its plane in the entity userData', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    const parent = entity(stage.root, 'DepthSlice3D') as unknown as {
      userData: Record<string, unknown>;
    };
    expect(String(parent.userData.exactness)).toMatch(/exact/i);
    expect(parent.userData.centreCount).toBe(KFOLD.cloud.points.length / 3);
    expect(parent.userData.planeNormal).toEqual([0, 0, 1]);
    stage.unmount();
  });

  it('uploads every centre once, as the INPUT points and not the mosaic vertices', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    const mi = meshInstance(stage.root, 'DepthSliceQuad');
    const centres = shaderParam(mi.material, 'uCentres[0]') as Float32Array;
    const n = KFOLD.cloud.points.length / 3;

    expect(centres).toBeInstanceOf(Float32Array);
    expect(centres.length).toBe(MAX_DEPTH_SLICE_CENTRES * 4);
    expect(numberParam(mi.material, 'uCentreCount')).toBe(n);
    for (let i = 0; i < n; i++) {
      expect(centres[i * 4]).toBeCloseTo(KFOLD.cloud.points[i * 3]!, 5);
      expect(centres[i * 4 + 1]).toBeCloseTo(KFOLD.cloud.points[i * 3 + 1]!, 5);
      expect(centres[i * 4 + 2]).toBeCloseTo(KFOLD.cloud.points[i * 3 + 2]!, 5);
    }
    // The mosaic has more vertices than the cloud has points; the slice counts
    // balls, so it must carry the points.
    expect(KFOLD.vertexCount).toBeGreaterThan(n);

    // Scrubbing t must not touch the centres: the SAME array object survives.
    stage.rerender(<DepthSlice3D filtration={KFOLD} t={0.9} colors={RAMP} />);
    expect(shaderParam(meshInstance(stage.root, 'DepthSliceQuad').material, 'uCentres[0]')).toBe(
      centres,
    );
    stage.unmount();
  });

  it('writes the new t into the uniform when t changes', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.25} colors={RAMP} />);
    expect(numberParam(meshInstance(stage.root, 'DepthSliceQuad').material, 'uT')).toBeCloseTo(
      0.25,
      12,
    );
    stage.rerender(<DepthSlice3D filtration={KFOLD} t={1.75} colors={RAMP} />);
    expect(numberParam(meshInstance(stage.root, 'DepthSliceQuad').material, 'uT')).toBeCloseTo(
      1.75,
      12,
    );
    stage.unmount();
  });

  it('packs the four ramp colours and the opacity into uniforms', () => {
    const stage = renderStage(
      <DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} opacity={0.5} />,
    );
    const mat = meshInstance(stage.root, 'DepthSliceQuad').material;
    const ramp = shaderParam(mat, 'uRamp[0]') as Float32Array;
    expect(ramp.length).toBe(16);
    // '#4450b4' -> (0x44, 0x50, 0xb4) / 255, in the last slot (depth >= 4).
    expect(ramp[12]).toBeCloseTo(0x44 / 255, 5);
    expect(ramp[13]).toBeCloseTo(0x50 / 255, 5);
    expect(ramp[14]).toBeCloseTo(0xb4 / 255, 5);
    expect(numberParam(mat, 'uOpacity')).toBeCloseTo(0.5, 12);
    stage.unmount();
  });

  it('defaults the opacity to 0.92', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    expect(
      numberParam(meshInstance(stage.root, 'DepthSliceQuad').material, 'uOpacity'),
    ).toBeCloseTo(0.92, 12);
    stage.unmount();
  });

  it('spans the plane through the cloud centroid, at the default half-extent', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    const mi = meshInstance(stage.root, 'DepthSliceQuad');
    const positions = new Float32Array(mi.mesh.vertexBuffer.numVertices * 3);
    mi.mesh.getPositions(positions);

    const centre = cloudCentroid(KFOLD.cloud.points);
    const half = cloudBoundingRadius(KFOLD.cloud.points, centre) * 1.15;
    // Default plane normal [0,0,1] through the centroid: every corner sits at
    // the centroid's z, one half-extent away in each in-plane direction.
    for (let i = 0; i < 6; i++) {
      expect(positions[i * 3 + 2]).toBeCloseTo(centre[2], 5);
      expect(Math.abs(positions[i * 3]! - centre[0])).toBeCloseTo(half, 5);
      expect(Math.abs(positions[i * 3 + 1]! - centre[1])).toBeCloseTo(half, 5);
    }
    stage.unmount();
  });

  it('honours an explicit plane and size', () => {
    const stage = renderStage(
      <DepthSlice3D
        filtration={KFOLD}
        t={0.4}
        colors={RAMP}
        plane={{ normal: [1, 0, 0], offset: 0.5 }}
        size={2}
      />,
    );
    const mi = meshInstance(stage.root, 'DepthSliceQuad');
    const positions = new Float32Array(mi.mesh.vertexBuffer.numVertices * 3);
    mi.mesh.getPositions(positions);
    const centre = cloudCentroid(KFOLD.cloud.points);
    // Normal +x, offset 0.5: the whole quad lies at x = centroid.x + 0.5, and
    // its in-plane half-extent is the size that was asked for.
    for (let i = 0; i < 6; i++) {
      expect(positions[i * 3]).toBeCloseTo(centre[0] + 0.5, 5);
      expect(Math.max(Math.abs(positions[i * 3 + 1]! - centre[1]), 0)).toBeCloseTo(2, 5);
    }
    stage.unmount();
  });

  it('unmounts without error and takes its entity with it', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    expect(findEntity(stage.root, 'DepthSlice3D')).not.toBeNull();
    expect(() => stage.rerender(null)).not.toThrow();
    expect(findEntity(stage.root, 'DepthSlice3D')).toBeNull();
    expect(() => stage.unmount()).not.toThrow();
  });

  it('survives the stage tearing the device down first (the 2026-09-06 contract)', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    expect(() => stage.unmount()).not.toThrow();
  });
});

describe('<DepthSlice3D> refusals', () => {
  it('refuses a filtration that is not a k-fold cover', () => {
    const alpha = recordedFiltration(TETRA4_ALPHA);
    expect(() => renderStage(<DepthSlice3D filtration={alpha} t={0.4} colors={RAMP} />)).toThrow(
      /k-fold cover/i,
    );
  });

  it('refuses a 2D cloud: there is no plane to slice that it does not lie in', () => {
    const flat = {
      ...KFOLD,
      cloud: { ...KFOLD.cloud, dimension: 2 },
    } as unknown as Filtration;
    expect(() => renderStage(<DepthSlice3D filtration={flat} t={0.4} colors={RAMP} />)).toThrow(
      /3D cloud/i,
    );
  });

  it('refuses a cloud with more centres than the compiled shader can count', () => {
    const huge = {
      ...KFOLD,
      cloud: { ...KFOLD.cloud, points: seededCloud(9, MAX_DEPTH_SLICE_CENTRES + 1) },
    } as unknown as Filtration;
    expect(() => renderStage(<DepthSlice3D filtration={huge} t={0.4} colors={RAMP} />)).toThrow(
      new RegExp(`at most ${MAX_DEPTH_SLICE_CENTRES}`),
    );
  });

  it('supports at least 256 centres', () => {
    expect(MAX_DEPTH_SLICE_CENTRES).toBeGreaterThanOrEqual(256);
    const big = {
      ...KFOLD,
      cloud: { ...KFOLD.cloud, points: seededCloud(11, MAX_DEPTH_SLICE_CENTRES) },
    } as unknown as Filtration;
    const stage = renderStage(<DepthSlice3D filtration={big} t={0.4} colors={RAMP} />);
    expect(numberParam(meshInstance(stage.root, 'DepthSliceQuad').material, 'uCentreCount')).toBe(
      MAX_DEPTH_SLICE_CENTRES,
    );
    stage.unmount();
  });
});

// ── Array uniforms bind by a name the shader source does not spell ───────

/**
 * The regression guard for the 2026-09-06 blank-slice bug.
 *
 * A material parameter is bound by NAME through `device.scope`, and for an
 * ARRAY uniform that name carries a `[0]` suffix on BOTH backends —
 * `gl.getActiveUniform().name` on WebGL2 (playcanvas@2.21.4
 * `webgl/webgl-shader-input.js:47`) and `UniformFormat`'s
 * `this.name = count ? name + "[0]" : name` on WebGPU
 * (`uniform-buffer-format.js:117-118`, resolved at `:242`). Setting the bare
 * name writes a slot nothing reads, so `uCentres` and `uRamp` stayed at their
 * zero-initialised contents in a real browser and the slice painted a black
 * disc of radius √t at the world origin.
 *
 * NOTHING IN THIS FILE CAN SEE THAT DIRECTLY. `pc.NullGraphicsDevice` compiles
 * no shader and reflects no uniforms, so no scope id is ever resolved here and
 * a wrong parameter name is indistinguishable from a right one at run time.
 * What IS checkable is the contract between the two halves: every array the
 * shader source declares must have a parameter set under its `[0]` name. That
 * is what these tests read — the GLSL and WGSL declarations are parsed out of
 * the shipped shader strings, so a new array uniform cannot be added without
 * being covered.
 */
describe('array uniforms are set under the name the engine binds', () => {
  /** `uniform vec4 uCentres[256];` -> { name: 'uCentres', count: 256, components: 4 } */
  function glslArrays(source: string) {
    const found: Array<{ name: string; count: number; components: number }> = [];
    const re = /uniform\s+(\w+)\s+(\w+)\s*\[\s*(\d+)\s*\]\s*;/g;
    for (const m of source.matchAll(re)) {
      const type = m[1]!;
      const components = type === 'float' ? 1 : Number(type.replace(/\D/g, '')) || 1;
      found.push({ name: m[2]!, count: Number(m[3]), components });
    }
    return found;
  }

  /** `uniform uCentres: array<vec4f, 256>;` -> the same shape. */
  function wgslArrays(source: string) {
    const found: Array<{ name: string; count: number; components: number }> = [];
    const re = /uniform\s+(\w+)\s*:\s*array<\s*(\w+)\s*,\s*(\d+)\s*>\s*;/g;
    for (const m of source.matchAll(re)) {
      const type = m[2]!;
      const components = Number(type.replace(/\D/g, '')) || 1;
      found.push({ name: m[1]!, count: Number(m[3]), components });
    }
    return found;
  }

  const glsl = glslArrays(DEPTH_SLICE_FRAGMENT_GLSL);
  const wgsl = wgslArrays(DEPTH_SLICE_FRAGMENT_WGSL);

  it('finds the array declarations at all (the parser is load-bearing)', () => {
    expect(glsl.map((a) => a.name).sort()).toEqual(['uCentres', 'uRamp']);
    expect(wgsl.map((a) => a.name).sort()).toEqual(['uCentres', 'uRamp']);
  });

  it('declares the same arrays, at the same sizes, in both languages', () => {
    expect([...wgsl].sort((a, b) => a.name.localeCompare(b.name))).toEqual(
      [...glsl].sort((a, b) => a.name.localeCompare(b.name)),
    );
  });

  it('sets every declared array under its "[0]" name, fully sized', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    const mat = meshInstance(stage.root, 'DepthSliceQuad').material;
    for (const { name, count, components } of glsl) {
      const value = shaderParam(mat, `${name}[0]`);
      expect(value, `${name}[0] is the name both backends resolve`).toBeInstanceOf(Float32Array);
      // Fully sized: WebGPU writes the whole uniform-buffer member, so a short
      // array would leave the tail of the range undefined rather than zero.
      expect((value as Float32Array).length).toBe(count * components);
    }
    stage.unmount();
  });

  it('sets the bare name too, so a driver that omits the suffix still binds', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    const mat = meshInstance(stage.root, 'DepthSliceQuad').material;
    for (const { name } of glsl) {
      expect(shaderParam(mat, name)).toBe(shaderParam(mat, `${name}[0]`));
    }
    stage.unmount();
  });

  it('leaves the scalar uniforms on their plain names', () => {
    const stage = renderStage(<DepthSlice3D filtration={KFOLD} t={0.4} colors={RAMP} />);
    const mat = meshInstance(stage.root, 'DepthSliceQuad').material;
    for (const name of ['uT', 'uCentreCount', 'uOpacity']) {
      expect(typeof shaderParam(mat, name)).toBe('number');
      expect(shaderParam(mat, `${name}[0]`)).toBeUndefined();
    }
    stage.unmount();
  });
});
