/**
 * <PointCloud3D>: instanced sphere markers, one instance per point.
 *
 * Mounted for real into a null-device `pc.Application` (see ./harness) — the
 * assertions read the instancing vertex buffer the engine would upload.
 */
import { describe, expect, it } from 'vitest';
import * as pc from 'playcanvas';
import { PointCloud3D, pointsToPositions } from '../PointCloud3D';
import { TETRA4_ALPHA } from '../../__fixtures__/realFiltrations';
import {
  findEntity,
  instancingBuffer,
  instancingFloats,
  meshInstance,
  renderStage,
} from './harness';

// Real recorded GUDHI cloud (SPEC.md §1.6): the unit tetrahedron, 4 points in 3D.
const TETRA_POINTS = TETRA4_ALPHA.cloud.points;
const TETRA_COUNT = TETRA_POINTS.length / 3;
const WEIGHTS = [0, 0.25, 1, 4];

/** pc.Mat4 is column-major: diagonal at 0/5/10, translation at 12/13/14. */
function instanceMatrix(data: Float32Array, i: number) {
  const m = data.subarray(i * 16, i * 16 + 16);
  return {
    scale: [m[0]!, m[5]!, m[10]!] as const,
    translation: [m[12]!, m[13]!, m[14]!] as const,
  };
}

describe('pointsToPositions (pure helper, no engine)', () => {
  it('packs 3D points into a Float32Array', () => {
    const positions = pointsToPositions([1, 2, 3, 4, 5, 6], 3);
    expect(positions).toBeInstanceOf(Float32Array);
    expect(Array.from(positions)).toEqual([1, 2, 3, 4, 5, 6]);
  });

  it('embeds 2D points at z=0 for display', () => {
    expect(Array.from(pointsToPositions([1, 2, 3, 4], 2))).toEqual([1, 2, 0, 3, 4, 0]);
  });

  it('rejects flat arrays whose length is not a multiple of the dimension', () => {
    expect(() => pointsToPositions([1, 2, 3], 2)).toThrow(/length|multiple/i);
  });

  it('rejects dimensions other than 2 or 3', () => {
    expect(() => pointsToPositions([1, 2, 3, 4], 4 as unknown as 2)).toThrow(/dimension/i);
  });
});

describe('<PointCloud3D> scene graph', () => {
  it('parents an instanced-render entity under the stage root', () => {
    const stage = renderStage(<PointCloud3D points={TETRA_POINTS} dimension={3} />);

    const parent = findEntity(stage.root, 'PointCloud3D');
    expect(parent).not.toBeNull();
    expect(parent!.parent).toBe(stage.root);

    const mi = meshInstance(stage.root, 'PointCloudInstanced');
    expect(mi.material).toBeInstanceOf(pc.StandardMaterial);
  });

  it('draws exactly one instance per point', () => {
    const stage = renderStage(<PointCloud3D points={TETRA_POINTS} dimension={3} />);
    const mi = meshInstance(stage.root, 'PointCloudInstanced');

    expect(TETRA_COUNT).toBe(4);
    expect(mi.instancingCount).toBe(TETRA_COUNT);
    expect(mi.instancingData?.count).toBe(TETRA_COUNT);
    expect(instancingBuffer(mi).numVertices).toBe(TETRA_COUNT);
    expect(instancingBuffer(mi).getNumVertices()).toBe(TETRA_COUNT);
  });

  it('uses the ENGINE matrix-instancing format (ATTR11/12/14/15, not ATTR12..15)', () => {
    // Regression guard: StandardMaterial's instancing chunk skips ATTR13. A
    // hand-rolled ATTR12..15 format leaves a matrix row unbound and draws every
    // instance as a spike through the origin (see utils.createInstancingVertexBuffer).
    const stage = renderStage(<PointCloud3D points={TETRA_POINTS} dimension={3} />);
    const format = instancingBuffer(meshInstance(stage.root, 'PointCloudInstanced')).format;

    expect(format.elements.map((e) => e.name)).toEqual(['ATTR11', 'ATTR12', 'ATTR14', 'ATTR15']);
    expect(format.instancing).toBe(true);
  });

  it('places one uniformly scaled sphere at each point when unweighted', () => {
    const size = 0.05;
    const stage = renderStage(<PointCloud3D points={TETRA_POINTS} dimension={3} size={size} />);
    const data = instancingFloats(meshInstance(stage.root, 'PointCloudInstanced'));

    expect(data).toHaveLength(TETRA_COUNT * 16);
    for (let i = 0; i < TETRA_COUNT; i++) {
      const { scale, translation } = instanceMatrix(data, i);
      expect(scale[0]).toBeCloseTo(size, 6);
      expect(scale[1]).toBeCloseTo(size, 6);
      expect(scale[2]).toBeCloseTo(size, 6);
      expect(translation[0]).toBeCloseTo(TETRA_POINTS[i * 3]!, 6);
      expect(translation[1]).toBeCloseTo(TETRA_POINTS[i * 3 + 1]!, 6);
      expect(translation[2]).toBeCloseTo(TETRA_POINTS[i * 3 + 2]!, 6);
    }
  });

  it('scales weighted markers by size·(1+√wᵢ) (SPEC.md §4.2)', () => {
    const size = 0.05;
    const stage = renderStage(
      <PointCloud3D points={TETRA_POINTS} dimension={3} size={size} weights={WEIGHTS} />,
    );
    const data = instancingFloats(meshInstance(stage.root, 'PointCloudInstanced'));

    for (let i = 0; i < TETRA_COUNT; i++) {
      const expected = size * (1 + Math.sqrt(WEIGHTS[i]!));
      const { scale, translation } = instanceMatrix(data, i);
      expect(scale[0]).toBeCloseTo(expected, 6);
      expect(scale[1]).toBeCloseTo(expected, 6);
      expect(scale[2]).toBeCloseTo(expected, 6);
      // Weight changes the radius only; the centre is still the data point.
      expect(translation[0]).toBeCloseTo(TETRA_POINTS[i * 3]!, 6);
    }
    // w=4 is 3× the radius of w=0: weight is visible on the cloud itself.
    expect(instanceMatrix(data, 3).scale[0]).toBeCloseTo(3 * instanceMatrix(data, 0).scale[0], 6);
  });

  it('embeds a 2D cloud at z=0', () => {
    const flat = [0, 0, 1, 0, 1, 1];
    const stage = renderStage(<PointCloud3D points={flat} dimension={2} />);
    const data = instancingFloats(meshInstance(stage.root, 'PointCloudInstanced'));

    expect(meshInstance(stage.root, 'PointCloudInstanced').instancingCount).toBe(3);
    for (let i = 0; i < 3; i++) {
      expect(instanceMatrix(data, i).translation[2]).toBe(0);
    }
  });

  it('removes its entity from the scene graph when it unmounts', () => {
    const stage = renderStage(<PointCloud3D points={TETRA_POINTS} dimension={3} />);
    expect(findEntity(stage.root, 'PointCloud3D')).not.toBeNull();

    stage.rerender(null);

    expect(findEntity(stage.root, 'PointCloud3D')).toBeNull();
    expect(findEntity(stage.root, 'PointCloudInstanced')).toBeNull();
    expect(stage.root.children).toHaveLength(0);
  });
});
