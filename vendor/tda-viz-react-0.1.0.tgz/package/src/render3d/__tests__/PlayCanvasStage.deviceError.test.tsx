/**
 * <PlayCanvasStage>'s DEFAULT (non-seam) graphics device path: the two ways
 * `pc.createGraphicsDevice` fails in the wild — an outright rejection (no
 * WebGPU adapter, no WebGL2 context — e.g. headless Chromium without
 * swiftshader), and the surprising one, a RESOLVED promise carrying a null
 * device (`device.isNull`) — plus the success case's backend readout and the
 * default fallback message's colour contract (DESIGN.md "Colour": no raw hex,
 * `var(--token)` only).
 *
 * `pc.createGraphicsDevice` is the one thing mocked here, at the module
 * level, so both failure shapes are reproducible without a real GPU. Every
 * other `pc` export — `Application`, `Entity`, `NullGraphicsDevice`, the
 * `DEVICETYPE_*` constants — stays the real engine, exactly as the rest of
 * this suite (./harness) uses it. The `createGraphicsDevice` TEST SEAM
 * (synchronous, no mock needed) covers the success path, same as every other
 * render3d test.
 */
import { render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import * as pc from 'playcanvas';
import { PlayCanvasStage, usePlayCanvas, type PlayCanvasContextValue } from '../PlayCanvasStage';
import { nullDevice } from './harness';

vi.mock('playcanvas', async (importOriginal) => {
  const actual = await importOriginal<typeof import('playcanvas')>();
  return { ...actual, createGraphicsDevice: vi.fn(actual.createGraphicsDevice) };
});

function mockedCreateGraphicsDevice() {
  return vi.mocked(pc.createGraphicsDevice);
}

/** Records the context value on every render it is given. */
function ContextProbe({ onRender }: { onRender: (v: PlayCanvasContextValue) => void }) {
  onRender(usePlayCanvas());
  return <div data-testid="probe" />;
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('<PlayCanvasStage> default graphics device path: rejection', () => {
  it('sets error, shows the default fallback, and calls onError exactly once', async () => {
    vi.spyOn(console, 'warn').mockImplementation(() => {});
    mockedCreateGraphicsDevice().mockRejectedValueOnce(new Error('no WebGPU adapter'));
    const onError = vi.fn();
    const seen: PlayCanvasContextValue[] = [];

    const { container } = render(
      <PlayCanvasStage onError={onError}>
        <ContextProbe onRender={(v) => seen.push(v)} />
      </PlayCanvasStage>,
    );

    await waitFor(() => expect(onError).toHaveBeenCalledTimes(1));

    // No children ever mounted against a failed engine.
    expect(seen).toHaveLength(0);
    const [reportedError] = onError.mock.calls[0]!;
    expect(reportedError).toBeInstanceOf(Error);
    expect((reportedError as Error).message).toBe('no WebGPU adapter');
    expect(screen.getByTestId('playcanvas-stage-fallback')).toBeInTheDocument();
    expect(container.querySelector('[data-device]')).toHaveAttribute('data-device', 'none');
  });
});

describe('<PlayCanvasStage> default graphics device path: resolved-null device', () => {
  it('treats a RESOLVED null device the same as a rejection, and frees it', async () => {
    // The engine's own documented surprise: createGraphicsDevice resolves
    // rather than rejects when every requested backend is unavailable, always
    // appending DEVICETYPE_NULL as the last-ditch fallback. The failure path
    // must check `device.isNull`, not just the promise's success/failure.
    vi.spyOn(console, 'warn').mockImplementation(() => {});
    const device = new pc.NullGraphicsDevice(document.createElement('canvas'));
    expect(device.isNull).toBe(true);
    const destroy = vi.spyOn(device, 'destroy');
    mockedCreateGraphicsDevice().mockResolvedValueOnce(device);
    const onError = vi.fn();
    const seen: PlayCanvasContextValue[] = [];

    const { container } = render(
      <PlayCanvasStage onError={onError}>
        <ContextProbe onRender={(v) => seen.push(v)} />
      </PlayCanvasStage>,
    );

    await waitFor(() => expect(onError).toHaveBeenCalledTimes(1));

    expect(seen).toHaveLength(0);
    expect(onError.mock.calls[0]![0]).toBeInstanceOf(Error);
    expect(screen.getByTestId('playcanvas-stage-fallback')).toBeInTheDocument();
    expect(container.querySelector('[data-device]')).toHaveAttribute('data-device', 'none');
    // The unusable device is freed, not leaked.
    expect(destroy).toHaveBeenCalledTimes(1);
  });
});

describe('<PlayCanvasStage> success reports the real backend', () => {
  it('deviceType / data-device read the achieved backend and children render', () => {
    // The seam path never runs the isNull check (that guards only the default
    // pc.createGraphicsDevice path), so a real NullGraphicsDevice with a
    // faked `deviceType` exercises exactly the mapping under test —
    // PlayCanvasStage's webgpu/webgl2/null classification — without touching
    // any other engine behaviour.
    const seen: PlayCanvasContextValue[] = [];

    const { container } = render(
      <PlayCanvasStage
        createGraphicsDevice={(canvas) => {
          const device = nullDevice(canvas);
          Object.defineProperty(device, 'deviceType', {
            value: pc.DEVICETYPE_WEBGL2,
            configurable: true,
          });
          return device;
        }}
      >
        <ContextProbe onRender={(v) => seen.push(v)} />
      </PlayCanvasStage>,
    );

    expect(seen).toHaveLength(1);
    expect(seen[0]!.error).toBeNull();
    expect(seen[0]!.deviceType).toBe('webgl2');
    expect(container.querySelector('[data-device]')).toHaveAttribute('data-device', 'webgl2');
    expect(screen.getByTestId('probe')).toBeInTheDocument();
  });
});

describe('<PlayCanvasStage> default fallback message', () => {
  it('renders no hex colour literal (DESIGN.md: colours come from var(--token))', () => {
    vi.spyOn(console, 'warn').mockImplementation(() => {});

    const { container } = render(
      <PlayCanvasStage
        createGraphicsDevice={() => {
          throw new Error('no graphics device in this environment');
        }}
      />,
    );

    expect(screen.getByTestId('playcanvas-stage-fallback')).toHaveTextContent(/webgpu|webgl2/i);
    expect(container.innerHTML).not.toMatch(/#[0-9a-f]{3,8}\b/i);
  });
});
