import type { Meta, StoryObj } from '@storybook/react-vite';
import { PlayCanvasStage } from './PlayCanvasStage';

/**
 * The fallback state, which is this file's reason for existing: when
 * `createGraphicsDevice` fails — no WebGPU adapter, no WebGL2 context, e.g. a
 * headless Chromium without swiftshader — the stage renders `fallback` (a
 * node, or a function of the `Error`) or, with neither `fallback` nor
 * `onError` supplied, its own plain one-sentence message set from the
 * stage's own tokens (`var(--token)`, never a raw hex — DESIGN.md "Colour").
 * It never falls back to a silent blank canvas.
 *
 * Both stories below force the failure with the library's own
 * `createGraphicsDevice` TEST SEAM, so the fallback renders deterministically
 * regardless of this browser's actual WebGPU/WebGL2 support — the same seam
 * `src/render3d/__tests__/PlayCanvasStage.test.tsx` uses.
 */
const meta = {
  title: '3D/PlayCanvasStage',
  component: PlayCanvasStage,
  tags: ['autodocs'],
} satisfies Meta<typeof PlayCanvasStage>;

export default meta;
type Story = StoryObj<typeof meta>;

const forceDeviceFailure = () => {
  throw new Error('No WebGPU adapter and no WebGL2 context in this environment.');
};

/** No `fallback` prop: the stage's own default message, never a blank canvas. */
export const DeviceFailureDefaultMessage: Story = {
  args: {
    style: { width: 480, height: 360 },
    createGraphicsDevice: forceDeviceFailure,
  },
};

/** A caller-supplied `fallback` function, rendered with the real `Error`. */
export const DeviceFailureCustomFallback: Story = {
  args: {
    style: { width: 480, height: 360 },
    createGraphicsDevice: forceDeviceFailure,
    fallback: (error: Error) => (
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '1.5rem',
          textAlign: 'center',
          fontFamily: 'ui-monospace, monospace',
          fontSize: 13,
          color: 'var(--text-on-ink, rgb(232, 230, 225))',
          background: 'var(--ink-2, rgb(17, 26, 46))',
        }}
      >
        3D preview unavailable: {error.message}
      </div>
    ),
  },
};
