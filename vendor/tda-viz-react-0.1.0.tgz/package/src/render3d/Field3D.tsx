/**
 * <Field3D>: the union of the growing shapes at scale t, in 3D — instanced
 * spheres with PER-POINT radii, oriented ellipsoids, or the box filtration's
 * grown boxes (SPEC.md §4.1).
 *
 * Lives ONLY under `tda-viz-react/3d` (SPEC.md §2/§4) and must be rendered
 * inside a <PlayCanvasStage>.
 *
 * GPU-DRIVEN SCALE (SPEC.md §1.5): the per-instance data is uploaded ONCE per
 * cloud and never re-uploaded when t moves.
 *
 *   ball      — centre + the point's weight; the radius is evaluated in the
 *               vertex shader from `uT`. `radiusFromT` is the exact GLSL/WGSL
 *               transcription of `Filtration.radiusAt` for all three
 *               conventions.
 *   ellipsoid — centre + the UNIT semi-axis profile + two frame rows (the third
 *               is their cross product, and an ellipsoid is symmetric so its
 *               sign is immaterial). The shader scales the unit sphere by
 *               (t/2)·profile along the frame, which is `ellipsoidSemiAxesAt`.
 *               The frame is FIXED at build time — re-fitting per scale would
 *               break X_s ⊆ X_t (SPEC.md §1.1).
 *   box       — every grown box of EVERY step, with its step index. Boxes exist
 *               only on the grid, so `uStep = ⌊t/π⌋` selects which ones draw:
 *               a lookup, never an interpolation, and still one uniform write.
 *
 * WHAT IT REFUSES. The wing complex is 2D only — in the engine and in the
 * mathematics (tda-wasm `WASM_HONESTY.md`: "3D is open research and is not
 * attempted") — so a wing filtration is a type error here, and a runtime throw
 * for JavaScript callers, rather than a hexagon extruded into a shape nobody
 * has defined. A filtration whose `shapesAvailable` is false draws no geometry
 * and says why in its entity's userData (SPEC.md §1.6).
 *
 * HONESTY LABEL (SPEC.md §8 Q2): this is an APPROXIMATION of X_t. Translucent
 * instances double-count overlapping regions instead of merging into one
 * surface; a marching-cubes union over the SDF would be exact but heavy.
 * The approximation is declared in the entity's userData and in this doc —
 * do not present this as the merged region <Field2D> draws.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import * as pc from 'playcanvas';
import { boxStepAt } from '../filtration/shapes';
import type {
  BallConvention,
  BallFiltration,
  BoxFiltration,
  EllipsoidFiltration,
  GrowingShapeKind,
} from '../filtration/types';
import { usePlayCanvas } from './PlayCanvasStage';
import { pointsToPositions } from './PointCloud3D';
import {
  SHADE_GLSL,
  SHADE_WGSL,
  createBoxMesh,
  createInstanceStreamsBuffer,
  createSphereMesh,
  destroyEntity,
  parseColor,
} from './utils';

/**
 * The filtrations this surface can draw. The wing is missing deliberately: it
 * is a 2D construction, and there is no 3D wing to draw (see the file header).
 */
export type Field3DFiltration = BallFiltration | EllipsoidFiltration | BoxFiltration;

export interface Field3DProps {
  /**
   * A ball, ellipsoid or box filtration. Which one decides the shader; the
   * shape law itself always comes from the filtration (SPEC.md §1.3).
   */
  filtration: Field3DFiltration;
  /** Current scale. Filters what is drawn; never triggers a recompute (SPEC.md §1.5). */
  t: number;
  color?: string;
  opacity?: number;
  /** Sphere tessellation bands (balls and ellipsoids). */
  segments?: number;
}

export const APPROXIMATION_LABEL =
  'instanced spheres: translucent balls double-count overlaps; not the merged union surface (SPEC.md §8 Q2)';

/**
 * The same caveat, per shape (SPEC.md §8 Q2). Every one of these is an
 * approximation for the same reason: translucent instances double-count their
 * overlaps, which are the regions the complex is about.
 */
export const APPROXIMATION_LABELS: Record<GrowingShapeKind, string> = {
  ball: APPROXIMATION_LABEL,
  ellipsoid:
    'instanced ellipsoids: translucent shapes double-count overlaps; not the merged union surface (SPEC.md §8 Q2)',
  box: 'instanced boxes: translucent shapes double-count overlaps; not the merged union surface (SPEC.md §8 Q2)',
  wing: 'the wing complex is 2D only: there is no 3D wing to draw',
};

/**
 * The refusal (SPEC.md §1.6). Thrown, not logged: a caller who hands this
 * surface a wing filtration is asking for a picture of something the engine
 * does not build and the source paper does not define, and quietly drawing
 * nothing would look like an empty filtration.
 */
function assertDrawableIn3D(filtration: { shapeKind: GrowingShapeKind }): void {
  if (filtration.shapeKind === 'wing') {
    throw new Error(
      '<Field3D> cannot draw a wing filtration: the wing complex is 2D only, in the ' +
        'engine and in the mathematics (tda-wasm WASM_HONESTY.md: "3D is open research ' +
        'and is not attempted"). Use <Field2D>, which draws the hexagons the engine ' +
        'actually built.',
    );
  }
}

/**
 * Selector handed to the shader as `uConvention`. Kept as a float uniform so
 * one compiled shader serves every convention.
 */
const CONVENTION_CODE: Record<BallConvention, number> = {
  rips: 0,
  cech: 1,
  alpha: 2,
};

/**
 * Per-instance stream: xyz = sphere centre, w = the point's weight wᵢ. Those
 * are the only per-point constants `radiusAt` needs, for every convention.
 */
const SEMANTIC_INSTANCE_SPHERE = pc.SEMANTIC_ATTR12;

const FIELD_VS = /* glsl */ `
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec4 aInstanceSphere;

uniform mat4 matrix_model;
uniform mat4 matrix_viewProjection;
uniform mat3 matrix_normal;

uniform float uT;
uniform float uConvention;

varying vec3 vNormal;

// EXACT transcription of Filtration.radiusAt (src/filtration/createFiltration.ts):
//   rips  -> max(t, 0) / 2      (t is edge length; balls touch when points are t apart)
//   cech  -> max(t, 0)          (t is the ball radius)
//   alpha -> sqrt(max(t + w, 0)) (t is squared radius, per point; SPEC.md §1.3)
// The clamps are what keep the picture monotone in t (SPEC.md §1.1): a radius
// never goes imaginary and never shrinks as t grows.
float radiusFromT(float t, float w) {
    if (uConvention < 0.5) return max(t, 0.0) * 0.5;
    if (uConvention < 1.5) return max(t, 0.0);
    return sqrt(max(t + w, 0.0));
}

void main(void) {
    float r = radiusFromT(uT, aInstanceSphere.w);
    vNormal = matrix_normal * aNormal;
    if (r <= 0.0) {
        // A ball that has not been born yet does not exist — <Field2D> skips
        // r <= 0 for the same reason ("drawing a dot would be fiction"). Clip
        // the instance outright instead of submitting a degenerate sphere,
        // which conservative rasterizers can still speckle. r > 0 is monotone
        // in t for every convention, so nothing vanishes as t grows (§1.1).
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    } else {
        vec3 local = aInstanceSphere.xyz + aPosition * r;
        gl_Position = matrix_viewProjection * matrix_model * vec4(local, 1.0);
    }
}
`;

/**
 * Exported for the shader-source tests: NullGraphicsDevice never compiles
 * GLSL/WGSL, so the load-bearing lines are pinned at source level instead
 * (src/render3d/__tests__/Field3D.test.tsx).
 */
export const FIELD_VERTEX_GLSL = FIELD_VS;

/**
 * Native WGSL for the WebGPU device. GLSL-only ShaderMaterial does NOT
 * compile on WebGPU in PlayCanvas 2.21.4 unless glslangUrl+twgslUrl are
 * passed to createGraphicsDevice — WebgpuShader.transpile errors when
 * those transpilers are absent. ShaderGeneratorShader.createShaderDefinition
 * picks WGSL iff both vertexWGSL and fragmentWGSL are set.
 */
const FIELD_VS_WGSL = /* wgsl */ `
attribute aPosition: vec3f;
attribute aNormal: vec3f;
attribute aInstanceSphere: vec4f;

uniform matrix_model: mat4x4f;
uniform matrix_viewProjection: mat4x4f;
uniform matrix_normal: mat3x3f;

uniform uT: f32;
uniform uConvention: f32;

varying vNormal: vec3f;

// EXACT transcription of Filtration.radiusAt (src/filtration/createFiltration.ts):
//   rips  -> max(t, 0) / 2
//   cech  -> max(t, 0)
//   alpha -> sqrt(max(t + w, 0))
// The clamps are what keep the picture monotone in t (SPEC.md §1.1).
fn radiusFromT(t: f32, w: f32) -> f32 {
    if (uniform.uConvention < 0.5) {
        return max(t, 0.0) * 0.5;
    }
    if (uniform.uConvention < 1.5) {
        return max(t, 0.0);
    }
    return sqrt(max(t + w, 0.0));
}

@vertex
fn vertexMain(input: VertexInput) -> VertexOutput {
    var output: VertexOutput;
    let r = radiusFromT(uniform.uT, input.aInstanceSphere.w);
    output.vNormal = uniform.matrix_normal * input.aNormal;
    if (r <= 0.0) {
        // A ball that has not been born yet does not exist — same honesty
        // clip as the GLSL path (off-frustum, not a degenerate sphere).
        output.position = vec4f(2.0, 2.0, 2.0, 1.0);
    } else {
        let local = input.aInstanceSphere.xyz + input.aPosition * r;
        output.position = uniform.matrix_viewProjection * uniform.matrix_model * vec4f(local, 1.0);
    }
    return output;
}
`;

export const FIELD_VERTEX_WGSL = FIELD_VS_WGSL;

// ── Ellipsoids (SPEC.md §1.3: semi-axes (t/2)·profile on a FIXED frame) ───

/**
 * Per-instance streams for an oriented ellipsoid. Four vec4s because a
 * `VertexElement` holds at most 4 components and the record needs 14 numbers:
 * centre, the UNIT semi-axis profile, and two frame rows. The third row is
 * `cross(f0, f1)`, which is ±frame[2]; an ellipsoid is symmetric about its
 * centre, so the sign cannot change the shape.
 */
const SEMANTIC_INSTANCE_CENTER = pc.SEMANTIC_ATTR12;
const SEMANTIC_INSTANCE_AXES = pc.SEMANTIC_ATTR13;
const SEMANTIC_INSTANCE_FRAME0 = pc.SEMANTIC_ATTR14;
const SEMANTIC_INSTANCE_FRAME1 = pc.SEMANTIC_ATTR15;

const ELLIPSOID_VS = /* glsl */ `
attribute vec3 aPosition;
attribute vec4 aInstanceCenter;
attribute vec4 aInstanceAxes;
attribute vec4 aInstanceFrame0;
attribute vec4 aInstanceFrame1;

uniform mat4 matrix_model;
uniform mat4 matrix_viewProjection;
uniform mat3 matrix_normal;

uniform float uT;

varying vec3 vNormal;

void main(void) {
    // EXACT transcription of ellipsoidSemiAxesAt (src/filtration/shapes.ts):
    // the engine's filtration value is TWICE the birth radius, so at value t
    // the semi-axis LENGTHS are (t/2) * profile (SPEC.md §1.3).
    float s = max(uT, 0.0) * 0.5;
    vec3 a = aInstanceAxes.xyz * s;
    vec3 f0 = aInstanceFrame0.xyz;
    vec3 f1 = aInstanceFrame1.xyz;
    vec3 f2 = cross(f0, f1);

    if (s <= 0.0 || max(a.x, max(a.y, a.z)) <= 0.0) {
        // Nothing has grown yet. Clip off-frustum rather than submit a
        // degenerate ellipsoid (same honesty rule as an unborn ball).
        vNormal = f2;
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    } else {
        vec3 local = aInstanceCenter.xyz
            + (a.x * aPosition.x) * f0
            + (a.y * aPosition.y) * f1
            + (a.z * aPosition.z) * f2;

        // Normal of an ellipsoid is the INVERSE-transpose direction: divide by
        // the semi-axes where you multiplied to build the point.
        vec3 nRaw;
        if (a.z <= 0.0) {
            // A 2D ellipsoid filtration drawn in 3D is a flat ellipse in the
            // frame plane; its normal is the plane normal, not an in-plane
            // gradient.
            nRaw = f2;
        } else {
            nRaw = (aPosition.x / max(a.x, 1e-8)) * f0
                 + (aPosition.y / max(a.y, 1e-8)) * f1
                 + (aPosition.z / max(a.z, 1e-8)) * f2;
        }
        vNormal = matrix_normal * normalize(nRaw);
        gl_Position = matrix_viewProjection * matrix_model * vec4(local, 1.0);
    }
}
`;

const ELLIPSOID_VS_WGSL = /* wgsl */ `
attribute aPosition: vec3f;
attribute aInstanceCenter: vec4f;
attribute aInstanceAxes: vec4f;
attribute aInstanceFrame0: vec4f;
attribute aInstanceFrame1: vec4f;

uniform matrix_model: mat4x4f;
uniform matrix_viewProjection: mat4x4f;
uniform matrix_normal: mat3x3f;

uniform uT: f32;

varying vNormal: vec3f;

@vertex
fn vertexMain(input: VertexInput) -> VertexOutput {
    var output: VertexOutput;
    // Same law as the GLSL path: semi-axes (t/2) * profile (SPEC.md §1.3).
    let s = max(uniform.uT, 0.0) * 0.5;
    let a = input.aInstanceAxes.xyz * s;
    let f0 = input.aInstanceFrame0.xyz;
    let f1 = input.aInstanceFrame1.xyz;
    let f2 = cross(f0, f1);

    if (s <= 0.0 || max(a.x, max(a.y, a.z)) <= 0.0) {
        output.vNormal = f2;
        output.position = vec4f(2.0, 2.0, 2.0, 1.0);
    } else {
        let local = input.aInstanceCenter.xyz
            + (a.x * input.aPosition.x) * f0
            + (a.y * input.aPosition.y) * f1
            + (a.z * input.aPosition.z) * f2;

        var nRaw = f2;
        if (a.z > 0.0) {
            nRaw = (input.aPosition.x / max(a.x, 1e-8)) * f0
                 + (input.aPosition.y / max(a.y, 1e-8)) * f1
                 + (input.aPosition.z / max(a.z, 1e-8)) * f2;
        }
        output.vNormal = uniform.matrix_normal * normalize(nRaw);
        output.position = uniform.matrix_viewProjection * uniform.matrix_model * vec4f(local, 1.0);
    }
    return output;
}
`;

export const ELLIPSOID_VERTEX_GLSL = ELLIPSOID_VS;
export const ELLIPSOID_VERTEX_WGSL = ELLIPSOID_VS_WGSL;

// ── Boxes (SPEC.md §1.3: the box at t is a LOOKUP on the π grid) ──────────

/** Per-instance streams for a grown box: centre + step index, and extent. */
const SEMANTIC_INSTANCE_BOX = pc.SEMANTIC_ATTR12;
const SEMANTIC_INSTANCE_EXTENT = pc.SEMANTIC_ATTR13;

const BOX_VS = /* glsl */ `
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec4 aInstanceBox;
attribute vec4 aInstanceExtent;

uniform mat4 matrix_model;
uniform mat4 matrix_viewProjection;
uniform mat3 matrix_normal;

uniform float uStep;

varying vec3 vNormal;

void main(void) {
    vNormal = matrix_normal * aNormal;
    // EVERY step's boxes are resident; uStep = floor(t / π) picks the last
    // COMPLETED step. A box that belongs to another step is clipped, so the
    // drawing is always one of the engine's own boxes and never an
    // interpolation between two of them (SPEC.md §1.1, §1.3).
    if (abs(aInstanceBox.w - uStep) > 0.5
        || max(aInstanceExtent.x, max(aInstanceExtent.y, aInstanceExtent.z)) <= 0.0) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    } else {
        // aPosition spans the unit cube's ±0.5, so this spans centre ± extent/2.
        vec3 local = aInstanceBox.xyz + aPosition * aInstanceExtent.xyz;
        gl_Position = matrix_viewProjection * matrix_model * vec4(local, 1.0);
    }
}
`;

const BOX_VS_WGSL = /* wgsl */ `
attribute aPosition: vec3f;
attribute aNormal: vec3f;
attribute aInstanceBox: vec4f;
attribute aInstanceExtent: vec4f;

uniform matrix_model: mat4x4f;
uniform matrix_viewProjection: mat4x4f;
uniform matrix_normal: mat3x3f;

uniform uStep: f32;

varying vNormal: vec3f;

@vertex
fn vertexMain(input: VertexInput) -> VertexOutput {
    var output: VertexOutput;
    output.vNormal = uniform.matrix_normal * input.aNormal;
    let extent = input.aInstanceExtent.xyz;
    if (abs(input.aInstanceBox.w - uniform.uStep) > 0.5
        || max(extent.x, max(extent.y, extent.z)) <= 0.0) {
        output.position = vec4f(2.0, 2.0, 2.0, 1.0);
    } else {
        let local = input.aInstanceBox.xyz + input.aPosition * extent;
        output.position = uniform.matrix_viewProjection * uniform.matrix_model * vec4f(local, 1.0);
    }
    return output;
}
`;

export const BOX_VERTEX_GLSL = BOX_VS;
export const BOX_VERTEX_WGSL = BOX_VS_WGSL;

const FIELD_FS = /* glsl */ `
${SHADE_GLSL}

varying vec3 vNormal;

uniform vec3 uColor;
uniform float uOpacity;

void main(void) {
    gl_FragColor = vec4(gammaCorrectOutput(tdaShade(uColor, vNormal)), uOpacity);
}
`;

const FIELD_FS_WGSL = /* wgsl */ `
${SHADE_WGSL}

varying vNormal: vec3f;

uniform uColor: vec3f;
uniform uOpacity: f32;

@fragment
fn fragmentMain(input: FragmentInput) -> FragmentOutput {
    var output: FragmentOutput;
    output.color = vec4f(gammaCorrectOutput(tdaShade(uniform.uColor, input.vNormal)), uniform.uOpacity);
    return output;
}
`;

/**
 * The per-instance record for one filtration, plus the vertex layout it needs.
 * Built from `filtration.shapeAt` — never from a scale law re-derived here.
 */
function instanceStream(filtration: Field3DFiltration): {
  data: Float32Array;
  count: number;
  elements: Array<{ semantic: string; components: number }>;
} {
  const { cloud } = filtration;
  const pointCount = cloud.points.length / cloud.dimension;
  const positions = pointsToPositions(cloud.points, cloud.dimension);

  if (filtration.shapeKind === 'ball') {
    // xyz = centre, w = the point's weight: the only per-point constants
    // `radiusAt` needs, for every convention.
    const data = new Float32Array(pointCount * 4);
    for (let i = 0; i < pointCount; i++) {
      data[i * 4] = positions[i * 3] ?? 0;
      data[i * 4 + 1] = positions[i * 3 + 1] ?? 0;
      data[i * 4 + 2] = positions[i * 3 + 2] ?? 0;
      data[i * 4 + 3] = cloud.weights[i] ?? 0;
    }
    return {
      data,
      count: pointCount,
      elements: [{ semantic: SEMANTIC_INSTANCE_SPHERE, components: 4 }],
    };
  }

  if (filtration.shapeKind === 'ellipsoid') {
    // The UNIT profile straight from the contract (`unitShape`), because that is
    // what the shader scales by t/2 and the stream must never move (SPEC.md
    // §1.5). Recovering it as `shapeAt(i, 2).semiAxes` is exact under
    // `ellipsoid-2r` and was what this did, but it encoded the scale law here
    // instead of in the filtration layer. 2D clouds get a zero third axis — a
    // flat ellipse in the frame plane, which is where that shape lives.
    const data = new Float32Array(pointCount * 16);
    for (let i = 0; i < pointCount; i++) {
      const shape = filtration.unitShape(i);
      const base = i * 16;
      data[base] = shape.center[0] ?? 0;
      data[base + 1] = shape.center[1] ?? 0;
      data[base + 2] = shape.center[2] ?? 0;
      data[base + 4] = shape.semiAxes[0] ?? 0;
      data[base + 5] = shape.semiAxes[1] ?? 0;
      data[base + 6] = shape.semiAxes[2] ?? 0;
      for (const [row, offset] of [
        [0, 8],
        [1, 12],
      ] as const) {
        const f = shape.frame[row] ?? [];
        data[base + offset] = f[0] ?? 0;
        data[base + offset + 1] = f[1] ?? 0;
        // A 2D frame row has no z; cross(f0, f1) is then ±(0, 0, 1), which is
        // the plane normal, so the flat case comes out right.
        data[base + offset + 2] = f[2] ?? 0;
      }
    }
    return {
      data,
      count: pointCount,
      elements: [
        { semantic: SEMANTIC_INSTANCE_CENTER, components: 4 },
        { semantic: SEMANTIC_INSTANCE_AXES, components: 4 },
        { semantic: SEMANTIC_INSTANCE_FRAME0, components: 4 },
        { semantic: SEMANTIC_INSTANCE_FRAME1, components: 4 },
      ],
    };
  }

  // Box: EVERY step's boxes, each tagged with its step. Boxes are a lookup on
  // the grid (SPEC.md §1.3), so uploading them all keeps scrubbing t to one
  // uniform write instead of a per-step re-upload. `boxesAtStep` hands over one
  // step's row of the engine's `(steps + 1) × n` records, so this loop never has
  // to turn a step index back into a t and hope the grid arithmetic agrees.
  const { steps } = filtration.quantization;
  const stepCount = steps + 1;
  const data = new Float32Array(pointCount * stepCount * 8);
  const dim = cloud.dimension;
  let at = 0;
  for (let s = 0; s < stepCount; s++) {
    for (const box of filtration.boxesAtStep(s)) {
      for (let a = 0; a < 3; a++) {
        const lo = a < dim ? (box.lower[a] ?? 0) : 0;
        const hi = a < dim ? (box.upper[a] ?? 0) : 0;
        data[at + a] = (lo + hi) / 2;
        data[at + 4 + a] = hi - lo;
      }
      data[at + 3] = box.step;
      at += 8;
    }
  }
  return {
    data,
    count: pointCount * stepCount,
    elements: [
      { semantic: SEMANTIC_INSTANCE_BOX, components: 4 },
      { semantic: SEMANTIC_INSTANCE_EXTENT, components: 4 },
    ],
  };
}

/** The shader pair and attribute map for a shape kind. */
function shaderFor(shapeKind: 'ball' | 'ellipsoid' | 'box'): {
  uniqueName: string;
  attributes: Record<string, string>;
  vertexGLSL: string;
  vertexWGSL: string;
} {
  switch (shapeKind) {
    case 'ball':
      return {
        uniqueName: 'TdaField3D',
        attributes: {
          aPosition: pc.SEMANTIC_POSITION,
          aNormal: pc.SEMANTIC_NORMAL,
          aInstanceSphere: SEMANTIC_INSTANCE_SPHERE,
        },
        vertexGLSL: FIELD_VS,
        vertexWGSL: FIELD_VS_WGSL,
      };
    case 'ellipsoid':
      return {
        uniqueName: 'TdaField3DEllipsoid',
        attributes: {
          aPosition: pc.SEMANTIC_POSITION,
          aInstanceCenter: SEMANTIC_INSTANCE_CENTER,
          aInstanceAxes: SEMANTIC_INSTANCE_AXES,
          aInstanceFrame0: SEMANTIC_INSTANCE_FRAME0,
          aInstanceFrame1: SEMANTIC_INSTANCE_FRAME1,
        },
        vertexGLSL: ELLIPSOID_VS,
        vertexWGSL: ELLIPSOID_VS_WGSL,
      };
    case 'box':
      return {
        uniqueName: 'TdaField3DBox',
        attributes: {
          aPosition: pc.SEMANTIC_POSITION,
          aNormal: pc.SEMANTIC_NORMAL,
          aInstanceBox: SEMANTIC_INSTANCE_BOX,
          aInstanceExtent: SEMANTIC_INSTANCE_EXTENT,
        },
        vertexGLSL: BOX_VS,
        vertexWGSL: BOX_VS_WGSL,
      };
  }
}

export function Field3D({
  filtration,
  t,
  color = '#2563eb',
  opacity = 0.22,
  segments = 24,
}: Field3DProps) {
  // Refused before anything is built: a wing has no 3D shape to draw, and a
  // silent empty scene would read as an empty filtration (see the header).
  assertDrawableIn3D(filtration);

  const { app, rootEntity } = usePlayCanvas();
  // Held in state (not a ref) so the cheap uniform effects below re-run
  // whenever the material is actually rebuilt, and only then.
  const [material, setMaterial] = useState<pc.ShaderMaterial | null>(null);
  /** The parent entity, for the uConvention effect's userData mirror. */
  const entityRef = useRef<pc.Entity | null>(null);

  const { cloud, convention, shapeKind, shapesAvailable, shapesUnavailableReason } = filtration;
  const count = cloud.points.length / cloud.dimension;

  /** Uploaded once per (cloud, shape). Never re-uploaded when t moves. */
  const stream = useMemo(
    () => (shapesAvailable ? instanceStream(filtration) : null),
    [filtration, shapesAvailable],
  );

  /**
   * Which grown box to show, from the filtration's own grid (SPEC.md §1.3).
   * A number for the box path, null otherwise — the shader for the other shapes
   * has no step to select.
   */
  const boxStep =
    filtration.shapeKind === 'box'
      ? boxStepAt(t, filtration.quantization.step, filtration.quantization.steps)
      : null;

  // Build ONCE per (app, cloud, shape, tessellation). Nothing here depends on
  // t — or on the convention, which is uniform-only (the effect below owns both
  // the uConvention parameter and the userData mirror of it).
  useEffect(() => {
    if (!app || !rootEntity || count === 0) return;

    const parent = new pc.Entity('Field3D', app);
    (parent as unknown as { userData: Record<string, string> }).userData = {
      approximation: APPROXIMATION_LABELS[shapeKind],
      shapeKind,
      // The engine did not hand over the geometry, so nothing is drawn and the
      // scene carries the filtration's own reason (SPEC.md §1.6).
      ...(shapesUnavailableReason ? { shapesUnavailable: shapesUnavailableReason } : {}),
    };
    entityRef.current = parent;
    rootEntity.addChild(parent);

    if (!stream) {
      // No shapes to draw. The entity exists so the reason above is findable.
      return () => {
        entityRef.current = null;
        destroyEntity(parent);
      };
    }

    const shader = shaderFor(shapeKind);
    const mat = new pc.ShaderMaterial({
      ...shader,
      fragmentGLSL: FIELD_FS,
      fragmentWGSL: FIELD_FS_WGSL,
    });
    mat.blendType = pc.BLEND_NORMAL;
    mat.cull = pc.CULLFACE_NONE;
    mat.depthWrite = false;
    mat.update();

    const mesh =
      shapeKind === 'box'
        ? createBoxMesh(app.graphicsDevice)
        : createSphereMesh(app.graphicsDevice, segments);

    const vb = createInstanceStreamsBuffer(
      app.graphicsDevice,
      stream.data,
      stream.count,
      stream.elements,
    );

    const meshInstance = new pc.MeshInstance(mesh, mat);
    // The mesh's CPU aabb is the unit sphere / unit cube at the origin: the real
    // extent is produced in the vertex shader and the engine cannot know it.
    // setInstancing already sets cull = false; state it explicitly so a later
    // edit cannot silently reintroduce frustum culling against a meaningless
    // bound.
    meshInstance.setInstancing(vb);
    meshInstance.cull = false;

    const renderEntity = new pc.Entity('Field3DInstanced', app);
    renderEntity.addComponent('render', { meshInstances: [meshInstance] });
    parent.addChild(renderEntity);

    setMaterial(mat);

    return () => {
      setMaterial(null);
      entityRef.current = null;
      destroyEntity(parent);
      vb.destroy();
      mat.destroy();
      mesh.destroy();
    };
  }, [app, rootEntity, stream, count, segments, shapeKind, shapesUnavailableReason]);

  // Scrubbing t: ONE uniform write, no geometry work (SPEC.md §1.5). The box
  // path writes the step index instead of t, because its shape is a lookup on
  // the grid and t between grid values means the same box.
  useEffect(() => {
    if (!material) return;
    material.setParameter('uT', t);
    if (boxStep !== null) material.setParameter('uStep', boxStep);
  }, [material, t, boxStep]);

  useEffect(() => {
    if (!material) return;
    if (shapeKind === 'ball') {
      material.setParameter('uConvention', CONVENTION_CODE[convention as BallConvention]);
    }
    // Keep the honesty label's convention field in step with the uniform —
    // a convention change is uniform-only and must not rebuild geometry.
    const parent = entityRef.current as unknown as {
      userData: Record<string, string>;
    } | null;
    if (parent) parent.userData.convention = convention;
  }, [material, convention, shapeKind]);

  useEffect(() => {
    if (!material) return;
    const c = parseColor(color);
    material.setParameter('uColor', [c.r, c.g, c.b]);
    material.setParameter('uOpacity', opacity);
  }, [material, color, opacity]);

  return null;
}
