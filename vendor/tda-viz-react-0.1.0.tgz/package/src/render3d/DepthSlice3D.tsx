/**
 * <DepthSlice3D>: the covering depth of a k-fold cover, painted exactly on a
 * plane through the cloud (SPEC.md §4.5).
 *
 * Lives ONLY under `tda-viz-react/3d` and must be rendered inside a
 * <PlayCanvasStage>, beside <PointCloud3D>, <Field3D> and <Nerve3D>.
 *
 * WHAT IT DRAWS, AND WHY IT IS NOT <Field3D>. For a k-fold cover the union of
 * the balls is the ONE-fold cover. It is not the object the complex is about,
 * and drawing it — which is what <Field3D> does, honestly labelled as an
 * approximation — says nothing about k. The k-fold cover is the region covered
 * at least k times, so this component evaluates the count: a quad is placed
 * across the cloud and every fragment on it counts the balls of squared radius
 * t that contain it, then takes its colour from that count. Depth 0 is
 * transparent; 1, 2, 3 and ≥4 take the four ramp colours the caller supplies.
 *
 * EXACT, NOT A SHADING TRICK. The fragment shader evaluates
 *
 *     depth(x) = #{ i : |x - cᵢ|² ≤ t }
 *
 * per pixel over every centre in the cloud — no distance field, no blur, no
 * accumulated alpha standing in for a count. Two regions of depth ≥ 4 merge on
 * screen exactly when they merge in R³, because the picture is the predicate.
 * `coveringDepthAt` (./depthSlice.ts) is the ORACLE for the GLSL and the WGSL
 * below: it is the same formula in TypeScript, tested against brute force, and
 * the shader is its transcription. Change one and you must change all three.
 *
 * WHY t IS A SQUARED RADIUS HERE. The k-fold cover carries the `alpha`
 * convention on an UNWEIGHTED cloud (the engine refuses weights for it), so
 * `radiusAt(i, t) = √(t + 0) = √t` for every point and the membership test
 * needs no per-point weight term. Comparing squared distances against t
 * directly is that law, not a shortcut around it.
 *
 * WHAT IT REFUSES. Anything that is not a 3D k-fold cover filtration: a Rips or
 * Čech or alpha complex has no covering multiplicity to show (its picture is
 * the union, which <Field3D> draws), and a 2D cloud has no plane to slice that
 * is not the plane it already lives in.
 *
 * GPU-DRIVEN SCALE (SPEC.md §1.5): the centres are uploaded ONCE per cloud, as
 * a uniform array. Moving t writes ONE uniform and re-uploads nothing.
 */
import { useEffect, useMemo, useState } from 'react';
import * as pc from 'playcanvas';
import type { Filtration } from '../filtration/types';
import { usePlayCanvas } from './PlayCanvasStage';
import {
  MAX_DEPTH_SLICE_CENTRES,
  cloudBoundingRadius,
  cloudCentroid,
  sliceFrame,
} from './depthSlice';
import { destroyEntity, deviceIsLive, parseColor } from './utils';

/** The slice plane: a unit normal, and a signed offset from the cloud centroid. */
export interface DepthSlicePlane {
  /** Plane normal. Normalised internally; need not be unit length. */
  normal: [number, number, number];
  /** Signed distance from the cloud centroid along `normal`. */
  offset: number;
}

/** Props for `<DepthSlice3D>`. */
export interface DepthSlice3DProps {
  /** A k-fold cover filtration on a 3D cloud. Anything else throws. */
  filtration: Filtration;
  /** Current scale: the SQUARED radius, the k-fold cover's own filtration value. */
  t: number;
  /** Slice plane. Default: `{ normal: [0, 0, 1], offset: 0 }` — through the centroid. */
  plane?: DepthSlicePlane;
  /**
   * The depth ramp, for counts 1, 2, 3 and ≥4, as CSS colour strings (the site
   * passes design tokens). Depth 0 is transparent and has no entry.
   *
   * Hex literals (`#rgb`, `#rrggbb`) are what `parseColor` reads exactly;
   * anything else falls back to white, as everywhere else in this library.
   */
  colors: [string, string, string, string];
  opacity?: number;
  /** Quad half-extent, in world units. Default: the cloud's bounding radius × 1.15. */
  size?: number;
}

const DEFAULT_PLANE: DepthSlicePlane = { normal: [0, 0, 1], offset: 0 };

/** Where the ramp is capped: depth ≥ 4 all share the last colour. */
const RAMP_LENGTH = 4;

/**
 * The refusal (SPEC.md §1.6). Thrown, not logged: covering depth is only
 * meaningful for a construction that has a multiplicity, and painting a Rips
 * complex's ball count on a plane would look like a k-fold cover picture while
 * meaning nothing about the complex drawn beside it.
 */
function assertKFoldIn3D(filtration: Filtration): void {
  if (filtration.complexType !== 'kfold' || filtration.vertexKind !== 'subset') {
    throw new Error(
      `<DepthSlice3D> needs a k-fold cover filtration (complexType 'kfold', vertexKind ` +
        `'subset'), got complexType '${filtration.complexType}' with vertexKind ` +
        `'${filtration.vertexKind}'. Covering depth is the multiplicity of the k-fold ` +
        'cover; for the union of the growing shapes of any other construction, use <Field3D>.',
    );
  }
  if (filtration.cloud.dimension !== 3) {
    throw new Error(
      `<DepthSlice3D> needs a 3D cloud, got dimension ${filtration.cloud.dimension}. ` +
        'A 2D cloud has no plane to slice other than the one it already lies in; ' +
        'use <Field2D>, which draws the merged region exactly in the plane.',
    );
  }
}

/**
 * Flat xyz centres of the balls: the INPUT points, not the mosaic vertices.
 *
 * The k-fold cover's vertices are k-subsets and its `vertexPositions` are their
 * barycentres — useful for drawing the mosaic (<Nerve3D> does), and wrong here.
 * The balls that are being counted grow around the input points.
 */
function centresOf(filtration: Filtration): Float32Array {
  const { points } = filtration.cloud;
  const count = points.length / 3;
  if (count > MAX_DEPTH_SLICE_CENTRES) {
    throw new Error(
      `<DepthSlice3D> counts at most ${MAX_DEPTH_SLICE_CENTRES} ball centres per slice, ` +
        `got ${count}. The count is evaluated per fragment from a uniform array of that ` +
        'size; counting a prefix of the cloud instead would draw a covering depth that is ' +
        'not the cloud’s. Raising the ceiling means moving the centres into a float ' +
        'texture (see MAX_DEPTH_SLICE_CENTRES in ./depthSlice.ts).',
    );
  }
  const out = new Float32Array(count * 3);
  for (let i = 0; i < count * 3; i++) out[i] = points[i]!;
  return out;
}

/**
 * Set a shader parameter that the shader declares as an ARRAY, under the name
 * the engine will actually look it up by.
 *
 * THE TRAP, and why this function exists. A material parameter is bound by
 * NAME through `device.scope`, and for an array uniform that name is not the
 * one written in the shader — it carries a `[0]` suffix, on BOTH backends:
 *
 *   - WebGL2: `WebglShaderInput`'s constructor is
 *     `this.scopeId = graphicsDevice.scope.resolve(name)` with `name` taken
 *     straight from `gl.getActiveUniform().name`
 *     (playcanvas@2.21.4 `platform/graphics/webgl/webgl-shader-input.js:47`),
 *     and GLES returns `"uCentres[0]"` for `uniform vec4 uCentres[256]` — the
 *     very next line, `if (name.substring(name.length - 3) === "[0]")`, is the
 *     engine keying off that same suffix to widen the uniform type to an ARRAY
 *     type.
 *   - WebGPU: `UniformFormat`'s constructor is
 *     `this.shortName = name;` then `this.name = count ? name + "[0]" : name;`
 *     (`platform/graphics/uniform-buffer-format.js:117-118`), and
 *     `UniformBufferFormat` resolves the scope id from that SUFFIXED `name`
 *     (`uniform-buffer-format.js:242`), with `count` coming from the WGSL
 *     reflection of `array<vec4f, N>`
 *     (`platform/graphics/webgpu/webgpu-shader-processor-wgsl.js:465`).
 *
 * `setParameter('uCentres', ...)` therefore writes a scope slot that NOTHING
 * reads, on either backend, and the array stays at its zero-initialised
 * contents in the shader — which for this component drew a black disc of
 * radius √t at the world origin (every centre at (0,0,0) is depth n ≥ 4 inside
 * it, and a zeroed ramp is black) instead of the depth field. Scalars bind
 * normally, which is exactly why the disc still tracked t and the failure read
 * as a shader problem rather than a binding one.
 *
 * Both spellings are set. The two backends agree on `[0]` today, so the bare
 * name is redundant — but an unresolved scope slot costs one map entry and
 * binds nothing, while a driver reporting an array's active name without the
 * suffix would otherwise reproduce the same silent blank.
 */
function setArrayParameter(material: pc.ShaderMaterial, name: string, value: Float32Array) {
  material.setParameter(`${name}[0]`, value);
  material.setParameter(name, value);
}

// ── The shaders ──────────────────────────────────────────────────────────

const SLICE_VS = /* glsl */ `
attribute vec3 aPosition;

uniform mat4 matrix_model;
uniform mat4 matrix_viewProjection;

varying vec3 vWorld;

void main(void) {
    vec4 world = matrix_model * vec4(aPosition, 1.0);
    vWorld = world.xyz;
    gl_Position = matrix_viewProjection * world;
}
`;

/**
 * The counting shader.
 *
 * EXACT TRANSCRIPTION of `coveringDepthAt` (./depthSlice.ts), which is its
 * oracle: squared distances, no square root, and `<=` so a point on a ball's
 * boundary is inside it. The loop bound is the compile-time array size, with an
 * early `break` at the live centre count — a GLSL ES 1.00-compatible loop that
 * the engine's shader processor rewrites for the GLSL 3.00 device.
 *
 * Colour is emitted as the caller's sRGB token unchanged. There is no lighting
 * term to work in linear space for: the slice is a painted field, and a shaded
 * one would make two pixels of the same depth different colours, which is
 * exactly the misreading this component exists to prevent.
 */
const SLICE_FS = /* glsl */ `
varying vec3 vWorld;

uniform vec4 uCentres[${MAX_DEPTH_SLICE_CENTRES}];
uniform float uCentreCount;
uniform float uT;
uniform vec4 uRamp[${RAMP_LENGTH}];
uniform float uOpacity;

void main(void) {
    int n = int(uCentreCount + 0.5);
    int depth = 0;
    for (int i = 0; i < ${MAX_DEPTH_SLICE_CENTRES}; i++) {
        if (i >= n) break;
        vec3 dv = vWorld - uCentres[i].xyz;
        if (dot(dv, dv) <= uT) depth++;
    }
    if (depth <= 0) {
        // Depth 0 is transparent: nothing covers this point, and painting it
        // would claim a cover that is not there.
        gl_FragColor = vec4(0.0);
    } else {
        int slot = depth - 1;
        if (slot > ${RAMP_LENGTH - 1}) slot = ${RAMP_LENGTH - 1};
        vec3 col = uRamp[0].rgb;
        if (slot == 1) col = uRamp[1].rgb;
        else if (slot == 2) col = uRamp[2].rgb;
        else if (slot == 3) col = uRamp[3].rgb;
        gl_FragColor = vec4(col, uOpacity);
    }
}
`;

/**
 * Exported for the shader-source tests: `NullGraphicsDevice` never compiles
 * GLSL/WGSL, so the load-bearing lines — the `<=` and the squared distance —
 * are pinned at source level instead.
 */
export const DEPTH_SLICE_VERTEX_GLSL = SLICE_VS;
export const DEPTH_SLICE_FRAGMENT_GLSL = SLICE_FS;

const SLICE_VS_WGSL = /* wgsl */ `
attribute aPosition: vec3f;

uniform matrix_model: mat4x4f;
uniform matrix_viewProjection: mat4x4f;

varying vWorld: vec3f;

@vertex
fn vertexMain(input: VertexInput) -> VertexOutput {
    var output: VertexOutput;
    let world = uniform.matrix_model * vec4f(input.aPosition, 1.0);
    output.vWorld = world.xyz;
    output.position = uniform.matrix_viewProjection * world;
    return output;
}
`;

/**
 * Native WGSL for the WebGPU device. GLSL-only `ShaderMaterial` does not
 * compile on WebGPU in PlayCanvas 2.21.4 without glslang+twgsl, so both
 * languages ship — and both are transcriptions of the same oracle.
 */
const SLICE_FS_WGSL = /* wgsl */ `
varying vWorld: vec3f;

uniform uCentres: array<vec4f, ${MAX_DEPTH_SLICE_CENTRES}>;
uniform uCentreCount: f32;
uniform uT: f32;
uniform uRamp: array<vec4f, ${RAMP_LENGTH}>;
uniform uOpacity: f32;

@fragment
fn fragmentMain(input: FragmentInput) -> FragmentOutput {
    var output: FragmentOutput;
    let n = i32(uniform.uCentreCount + 0.5);
    var depth = 0;
    for (var i = 0; i < ${MAX_DEPTH_SLICE_CENTRES}; i++) {
        if (i >= n) { break; }
        let dv = input.vWorld - uniform.uCentres[i].xyz;
        if (dot(dv, dv) <= uniform.uT) { depth += 1; }
    }
    if (depth <= 0) {
        output.color = vec4f(0.0);
    } else {
        var slot = depth - 1;
        if (slot > ${RAMP_LENGTH - 1}) { slot = ${RAMP_LENGTH - 1}; }
        output.color = vec4f(uniform.uRamp[slot].rgb, uniform.uOpacity);
    }
    return output;
}
`;

export const DEPTH_SLICE_VERTEX_WGSL = SLICE_VS_WGSL;
export const DEPTH_SLICE_FRAGMENT_WGSL = SLICE_FS_WGSL;

/**
 * The quad, in WORLD coordinates: four corners at `origin ± size·u ± size·v`,
 * as two triangles.
 *
 * Built in world space, with the entity left at the identity, rather than as a
 * unit quad under a rotation: the plane is a stated geometric object here, and
 * a test (and a reader) can check the corners directly against
 * `origin`, `u`, `v` and `size` without unpacking a quaternion.
 */
function quadVertices(
  origin: readonly [number, number, number],
  u: readonly [number, number, number],
  v: readonly [number, number, number],
  size: number,
): number[] {
  const corner = (a: number, b: number) => [
    origin[0] + a * size * u[0] + b * size * v[0],
    origin[1] + a * size * u[1] + b * size * v[1],
    origin[2] + a * size * u[2] + b * size * v[2],
  ];
  const c00 = corner(-1, -1);
  const c10 = corner(1, -1);
  const c11 = corner(1, 1);
  const c01 = corner(-1, 1);
  return [...c00, ...c10, ...c11, ...c00, ...c11, ...c01];
}

/**
 * The covering depth of a k-fold cover, painted exactly on a plane through the
 * cloud (SPEC.md §4.5). Each fragment counts the balls that contain it and
 * takes its colour from that count. Must be rendered inside a `<PlayCanvasStage>`.
 */
export function DepthSlice3D({
  filtration,
  t,
  plane = DEFAULT_PLANE,
  colors,
  opacity = 0.92,
  size,
}: DepthSlice3DProps) {
  // Refused before anything is built (see the header): a filtration with no
  // covering multiplicity has no depth to paint.
  assertKFoldIn3D(filtration);

  const { app, rootEntity } = usePlayCanvas();
  // State, not a ref, so the cheap uniform effects below re-run exactly when
  // the material is rebuilt — the same arrangement <Field3D> uses.
  const [material, setMaterial] = useState<pc.ShaderMaterial | null>(null);

  const { cloud } = filtration;

  /** Uploaded ONCE per cloud; never re-uploaded when t moves. */
  const centres = useMemo(() => centresOf(filtration), [filtration]);

  // Scalars rather than the array literal, so the geometry effect can declare
  // its real dependencies and an inline `plane={{...}}` prop does not rebuild
  // the quad on every render of the parent.
  const [normalX, normalY, normalZ] = plane.normal;
  const planeOffset = plane.offset;

  const geometry = useMemo(() => {
    const frame = sliceFrame([normalX, normalY, normalZ]);
    const centre = cloudCentroid(cloud.points);
    const origin: [number, number, number] = [
      centre[0] + frame.n[0] * planeOffset,
      centre[1] + frame.n[1] * planeOffset,
      centre[2] + frame.n[2] * planeOffset,
    ];
    // The default half-extent frames the whole cloud with a margin, so the
    // depth field is visible out to where it falls to zero rather than being
    // cropped at the outermost ball.
    const halfExtent =
      size !== undefined ? size : Math.max(cloudBoundingRadius(cloud.points, centre) * 1.15, 1e-6);
    return { frame, origin, halfExtent };
  }, [cloud.points, normalX, normalY, normalZ, planeOffset, size]);

  // Build ONCE per (app, cloud, plane, size). Nothing here depends on t, on the
  // ramp or on the opacity — those are uniform-only, and own the effects below.
  useEffect(() => {
    if (!app || !rootEntity || centres.length === 0) return;

    const parent = new pc.Entity('DepthSlice3D', app);
    (parent as unknown as { userData: Record<string, unknown> }).userData = {
      // The claim this component makes, in the scene, next to the picture that
      // makes it (SPEC.md §1.6).
      exactness:
        'exact: every fragment counts the balls of squared radius t containing it ' +
        '(oracle: coveringDepthAt in src/render3d/depthSlice.ts)',
      centreCount: centres.length / 3,
      planeNormal: [...geometry.frame.n],
      planeOrigin: [...geometry.origin],
      halfExtent: geometry.halfExtent,
    };
    rootEntity.addChild(parent);

    const mesh = new pc.Mesh(app.graphicsDevice);
    mesh.setPositions(
      quadVertices(geometry.origin, geometry.frame.u, geometry.frame.v, geometry.halfExtent),
    );
    mesh.update(pc.PRIMITIVE_TRIANGLES);

    const mat = new pc.ShaderMaterial({
      uniqueName: 'TdaDepthSlice3D',
      attributes: { aPosition: pc.SEMANTIC_POSITION },
      vertexGLSL: SLICE_VS,
      fragmentGLSL: SLICE_FS,
      vertexWGSL: SLICE_VS_WGSL,
      fragmentWGSL: SLICE_FS_WGSL,
    });
    mat.blendType = pc.BLEND_NORMAL;
    mat.cull = pc.CULLFACE_NONE; // The slice reads from both sides.
    mat.depthWrite = false;
    mat.update();

    // The centres: ONE upload, here. The array is always the full compiled
    // size so the uniform buffer WebGPU builds for it is completely written;
    // `uCentreCount` is what bounds the loop.
    const packed = new Float32Array(MAX_DEPTH_SLICE_CENTRES * 4);
    const count = centres.length / 3;
    for (let i = 0; i < count; i++) {
      packed[i * 4] = centres[i * 3]!;
      packed[i * 4 + 1] = centres[i * 3 + 1]!;
      packed[i * 4 + 2] = centres[i * 3 + 2]!;
    }
    setArrayParameter(mat, 'uCentres', packed);
    mat.setParameter('uCentreCount', count);

    const meshInstance = new pc.MeshInstance(mesh, mat);
    // The quad's own aabb is correct, but the material is fully transparent
    // wherever the depth is 0 and the stage never moves this entity, so
    // culling buys nothing and can only hide the slice at grazing angles.
    meshInstance.cull = false;

    const renderEntity = new pc.Entity('DepthSliceQuad', app);
    renderEntity.addComponent('render', { meshInstances: [meshInstance] });
    parent.addChild(renderEntity);

    setMaterial(mat);

    return () => {
      setMaterial(null);
      destroyEntity(parent, app);
      // Skipped when <PlayCanvasStage>'s cleanup already destroyed the
      // app/device first — React tears a deleted subtree down parent-first,
      // and the engine has already freed these with the device (see
      // `deviceIsLive`).
      if (deviceIsLive(app)) {
        mat.destroy();
        mesh.destroy();
      }
    };
  }, [app, rootEntity, centres, geometry]);

  // Scrubbing t: ONE uniform write, no geometry work and no re-upload of the
  // centres (SPEC.md §1.5).
  useEffect(() => {
    if (!material) return;
    material.setParameter('uT', t);
  }, [material, t]);

  const [color1, color2, color3, color4] = colors;
  useEffect(() => {
    if (!material) return;
    const ramp = new Float32Array(RAMP_LENGTH * 4);
    [color1, color2, color3, color4].forEach((css, i) => {
      const c = parseColor(css);
      ramp[i * 4] = c.r;
      ramp[i * 4 + 1] = c.g;
      ramp[i * 4 + 2] = c.b;
      ramp[i * 4 + 3] = 1;
    });
    setArrayParameter(material, 'uRamp', ramp);
    material.setParameter('uOpacity', opacity);
  }, [material, color1, color2, color3, color4, opacity]);

  return null;
}
