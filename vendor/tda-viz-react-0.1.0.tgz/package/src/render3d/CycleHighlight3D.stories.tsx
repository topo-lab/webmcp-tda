import type { Meta, StoryObj } from '@storybook/react-vite';
import { CycleHighlight3D } from './CycleHighlight3D';
import { PlayCanvasStage } from './PlayCanvasStage';
import { PointCloud3D } from './PointCloud3D';

/**
 * Draws one cycle as a closed ring using PlayCanvas, so a bar on the barcode and a shape on the
 * stage are visibly the same object — the claim the whole instrument is built
 * to make.
 *
 * It renders a cycle it is GIVEN. It does not derive generators: tda-wasm does
 * not currently expose volume-optimal or stable-volume generators, and drawing
 * an arbitrary ring while calling it "the generator" would be a fabrication
 * (SPEC.md §5).
 */
function ring(n: number, r = 1, z = 0): number[] {
  const pts: number[] = [];
  for (let i = 0; i < n; i++) {
    const t = (2 * Math.PI * i) / n;
    pts.push(r * Math.cos(t), r * Math.sin(t), z);
  }
  return pts;
}

const RING = ring(24);
const RING_CYCLE = Array.from({ length: 24 }, (_, i) => i);

const meta = {
  title: '3D/CycleHighlight3D',
  component: CycleHighlight3D,
  decorators: [
    (Story) => (
      <div style={{ width: 480, height: 360 }}>
        <PlayCanvasStage cameraPosition={[0, -2.2, 2.2]} fov={50}>
          <Story />
        </PlayCanvasStage>
      </div>
    ),
  ],
  tags: ['autodocs'],
} satisfies Meta<typeof CycleHighlight3D>;

export default meta;
type Story = StoryObj<typeof meta>;

/** A closed 1-cycle: the generator of an H₁ class. */
export const ClosedLoop: Story = { args: { points: RING, cycle: RING_CYCLE } };

/** Open path: the wrap-around segment is omitted, so this is not a cycle. */
export const OpenPath: Story = {
  args: { points: RING, cycle: RING_CYCLE.slice(0, 14), closed: false },
};

/** Just the ring, without vertex markers. */
export const WithoutVertices: Story = {
  args: { points: RING, cycle: RING_CYCLE, showVertices: false },
};

/** Highlighted against the cloud it came from. */
export const OverPointCloud: Story = {
  args: { points: RING, cycle: RING_CYCLE },
  render: (args) => (
    <>
      <PointCloud3D points={RING} dimension={3} size={0.05} color="#94a3b8" />
      <CycleHighlight3D {...args} />
    </>
  ),
};

/** A degenerate cycle renders nothing rather than a stray segment. */
export const Degenerate: Story = { args: { points: RING, cycle: [3] } };
