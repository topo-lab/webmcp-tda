import * as pc from 'playcanvas';

const HEX_COLOR = /^#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i;

/**
 * Parse a **hex** color string (`#rgb`, `#rrggbb`, `#rrggbbaa`) into a
 * `pc.Color`, with `alpha` as the resulting alpha channel.
 *
 * Hex only, deliberately: `pc.Color.fromString` runs `parseInt(hex, 16)` and
 * returns NaN components for anything else (CSS names, `rgb(...)`) without
 * throwing, so a try/catch cannot catch the failure. Anything that is not a
 * recognized hex literal falls back to opaque white rather than to NaN.
 * Any alpha byte in an 8-digit literal is ignored; `alpha` wins.
 */
export function parseColor(colorStr: string, alpha = 1.0): pc.Color {
  const c = new pc.Color();
  if (!colorStr || !HEX_COLOR.test(colorStr)) {
    c.set(1, 1, 1, alpha);
    return c;
  }
  const hex = colorStr.slice(1);
  const expand =
    hex.length === 3
      ? hex
          .split('')
          .map((ch) => ch + ch)
          .join('')
      : hex;
  const r = parseInt(expand.slice(0, 2), 16) / 255;
  const g = parseInt(expand.slice(2, 4), 16) / 255;
  const b = parseInt(expand.slice(4, 6), 16) / 255;
  c.set(r, g, b, alpha);
  return c;
}

/**
 * Unit-radius sphere mesh.
 *
 * `pc.createSphere` is deprecated in engine v2 and logs a warning on every
 * call, which would fire on every mount of every 3D component here.
 */
export function createSphereMesh(device: pc.GraphicsDevice, segments: number): pc.Mesh {
  return pc.Mesh.fromGeometry(
    device,
    new pc.SphereGeometry({ radius: 1, latitudeBands: segments, longitudeBands: segments }),
  );
}

/**
 * Unit-edge cube mesh, centred on the origin (half extents 0.5), for markers
 * and for the box filtration's grown boxes. Scaled per instance by the shader
 * that draws it, so one mesh serves every size.
 *
 * `pc.createBox` is deprecated in engine v2 and logs on every call, exactly as
 * `pc.createSphere` does.
 */
export function createBoxMesh(device: pc.GraphicsDevice): pc.Mesh {
  return pc.Mesh.fromGeometry(
    device,
    new pc.BoxGeometry({ halfExtents: new pc.Vec3(0.5, 0.5, 0.5) }),
  );
}

/**
 * Create a per-instance VertexBuffer for one arbitrary float stream.
 *
 * `setInstancing` flips `format.instancing`, which sets the attribute divisor
 * to 1 for every element, so one record is consumed per instance.
 */
export function createInstanceStreamBuffer(
  device: pc.GraphicsDevice,
  data: Float32Array,
  count: number,
  semantic: string,
  components: number,
): pc.VertexBuffer {
  return createInstanceStreamsBuffer(device, data, count, [{ semantic, components }]);
}

/**
 * The same, for a record that needs more than one attribute — an oriented
 * ellipsoid carries a centre, a semi-axis profile and two frame rows, and a
 * `VertexElement` holds at most 4 components.
 *
 * The buffer is INTERLEAVED in the order given: each instance contributes
 * `elements[0].components` floats, then `elements[1]`'s, and so on, which is the
 * layout `pc.VertexFormat` computes for the same list.
 */
export function createInstanceStreamsBuffer(
  device: pc.GraphicsDevice,
  data: Float32Array,
  count: number,
  elements: ReadonlyArray<{ semantic: string; components: number }>,
): pc.VertexBuffer {
  const format = new pc.VertexFormat(
    device,
    elements.map(({ semantic, components }) => ({ semantic, components, type: pc.TYPE_FLOAT32 })),
  );
  return new pc.VertexBuffer(device, format, count, {
    usage: pc.BUFFER_STATIC,
    data: data.buffer as ArrayBuffer,
  });
}

/**
 * Create an instancing VertexBuffer for 4x4 transform matrices, for meshes
 * drawn with a `StandardMaterial`.
 *
 * The format MUST come from the engine, not from a hand-written element list.
 * `StandardMaterial`'s instancing chunk binds its four matrix rows to
 * ATTR11, ATTR12, ATTR14 and ATTR15 (see `LitShader.generateVertexShader`) —
 * it skips ATTR13 and it is not the ATTR12..15 run you would guess. Supplying
 * ATTR12..15 leaves row 1 reading an unbound attribute and shifts the rest,
 * which draws every instance as a spike through the origin.
 */
export function createInstancingVertexBuffer(
  device: pc.GraphicsDevice,
  matrixData: Float32Array,
  count: number,
): pc.VertexBuffer {
  const format = pc.VertexFormat.getDefaultInstancingFormat(device);
  const vb = new pc.VertexBuffer(device, format, count, {
    usage: pc.BUFFER_DYNAMIC,
    data: matrixData.buffer as ArrayBuffer,
  });
  return vb;
}

/**
 * Create an unlit material for lines and flat markers.
 */
export function createUnlitMaterial(color: pc.Color, opacity = 1.0): pc.StandardMaterial {
  const mat = new pc.StandardMaterial();
  mat.useLighting = false;
  mat.diffuse = color;
  mat.emissive = color;
  mat.opacity = opacity;
  if (opacity < 1.0) {
    mat.blendType = pc.BLEND_NORMAL;
    mat.depthWrite = false;
  }
  mat.update();
  return mat;
}

/**
 * Shared fragment-shader prelude for the GPU-driven components: the engine's
 * gamma chunk plus one fixed-direction key light, a weak fill and a flat
 * ambient term. Deliberately not a PBR model — these surfaces are translucent
 * mathematical objects, and the lighting exists only to make curvature
 * readable, roughly matching what `StandardMaterial` produced before.
 *
 * Written in GLSL ES 1.00 style (`varying`, `gl_FragColor`); the engine's
 * shader processor rewrites it for the WebGL2 GLSL 3.00 device.
 */
export const SHADE_GLSL = /* glsl */ `
#include "gammaPS"

vec3 tdaShade(vec3 srgbColor, vec3 rawNormal) {
    vec3 n = normalize(rawNormal);
    if (!gl_FrontFacing) n = -n;
    vec3 keyDir = normalize(vec3(0.45, 0.75, 0.55));
    vec3 fillDir = normalize(vec3(-0.5, -0.35, -0.6));
    float lit = 0.30
        + 0.85 * max(dot(n, keyDir), 0.0)
        + 0.22 * max(dot(n, fillDir), 0.0);
    return decodeGamma(srgbColor) * lit;
}
`;

/**
 * WGSL counterpart of `SHADE_GLSL`. PlayCanvas 2.21.4's WebGPU backend will
 * not compile GLSL-only ShaderMaterial source unless glslang+twgsl are
 * loaded (`WebgpuShader.transpile` in playcanvas.mjs); we ship native WGSL
 * instead. `#include "gammaPS"` resolves against the engine's WGSL chunk
 * library (shaderChunksWGSL.gammaPS). Front-facing is `pcFrontFacing` —
 * the WGSL processor injects `@builtin(front_facing)` when that name is
 * referenced. `decodeGamma3` is the vec3 overload; WGSL has no GLSL-style
 * overloading of `decodeGamma`.
 */
export const SHADE_WGSL = /* wgsl */ `
#include "gammaPS"

fn tdaShade(srgbColor: vec3f, rawNormal: vec3f) -> vec3f {
    var n = normalize(rawNormal);
    if (!pcFrontFacing) {
        n = -n;
    }
    let keyDir = normalize(vec3f(0.45, 0.75, 0.55));
    let fillDir = normalize(vec3f(-0.5, -0.35, -0.6));
    let lit = 0.30
        + 0.85 * max(dot(n, keyDir), 0.0)
        + 0.22 * max(dot(n, fillDir), 0.0);
    return decodeGamma3(srgbColor) * lit;
}
`;

/**
 * Whether `app`'s graphics device can still release GPU resources — i.e.
 * whether calling `.destroy()` on a vertex buffer, mesh, material, texture or
 * entity it owns is safe, as opposed to a guaranteed crash.
 *
 * The mechanism, confirmed against playcanvas@2.21.4
 * (`node_modules/playcanvas/build/playcanvas.dbg/src/`):
 *
 * - `AppBase.destroy()` (`framework/app-base.js`) destroys and then nulls its
 *   own device in two back-to-back statements —
 *   `this.graphicsDevice.destroy(); this.graphicsDevice = null;` — so by the
 *   time `app.destroy()` returns, `app.graphicsDevice` is already `null`.
 * - `WebglGraphicsDevice.destroy()`
 *   (`platform/graphics/webgl/webgl-graphics-device.js`) sets `this.gl = null`
 *   as its last step.
 * - Every WebGL-backed GPU resource's `.destroy()` bottoms out in
 *   `WebglBuffer.destroy(device)` (`platform/graphics/webgl/webgl-buffer.js`):
 *   `device.gl.deleteBuffer(this.bufferId)`. `VertexBuffer`/`Mesh` capture the
 *   device they were constructed with (`this.device = graphicsDevice` in
 *   `platform/graphics/vertex-buffer.js`), so that reference stays a live JS
 *   object even after `app.graphicsDevice` has been nulled — it is the
 *   device's OWN `gl` field that has gone null, and
 *   `device.gl.deleteBuffer(...)` throws `TypeError: Cannot read properties
 *   of null (reading 'deleteBuffer')`.
 * - The WebGPU device has no `gl` field at all (only WebGL1/WebGL2 devices
 *   do), so this path is WebGL-only — which is exactly why it never showed up
 *   on a WebGPU-capable machine and only under a forced no-WebGPU-adapter /
 *   SwiftShader CI profile.
 *
 * React tears down a deleted subtree's passive effects PARENT-FIRST:
 * `<PlayCanvasStage>`'s cleanup destroys the `pc.Application` (and with it
 * the device) before `<PointCloud3D>`/`<Field3D>`/`<Nerve3D>`/
 * `<CycleHighlight3D>`'s cleanups run and try to free their own buffers,
 * meshes and materials. By then the engine has already freed everything that
 * lived on the device, so the correct move is to SKIP those calls outright —
 * not to wrap them in a blanket try/catch, which would also swallow unrelated
 * bugs.
 */
export function deviceIsLive(app: pc.AppBase | null | undefined): boolean {
  if (!app) return false;
  const device = app.graphicsDevice;
  if (!device || device.isNull) return false;
  // `gl` is not part of the engine's public `GraphicsDevice` typings — only
  // WebGL1/WebGL2 devices carry it, and only they null it out on destroy —
  // so duck-type it rather than importing an internal engine class.
  const gl = (device as unknown as { gl?: WebGLRenderingContext | WebGL2RenderingContext | null })
    .gl;
  return gl !== null;
}

/**
 * Safely dispose a PlayCanvas entity and all its child entities and render
 * components — but only while `app`'s graphics device is still alive
 * (`deviceIsLive`). Once the device is gone, `app.destroy()` has already
 * destroyed the whole entity tree via its own `this.root.destroy()`, so a
 * second `entity.destroy()` here is both redundant and liable to walk into
 * the same dead-device crash through a render component's mesh-instance
 * teardown.
 */
export function destroyEntity(
  entity: pc.Entity | null | undefined,
  app: pc.AppBase | null | undefined,
) {
  if (!entity) return;
  if (!deviceIsLive(app)) return;
  entity.destroy();
}
