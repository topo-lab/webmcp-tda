import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';
import * as pc from 'playcanvas';
import { parseColor } from './utils';

export interface PlayCanvasContextValue {
  app: pc.Application | null;
  camera: pc.Entity | null;
  rootEntity: pc.Entity | null;
  /** Active graphics backend: `'webgpu' | 'webgl2' | 'null'`, or `null` before init. */
  deviceType: string | null;
}

export const PlayCanvasContext = createContext<PlayCanvasContextValue>({
  app: null,
  camera: null,
  rootEntity: null,
  deviceType: null,
});

export function usePlayCanvas(): PlayCanvasContextValue {
  return useContext(PlayCanvasContext);
}

/**
 * Default `createGraphicsDevice` attempt order: WebGPU first, WebGL2 fallback.
 *
 * Passed as a copy (`[...DEFAULT_DEVICE_TYPES]`) because the engine mutates
 * the array it is given — it appends `DEVICETYPE_WEBGL2` if missing, then
 * `DEVICETYPE_NULL` as a last-ditch fallback (playcanvas
 * `createGraphicsDevice`, 2.21.4).
 */
export const DEFAULT_DEVICE_TYPES: [typeof pc.DEVICETYPE_WEBGPU, typeof pc.DEVICETYPE_WEBGL2] = [
  pc.DEVICETYPE_WEBGPU,
  pc.DEVICETYPE_WEBGL2,
];

const GRAPHICS_DEVICE_OPTIONS = {
  antialias: true,
  alpha: true,
  preserveDrawingBuffer: false,
};

export interface PlayCanvasStageProps {
  children?: ReactNode;
  className?: string;
  style?: CSSProperties;
  cameraPosition?: [number, number, number];
  targetPosition?: [number, number, number];
  fov?: number;
  clearColor?: string;
  enableControls?: boolean;
  autoRotate?: boolean;
  autoRotateSpeed?: number;
  onAppReady?: (app: pc.Application) => void;
  /**
   * TEST SEAM. Supplies the `pc.GraphicsDevice` instead of letting the
   * default path `await pc.createGraphicsDevice(...)`.
   *
   * jsdom has no WebGL/WebGPU context, so the only way to exercise the real
   * scene graph in a unit test is to hand the engine a `pc.NullGraphicsDevice`
   * (`pc.Application` takes `options.graphicsDevice` and only calls its own
   * `createDevice` when that is absent). When this prop is set the whole
   * mount stays SYNCHRONOUS — no `await` — which the jsdom tests depend on.
   * Production code must leave this undefined.
   */
  createGraphicsDevice?: (canvas: HTMLCanvasElement) => pc.GraphicsDevice;
}

/**
 * Retina cap. Above 2 the pixel count grows faster than the picture improves,
 * and these scenes are fill-rate bound on translucent geometry.
 */
const MAX_PIXEL_RATIO = 2;

const NULL_CONTEXT: PlayCanvasContextValue = {
  app: null,
  camera: null,
  rootEntity: null,
  deviceType: null,
};

export function PlayCanvasStage({
  children,
  className,
  style,
  cameraPosition = [0, 0, 3.2],
  targetPosition = [0, 0, 0],
  fov = 45,
  clearColor = '#0b1020',
  enableControls = true,
  autoRotate = false,
  autoRotateSpeed = 0.5,
  onAppReady,
  createGraphicsDevice,
}: PlayCanvasStageProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [contextValue, setContextValue] = useState<PlayCanvasContextValue>(NULL_CONTEXT);

  // Held in a ref so a consumer passing an inline arrow function does not
  // destroy and rebuild the whole engine on every one of its renders.
  const onAppReadyRef = useRef(onAppReady);
  useEffect(() => {
    onAppReadyRef.current = onAppReady;
  }, [onAppReady]);

  // Same reasoning as onAppReady: the injected-device factory is read once, at
  // engine construction time, and must not be an effect dependency.
  const createGraphicsDeviceRef = useRef(createGraphicsDevice);
  useEffect(() => {
    createGraphicsDeviceRef.current = createGraphicsDevice;
  }, [createGraphicsDevice]);

  // Scalars, not array literals: the effect below must be able to declare its
  // real dependencies without tripping exhaustive-deps on `cameraPosition[0]`.
  const [cameraX, cameraY, cameraZ] = cameraPosition;
  const [targetX, targetY, targetZ] = targetPosition;

  const controlsStateRef = useRef({
    isDragging: false,
    lastX: 0,
    lastY: 0,
    yaw: 0,
    pitch: 0,
    distance: 3.2,
    targetDistance: 3.2,
    targetYaw: 0,
    targetPitch: 0,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let cancelled = false;
    let app: pc.Application | null = null;
    const disposers: Array<() => void> = [];

    const warnInit = (e: unknown) => {
      console.warn('PlayCanvas application failed to initialize:', e);
    };

    const abortMount = () => {
      for (const d of disposers.splice(0)) d();
      if (app) {
        app.destroy();
        app = null;
      }
    };

    const mount = (device: pc.GraphicsDevice) => {
      app = new pc.Application(canvas, {
        // `graphicsDevice` wins over `graphicsDeviceOptions`: the engine only
        // builds a device of its own when none is handed to it.
        graphicsDevice: device,
        graphicsDeviceOptions: { ...GRAPHICS_DEVICE_OPTIONS },
      });
      app.setCanvasFillMode(pc.FILLMODE_NONE);
      app.setCanvasResolution(pc.RESOLUTION_AUTO);
      // The device defaults to min(1, devicePixelRatio), which renders at CSS
      // pixels and looks soft on retina. RESOLUTION_AUTO multiplies the CSS
      // size by min(maxPixelRatio, devicePixelRatio), so raising the cap is
      // all that is needed.
      app.graphicsDevice.maxPixelRatio = Math.min(
        typeof window === 'undefined' ? 1 : window.devicePixelRatio || 1,
        MAX_PIXEL_RATIO,
      );
      app.start();
      app.resizeCanvas();

      // Set clear color
      const bg = parseColor(clearColor);
      if (app.scene) {
        app.scene.ambientLight = new pc.Color(0.2, 0.25, 0.35);
      }

      // Camera Entity
      const camera = new pc.Entity('MainCamera', app);
      camera.addComponent('camera', {
        clearColor: bg,
        fov: fov,
        frustumCulling: false,
      });
      app.root.addChild(camera);

      // Initial spherical coordinates calculation
      const dx = cameraX - targetX;
      const dy = cameraY - targetY;
      const dz = cameraZ - targetZ;
      const initialDist = Math.sqrt(dx * dx + dy * dy + dz * dz) || 3.2;
      const initialPitch = Math.asin(Math.max(-1, Math.min(1, dy / initialDist)));
      const initialYaw = Math.atan2(dx, dz);

      controlsStateRef.current = {
        isDragging: false,
        lastX: 0,
        lastY: 0,
        yaw: initialYaw,
        pitch: initialPitch,
        distance: initialDist,
        targetDistance: initialDist,
        targetYaw: initialYaw,
        targetPitch: initialPitch,
      };

      // Lights
      const dirLight = new pc.Entity('DirectionalLight', app);
      dirLight.addComponent('light', {
        type: 'directional',
        color: new pc.Color(1, 0.98, 0.95),
        intensity: 1.2,
      });
      dirLight.setEulerAngles(45, 30, 0);
      app.root.addChild(dirLight);

      const fillLight = new pc.Entity('FillLight', app);
      fillLight.addComponent('light', {
        type: 'directional',
        color: new pc.Color(0.6, 0.75, 1.0),
        intensity: 0.5,
      });
      fillLight.setEulerAngles(-45, -150, 0);
      app.root.addChild(fillLight);

      // Root entity for user scene content
      const rootEntity = new pc.Entity('TdaRootNode', app);
      app.root.addChild(rootEntity);

      // Update loop for smooth orbit camera & auto-rotation
      const onUpdate = (dt: number) => {
        const state = controlsStateRef.current;
        if (autoRotate && !state.isDragging) {
          state.targetYaw += dt * autoRotateSpeed * 0.5;
        }

        // Smooth damping interpolation
        const factor = Math.min(1, dt * 10);
        state.yaw += (state.targetYaw - state.yaw) * factor;
        state.pitch += (state.targetPitch - state.pitch) * factor;
        state.distance += (state.targetDistance - state.distance) * factor;

        // Position camera on sphere around targetPosition
        const cp = Math.cos(state.pitch);
        const sp = Math.sin(state.pitch);
        const cy = Math.sin(state.yaw);
        const sy = Math.cos(state.yaw);

        const cx = targetX + state.distance * cp * cy;
        const cyPos = targetY + state.distance * sp;
        const cz = targetZ + state.distance * cp * sy;

        camera.setPosition(cx, cyPos, cz);
        camera.lookAt(targetX, targetY, targetZ);
      };

      app.on('update', onUpdate);

      // Mouse / Touch Controls
      const handleMouseDown = (e: MouseEvent) => {
        if (!enableControls) return;
        controlsStateRef.current.isDragging = true;
        controlsStateRef.current.lastX = e.clientX;
        controlsStateRef.current.lastY = e.clientY;
      };

      const handleMouseMove = (e: MouseEvent) => {
        const state = controlsStateRef.current;
        if (!state.isDragging || !enableControls) return;
        const dxMove = e.clientX - state.lastX;
        const dyMove = e.clientY - state.lastY;
        state.lastX = e.clientX;
        state.lastY = e.clientY;

        state.targetYaw -= dxMove * 0.006;
        state.targetPitch = Math.max(-1.5, Math.min(1.5, state.targetPitch + dyMove * 0.006));
      };

      const handleMouseUp = () => {
        controlsStateRef.current.isDragging = false;
      };

      const handleWheel = (e: WheelEvent) => {
        if (!enableControls) return;
        e.preventDefault();
        const zoomDelta = e.deltaY * 0.002;
        const state = controlsStateRef.current;
        state.targetDistance = Math.max(
          0.4,
          Math.min(25, state.targetDistance + zoomDelta * state.targetDistance),
        );
      };

      let touchStartDist = 0;
      const handleTouchStart = (e: TouchEvent) => {
        if (!enableControls) return;
        if (e.touches.length === 1) {
          controlsStateRef.current.isDragging = true;
          controlsStateRef.current.lastX = e.touches[0]!.clientX;
          controlsStateRef.current.lastY = e.touches[0]!.clientY;
        } else if (e.touches.length === 2) {
          controlsStateRef.current.isDragging = false;
          const tdx = e.touches[0]!.clientX - e.touches[1]!.clientX;
          const tdy = e.touches[0]!.clientY - e.touches[1]!.clientY;
          touchStartDist = Math.sqrt(tdx * tdx + tdy * tdy);
        }
      };

      const handleTouchMove = (e: TouchEvent) => {
        if (!enableControls) return;
        if (e.touches.length === 1 && controlsStateRef.current.isDragging) {
          const tdx = e.touches[0]!.clientX - controlsStateRef.current.lastX;
          const tdy = e.touches[0]!.clientY - controlsStateRef.current.lastY;
          controlsStateRef.current.lastX = e.touches[0]!.clientX;
          controlsStateRef.current.lastY = e.touches[0]!.clientY;

          controlsStateRef.current.targetYaw -= tdx * 0.008;
          controlsStateRef.current.targetPitch = Math.max(
            -1.5,
            Math.min(1.5, controlsStateRef.current.targetPitch + tdy * 0.008),
          );
        } else if (e.touches.length === 2) {
          const tdx = e.touches[0]!.clientX - e.touches[1]!.clientX;
          const tdy = e.touches[0]!.clientY - e.touches[1]!.clientY;
          const dist = Math.sqrt(tdx * tdx + tdy * tdy);
          if (touchStartDist > 0) {
            const factor = touchStartDist / dist;
            controlsStateRef.current.targetDistance = Math.max(
              0.4,
              Math.min(25, controlsStateRef.current.targetDistance * (1 + (factor - 1) * 0.5)),
            );
          }
          touchStartDist = dist;
        }
      };

      const handleTouchEnd = () => {
        controlsStateRef.current.isDragging = false;
        touchStartDist = 0;
      };

      canvas.addEventListener('mousedown', handleMouseDown);
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      canvas.addEventListener('wheel', handleWheel, { passive: false });
      canvas.addEventListener('touchstart', handleTouchStart, { passive: true });
      canvas.addEventListener('touchmove', handleTouchMove, { passive: true });
      canvas.addEventListener('touchend', handleTouchEnd);

      // Resize observer
      const resizeObserver = new ResizeObserver(() => {
        if (app && app.graphicsDevice) {
          app.resizeCanvas();
        }
      });
      resizeObserver.observe(canvas);

      const liveApp = app;
      disposers.push(() => {
        canvas.removeEventListener('mousedown', handleMouseDown);
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
        canvas.removeEventListener('wheel', handleWheel);
        canvas.removeEventListener('touchstart', handleTouchStart);
        canvas.removeEventListener('touchmove', handleTouchMove);
        canvas.removeEventListener('touchend', handleTouchEnd);
        resizeObserver.disconnect();

        liveApp.off('update', onUpdate);
        liveApp.destroy();
        app = null;
      });

      setContextValue({
        app: liveApp,
        camera,
        rootEntity,
        deviceType: liveApp.graphicsDevice.deviceType,
      });
      onAppReadyRef.current?.(liveApp);
    };

    const injectedFactory = createGraphicsDeviceRef.current;
    if (injectedFactory) {
      // Seam path: fully synchronous. jsdom tests mount children after the
      // first effect flush and must not have to `await waitFor`.
      try {
        mount(injectedFactory(canvas));
      } catch (e) {
        abortMount();
        warnInit(e);
        return;
      }
    } else {
      void (async () => {
        let created: pc.GraphicsDevice;
        try {
          // Copy: createGraphicsDevice mutates deviceTypes in place (appends
          // WEBGL2 if missing, then NULL).
          created = (await pc.createGraphicsDevice(canvas, {
            deviceTypes: [...DEFAULT_DEVICE_TYPES],
            ...GRAPHICS_DEVICE_OPTIONS,
          })) as pc.GraphicsDevice;
        } catch (e) {
          if (!cancelled) warnInit(e);
          return;
        }
        if (cancelled) {
          created.destroy();
          return;
        }
        // The engine always appends DEVICETYPE_NULL after the requested types.
        // A null device is not a usable renderer — treat it as init failure
        // so we warn and draw nothing, matching the old WebGL-only catch path.
        if (created.isNull) {
          created.destroy();
          if (!cancelled) {
            warnInit(new Error('WebGPU and WebGL2 graphics devices are unavailable'));
          }
          return;
        }
        try {
          mount(created);
        } catch (e) {
          const hadApp = app !== null;
          abortMount();
          if (!hadApp) {
            // Constructor threw before taking ownership — free the device.
            created.destroy();
          }
          if (!cancelled) warnInit(e);
        }
      })();
    }

    return () => {
      cancelled = true;
      for (const d of disposers) d();
      setContextValue(NULL_CONTEXT);
    };
  }, [
    clearColor,
    fov,
    enableControls,
    autoRotate,
    autoRotateSpeed,
    cameraX,
    cameraY,
    cameraZ,
    targetX,
    targetY,
    targetZ,
  ]);

  return (
    <div
      className={className}
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
        overflow: 'hidden',
        ...style,
      }}
    >
      <canvas
        ref={canvasRef}
        style={{
          width: '100%',
          height: '100%',
          display: 'block',
          outline: 'none',
        }}
      />
      <PlayCanvasContext.Provider value={contextValue}>
        {contextValue.app ? children : null}
      </PlayCanvasContext.Provider>
    </div>
  );
}
