/**
 * The arithmetic behind `<KFoldCover3D>` — pure TypeScript, no engine, no
 * React.
 *
 * WHAT THE K-FOLD COVER IS, AS A SOLID. For a k-fold cover filtration the
 * region the complex is about is the set of points of R³ covered by at least k
 * of the balls of radius √t:
 *
 *     C_k(t) = { x : #{ i : |x − cᵢ| ≤ √t } ≥ k }
 *
 * That is a SOLID region, not a curve and not a disc on a plane.
 * `<DepthSlice3D>` paints its cross-section on one plane exactly; this module
 * serves the component that draws the solid itself.
 *
 * THE IDENTITY THAT MAKES IT EXACT AND CHEAP. Let d₍ₖ₎(x) be the k-th smallest
 * distance from x to the centres. Then
 *
 *     depth(x) ≥ k   ⇔   d₍ₖ₎(x) ≤ √t   ⇔   d₍ₖ₎(x)² ≤ t
 *
 * — counting and ordering are the same statement, because "at least k of the
 * distances are ≤ √t" is exactly "the k-th smallest of them is ≤ √t". So the
 * k-fold cover is the SUBLEVEL SET of d₍ₖ₎ at √t, its boundary is the
 * isosurface d₍ₖ₎(x) = √t, and:
 *
 *   - d₍ₖ₎ is 1-Lipschitz (each |x − cᵢ| is, and the k-th order statistic of a
 *     family of 1-Lipschitz functions is), so `d₍ₖ₎(x) − √t` is a valid
 *     signed-distance BOUND and sphere tracing with that step size never
 *     overshoots the surface. The shader marches on exactly this.
 *   - the outward normal at a boundary point x is (x − c₍ₖ₎)/|x − c₍ₖ₎|, where
 *     c₍ₖ₎ is the k-th nearest centre — analytic, so the picture needs no
 *     finite differences and no normal smoothing.
 *
 * `kthNearestDistanceSquared` IS THE ORACLE FOR THE GLSL/WGSL. The fragment
 * shader in KFoldCover3D.tsx runs the identical partial selection, term for
 * term: squared distances, no square roots inside the selection, a non-strict
 * comparison at the surface so a point exactly on the boundary is inside, and
 * the same insert-and-shift over the k best. If either side of that pair ever
 * changes, both must change together.
 *
 * The k = 1 case is the plain union of the balls, the same machinery with the
 * selection degenerating to a minimum — which is why one shader draws both the
 * k-fold surface and the union shell in front of it.
 *
 * HEADLESS: this module imports nothing from playcanvas. It lives under
 * src/render3d only because it exists to serve `<KFoldCover3D>`.
 */

/**
 * How many ball centres the compiled fragment shader can hold.
 *
 * The centres travel as one `vec4[256]` uniform array, the same ceiling and
 * the same reason as `MAX_DEPTH_SLICE_CENTRES` (./depthSlice.ts): 256 uniform
 * vectors sit comfortably inside the fragment uniform budget of every WebGL2
 * and WebGPU device in use, and far above the clouds this draws — 8 points for
 * the motifs, 48 for the lattices. Above it the component THROWS rather than
 * tracing a prefix of the cloud, which would draw a surface that is not the
 * cloud's. Raising the ceiling means moving the centres into a float texture;
 * the region itself would not change, because it is this function.
 */
export const MAX_COVER_CENTRES = 256;

/**
 * Largest k the compiled shader supports.
 *
 * The partial selection keeps the k smallest squared distances in REGISTERS —
 * a fixed `float[8]` in the shader, walked with an insert-and-shift — so k is
 * bounded by the array the shader declares, not by anything mathematical. Eight
 * covers every k-fold cover that is drawable at all: the order-k mosaic's cost
 * grows quickly with k, and k = 4 is the multiplicity the Barlow-packing
 * comparison turns on.
 */
export const MAX_COVER_K = 8;

/**
 * The sphere-tracing step cap, in the shader and in this module's doc.
 *
 * d₍ₖ₎ − √t is a 1-Lipschitz lower bound on the distance to the surface, so
 * marching by it converges, but convergence is geometric and grazing rays
 * converge slowly. 128 steps is the cap; a ray that has not landed by then is
 * treated as a MISS and the fragment is discarded rather than drawn at a
 * guessed position. At the budget this component is built for — 48 centres,
 * around 96 steps on the rays that actually hit — the cap is not reached on
 * the surface, only on rays that graze it.
 */
export const COVER_MAX_STEPS = 128;

/**
 * d₍ₖ₎(point)², the SQUARED k-th smallest distance from `point` to `centres`.
 *
 * `centres` is flat xyz, length 3n. Returns `Infinity` when there are fewer
 * than k centres: no point is covered k times, at any t.
 *
 * The algorithm is a PARTIAL SELECTION, not a sort: an array of the k best
 * squared distances is kept in ascending order, and each new distance is
 * either rejected outright (it is not better than the current k-th) or
 * inserted by walking down from slot k − 1 and shifting. That is O(n·k) with
 * no allocation beyond the k-element array, and it is what the shader does in
 * registers.
 *
 * A non-integer, non-positive or too-large k is a programming error and
 * throws — a silently clamped k would draw a different region than the caller
 * asked for and nothing on screen would say so.
 */
export function kthNearestDistanceSquared(
  point: readonly number[],
  centres: ArrayLike<number>,
  k: number,
): number {
  assertCoverK(k);
  const x = point[0] ?? 0;
  const y = point[1] ?? 0;
  const z = point[2] ?? 0;
  const n = Math.floor(centres.length / 3);
  const best = new Array<number>(k).fill(Infinity);
  for (let i = 0; i < n; i++) {
    const dx = x - centres[i * 3]!;
    const dy = y - centres[i * 3 + 1]!;
    const dz = z - centres[i * 3 + 2]!;
    const d2 = dx * dx + dy * dy + dz * dz;
    // Not among the k smallest: nothing to do. (`>=` keeps ties out, which
    // cannot change the k-th value.)
    if (d2 >= best[k - 1]!) continue;
    for (let j = k - 1; j >= 0; j--) {
      if (j > 0 && best[j - 1]! > d2) {
        best[j] = best[j - 1]!;
      } else {
        best[j] = d2;
        break;
      }
    }
  }
  return best[k - 1]!;
}

/**
 * Whether `point` lies in the k-fold cover at scale `t` — the predicate the
 * fragment shader's sphere tracing converges to.
 *
 * `t` is the k-fold cover's own filtration value: a SQUARED radius. Its
 * convention is `alpha` on an unweighted cloud (the engine refuses weights for
 * this construction), so every ball has radius √t exactly and no per-point
 * weight term enters.
 *
 * Boundary points count as inside (`≤`, not `<`), matching `coveringDepthAt`
 * in ./depthSlice.ts. A negative or NaN `t` is outside everywhere: no ball has
 * been born yet.
 */
export function insideKFoldCover(
  point: readonly number[],
  centres: ArrayLike<number>,
  k: number,
  t: number,
): boolean {
  if (!(t >= 0)) return false;
  return kthNearestDistanceSquared(point, centres, k) <= t;
}

/**
 * The k-th nearest centre to `point`, as an INPUT INDEX, or −1 when there are
 * fewer than k centres.
 *
 * This is what the outward normal at a boundary point is measured from:
 * (x − c₍ₖ₎)/|x − c₍ₖ₎|. Exported so a test can check the analytic normal the
 * shader uses against the surface it claims to be drawing.
 *
 * Ties are broken toward the LAST index achieving the k-th distance, which is
 * the same choice the shader's second pass makes. On a cloud with distinct
 * points a tie is a measure-zero coincidence and either choice gives the same
 * normal direction up to the tie itself.
 */
export function kthNearestCentreIndex(
  point: readonly number[],
  centres: ArrayLike<number>,
  k: number,
): number {
  const s = kthNearestDistanceSquared(point, centres, k);
  if (!Number.isFinite(s)) return -1;
  const x = point[0] ?? 0;
  const y = point[1] ?? 0;
  const z = point[2] ?? 0;
  const n = Math.floor(centres.length / 3);
  let found = -1;
  let bestD2 = -1;
  for (let i = 0; i < n; i++) {
    const dx = x - centres[i * 3]!;
    const dy = y - centres[i * 3 + 1]!;
    const dz = z - centres[i * 3 + 2]!;
    const d2 = dx * dx + dy * dy + dz * dz;
    // The k-th nearest is the FURTHEST of the k nearest, so among the centres
    // at or inside the k-th distance, take the one that attains it.
    if (d2 <= s && d2 >= bestD2) {
      bestD2 = d2;
      found = i;
    }
  }
  return found;
}

/** An axis-aligned box in world space. */
export interface CoverBounds {
  readonly min: [number, number, number];
  readonly max: [number, number, number];
}

/**
 * The cloud's axis-aligned bounding box, grown by `pad` on every side.
 *
 * `<KFoldCover3D>` traces inside this box and nowhere else, so the padding has
 * to be at least the largest ball radius the caller can scrub to — √tMax —
 * or the surface would be cut off at the box wall with nothing on screen
 * saying why. An empty cloud gives a degenerate box at the origin.
 */
export function cloudBounds(points: readonly number[], pad = 0): CoverBounds {
  const n = Math.floor(points.length / 3);
  if (n === 0) return { min: [-pad, -pad, -pad], max: [pad, pad, pad] };
  const min: [number, number, number] = [Infinity, Infinity, Infinity];
  const max: [number, number, number] = [-Infinity, -Infinity, -Infinity];
  for (let i = 0; i < n; i++) {
    for (let a = 0; a < 3; a++) {
      const v = points[i * 3 + a]!;
      if (v < min[a]!) min[a] = v;
      if (v > max[a]!) max[a] = v;
    }
  }
  return {
    min: [min[0] - pad, min[1] - pad, min[2] - pad],
    max: [max[0] + pad, max[1] + pad, max[2] + pad],
  };
}

/**
 * The 36 world-space positions of an axis-aligned box, as 12 triangles.
 *
 * WINDING IS LOAD-BEARING. Every face is wound counter-clockwise as seen from
 * OUTSIDE the box, which under the default `FRONTFACE_CCW` makes the outward
 * side the front face. `<KFoldCover3D>` then culls the FRONT faces and
 * rasterizes only the inward-facing ones, so exactly one fragment per pixel
 * enters the trace — and the box still covers the screen when the camera moves
 * inside it, which is when a front-face box would vanish.
 *
 * The construction is per axis rather than twelve hand-written triangles: for
 * the +a face the in-plane axes (a+1, a+2) form a right-handed triple with a,
 * so listing the corners (−u,−v), (+u,−v), (+u,+v), (−u,+v) gives an outward
 * normal by the right-hand rule; the −a face is the same list reversed.
 */
export function boxTriangles(bounds: CoverBounds): number[] {
  const { min, max } = bounds;
  const out: number[] = [];
  const corner = (axis: number, sign: number, su: number, sv: number) => {
    const u = (axis + 1) % 3;
    const v = (axis + 2) % 3;
    const p: [number, number, number] = [0, 0, 0];
    p[axis] = sign > 0 ? max[axis]! : min[axis]!;
    p[u] = su > 0 ? max[u]! : min[u]!;
    p[v] = sv > 0 ? max[v]! : min[v]!;
    return p;
  };
  for (let axis = 0; axis < 3; axis++) {
    for (const sign of [1, -1]) {
      const quad: [number, number][] = [
        [-1, -1],
        [1, -1],
        [1, 1],
        [-1, 1],
      ];
      const ordered = sign > 0 ? quad : [...quad].reverse();
      const c = ordered.map(([su, sv]) => corner(axis, sign, su, sv));
      out.push(...c[0]!, ...c[1]!, ...c[2]!);
      out.push(...c[0]!, ...c[2]!, ...c[3]!);
    }
  }
  return out;
}

/**
 * The surface epsilon the sphere trace stops at, for a box of this size.
 *
 * Sphere tracing approaches the surface geometrically and never reaches it, so
 * a hit is declared when d₍ₖ₎ − √t drops below this. Absolute units, scaled to
 * the scene so the same component works on a cloud of unit spheres and on one
 * a thousand times larger; the floor keeps a degenerate box from asking for
 * infinite precision.
 */
export function coverEpsilon(bounds: CoverBounds): number {
  const dx = bounds.max[0] - bounds.min[0];
  const dy = bounds.max[1] - bounds.min[1];
  const dz = bounds.max[2] - bounds.min[2];
  const diagonal = Math.sqrt(dx * dx + dy * dy + dz * dz);
  return Math.max(diagonal * 2e-4, 1e-6);
}

function assertCoverK(k: number): void {
  if (!Number.isInteger(k) || k < 1 || k > MAX_COVER_K) {
    throw new Error(
      `k must be an integer in [1, ${MAX_COVER_K}], got ${k}. The k smallest squared ` +
        'distances are selected in registers, in a fixed-size array the fragment shader ' +
        `declares as float[${MAX_COVER_K}] (MAX_COVER_K in src/render3d/kfoldCover.ts).`,
    );
  }
}
