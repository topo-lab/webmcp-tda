/**
 * <PointCloud3D>: PlayCanvas point cloud. Lives ONLY under the `tda-viz-react/3d`
 * entry so 2D consumers never pull PlayCanvas (SPEC.md §3/§4). Must be
 * rendered inside a <PlayCanvasStage>.
 */
import { useEffect, useMemo, useRef } from 'react';
import * as pc from 'playcanvas';
import { usePlayCanvas } from './PlayCanvasStage';
import { createInstancingVertexBuffer, createSphereMesh, destroyEntity, parseColor } from './utils';

/**
 * Pack a flat coordinate array into Float32Array positions.
 * 2D clouds are embedded at z=0 for display.
 *
 * `readonly number[]` because the filtration's `vertexPositions` is readonly and
 * this function only reads: taking a mutable array forced every caller drawing a
 * complex to copy the whole position array per build for nothing.
 */
export function pointsToPositions(points: readonly number[], dimension: number): Float32Array {
  if (dimension !== 2 && dimension !== 3) {
    throw new Error(`dimension must be 2 or 3, got ${dimension}`);
  }
  if (points.length % dimension !== 0) {
    throw new Error(`points length ${points.length} is not a multiple of dimension ${dimension}`);
  }
  const count = points.length / dimension;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    positions[i * 3] = points[i * dimension]!;
    positions[i * 3 + 1] = points[i * dimension + 1]!;
    positions[i * 3 + 2] = dimension === 3 ? points[i * dimension + 2]! : 0;
  }
  return positions;
}

export interface PointCloud3DProps {
  /** Flat coordinates [x0, y0, (z0,) x1, ...]. */
  points: number[];
  /** Ambient dimension of the data; 2D clouds are embedded at z=0. */
  dimension?: 2 | 3;
  /**
   * Per-point weights (SPEC.md §4.2): with weights, points render as
   * instanced sphere markers whose radius scales with √wᵢ, so weight is
   * visible on the cloud itself.
   */
  weights?: number[];
  color?: string;
  /** Point size in world units. */
  size?: number;
}

export function PointCloud3D({
  points,
  dimension = 3,
  weights,
  color = '#60a5fa',
  size = 0.05,
}: PointCloud3DProps) {
  const { app, rootEntity } = usePlayCanvas();
  const entityRef = useRef<pc.Entity | null>(null);

  const positions = useMemo(() => pointsToPositions(points, dimension), [points, dimension]);
  const count = positions.length / 3;

  useEffect(() => {
    if (!app || !rootEntity) return;

    const parent = new pc.Entity('PointCloud3D', app);
    rootEntity.addChild(parent);
    entityRef.current = parent;

    const parsedCol = parseColor(color);
    const material = new pc.StandardMaterial();
    material.diffuse = parsedCol;
    // Engine v2 normalized gloss to 0..1 (it was 0..100 in v1). 40 was a
    // migration leftover and clamped to fully polished.
    material.gloss = 0.4;
    material.metalness = 0.1;
    material.update();

    // Create a sphere mesh for points
    const sphereMesh = createSphereMesh(app.graphicsDevice, 12);

    const matrixData = new Float32Array(count * 16);
    const mat = new pc.Mat4();

    for (let i = 0; i < count; i++) {
      const px = positions[i * 3]!;
      const py = positions[i * 3 + 1]!;
      const pz = positions[i * 3 + 2]!;

      let r = size;
      if (weights && weights[i] !== undefined) {
        // sqrt(w): natural scale for weighted alpha complexes (SPEC.md §4.2)
        r = size * (1 + Math.sqrt(Math.max(weights[i] ?? 0, 0)));
      }

      mat.setTRS(new pc.Vec3(px, py, pz), pc.Quat.IDENTITY, new pc.Vec3(r, r, r));
      const raw = mat.data;
      for (let m = 0; m < 16; m++) {
        matrixData[i * 16 + m] = raw[m]!;
      }
    }

    const vb = createInstancingVertexBuffer(app.graphicsDevice, matrixData, count);
    const meshInstance = new pc.MeshInstance(sphereMesh, material);
    meshInstance.setInstancing(vb);

    const renderEntity = new pc.Entity('PointCloudInstanced', app);
    renderEntity.addComponent('render', {
      meshInstances: [meshInstance],
    });
    parent.addChild(renderEntity);

    return () => {
      destroyEntity(parent);
      vb.destroy();
      material.destroy();
      sphereMesh.destroy();
      entityRef.current = null;
    };
  }, [app, rootEntity, positions, count, weights, color, size]);

  return null;
}
