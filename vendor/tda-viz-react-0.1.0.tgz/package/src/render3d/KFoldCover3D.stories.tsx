/**
 * <KFoldCover3D>: the k-fold cover as a solid, orbitable region.
 *
 * These stories build their filtrations AT STORY LOAD through the library's
 * own `buildFiltration`, against the REAL engine — the same call a consumer
 * makes. Nothing here is recorded or hand-authored: the k = 4 mosaic, and the
 * region the surface traces, are what tda-wasm and the arithmetic produce for
 * these points.
 *
 * WHAT TO LOOK AT. Two Barlow packings, identical apart from how the layers
 * stack: HCP has them ECLIPSED (A B A) and its two tetrahedral holes share a
 * FACE; FCC has them STAGGERED (A B C) and its holes share only an EDGE. Both
 * open a pair of depth-4 lobes at t = 0.375, the squared circumradius of four
 * touching unit spheres. Scrub past that and the lobes grow toward each other
 * — and the pair JOINS at t ≈ 0.670 for HCP but not until t ≈ 0.7525 for FCC,
 * because a shared face is a shorter way through than a shared edge.
 *
 * The point of drawing it in 3D rather than on a plane is that the joining is a
 * three-dimensional event. <DepthSlice3D> shows the cross-section of it exactly
 * and cannot show the shape of the lobes, the neck they join through, or how
 * many of them there are. Orbit these.
 *
 * AND THERE ARE MORE THAN TWO. At t = 0.42 each motif's 4-fold cover is exactly
 * two components — the two tetrahedral lobes the comparison is about. Above
 * t = 0.5, the squared circumradius of the OCTAHEDRAL hole of unit spheres,
 * further depth-4 regions are born around the other 4-tuples, so by t = 0.7
 * there are seven or eight pieces on screen. That is what the region really is;
 * a plane through the two tetrahedral holes shows two because it cuts only
 * those. The claim being read off these pictures is about the two lobes and the
 * segment between them, and it survives the company.
 *
 * The pale shell around everything is the ONE-fold cover — the plain union of
 * the balls, which is what <Field3D> approximates with instanced spheres and
 * what this traces exactly. It is the same shader at k = 1, which is the whole
 * argument: the union says nothing about k, and the lobes inside it are what k
 * buys.
 */
import { useEffect, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import wasmUrl from 'tda-wasm/dist/persistent_cohomology.wasm?url';
import { TdaEngine } from '../compute/TdaEngine';
import { buildFiltration } from '../engine/buildFiltration';
import type { Filtration } from '../filtration/types';
import { KFoldCover3D } from './KFoldCover3D';
import { PlayCanvasStage } from './PlayCanvasStage';
import { PointCloud3D } from './PointCloud3D';

/** k, the cover multiplicity every story here builds and draws. */
const K = 4;

/**
 * The surface colours, from DESIGN.md rather than from any reference picture.
 * The k-fold cover's mosaic is a NERVE, and `--nerve-on-ink` (#2dd4bf) is the
 * colour this design system gives a nerve surface drawn on ink — so it is the
 * cover itself. The union shell is a neutral cool grey: it is CONTEXT, not a
 * second claim, and giving it the same hue would read as two grades of one
 * quantity when it is a different k.
 */
const COVER_COLOR = '#2dd4bf';
const UNION_COLOR = '#9db1cf';
/** The cloud, in the paper of the ink page — the balls' centres, nothing more. */
const POINT_COLOR = '#e8e6e1';

// ── The eight-sphere motifs ──────────────────────────────────────────────
//
// Verbatim from wasm-tda-webapp/public/datasets/motif_{hcp,fcc}_8.json (the
// Explorer's own datasets). A Storybook story cannot read that sibling
// checkout's public/ directory, so the points travel inline. Eight
// unit-diameter spheres: a hexagonal layer of six with one sphere above and one
// below. Seeds 777 and 778, jitter 2e-3.

interface Cloud {
  name: string;
  stacking: string;
  points: number[];
  /** Where the two depth-4 lobes join, from the arithmetic. */
  join: number;
  /** Drop mosaic simplices born after this squared radius. */
  maxSquaredRadius: number;
  camera: [number, number, number];
  target: [number, number, number];
  pointSize: number;
}

const MOTIFS: Cloud[] = [
  {
    name: 'HCP — layers eclipsed (A B A)',
    stacking: 'the two tetrahedral holes share the FACE 0-1-2',
    points: [
      0.0007, -0.0019, -0.0012, 0.9985, 0.0005, -0.0005, 0.499, 0.867, 0.0005, -0.4989, 0.8668,
      0.0014, 0.4986, -0.8653, 0.0002, -0.4983, -0.8659, -0.0017, 0.5017, 0.2896, 0.8184, 0.4985,
      0.2881, -0.8183,
    ],
    join: 0.67,
    maxSquaredRadius: 4,
    camera: [3.1, 0.75, 0.95],
    target: [0.2, 0, 0],
    pointSize: 0.045,
  },
  {
    name: 'FCC — layers staggered (A B C)',
    stacking: 'the two tetrahedral holes share only the EDGE 0-1',
    points: [
      -0.0019, 0.0004, 0.0014, 1.0007, 0.0007, 0.0013, 0.502, 0.8671, -0.0006, -0.5009, 0.8653,
      0.0018, 0.4996, -0.8674, -0.0016, -0.4996, -0.8673, 0, 0.5, 0.2875, 0.8185, 0.5014, -0.2888,
      -0.8169,
    ],
    join: 0.7525,
    maxSquaredRadius: 4,
    camera: [3.1, 0.75, 0.95],
    target: [0.2, 0, 0],
    pointSize: 0.045,
  },
];

// ── The 48-sphere lattices ───────────────────────────────────────────────
//
// Verbatim from wasm-tda-webapp/public/datasets/{fcc,hcp}_48.json: four
// hexagonal layers of 4x3 spheres at unit spacing, jittered by 2e-3 so the
// order-k mosaic is non-degenerate. Seeds 20260841 and 20260842. At k = 4 the
// cover is a whole lattice of lobes rather than a single pair, which is the
// picture the motifs are a two-hole excerpt of.
const FCC48_POINTS = [
  -0.0013, 0.0001, -0.0018, 0.5013, 0.8654, -0.0011, 1.002, 1.7324, -0.0008, 1.0006, -0.0015,
  -0.0015, 1.498, 0.8667, -0.0019, 2.0006, 1.7338, -0.0001, 1.999, 0.001, 0.0018, 2.4989,
  0.8672, -0.001, 3.0005, 1.7307, -0.0019, 2.9999, -0.0014, -0.0017, 3.5008, 0.8662, 0.0004,
  3.9982, 1.7304, 0, 0.5014, 0.2882, 0.8174, 0.9993, 1.1535, 0.8145, 1.5002, 2.0223, 0.8174,
  1.5015, 0.2895, 0.8167, 2.0015, 1.1548, 0.8179, 2.5007, 2.0198, 0.8156, 2.5005, 0.2875,
  0.8153, 3.0002, 1.1531, 0.816, 3.4996, 2.0204, 0.8171, 3.4993, 0.2892, 0.8171, 4.0006,
  1.1557, 0.8176, 4.5018, 2.0212, 0.8156, 1.0008, 0.5793, 1.6349, 1.5001, 1.4434, 1.6324,
  1.9991, 2.3113, 1.6333, 1.9993, 0.578, 1.6344, 2.499, 1.4441, 1.6321, 3.0014, 2.3083,
  1.6337, 2.9989, 0.5792, 1.6312, 3.4991, 1.4441, 1.6322, 3.9984, 2.3098, 1.6337, 4.0018,
  0.5791, 1.6328, 4.4996, 1.4414, 1.6335, 5.0005, 2.3087, 1.6313, -0.0005, -0.0015, 2.4498,
  0.4994, 0.8674, 2.4483, 1.0019, 1.7307, 2.4482, 1.0004, -0.0013, 2.4491, 1.5004, 0.8644,
  2.4496, 2.0008, 1.7335, 2.4488, 1.9997, -0.0008, 2.4476, 2.5003, 0.8641, 2.4489, 2.9982,
  1.7303, 2.4494, 2.9989, 0.0014, 2.4512, 3.5001, 0.8671, 2.4504, 3.9997, 1.7302, 2.4498,
];

const HCP48_POINTS = [
  0.0007, -0.0001, -0.0001, 0.4981, 0.8649, -0.0002, 0.9982, 1.7302, -0.0001, 1.0001, 0.0001,
  -0.0011, 1.5013, 0.8643, -0.0016, 2.0018, 1.7313, 0.0009, 2, 0.0006, -0.0018, 2.5016,
  0.8641, 0.0007, 3, 1.7326, -0.0012, 3.0006, -0.001, 0.0017, 3.501, 0.8679, 0.0005, 3.9981,
  1.7324, 0.0017, 0.4987, 0.2888, 0.816, 0.9987, 1.1531, 0.8173, 1.5011, 2.0221, 0.8152, 1.5,
  0.2899, 0.8178, 1.9992, 1.1543, 0.8169, 2.5006, 2.0192, 0.8169, 2.499, 0.2883, 0.8154,
  2.9998, 1.1554, 0.8167, 3.5009, 2.0199, 0.8157, 3.5004, 0.2886, 0.8175, 4.0006, 1.1527,
  0.8147, 4.4983, 2.0193, 0.8155, -0.0015, -0.0012, 1.6326, 0.5015, 0.866, 1.634, 0.9985,
  1.7326, 1.6339, 0.9989, -0.0016, 1.6343, 1.4991, 0.8662, 1.6346, 2.0002, 1.731, 1.635,
  2.0005, -0.0008, 1.6319, 2.4982, 0.8673, 1.6338, 3.0008, 1.732, 1.6312, 3.0018, -0.0008,
  1.6347, 3.4982, 0.8663, 1.6342, 4.0007, 1.7313, 1.6343, 0.5009, 0.2895, 2.45, 0.9993,
  1.1546, 2.4506, 1.5011, 2.0191, 2.4486, 1.5002, 0.2882, 2.4509, 2.0015, 1.1557, 2.4488,
  2.5017, 2.0219, 2.4492, 2.4985, 0.2902, 2.4491, 2.9999, 1.1533, 2.4481, 3.4994, 2.0208,
  2.449, 3.5009, 0.287, 2.4484, 4.0011, 1.1561, 2.4501, 4.4993, 2.021, 2.4482,
];

const LATTICES: Cloud[] = [
  {
    name: 'HCP, 48 spheres — layers eclipsed (A B)',
    stacking: 'four hexagonal layers, A B A B',
    points: HCP48_POINTS,
    join: 0.67,
    // The site's own bound for these clouds at k = 4: the order-4 mosaic's
    // cost grows quickly with k and n, and every lobe of interest is born and
    // joined well below 0.8.
    maxSquaredRadius: 0.8,
    camera: [2.5, 5.5, 8.5],
    target: [2.2, 1.05, 1.2],
    pointSize: 0.05,
  },
  {
    name: 'FCC, 48 spheres — layers staggered (A B C)',
    stacking: 'four hexagonal layers, A B C A',
    points: FCC48_POINTS,
    join: 0.7525,
    maxSquaredRadius: 0.8,
    camera: [2.5, 5.5, 8.5],
    target: [2.4, 1.15, 1.2],
    pointSize: 0.05,
  },
];

// ── The engine, once per Storybook session ───────────────────────────────

/**
 * One engine for the whole story file. `createWorker: null` keeps the build on
 * the calling thread — there are four small builds and nothing to parallelise
 * — and `locateFile` points the Emscripten runtime at the wasm Vite emitted.
 */
let enginePromise: Promise<TdaEngine> | null = null;
function sharedEngine(): Promise<TdaEngine> {
  if (!enginePromise) {
    const engine = new TdaEngine({
      wasmUrl,
      moduleOptions: { locateFile: (path: string) => (path.endsWith('.wasm') ? wasmUrl : path) },
      createWorker: null,
    });
    enginePromise = engine.initialize().then(() => engine);
  }
  return enginePromise;
}

/** One build per cloud, cached: scrubbing t must never call the engine again. */
const builds = new Map<string, Promise<Filtration>>();
function buildCloud(cloud: Cloud): Promise<Filtration> {
  const cached = builds.get(cloud.name);
  if (cached) return cached;
  const built = sharedEngine().then((engine) =>
    buildFiltration(
      engine,
      {
        points: cloud.points,
        weights: new Array(cloud.points.length / 3).fill(0),
        dimension: 3,
      },
      { complexType: 'kfold', k: K, maxSquaredRadius: cloud.maxSquaredRadius },
    ),
  );
  builds.set(cloud.name, built);
  return built;
}

// ── The view ─────────────────────────────────────────────────────────────

const caption: React.CSSProperties = {
  fontFamily: 'ui-monospace, monospace',
  fontSize: 12,
  lineHeight: 1.6,
  marginBottom: 8,
};

function CloudPanel({
  cloud,
  t,
  showUnion,
  width,
  height,
}: {
  cloud: Cloud;
  t: number;
  showUnion: boolean;
  width: number;
  height: number;
}) {
  const [filtration, setFiltration] = useState<Filtration | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    buildCloud(cloud).then(
      (f) => {
        if (live) setFiltration(f);
      },
      (e: unknown) => {
        if (live) setError(e instanceof Error ? e.message : String(e));
      },
    );
    return () => {
      live = false;
    };
  }, [cloud]);

  return (
    <figure style={{ margin: 0, width }}>
      <figcaption style={caption}>
        <strong>{cloud.name}</strong>
        <br />
        {cloud.stacking}
        <br />
        the depth-{K} lobes join at t ≈ {cloud.join}
      </figcaption>
      <div style={{ width, height }}>
        <PlayCanvasStage
          cameraPosition={cloud.camera}
          targetPosition={cloud.target}
          fov={45}
          enableControls
        >
          {filtration ? (
            <>
              <PointCloud3D
                points={cloud.points}
                dimension={3}
                size={cloud.pointSize}
                color={POINT_COLOR}
              />
              <KFoldCover3D
                filtration={filtration}
                t={t}
                colorCover={COVER_COLOR}
                colorUnion={showUnion ? UNION_COLOR : undefined}
              />
            </>
          ) : null}
        </PlayCanvasStage>
      </div>
      {error ? (
        <p style={{ ...caption, color: '#b45309' }}>The engine did not load: {error}</p>
      ) : null}
    </figure>
  );
}

/**
 * The comparison itself: the same scale, the same colours and the same k on
 * both clouds, so the only difference on screen is how the layers stack.
 */
function CoverComparison({
  t,
  showUnion,
  clouds,
  width = 420,
  height = 360,
}: {
  t: number;
  showUnion: boolean;
  clouds?: Cloud[];
  width?: number;
  height?: number;
}) {
  const list = clouds ?? MOTIFS;
  return (
    <div>
      <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>
        {list.map((c) => (
          <CloudPanel
            key={c.name}
            cloud={c}
            t={t}
            showUnion={showUnion}
            width={width}
            height={height}
          />
        ))}
      </div>
      <p style={{ ...caption, marginTop: 12, maxWidth: 880 }}>
        t = {t} (a squared radius). The solid teal region is the {K}-fold cover — every point of
        space covered by at least {K} of the balls of radius √t. The pale shell is the ONE-fold
        cover, the plain union of those balls, drawn by the same shader at k = 1. Drag to orbit.
      </p>
    </div>
  );
}

const meta = {
  title: '3D/KFoldCover3D',
  component: CoverComparison,
  parameters: { layout: 'padded' },
  argTypes: {
    t: { control: { type: 'range', min: 0, max: 1.2, step: 0.005 } },
    showUnion: { control: 'boolean' },
  },
} satisfies Meta<typeof CoverComparison>;

export default meta;
type Story = StoryObj<typeof meta>;

/**
 * Just past the birth: t = 0.42, a little above the squared circumradius 0.375.
 * Each motif's 4-fold cover is exactly TWO components here — the two tetrahedral
 * holes — inside the union shell.
 */
export const TwoLobesOpen: Story = { args: { t: 0.42, showUnion: true } };

/**
 * t = 0.70: the eclipsed pair has joined through its shared face and reads as
 * one body; the staggered pair still has a cleft between its two lobes. The
 * same two numbers <DepthSlice3D> reads off a plane, here as one solid against
 * two. The smaller lobes around them are the octahedral holes, born since
 * t = 0.5.
 */
export const EclipsedJoinsFirst: Story = { args: { t: 0.7, showUnion: true } };

/** t = 0.80: both tetrahedral pairs have joined, and each reads as one body. */
export const BothJoined: Story = { args: { t: 0.8, showUnion: true } };

/**
 * The lobes alone, with the union shell off — the shape of the region, with
 * nothing in front of it.
 */
export const NoUnionShell: Story = { args: { t: 0.7, showUnion: false } };

/**
 * The 48-sphere lattices at the same k. A Barlow packing's tetrahedral holes
 * are a LATTICE of them, not a pair: the motifs are the two-hole excerpt that
 * makes the face-versus-edge argument, and this is what that argument is a
 * statement about. Scrub through 0.67 and watch the HCP lobes chain together a
 * scale before the FCC ones do.
 */
export const Lattices48: Story = {
  args: { t: 0.7, showUnion: true, clouds: LATTICES, width: 480, height: 420 },
};
