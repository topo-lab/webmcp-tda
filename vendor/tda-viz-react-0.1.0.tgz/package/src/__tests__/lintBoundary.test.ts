// @vitest-environment node
import { describe, expect, it } from 'vitest';
import { ESLint } from 'eslint';

/**
 * The layering rule (SPEC.md §2) is enforced by an actual ESLint
 * `no-restricted-imports` rule, not a comment. This test proves the rule
 * fires — if someone deletes or weakens the eslint.config.js block, this
 * test fails.
 */
const eslint = new ESLint();

async function restrictedImportErrors(filePath: string, code: string) {
  const [result] = await eslint.lintText(code, { filePath });
  return (result?.messages ?? []).filter((m) => m.ruleId === 'no-restricted-imports');
}

describe('headless-layer import boundary (SPEC.md §2)', () => {
  it('forbids playcanvas in src/compute', async () => {
    const errors = await restrictedImportErrors(
      'src/compute/__lint_probe__.ts',
      "import 'playcanvas';\n",
    );
    expect(errors.length).toBeGreaterThan(0);
  });

  it('forbids playcanvas subpaths in src/compute', async () => {
    const errors = await restrictedImportErrors(
      'src/compute/__lint_probe__.ts',
      "import 'playcanvas/build/playcanvas.js';\n",
    );
    expect(errors.length).toBeGreaterThan(0);
  });

  it('forbids d3 (and d3-* subpackages) in src/state', async () => {
    expect(
      await restrictedImportErrors('src/state/__lint_probe__.ts', "import 'd3';\n"),
    ).not.toHaveLength(0);
    expect(
      await restrictedImportErrors('src/state/__lint_probe__.ts', "import 'd3-scale';\n"),
    ).not.toHaveLength(0);
  });

  it('forbids playcanvas and d3 in src/engine (the adapter is headless, SPEC.md §2)', async () => {
    expect(
      await restrictedImportErrors('src/engine/__lint_probe__.ts', "import 'playcanvas';\n"),
    ).not.toHaveLength(0);
    expect(
      await restrictedImportErrors('src/engine/__lint_probe__.ts', "import 'd3';\n"),
    ).not.toHaveLength(0);
  });

  it('forbids playcanvas in src/filtration (the central abstraction is headless)', async () => {
    expect(
      await restrictedImportErrors('src/filtration/__lint_probe__.ts', "import 'playcanvas';\n"),
    ).not.toHaveLength(0);
  });

  it('still allows playcanvas in src/render3d (the isolated 3D module)', async () => {
    const errors = await restrictedImportErrors(
      'src/render3d/__lint_probe__.tsx',
      "import 'playcanvas';\n",
    );
    expect(errors).toHaveLength(0);
  });
});
