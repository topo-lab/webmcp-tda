/**
 * The engine adapter (SPEC.md §2, §3.2): one engine BUILD per
 * (cloud, weights, params). Everything downstream — shapeAt, radiusAt,
 * simplicesAt, the whole UI — is a pure function of the result and t
 * (SPEC.md §1.5). Nothing here is ever called again because t moved.
 *
 * Validation happens HERE, up front, and mirrors the engine's own rules so a
 * caller sees a sentence instead of a WASM abort: negative weights, weighted
 * clouds handed to unweighted builders, 3D-only and 2D-only constructions,
 * non-positive cutoffs, coincident input for the k-fold cover. The engine
 * rejects all of those too, some of them opaquely ("Alpha complex computation
 * failed: undefined"), and the adapter must never let that reach a user.
 *
 * The z=0 embedding of 2D clouds into the 3D-only weighted alpha binding
 * lives here and nowhere else.
 */
import type { EllipsoidAxesMode, Point3D } from 'tda-wasm';
import type { TdaEngine } from '../compute/TdaEngine';
import { createFiltration } from '../filtration/createFiltration';
import { createGridFiltration } from '../filtration/createGridFiltration';
import type {
  AnyFiltration,
  BallFiltration,
  BoxFiltration,
  EllipsoidFiltration,
  Filtration,
  GridConstruction,
  GridDirection,
  GridFiltration,
  WeightedCloud,
  WingFiltration,
} from '../filtration/types';
import { DEFAULT_MAX_SIMPLEX_DIMENSION } from '../state/honesty';

interface CommonFiltrationParams {
  /** Simplex-dimension cap (default 2, SPEC.md §1.6). */
  maxSimplexDimension?: number;
  /** Coefficient field characteristic (default 2). */
  coeffField?: number;
}

/** Weighted alpha: the filtration is intrinsic, so it takes no scale. */
export interface AlphaFiltrationParams extends CommonFiltrationParams {
  complexType: 'alpha';
  /**
   * Not accepted: alpha's honest cap is the triangulation's own dimension, so
   * there is nothing to choose and a supplied cap would be silently dropped.
   */
  maxSimplexDimension?: undefined;
}

/** Vietoris–Rips: `maxEdgeLength` is the max edge length. Required. */
export interface RipsFiltrationParams extends CommonFiltrationParams {
  complexType: 'rips';
  maxEdgeLength?: number;
}

/** Čech: `maxEdgeLength` is the max ball radius (the engine's MEB radius). */
export interface CechFiltrationParams extends CommonFiltrationParams {
  complexType: 'cech';
  maxEdgeLength?: number;
}

/** Witness: refused. The engine has no weighted witness filtration (§8 Q3). */
export interface WitnessFiltrationParams extends CommonFiltrationParams {
  complexType: 'witness';
}

/**
 * k-fold cover: the order-k Delaunay mosaic filtered by SQUARED radius.
 * 3D and unweighted only, and it refuses coincident input by index.
 */
export interface KFoldFiltrationParams extends CommonFiltrationParams {
  complexType: 'kfold';
  /** Cover multiplicity k ≥ 1. Needs at least k + 3 points. */
  k: number;
  /**
   * Drop simplices born after this squared radius. Cost grows quickly with k,
   * so bounding it is the usual way to keep a browser call cheap.
   */
  maxSquaredRadius?: number;
}

/**
 * Ellipsoid complexes: `ellipsoid-rips` is a FLAG complex, `ellipsoid-cech`
 * is a true nerve, and both grow the same ellipsoids at the same scale
 * (filtration = twice the birth radius).
 */
export interface EllipsoidFiltrationParams extends CommonFiltrationParams {
  complexType: 'ellipsoid-rips' | 'ellipsoid-cech';
  /** k, the local PCA neighbourhood. Integer ≥ 2; counts the point itself. */
  neighborhoodSize: number;
  /** Tangent-to-normal semi-axis ratio q ≥ 1, or 'pca' for singular values. */
  axesMode: EllipsoidAxesMode;
  /**
   * Cutoff on the filtration value, in the emitted (Rips-comparable) units.
   * REQUIRED, and not because the engine demands it: every pair of ellipsoids
   * eventually touches, so an uncut build asks for the complete complex.
   */
  maxFiltration: number;
}

/** 2D curvature-adaptive wing complex (flag / Rips-type, never a nerve). */
export interface WingFiltrationParams extends CommonFiltrationParams {
  complexType: 'wing';
  /** Spine half-length / wing-length ratio q ∈ [0, 1]. */
  q: number;
  /** Wing angle θ ∈ (0, π/2], radians. */
  theta: number;
  /**
   * Flat unit normals, length 2n (exact-sampling mode). Exclusive with
   * `neighborhoodSize`.
   */
  normals?: readonly number[];
  /**
   * k ≥ 2, the neighbourhood for estimated osculating-circle normals. Exclusive
   * with `normals`. Both modes are drawable: `computeWingGeometry` reads the
   * estimated normals back out of the builder, and every wing carries where its
   * normal came from (`WingShape.normalSource`).
   */
  neighborhoodSize?: number;
  /** Omit edges with birth > maxEps. */
  maxEps?: number;
}

/** Box filtration: a nerve by Helly, on a grid of multiples of `stepSize`. */
export interface BoxFiltrationParams extends CommonFiltrationParams {
  complexType: 'box';
  /** π > 0: the growth increment AND the filtration grid spacing. */
  stepSize: number;
  /** Growth aggressiveness in [0, 1]; the paper's experiments use ~0.5. */
  alpha: number;
  /** Stop after this many steps. Omit to run to the paper's m. */
  maxSteps?: number;
  /**
   * Keep the grown boxes so `shapeAt` can draw them. Default TRUE here: the
   * growing shape is this library's subject (SPEC.md §0). Costs
   * (steps + 1) · n box records; set false for a summary-only build.
   */
  retainBoxes?: boolean;
}

/**
 * The cubical filtration of a GRID OF VALUES — the one construction here that
 * takes no cloud (SPEC.md §3.1b).
 *
 * It is passed WITHOUT a second argument, `buildFiltration(engine, params)`,
 * because there is no cloud to pass and an ignored parameter is worse than a
 * shorter call: a caller who hands this one a cloud has misunderstood what a
 * cubical complex is built from, and the signature should say so rather than
 * silently discard it. The grid travels in the params for the same reason the
 * box filtration's step does — it is the thing the construction is OF.
 */
export interface CubicalFiltrationParams {
  complexType: 'cubical';
  /** Row-major values, `width * height` finite numbers. */
  values: Float64Array | readonly number[];
  /** Values per row: pixels under `cubical-t`, grid vertices under `cubical-v`. */
  width: number;
  /** Rows: pixels under `cubical-t`, grid vertices under `cubical-v`. */
  height: number;
  /**
   * Which convention the values live in. REQUIRED, and deliberately without a
   * default: the two give different diagrams on the same numbers (SPEC.md
   * §1.3), so a default here would be the library quietly choosing what the
   * picture means.
   */
  construction: GridConstruction;
  /**
   * Which side of the threshold to filter by. REQUIRED for the same reason:
   * the sublevel and superlevel diagrams of one image are different diagrams,
   * and neither is the obvious one.
   */
  direction: GridDirection;
  /**
   * Coefficient field, `cubical-t` only (default 2). The `cubical-v` binding is
   * an F2-only implementation and refuses anything else rather than ignoring it.
   */
  coeffField?: number;
}

/** The constructions whose growing shape is a ball. */
export type BallFiltrationParams =
  AlphaFiltrationParams | RipsFiltrationParams | CechFiltrationParams | KFoldFiltrationParams;

/** Parameters for any cloud construction `buildFiltration` accepts. */
export type FiltrationParams =
  | BallFiltrationParams
  | WitnessFiltrationParams
  | EllipsoidFiltrationParams
  | WingFiltrationParams
  | BoxFiltrationParams;

function validateCloud(cloud: WeightedCloud): void {
  const { points, weights, dimension } = cloud;
  if (points.length % dimension !== 0) {
    throw new Error(`points length ${points.length} is not a multiple of dimension ${dimension}`);
  }
  const count = points.length / dimension;
  if (weights.length !== count) {
    throw new Error(
      `weights length ${weights.length} does not match the points count ${count} ` +
        '(one weight per point; use 0 for unweighted points, SPEC.md §1.2)',
    );
  }
  for (let i = 0; i < points.length; i++) {
    if (!Number.isFinite(points[i])) {
      throw new Error(`coordinate at index ${i} must be finite, got ${points[i]}`);
    }
  }
  for (let i = 0; i < weights.length; i++) {
    if (!Number.isFinite(weights[i]) || weights[i] < 0) {
      throw new Error(
        `weight at index ${i} must be non-negative and finite, got ${weights[i]} ` +
          '(the engine rejects negative weights; the general power filtration with ' +
          'w < 0 is unreachable through tda-wasm, SPEC.md §1.2)',
      );
    }
  }
}

/**
 * Every builder except weighted alpha ignores weights at the engine boundary.
 * Handing one a weighted cloud would silently draw a DIFFERENT filtration, so
 * refuse (SPEC.md §3.2).
 */
function requireUnweighted(cloud: WeightedCloud, subject: string): void {
  if (cloud.weights.some((w) => w !== 0)) {
    throw new Error(
      `${subject}: this builder ignores weights at the engine boundary (SPEC.md §3.2), and ` +
        'this cloud has nonzero weights. Use complexType "alpha" (the only weighted path), ' +
        'or zero the weights explicitly to draw the unweighted filtration.',
    );
  }
}

function requireDimension(cloud: WeightedCloud, complexType: string, dimension: 2 | 3): void {
  if (cloud.dimension !== dimension) {
    const why =
      dimension === 3
        ? 'the level-by-level order-k construction relies on Edelsbrunner–Osang Theorem 5, ' +
          'which is stated for 3D point sets'
        : 'the wing construction is 2D only (Weng–Zhao §6 item 1: the 3D case is open ' +
          'research, and the engine will not attempt it)';
    throw new Error(
      `${complexType} requires a ${dimension}D cloud, got ${cloud.dimension}D — ${why}.`,
    );
  }
}

function requirePositive(name: string, value: number | undefined, complexType: string): void {
  if (value === undefined) return;
  if (!(value > 0) || !Number.isFinite(value)) {
    throw new Error(`${complexType}: ${name} must be a positive finite number, got ${value}`);
  }
}

/**
 * The k-fold cover rejects coincident input by index, because a repeated point
 * breaks the order-k mosaic. Find it here so the message names both indices.
 */
function requireDistinctPoints(cloud: WeightedCloud, complexType: string): void {
  const { points, dimension } = cloud;
  const seen = new Map<string, number>();
  for (let i = 0; i < points.length / dimension; i++) {
    const key = points.slice(i * dimension, (i + 1) * dimension).join(',');
    const previous = seen.get(key);
    if (previous !== undefined) {
      throw new Error(
        `${complexType}: input points ${previous} and ${i} coincide at (${key}). The engine ` +
          'rejects coincident input rather than returning a mosaic with vertices missing; ' +
          'perturb the cloud (its own fixtures jitter lattices for exactly this reason).',
      );
    }
    seen.set(key, i);
  }
}

/**
 * The grid, checked the way every other builder checks its input: up front,
 * mirroring the engine's own rules, so a caller reads a sentence instead of a
 * WASM abort (tda-wasm `validateCubicalInput`, which rejects non-positive
 * dimensions, a length mismatch and non-finite values, and whose messages this
 * anticipates rather than waits for).
 *
 * Returns the values as a `Float64Array`, copied: the filtration must not be
 * able to change under the caller's hands after it is built.
 */
function validateGrid(params: CubicalFiltrationParams): Float64Array {
  const { values, width, height, construction, direction } = params;
  if (construction !== 'cubical-t' && construction !== 'cubical-v') {
    throw new Error(
      `cubical: construction must be 'cubical-t' (values on pixels) or 'cubical-v' ` +
        `(values on grid vertices), got ${String(construction)} — the two are different ` +
        'filtrations of the same numbers and there is no default (SPEC.md §1.3).',
    );
  }
  if (direction !== 'sublevel' && direction !== 'superlevel') {
    throw new Error(
      `cubical: direction must be 'sublevel' ({f <= t}) or 'superlevel' ({f >= t}), got ` +
        `${String(direction)} — they are different diagrams of the same image.`,
    );
  }
  if (!Number.isInteger(width) || width < 1 || !Number.isInteger(height) || height < 1) {
    throw new Error(
      `cubical: width and height must be positive integers, got ${width} × ${height}`,
    );
  }
  if (values.length !== width * height) {
    throw new Error(
      `cubical: values has ${values.length} entries but the grid is ${width} × ${height} ` +
        `= ${width * height}. The array is read ROW-MAJOR, one row of ${width} at a time.`,
    );
  }
  const out = new Float64Array(width * height);
  for (let i = 0; i < out.length; i++) {
    const v = values[i];
    if (typeof v !== 'number' || !Number.isFinite(v)) {
      throw new Error(
        `cubical: the value at index ${i} (column ${i % width}, row ${Math.floor(i / width)}) ` +
          `must be a finite number, got ${String(v)}. A NaN or an infinity has no place in ` +
          'the value order the filtration is built from.',
      );
    }
    out[i] = v;
  }
  if (construction === 'cubical-v' && params.coeffField !== undefined && params.coeffField !== 2) {
    throw new Error(
      `cubical-v: coeffField ${params.coeffField} is not available. The vertex lower-star ` +
        'binding is an F2-only implementation (tda-wasm ' +
        '`computeCubicalPersistenceFromVertices2D`), and it refuses another field rather ' +
        'than ignoring it and returning an F2 answer under another name. Use ' +
        "construction 'cubical-t' for a field other than 2.",
    );
  }
  return out;
}

/** z=0 embedding of 2D clouds into the 3D-only weighted alpha binding. */
function toWeightedPoints3D(cloud: WeightedCloud): Point3D[] {
  const { points, weights, dimension } = cloud;
  const out: Point3D[] = [];
  for (let i = 0; i < weights.length; i++) {
    out.push({
      x: points[i * dimension],
      y: points[i * dimension + 1],
      z: dimension === 3 ? points[i * dimension + 2] : 0,
      weight: weights[i],
    });
  }
  return out;
}

export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: BallFiltrationParams,
): Promise<BallFiltration>;
export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: EllipsoidFiltrationParams,
): Promise<EllipsoidFiltration>;
export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: WingFiltrationParams,
): Promise<WingFiltration>;
export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: BoxFiltrationParams,
): Promise<BoxFiltration>;
export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: FiltrationParams,
): Promise<Filtration>;
/** The grid domain: no cloud, because a cubical complex is not built from one. */
export function buildFiltration(
  engine: TdaEngine,
  params: CubicalFiltrationParams,
): Promise<GridFiltration>;

/**
 * Build the filtration for one (cloud, weights, params) — or, in the grid
 * domain, for one (grid, params). Moving t afterwards filters what is drawn;
 * it never triggers another engine call.
 */
export async function buildFiltration(
  engine: TdaEngine,
  cloudOrParams: WeightedCloud | CubicalFiltrationParams,
  maybeParams?: FiltrationParams,
): Promise<AnyFiltration> {
  if (maybeParams === undefined) {
    if (
      typeof cloudOrParams !== 'object' ||
      cloudOrParams === null ||
      (cloudOrParams as CubicalFiltrationParams).complexType !== 'cubical'
    ) {
      throw new Error(
        'buildFiltration was called with two arguments, which is the GRID form and takes ' +
          "cubical params (`{ complexType: 'cubical', values, width, height, construction, " +
          'direction }`). Every cloud construction takes three: (engine, cloud, params).',
      );
    }
    return buildGridFiltration(engine, cloudOrParams as CubicalFiltrationParams);
  }
  const cloud = cloudOrParams as WeightedCloud;
  const params = maybeParams;
  validateCloud(cloud);
  const coeffField = params.coeffField ?? 2;
  const maxSimplexDimension = params.maxSimplexDimension ?? DEFAULT_MAX_SIMPLEX_DIMENSION;
  const pointCount = cloud.weights.length;

  switch (params.complexType) {
    case 'witness':
      throw new Error(
        'witness complexes are not wired into this adapter: the engine exposes only ' +
          'the weak Euclidean witness complex, and a weighted witness filtration is ' +
          'not defined by the engine (SPEC.md §8 Q3).',
      );

    case 'alpha': {
      const complex = engine.computeWeightedAlphaComplex(toWeightedPoints3D(cloud));
      const persistence = engine.computePersistence(complex.simplices, coeffField);
      return createFiltration({
        cloud,
        convention: 'alpha',
        complexType: 'alpha',
        // Alpha is not truncated by a cap: the triangulation's own dimension is
        // the honest bound for what it can resolve.
        maxSimplexDimension: complex.dimension,
        simplices: complex.simplices,
        rawPairs: persistence.pairs,
      });
    }

    case 'rips':
    case 'cech': {
      const complexType = params.complexType;
      requireUnweighted(cloud, `${complexType} complexes`);
      if (
        params.maxEdgeLength === undefined ||
        params.maxEdgeLength <= 0 ||
        !Number.isFinite(params.maxEdgeLength)
      ) {
        throw new Error(
          `a positive finite maxEdgeLength is required for ${complexType} (max edge length ` +
            'for rips, max ball radius for cech) — a default or unbounded scale would be an ' +
            'invented parameter.',
        );
      }
      const pipeline = await engine.computePipelineAsync(cloud.points, cloud.dimension, {
        complexType,
        maxEdgeLength: params.maxEdgeLength,
        maxSimplexDimension,
        coeffField,
      });
      return createFiltration({
        cloud,
        convention: complexType,
        complexType,
        maxSimplexDimension,
        simplices: pipeline.complex.simplices,
        rawPairs: pipeline.persistence.pairs,
      });
    }

    case 'kfold': {
      requireUnweighted(cloud, 'the k-fold cover complex');
      requireDimension(cloud, 'the k-fold cover complex', 3);
      if (!Number.isInteger(params.k) || params.k < 1) {
        throw new Error(`kfold: k must be a positive integer, got ${params.k}`);
      }
      if (pointCount < params.k + 3) {
        throw new Error(
          `kfold: the order-${params.k} mosaic in 3D needs at least k + 3 = ${params.k + 3} ` +
            `points, got ${pointCount}`,
        );
      }
      requirePositive('maxSquaredRadius', params.maxSquaredRadius, 'kfold');
      requireDistinctPoints(cloud, 'kfold');

      const complex = engine.computeKFoldCoverComplex(
        cloud.points,
        params.k,
        params.maxSquaredRadius,
        maxSimplexDimension,
      );
      const persistence = engine.computePersistence(complex.simplices, coeffField);
      return createFiltration({
        cloud,
        // Squared radius with no weights: exactly the alpha radius law, so the
        // balls are drawn at √t — around INPUT POINTS, while the vertices below
        // are k-subsets of them.
        convention: 'alpha',
        complexType: 'kfold',
        maxSimplexDimension,
        simplices: complex.simplices,
        rawPairs: persistence.pairs,
        vertexSubsets: complex.mosaicVertices,
        // k travels with the filtration: it is a parameter of the
        // construction, and a renderer of the k-fold COVER (the region covered
        // at least k times) needs it without being told twice.
        coverMultiplicity: params.k,
      });
    }

    case 'ellipsoid-rips':
    case 'ellipsoid-cech': {
      const complexType = params.complexType;
      requireUnweighted(cloud, `${complexType} complexes`);
      if (!Number.isInteger(params.neighborhoodSize) || params.neighborhoodSize < 2) {
        throw new Error(
          `${complexType}: neighborhoodSize must be an integer >= 2, got ` +
            `${params.neighborhoodSize} (it counts the point itself and is clamped to n)`,
        );
      }
      if (
        params.axesMode !== 'pca' &&
        !(Number.isFinite(params.axesMode) && params.axesMode >= 1)
      ) {
        throw new Error(
          `${complexType}: axesMode must be a finite tangent-to-normal ratio >= 1 or 'pca', ` +
            `got ${String(params.axesMode)}`,
        );
      }
      if (!(params.maxFiltration > 0) || !Number.isFinite(params.maxFiltration)) {
        throw new Error(
          `${complexType}: maxFiltration must be a positive finite cutoff, got ` +
            `${params.maxFiltration}. Every pair of ellipsoids eventually touches, so an ` +
            'uncut build asks for the complete complex; the cutoff is in the emitted ' +
            '(Rips-comparable) units, which are TWICE the ellipsoid radius.',
        );
      }
      if (pointCount < 2) {
        throw new Error(`${complexType}: need at least 2 points, got ${pointCount}`);
      }

      const complex =
        complexType === 'ellipsoid-rips'
          ? engine.computeEllipsoidRipsComplex(
              cloud.points,
              cloud.dimension,
              params.neighborhoodSize,
              params.axesMode,
              maxSimplexDimension,
              params.maxFiltration,
            )
          : engine.computeEllipsoidCechComplex(
              cloud.points,
              cloud.dimension,
              params.neighborhoodSize,
              params.axesMode,
              maxSimplexDimension,
              params.maxFiltration,
            );
      // Second engine call, geometry only: the same local-PCA fitting the
      // complex used, so shapes and simplices can never disagree. Still one
      // BUILD — nothing here happens again because t moved (SPEC.md §1.5).
      const geometry = engine.computeEllipsoidGeometry(
        cloud.points,
        cloud.dimension,
        params.neighborhoodSize,
        params.axesMode,
      );
      const persistence = engine.computePersistence(complex.simplices, coeffField);
      return createFiltration({
        cloud,
        convention: 'ellipsoid-2r',
        complexType,
        maxSimplexDimension,
        simplices: complex.simplices,
        rawPairs: persistence.pairs,
        ellipsoid: {
          geometry,
          neighborhoodSize: params.neighborhoodSize,
          axesMode: params.axesMode,
        },
      });
    }

    case 'wing': {
      requireUnweighted(cloud, 'the wing complex');
      requireDimension(cloud, 'the wing complex', 2);
      if (!(params.q >= 0 && params.q <= 1)) {
        throw new Error(`wing: q must lie in [0, 1], got ${params.q}`);
      }
      if (!(params.theta > 0 && params.theta <= Math.PI / 2)) {
        throw new Error(`wing: theta must lie in (0, pi/2], got ${params.theta}`);
      }
      requirePositive('maxEps', params.maxEps, 'wing');
      if (pointCount < 2) {
        throw new Error(`wing: need at least 2 points, got ${pointCount}`);
      }
      const hasNormals = params.normals !== undefined;
      const hasK = params.neighborhoodSize !== undefined;
      if (hasNormals === hasK) {
        throw new Error(
          'wing: supply EXACTLY one of `normals` (a flat 2n array of unit normals, the ' +
            'exact-sampling mode) or `neighborhoodSize` (k >= 2, estimated ' +
            'osculating-circle normals). Both modes draw their wings; they differ in ' +
            'where the normal comes from, which every wing reports as `normalSource`.',
        );
      }
      if (params.normals !== undefined) {
        if (params.normals.length !== pointCount * 2) {
          throw new Error(
            `wing: normals must be a flat 2n array, expected ${pointCount * 2} numbers, ` +
              `got ${params.normals.length}`,
          );
        }
        for (let i = 0; i < pointCount; i++) {
          const len2 = params.normals[i * 2] ** 2 + params.normals[i * 2 + 1] ** 2;
          if (!(len2 > 0.25 && len2 < 4) || !Number.isFinite(len2)) {
            throw new Error(
              `wing: the normal at point ${i} must be a finite, roughly unit vector ` +
                `(the engine requires |α|² ∈ (0.25, 4) and then normalizes), got ` +
                `(${params.normals[i * 2]}, ${params.normals[i * 2 + 1]})`,
            );
          }
        }
      } else if (!Number.isInteger(params.neighborhoodSize) || params.neighborhoodSize! < 2) {
        throw new Error(
          `wing: neighborhoodSize must be an integer >= 2, got ${params.neighborhoodSize}`,
        );
      }

      const normalsOrK = params.normals ? [...params.normals] : params.neighborhoodSize!;
      const complex = engine.computeWingComplex(
        cloud.points,
        params.q,
        params.theta,
        normalsOrK,
        maxSimplexDimension,
        params.maxEps,
      );
      // Second engine call, geometry only, through the SAME normal resolution the
      // builder just used — supplied normals come back normalised, an estimated k
      // comes back as the fit the builder made. So the drawn wing is the wing
      // whose births are in `complex`, and the k mode is drawable too. Still one
      // BUILD: nothing here runs again because t moved (SPEC.md §1.5).
      const geometry = engine.computeWingGeometry(cloud.points, params.q, params.theta, normalsOrK);
      const persistence = engine.computePersistence(complex.simplices, coeffField);
      return createFiltration({
        cloud,
        convention: 'wing-eps',
        complexType: 'wing',
        maxSimplexDimension,
        simplices: complex.simplices,
        rawPairs: persistence.pairs,
        wing: { q: params.q, theta: params.theta, geometry },
      });
    }

    case 'box': {
      requireUnweighted(cloud, 'the box filtration');
      if (!(params.stepSize > 0) || !Number.isFinite(params.stepSize)) {
        throw new Error(
          `box: stepSize (π) must be a positive finite number, got ${params.stepSize}. It is ` +
            'both the growth increment and the filtration grid: every birth and death is an ' +
            'exact multiple of it.',
        );
      }
      if (!(params.alpha >= 0 && params.alpha <= 1)) {
        throw new Error(`box: alpha must lie in [0, 1], got ${params.alpha}`);
      }
      if (
        params.maxSteps !== undefined &&
        (!Number.isInteger(params.maxSteps) || params.maxSteps < 1)
      ) {
        throw new Error(`box: maxSteps must be a positive integer, got ${params.maxSteps}`);
      }
      if (pointCount < 1) {
        throw new Error('box: need at least 1 point');
      }

      const retainBoxes = params.retainBoxes ?? true;
      const result = engine.computeBoxFiltration(
        cloud.points,
        cloud.dimension,
        params.stepSize,
        params.alpha,
        params.maxSteps,
        maxSimplexDimension,
        retainBoxes,
      );
      const persistence = engine.computePersistence(result.simplices, coeffField);
      return createFiltration({
        cloud,
        convention: 'box-step',
        complexType: 'box',
        maxSimplexDimension,
        simplices: result.simplices,
        rawPairs: persistence.pairs,
        box: {
          stepSize: result.stepSize,
          numSteps: result.numSteps,
          alpha: result.alpha,
          maxBirthStep: result.maxBirthStep,
          extents: result.boxes ?? null,
        },
      });
    }

    default: {
      const exhausted: never = params;
      throw new Error(`Unknown complex type: ${String(exhausted)}`);
    }
  }
}

/**
 * The grid domain (SPEC.md §3.1b). One engine call, and the same §1.5 contract
 * as every other build: moving the threshold afterwards filters what is drawn
 * and never comes back here.
 *
 * SUPERLEVEL IS THE SUBLEVEL FILTRATION OF −f. Neither cubical binding takes a
 * direction — the engine computes sublevel only — so a superlevel build negates
 * the grid, runs the identical binding, and negates the endpoints back into the
 * image's own units. The identity is exact for both constructions because
 * min(−v) = −max(v): under negation the T-construction's minimum-over-pixels
 * rule becomes a maximum and the V-construction's lower star becomes the upper
 * star, which is what a superlevel filtration is. Nothing is approximated and
 * nothing is resampled. The negation lives HERE, at the engine boundary, so
 * that everything downstream — the pairs, the renderer, the barcode — is in
 * image units and no other layer has to remember a sign.
 *
 * A superlevel diagram therefore runs DOWNWARD: birth >= death, because the
 * sweep does. That is not a defect to normalise away; it is the direction the
 * filtration goes, and `GridFiltration.containsValue` is the one predicate
 * that reads it.
 */
async function buildGridFiltration(
  engine: TdaEngine,
  params: CubicalFiltrationParams,
): Promise<GridFiltration> {
  const values = validateGrid(params);
  const { width, height, construction, direction } = params;
  const superlevel = direction === 'superlevel';
  const swept = superlevel ? Array.from(values, (v) => -v) : Array.from(values);

  const persistence =
    construction === 'cubical-t'
      ? engine.computeCubicalPersistence2D(swept, width, height, params.coeffField ?? 2)
      : engine.computeCubicalPersistenceFromVertices2D(swept, width, height);

  const rawPairs = superlevel
    ? persistence.pairs.map((p) => ({ dimension: p.dimension, birth: -p.birth, death: -p.death }))
    : persistence.pairs;

  return createGridFiltration({
    values,
    width,
    height,
    construction,
    direction,
    rawPairs,
  });
}
