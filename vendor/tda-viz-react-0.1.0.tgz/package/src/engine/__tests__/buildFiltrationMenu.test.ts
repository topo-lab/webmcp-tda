// The adapter over the whole complex menu (SPEC.md §3.2, §5): routing and
// validation. The MATH of each construction is checked against the real engine
// (buildFiltration.integration.test.ts + recorded fixtures); this file checks
// that the adapter calls the right binding with the right arguments, and that
// it refuses what the engine refuses — with a sentence, before the WASM call.
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { mockControl } from '../../../__mocks__/tda-wasm';
import { TdaEngine } from '../../compute/TdaEngine';
import type { WeightedCloud } from '../../filtration/types';
import { buildFiltration } from '../buildFiltration';

vi.mock('tda-wasm', () => import('../../../__mocks__/tda-wasm'));

const cloud2D = (weights = [0, 0, 0]): WeightedCloud => ({
  points: [0, 0, 1, 0, 0.5, 1],
  weights,
  dimension: 2,
});

const cloud3D = (n = 8, weights?: number[]): WeightedCloud => {
  const points: number[] = [];
  for (let i = 0; i < n; i++) points.push(i * 0.9, i * i * 0.31, Math.sin(i) * 0.77);
  return { points, weights: weights ?? new Array(n).fill(0), dimension: 3 };
};

async function readyEngine(): Promise<TdaEngine> {
  const engine = new TdaEngine({ createWorker: null });
  await engine.initialize();
  return engine;
}

const ellipsoidParams = {
  neighborhoodSize: 3,
  axesMode: 2,
  maxFiltration: 1.5,
} as const;

beforeEach(() => {
  mockControl.reset();
  vi.clearAllMocks();
});

describe('routing: each complex type reaches its OWN binding, with its own args', () => {
  it('ellipsoid-rips calls the flag builder plus the geometry call', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'ellipsoid-rips',
      ...ellipsoidParams,
    });
    expect(gudhi.computeEllipsoidRipsComplex).toHaveBeenCalledWith(
      [0, 0, 1, 0, 0.5, 1],
      2,
      3,
      2,
      2,
      1.5,
    );
    expect(gudhi.computeEllipsoidCechComplex).not.toHaveBeenCalled();
    // The geometry is a SECOND call with the same fitting parameters, so the
    // drawn ellipsoids can never disagree with the simplices.
    expect(gudhi.computeEllipsoidGeometry).toHaveBeenCalledWith([0, 0, 1, 0, 0.5, 1], 2, 3, 2);
    expect(f.ellipsoid).toEqual({ neighborhoodSize: 3, axesMode: 2 });
    expect(f.shapeKind).toBe('ellipsoid');
    expect(f.convention).toBe('ellipsoid-2r');
    expect(f.guarantee).toEqual({ kind: 'flag', label: 'flag complex (Rips-type)' });
  });

  it('ellipsoid-cech calls the NERVE builder, never the flag one', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'ellipsoid-cech',
      ...ellipsoidParams,
    });
    expect(gudhi.computeEllipsoidCechComplex).toHaveBeenCalledTimes(1);
    expect(gudhi.computeEllipsoidRipsComplex).not.toHaveBeenCalled();
    expect(f.guarantee).toEqual({ kind: 'nerve', label: 'true nerve (ellipsoidal Cech)' });
  });

  it('wing calls the complex AND the geometry with the same normal source', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const normals = [1, 0, 0, 1, -1, 0];
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'wing',
      q: 0.5,
      theta: Math.PI / 3,
      normals,
      maxEps: 2,
    });
    expect(gudhi.computeWingComplex).toHaveBeenCalledWith(
      [0, 0, 1, 0, 0.5, 1],
      0.5,
      Math.PI / 3,
      normals,
      2,
      2,
    );
    // The geometry call carries the SAME (points, q, theta, normalsOrK), which is
    // what makes the drawn wing the wing whose births are in the complex.
    expect(gudhi.computeWingGeometry).toHaveBeenCalledWith(
      [0, 0, 1, 0, 0.5, 1],
      0.5,
      Math.PI / 3,
      normals,
    );
    expect(f.wing.normals).toEqual(normals);
    expect(f.wing.normalSources).toEqual(['supplied', 'supplied', 'supplied']);
    expect(f.shapesAvailable).toBe(true);
    expect(f.guarantee.kind).toBe('flag');
  });

  it('wing with a neighbourhood size passes k, and STILL draws its shapes', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'wing',
      q: 0.5,
      theta: Math.PI / 3,
      neighborhoodSize: 3,
    });
    expect(gudhi.computeWingComplex).toHaveBeenCalledWith(
      [0, 0, 1, 0, 0.5, 1],
      0.5,
      Math.PI / 3,
      3,
      2,
      undefined,
    );
    expect(gudhi.computeWingGeometry).toHaveBeenCalledWith(
      [0, 0, 1, 0, 0.5, 1],
      0.5,
      Math.PI / 3,
      3,
    );
    // The engine estimated the normals internally and hands them back, so the
    // shapes exist. What differs from the exact mode is provenance, not
    // drawability.
    expect(f.shapesAvailable).toBe(true);
    expect(f.shapesUnavailableReason).toBeNull();
    expect(f.wing.normals).toHaveLength(6);
    expect(f.wing.normalSources).toEqual(['osculating', 'osculating', 'osculating']);
    expect(f.shapeAt(0, 1).normalSource).toBe('osculating');
    expect(f.shapeAt(0, 1).outline).toHaveLength(6);
  });

  it('box retains the grown boxes BY DEFAULT (the growing shape is the subject)', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'box',
      stepSize: 0.25,
      alpha: 0.5,
    });
    expect(gudhi.computeBoxFiltration).toHaveBeenCalledWith(
      [0, 0, 1, 0, 0.5, 1],
      2,
      0.25,
      0.5,
      undefined,
      2,
      true,
    );
    expect(f.shapesAvailable).toBe(true);
    expect(f.quantization).toEqual({ step: 0.25, steps: 2 });
    expect(f.shapeAt(0, 0.25).step).toBe(1);
  });

  it('box with retainBoxes: false keeps the quantization and drops the shapes', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'box',
      stepSize: 0.5,
      alpha: 1,
      maxSteps: 3,
      retainBoxes: false,
    });
    expect(gudhi.computeBoxFiltration).toHaveBeenCalledWith(
      [0, 0, 1, 0, 0.5, 1],
      2,
      0.5,
      1,
      3,
      2,
      false,
    );
    expect(f.shapesAvailable).toBe(false);
    expect(f.quantization.step).toBe(0.5);
  });

  it('kfold passes k and the squared-radius bound, and keeps the mosaic subsets', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const cloud = cloud3D();
    const f = await buildFiltration(engine, cloud, {
      complexType: 'kfold',
      k: 2,
      maxSquaredRadius: 1.5,
    });
    expect(gudhi.computeKFoldCoverComplex).toHaveBeenCalledWith(cloud.points, 2, 1.5, 2);
    expect(f.vertexKind).toBe('subset');
    expect(f.vertexSubsets![0]).toHaveLength(2);
    // Squared radius, no weights: the alpha radius law, so balls at √t.
    expect(f.convention).toBe('alpha');
    expect(f.shapeKind).toBe('ball');
    expect(f.radiusAt(0, 0.25)).toBeCloseTo(0.5, 12);
    expect(f.guarantee.label).toBe('exact (order-k Delaunay nerve)');
  });

  it('calls the engine once per BUILD; querying shapes never recomputes (§1.5)', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'ellipsoid-cech',
      ...ellipsoidParams,
    });
    for (const t of [0, 0.5, 1, 1.5]) f.shapeAt(0, t);
    f.simplicesAt(1);
    f.bettiAt(1);
    expect(gudhi.computeEllipsoidCechComplex).toHaveBeenCalledTimes(1);
    expect(gudhi.computeEllipsoidGeometry).toHaveBeenCalledTimes(1);
    expect(gudhi.computePersistence).toHaveBeenCalledTimes(1);
  });
});

describe('validation mirrors the engine, and fires BEFORE the wasm call', () => {
  it('kfold refuses a 2D cloud (3D-only construction)', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await expect(
      buildFiltration(engine, cloud2D(), { complexType: 'kfold', k: 1 }),
    ).rejects.toThrow(/k-fold cover complex requires a 3D cloud, got 2D/i);
    expect(gudhi.computeKFoldCoverComplex).not.toHaveBeenCalled();
  });

  it('kfold refuses coincident points, naming both indices', async () => {
    const engine = await readyEngine();
    const cloud = cloud3D();
    cloud.points.splice(9, 3, cloud.points[0], cloud.points[1], cloud.points[2]);
    await expect(buildFiltration(engine, cloud, { complexType: 'kfold', k: 2 })).rejects.toThrow(
      /points 0 and 3 coincide/i,
    );
  });

  it('kfold refuses a non-integer or non-positive k', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud3D(), { complexType: 'kfold', k: 1.5 }),
    ).rejects.toThrow(/k must be a positive integer/i);
    await expect(
      buildFiltration(engine, cloud3D(), { complexType: 'kfold', k: 0 }),
    ).rejects.toThrow(/k must be a positive integer/i);
  });

  it('kfold refuses fewer than k + 3 points', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud3D(4), { complexType: 'kfold', k: 2 }),
    ).rejects.toThrow(/at least k \+ 3 = 5 points, got 4/i);
  });

  it('kfold refuses a non-positive squared-radius bound', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud3D(), { complexType: 'kfold', k: 1, maxSquaredRadius: 0 }),
    ).rejects.toThrow(/maxSquaredRadius must be a positive finite number/i);
  });

  it('kfold refuses weights: multicover is proved for unweighted points only', async () => {
    const engine = await readyEngine();
    const cloud = cloud3D(8);
    cloud.weights[2] = 0.5;
    await expect(buildFiltration(engine, cloud, { complexType: 'kfold', k: 1 })).rejects.toThrow(
      /the k-fold cover complex: this builder ignores weights/i,
    );
  });

  it('wing refuses a 3D cloud (2D only; 3D is open research)', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await expect(
      buildFiltration(engine, cloud3D(), { complexType: 'wing', q: 0.5, theta: 1, normals: [] }),
    ).rejects.toThrow(/wing complex requires a 2D cloud, got 3D/i);
    expect(gudhi.computeWingComplex).not.toHaveBeenCalled();
  });

  it('wing refuses q outside [0, 1] and theta outside (0, pi/2]', async () => {
    const engine = await readyEngine();
    const normals = [1, 0, 0, 1, -1, 0];
    await expect(
      buildFiltration(engine, cloud2D(), { complexType: 'wing', q: 1.5, theta: 1, normals }),
    ).rejects.toThrow(/q must lie in \[0, 1\]/i);
    await expect(
      buildFiltration(engine, cloud2D(), { complexType: 'wing', q: 0.5, theta: 0, normals }),
    ).rejects.toThrow(/theta must lie in \(0, pi\/2\]/i);
    await expect(
      buildFiltration(engine, cloud2D(), { complexType: 'wing', q: 0.5, theta: 2, normals }),
    ).rejects.toThrow(/theta must lie in \(0, pi\/2\]/i);
  });

  it('wing insists on EXACTLY one normal source', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud2D(), { complexType: 'wing', q: 0.5, theta: 1 }),
    ).rejects.toThrow(/EXACTLY one of `normals`/i);
    await expect(
      buildFiltration(engine, cloud2D(), {
        complexType: 'wing',
        q: 0.5,
        theta: 1,
        normals: [1, 0, 0, 1, -1, 0],
        neighborhoodSize: 4,
      }),
    ).rejects.toThrow(/EXACTLY one of `normals`/i);
  });

  it('wing refuses a normals array of the wrong length, or a zero normal', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud2D(), {
        complexType: 'wing',
        q: 0.5,
        theta: 1,
        normals: [1, 0],
      }),
    ).rejects.toThrow(/expected 6 numbers, got 2/i);
    await expect(
      buildFiltration(engine, cloud2D(), {
        complexType: 'wing',
        q: 0.5,
        theta: 1,
        normals: [1, 0, 0, 0, -1, 0],
      }),
    ).rejects.toThrow(/normal at point 1 must be a finite, roughly unit vector/i);
  });

  it('wing refuses k < 2 (the engine estimator needs a neighbourhood)', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud2D(), {
        complexType: 'wing',
        q: 0.5,
        theta: 1,
        neighborhoodSize: 1,
      }),
    ).rejects.toThrow(/neighborhoodSize must be an integer >= 2/i);
  });

  it('ellipsoid paths refuse a missing or non-positive cutoff', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await expect(
      buildFiltration(engine, cloud2D(), {
        complexType: 'ellipsoid-cech',
        neighborhoodSize: 3,
        axesMode: 2,
        maxFiltration: 0,
      }),
    ).rejects.toThrow(/maxFiltration must be a positive finite cutoff/i);
    expect(gudhi.computeEllipsoidCechComplex).not.toHaveBeenCalled();
  });

  it('ellipsoid paths refuse an axes ratio below 1 and a neighbourhood below 2', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud2D(), {
        complexType: 'ellipsoid-rips',
        neighborhoodSize: 3,
        axesMode: 0.5,
        maxFiltration: 1,
      }),
    ).rejects.toThrow(/axesMode must be a finite tangent-to-normal ratio >= 1 or 'pca'/i);
    await expect(
      buildFiltration(engine, cloud2D(), {
        complexType: 'ellipsoid-rips',
        neighborhoodSize: 1,
        axesMode: 2,
        maxFiltration: 1,
      }),
    ).rejects.toThrow(/neighborhoodSize must be an integer >= 2/i);
  });

  it("ellipsoid paths accept axesMode 'pca' (the paper's alternative)", async () => {
    const engine = await readyEngine();
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'ellipsoid-rips',
      neighborhoodSize: 3,
      axesMode: 'pca',
      maxFiltration: 1,
    });
    expect(f.ellipsoid.axesMode).toBe('pca');
  });

  it('box refuses a non-positive step size and an alpha outside [0, 1]', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await expect(
      buildFiltration(engine, cloud2D(), { complexType: 'box', stepSize: 0, alpha: 0.5 }),
    ).rejects.toThrow(/stepSize \(π\) must be a positive finite number/i);
    await expect(
      buildFiltration(engine, cloud2D(), { complexType: 'box', stepSize: 0.25, alpha: 1.2 }),
    ).rejects.toThrow(/alpha must lie in \[0, 1\]/i);
    await expect(
      buildFiltration(engine, cloud2D(), {
        complexType: 'box',
        stepSize: 0.25,
        alpha: 0.5,
        maxSteps: 0,
      }),
    ).rejects.toThrow(/maxSteps must be a positive integer/i);
    expect(gudhi.computeBoxFiltration).not.toHaveBeenCalled();
  });

  it('every unweighted-only builder refuses a weighted cloud, one message each', async () => {
    const engine = await readyEngine();
    const weighted2D = cloud2D([0, 0.5, 0]);
    await expect(
      buildFiltration(engine, weighted2D, { complexType: 'ellipsoid-rips', ...ellipsoidParams }),
    ).rejects.toThrow(/ellipsoid-rips complexes: this builder ignores weights/i);
    await expect(
      buildFiltration(engine, weighted2D, {
        complexType: 'wing',
        q: 0.5,
        theta: 1,
        neighborhoodSize: 3,
      }),
    ).rejects.toThrow(/the wing complex: this builder ignores weights/i);
    await expect(
      buildFiltration(engine, weighted2D, { complexType: 'box', stepSize: 0.25, alpha: 0.5 }),
    ).rejects.toThrow(/the box filtration: this builder ignores weights/i);
  });

  it('rejects non-finite coordinates before any builder sees them', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await expect(
      buildFiltration(
        engine,
        { points: [0, 0, NaN, 1], weights: [0, 0], dimension: 2 },
        { complexType: 'box', stepSize: 0.25, alpha: 0.5 },
      ),
    ).rejects.toThrow(/coordinate at index 2 must be finite/i);
    expect(gudhi.computeBoxFiltration).not.toHaveBeenCalled();
  });
});
