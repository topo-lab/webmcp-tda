// @vitest-environment node
//
// buildFiltration against the REAL tda-wasm engine (no mocks): the SPEC.md §7
// acceptance mathematics, end to end.
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { TdaEngine } from '../../compute/TdaEngine';
import { buildFiltration } from '../buildFiltration';

const TIMEOUT = 60_000;

function circlePoints(n: number): number[] {
  const pts: number[] = [];
  for (let i = 0; i < n; i++) {
    const t = (2 * Math.PI * i) / n;
    pts.push(Math.cos(t), Math.sin(t));
  }
  return pts;
}

describe('buildFiltration: real engine', () => {
  const engine = new TdaEngine({ createWorker: null });

  beforeAll(async () => {
    await engine.initialize();
  }, TIMEOUT);

  afterAll(() => {
    engine.dispose();
  });

  it(
    'weighted alpha (story 2): the heavy ball exists at t=0 and its nerve edges appear first',
    async () => {
      const f = await buildFiltration(
        engine,
        { points: [0, 0, 2, 0, 1, 1.6], weights: [0.5, 0, 0], dimension: 2 },
        { complexType: 'alpha' },
      );

      // At t = 0: heavy ball radius sqrt(0.5), light ones are points.
      expect(f.radiusAt(0, 0)).toBeCloseTo(Math.sqrt(0.5), 10);
      expect(f.radiusAt(1, 0)).toBe(0);
      expect(f.radiusAt(2, 0)).toBe(0);

      // Both heavy-light edges enter the filtration before the light-light edge.
      const edges = f.simplices.filter((s) => s.vertices.length === 2);
      const withHeavy = edges.filter((e) => e.vertices.includes(0));
      const lightLight = edges.find((e) => !e.vertices.includes(0))!;
      expect(withHeavy).toHaveLength(2);
      for (const e of withHeavy) expect(e.filtration).toBeLessThan(lightLight.filtration);
    },
    TIMEOUT,
  );

  it(
    'weighted alpha: a nerve edge appears exactly when the two balls touch (SPEC.md §1.4)',
    async () => {
      const f = await buildFiltration(
        engine,
        { points: [0, 0, 2, 0, 1, 1.6], weights: [0.5, 0, 0], dimension: 2 },
        { complexType: 'alpha' },
      );
      for (const e of f.simplices.filter((s) => s.vertices.length === 2)) {
        const [a, b] = e.vertices;
        const dx = f.cloud.points[a * 2] - f.cloud.points[b * 2];
        const dy = f.cloud.points[a * 2 + 1] - f.cloud.points[b * 2 + 1];
        const dist = Math.hypot(dx, dy);
        const t = e.filtration;
        // At the edge's filtration value the two drawn balls meet.
        expect(f.radiusAt(a, t) + f.radiusAt(b, t)).toBeCloseTo(dist, 6);
      }
    },
    TIMEOUT,
  );

  it(
    'rejects a negative weight with the adapter error, not the opaque engine failure',
    async () => {
      await expect(
        buildFiltration(
          engine,
          { points: [0, 0, 1, 0], weights: [-0.1, 0], dimension: 2 },
          { complexType: 'alpha' },
        ),
      ).rejects.toThrow(/index 0.*non-negative/i);
      // The engine's own failure reads "Alpha complex computation failed:
      // undefined" — the adapter must never let a user see that.
    },
    TIMEOUT,
  );

  it(
    'honesty (story 5): spurious H2 in rawPairs, absent from pairs',
    async () => {
      const f = await buildFiltration(
        engine,
        { points: circlePoints(50), weights: new Array(50).fill(0), dimension: 2 },
        { complexType: 'rips', maxEdgeLength: 0.6, maxSimplexDimension: 2 },
      );
      expect(f.rawPairs.filter((p) => p.dimension === 2)).toHaveLength(150);
      expect(f.pairs.filter((p) => p.dimension === 2)).toHaveLength(0);
      expect(f.bettiAt(0.6)).toEqual([1, 1]);
    },
    TIMEOUT,
  );
});
