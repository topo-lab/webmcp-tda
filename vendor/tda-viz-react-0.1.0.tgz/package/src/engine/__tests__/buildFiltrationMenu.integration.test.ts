// @vitest-environment node
//
// The complex menu against the REAL tda-wasm engine (no mocks): every new
// construction built end to end, its guarantee label, its scale law, and the
// properties that make the picture agree with the homology beside it
// (SPEC.md §1.1, §1.3, §1.4, §5).
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { TdaEngine } from '../../compute/TdaEngine';
import { buildFiltration } from '../buildFiltration';

const TIMEOUT = 60_000;

function circle2D(n: number, radius = 1): number[] {
  const pts: number[] = [];
  for (let i = 0; i < n; i++) {
    const th = (2 * Math.PI * i) / n;
    pts.push(radius * Math.cos(th), radius * Math.sin(th));
  }
  return pts;
}

function exactCircleNormals(n: number): number[] {
  const out: number[] = [];
  for (let i = 0; i < n; i++) {
    const th = (2 * Math.PI * i) / n;
    out.push(Math.cos(th), Math.sin(th));
  }
  return out;
}

/** Jittered 2x2x2 lattice: general position, which the k-fold cover requires. */
function jitteredCube(): number[] {
  const pts: number[] = [];
  let seed = 7;
  const jitter = () => {
    seed = (seed * 1103515245 + 12345) % 2147483648;
    return ((seed / 2147483648) * 2 - 1) * 0.07;
  };
  for (let x = 0; x < 2; x++) {
    for (let y = 0; y < 2; y++) {
      for (let z = 0; z < 2; z++) pts.push(x + jitter(), y + jitter(), z + jitter());
    }
  }
  return pts;
}

const unweighted = (points: number[], dimension: 2 | 3) => ({
  points,
  weights: new Array(points.length / dimension).fill(0),
  dimension,
});

describe('the complex menu: real engine', () => {
  const engine = new TdaEngine({ createWorker: null });

  beforeAll(async () => {
    await engine.initialize();
  }, TIMEOUT);

  afterAll(() => {
    engine.dispose();
  });

  it(
    'ellipsoid-rips: a FLAG complex whose ellipsoids come from the same fitting',
    async () => {
      const cloud = unweighted(circle2D(20), 2);
      const f = await buildFiltration(engine, cloud, {
        complexType: 'ellipsoid-rips',
        neighborhoodSize: 6,
        axesMode: 2,
        maxFiltration: 1.6,
      });

      expect(f.guarantee).toEqual({ kind: 'flag', label: 'flag complex (Rips-type)' });
      expect(f.convention).toBe('ellipsoid-2r');
      expect(f.shapeKind).toBe('ellipsoid');
      expect(f.simplices.length).toBeGreaterThan(20);

      // At the birth value of an edge the two ellipsoids touch, so at that t
      // each is scaled by exactly half the value: this is the 2 x radius scale
      // the engine emits, and getting it wrong would draw shapes that meet at
      // the wrong time.
      const shape = f.shapeAt(4, 1.6);
      const half = f.shapeAt(4, 0.8);
      expect(shape.semiAxes[0]).toBeCloseTo(2 * half.semiAxes[0], 12);
      expect(shape.center[0]).toBeCloseTo(cloud.points[8], 12);
      // The frame is orthonormal, straight from the engine's local PCA.
      const [u, v] = shape.frame;
      expect(Math.hypot(u[0], u[1])).toBeCloseTo(1, 9);
      expect(u[0] * v[0] + u[1] * v[1]).toBeCloseTo(0, 9);
      // Anisotropic at q = 2: the normal semi-axis is half the tangent one.
      expect(shape.semiAxes[1] / shape.semiAxes[0]).toBeCloseTo(0.5, 6);
    },
    TIMEOUT,
  );

  it(
    'ellipsoid-cech: a true NERVE, a subcomplex of the flag complex, never earlier',
    async () => {
      const cloud = unweighted(circle2D(16), 2);
      const params = { neighborhoodSize: 6, axesMode: 2, maxFiltration: 1.6 } as const;
      const flag = await buildFiltration(engine, cloud, {
        complexType: 'ellipsoid-rips',
        ...params,
      });
      const nerve = await buildFiltration(engine, cloud, {
        complexType: 'ellipsoid-cech',
        ...params,
      });

      expect(nerve.guarantee).toEqual({ kind: 'nerve', label: 'true nerve (ellipsoidal Cech)' });
      expect(nerve.convention).toBe(flag.convention);

      const flagBirth = new Map(
        flag.simplices.map((s) => [[...s.vertices].sort((a, b) => a - b).join(','), s.filtration]),
      );
      for (const s of nerve.simplices) {
        const key = [...s.vertices].sort((a, b) => a - b).join(',');
        expect(flagBirth.has(key)).toBe(true);
        expect(s.filtration).toBeGreaterThanOrEqual(flagBirth.get(key)! - 1e-9);
      }
      // The 1-skeletons agree exactly: a two-element family's minimal
      // intersection radius IS the pairwise touch radius.
      const edges = (fil: typeof flag) =>
        fil.simplices
          .filter((s) => s.vertices.length === 2)
          .map((s) => `${[...s.vertices].sort((a, b) => a - b)}@${s.filtration.toFixed(9)}`)
          .sort();
      expect(edges(nerve)).toEqual(edges(flag));
    },
    TIMEOUT,
  );

  it(
    'wing: a FLAG complex, drawable in BOTH normal modes',
    async () => {
      const n = 12;
      const cloud = unweighted(circle2D(n), 2);
      const supplied = await buildFiltration(engine, cloud, {
        complexType: 'wing',
        q: 1 / 3,
        theta: Math.PI / 2,
        normals: exactCircleNormals(n),
        maxEps: 1,
      });
      const estimated = await buildFiltration(engine, cloud, {
        complexType: 'wing',
        q: 1 / 3,
        theta: Math.PI / 2,
        neighborhoodSize: 6,
        maxEps: 1,
      });

      expect(supplied.guarantee).toEqual({ kind: 'flag', label: 'flag complex (Rips-type)' });
      expect(supplied.convention).toBe('wing-eps');
      // Both draw: the engine reads back the normal the builder used, including
      // the one it fitted itself from k. Provenance is what differs.
      for (const f of [supplied, estimated]) {
        expect(f.shapesAvailable).toBe(true);
        expect(f.shapesUnavailableReason).toBeNull();
        expect(f.shapeAt(0, 1).outline).toHaveLength(6);
      }
      expect(new Set(supplied.wing.normalSources)).toEqual(new Set(['supplied']));
      expect(new Set(estimated.wing.normalSources)).toEqual(new Set(['osculating']));
      // On a circle the osculating fit is exact, so it recovers the outward
      // radial the exact-sampling mode was given — up to the fit's own precision.
      for (let i = 0; i < n; i++) {
        for (let d = 0; d < 2; d++) {
          expect(estimated.wing.normals[i * 2 + d]).toBeCloseTo(
            supplied.wing.normals[i * 2 + d],
            9,
          );
        }
      }

      // Eq. 4.3, the paper's circle closed form, with theta = pi/2 and q = 1/3:
      //   eps = r sin(phi/2) / (q sin(phi/2) + sin(theta + phi/2))
      const phi = (2 * Math.PI) / n;
      const s = Math.sin(phi / 2);
      const expected = s / ((1 / 3) * s + Math.sin(Math.PI / 2 + phi / 2));
      const neighbourEdges = supplied.simplices.filter(
        (x) => x.vertices.length === 2 && (x.vertices[1] - x.vertices[0] + n) % n === 1,
      );
      expect(neighbourEdges.length).toBeGreaterThan(0);
      for (const e of neighbourEdges) expect(e.filtration).toBeCloseTo(expected, 6);

      // t IS the wing scale: spine half-length q·t, wing edges of length t.
      const shape = supplied.shapeAt(0, expected);
      expect(shape.wingLength).toBeCloseTo(expected, 12);
      expect(shape.spineHalfLength).toBeCloseTo(expected / 3, 12);
      expect(shape.outline).toHaveLength(6);
    },
    TIMEOUT,
  );

  it(
    'wing: the drawn polygon IS point + eps * outline[v] from computeWingGeometry',
    async () => {
      // The property the geometry API exists for, checked against the live
      // engine on a canonical dataset: a 12-point circle with normals ESTIMATED
      // from k, which is the case that used to be undrawable. Bit equality, not a
      // tolerance — anything looser would let a re-derived hexagon pass.
      const n = 12;
      const q = 1 / 3;
      const theta = Math.PI / 2;
      const k = 6;
      const cloud = unweighted(circle2D(n), 2);
      const f = await buildFiltration(engine, cloud, {
        complexType: 'wing',
        q,
        theta,
        neighborhoodSize: k,
        maxEps: 1,
      });
      const geometry = engine.computeWingGeometry(cloud.points, q, theta, k);

      expect(geometry).toHaveLength(n);
      for (const eps of [0.1, 0.5, 1, 2.5]) {
        geometry.forEach((g, i) => {
          const shape = f.shapeAt(i, eps);
          expect(shape.normalSource).toBe(g.normalSource);
          expect([...shape.normal]).toEqual(g.normal);
          expect(shape.outline).toHaveLength(g.outline.length);
          shape.outline.forEach((vertex, v) => {
            for (let d = 0; d < 2; d++) {
              expect(vertex[d]).toBe(g.point[d] + eps * g.outline[v][d]);
            }
          });
        });
      }

      // The unscaled record is the engine's own, so a GPU renderer that uploads
      // it once and multiplies by eps in the shader draws the same polygon.
      geometry.forEach((g, i) => {
        const unit = f.unitShape(i);
        expect(unit.outline.map((o) => [...o])).toEqual(g.outline);
        expect(unit.curvatureRadius).toBe(g.curvatureRadius);
        expect(unit.neighborhoodScale).toBe(g.neighborhoodScale);
      });
    },
    TIMEOUT,
  );

  it(
    'box: a nerve by Helly, step-quantized — every value is a multiple of pi',
    async () => {
      const step = 0.25;
      const cloud = unweighted(circle2D(6), 2);
      const f = await buildFiltration(engine, cloud, {
        complexType: 'box',
        stepSize: step,
        alpha: 1,
      });

      expect(f.guarantee).toEqual({
        kind: 'nerve',
        label: 'nerve (= flag, by Helly for boxes); step-quantized',
      });
      expect(f.convention).toBe('box-step');
      expect(f.quantization.step).toBe(step);
      expect(f.quantization.steps).toBeGreaterThan(0);

      for (const simplex of f.simplices) {
        const grid = simplex.filtration / step;
        expect(Math.abs(grid - Math.round(grid))).toBeLessThan(1e-9);
      }
      for (const pair of f.rawPairs) {
        for (const value of [pair.birth, pair.death]) {
          if (!Number.isFinite(value)) continue;
          expect(Math.abs(value / step - Math.round(value / step))).toBeLessThan(1e-9);
        }
      }

      // The boxes are the engine's own, on the grid, and they only grow.
      expect(f.shapesAvailable).toBe(true);
      const first = f.shapeAt(0, 0);
      expect(first.step).toBe(0);
      expect(first.lower).toEqual(first.upper); // the degenerate pivot box
      const later = f.shapeAt(0, f.quantization.steps * step);
      expect(later.step).toBe(f.quantization.steps);
      expect(later.upper[0]).toBeGreaterThan(first.upper[0]);
      expect(later.lower[0]).toBeLessThan(first.lower[0]);

      // The engine returned (steps + 1) x n records; each step is readable as a
      // row, which is what a renderer uploads once (SPEC.md §1.5).
      const pointCount = cloud.points.length / 2;
      for (let s = 0; s <= f.quantization.steps; s++) {
        const boxes = f.boxesAtStep(s);
        expect(boxes).toHaveLength(pointCount);
        boxes.forEach((box, i) => {
          expect(box.step).toBe(s);
          expect(box).toEqual(f.shapeAt(i, s * step));
        });
      }
      expect(() => f.boxesAtStep(f.quantization.steps + 1)).toThrow(/out of range/i);
    },
    TIMEOUT,
  );

  it(
    'kfold: vertices are k-subsets of the input, and balls grow at sqrt(t)',
    async () => {
      const cloud = unweighted(jitteredCube(), 3);
      const f = await buildFiltration(engine, cloud, {
        complexType: 'kfold',
        k: 2,
        maxSquaredRadius: 1.5,
      });

      expect(f.guarantee).toEqual({ kind: 'nerve', label: 'exact (order-k Delaunay nerve)' });
      expect(f.vertexKind).toBe('subset');
      expect(f.vertexSubsets).not.toBeNull();
      expect(f.vertexCount).toBeGreaterThan(8); // more mosaic vertices than points
      for (const subset of f.vertexSubsets!) expect(subset).toHaveLength(2);

      // Vertex positions are the barycentres of their subsets, which is what
      // makes a drawn mosaic honest; the balls belong to the INPUT points.
      f.vertexSubsets!.forEach((subset, v) => {
        const position = f.vertexPosition(v);
        for (let a = 0; a < 3; a++) {
          const mean = subset.reduce((sum, i) => sum + cloud.points[i * 3 + a], 0) / subset.length;
          expect(position[a]).toBeCloseTo(mean, 12);
        }
      });

      // Squared-radius filtration: the ball around an input point has radius √t.
      expect(f.radiusAt(0, 0.49)).toBeCloseTo(0.7, 12);
      expect(f.shapeAt(0, 0.49).radius).toBeCloseTo(0.7, 12);
      // k = 2 means a mosaic vertex is born where two balls already overlap, so
      // no vertex is born at t = 0 the way an alpha vertex is.
      const vertexBirths = f.simplices.filter((s) => s.vertices.length === 1);
      expect(vertexBirths.length).toBe(f.vertexCount);
      expect(Math.min(...vertexBirths.map((s) => s.filtration))).toBeGreaterThan(0);
    },
    TIMEOUT,
  );

  it(
    'k = 1 reproduces the alpha complex, which is the engine\u2019s own claim',
    async () => {
      const cloud = unweighted(jitteredCube(), 3);
      const kfold = await buildFiltration(engine, cloud, {
        complexType: 'kfold',
        k: 1,
        maxSimplexDimension: 3,
      });
      const alpha = await buildFiltration(engine, cloud, { complexType: 'alpha' });

      expect(kfold.vertexSubsets!.every((s) => s.length === 1)).toBe(true);
      // Same convention, so values are directly comparable.
      expect(kfold.convention).toBe(alpha.convention);
      const key = (s: { vertices: number[]; filtration: number }) =>
        `${[...s.vertices].sort((a, b) => a - b)}`;
      const alphaBirth = new Map(alpha.simplices.map((s) => [key(s), s.filtration]));
      for (const s of kfold.simplices) {
        const expected = alphaBirth.get(key(s));
        expect(expected).toBeDefined();
        expect(s.filtration).toBeCloseTo(expected!, 9);
      }
      expect(kfold.simplices.length).toBe(alpha.simplices.length);
    },
    TIMEOUT,
  );

  it(
    'surfaces the engine\u2019s refusals as sentences, not wasm aborts',
    async () => {
      const cube = unweighted(jitteredCube(), 3);
      const flat = unweighted(circle2D(8), 2);

      await expect(buildFiltration(engine, flat, { complexType: 'kfold', k: 2 })).rejects.toThrow(
        /requires a 3D cloud/i,
      );
      await expect(
        buildFiltration(engine, cube, {
          complexType: 'wing',
          q: 0.5,
          theta: 1,
          neighborhoodSize: 4,
        }),
      ).rejects.toThrow(/requires a 2D cloud/i);
      await expect(
        buildFiltration(engine, flat, {
          complexType: 'ellipsoid-cech',
          neighborhoodSize: 4,
          axesMode: 2,
          maxFiltration: -1,
        }),
      ).rejects.toThrow(/maxFiltration must be a positive finite cutoff/i);
      await expect(
        buildFiltration(engine, flat, { complexType: 'box', stepSize: -0.5, alpha: 0.5 }),
      ).rejects.toThrow(/stepSize/i);

      // Coincident input: the engine rejects it by index; so does the adapter,
      // before the call.
      const duplicated = unweighted(jitteredCube(), 3);
      duplicated.points.splice(
        3,
        3,
        duplicated.points[0],
        duplicated.points[1],
        duplicated.points[2],
      );
      await expect(
        buildFiltration(engine, duplicated, { complexType: 'kfold', k: 2 }),
      ).rejects.toThrow(/coincide/i);
    },
    TIMEOUT,
  );
});
