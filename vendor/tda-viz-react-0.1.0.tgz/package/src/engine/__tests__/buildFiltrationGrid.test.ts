// The grid domain's adapter (SPEC.md §3.1b): the two-argument form, the
// validation that fires BEFORE the wasm call, and which binding each
// construction is routed to. The MATH is in the integration suite — no canned
// diagram can stand in for the T/V difference, which is the whole subject.
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { mockControl } from '../../../__mocks__/tda-wasm';
import { TdaEngine } from '../../compute/TdaEngine';
import { buildFiltration } from '../buildFiltration';

vi.mock('tda-wasm', () => import('../../../__mocks__/tda-wasm'));

const GRID = [0, 1, 2, 3, 4, 5];

async function readyEngine(): Promise<TdaEngine> {
  const engine = new TdaEngine({ createWorker: null });
  await engine.initialize();
  return engine;
}

const cubical = (over: Record<string, unknown> = {}) =>
  ({
    complexType: 'cubical',
    values: GRID,
    width: 3,
    height: 2,
    construction: 'cubical-t',
    direction: 'sublevel',
    ...over,
  }) as Parameters<typeof buildFiltration>[1];

beforeEach(() => {
  mockControl.reset();
  vi.clearAllMocks();
});

describe('the grid domain routes to the binding its construction names', () => {
  it('cubical-t goes to the GENERAL binding, with [width, height] — never the 2D wrapper', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await buildFiltration(engine, cubical());
    // [width, height], because GUDHI's bitmap reads sizes[0] fastest and the
    // values are row-major. The 2D convenience wrapper builds {height, width}
    // instead and scrambles any grid whose sides differ, so it is not used.
    expect(gudhi.computeCubicalPersistence).toHaveBeenCalledWith([3, 2], GRID, 2);
    expect(gudhi.computeCubicalPersistenceFromVertices2D).not.toHaveBeenCalled();
  });

  it('cubical-v goes to the vertex lower-star binding, with (width, height)', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await buildFiltration(engine, cubical({ construction: 'cubical-v' }));
    expect(gudhi.computeCubicalPersistenceFromVertices2D).toHaveBeenCalledWith(GRID, 3, 2);
    expect(gudhi.computeCubicalPersistence).not.toHaveBeenCalled();
  });

  it('superlevel negates the GRID on the way in and the endpoints on the way out', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const f = await buildFiltration(engine, cubical({ direction: 'superlevel' }));
    // The engine computes sublevel only, so the adapter hands it -f …
    expect(gudhi.computeCubicalPersistence).toHaveBeenCalledWith(
      [3, 2],
      GRID.map((v) => -v),
      2,
    );
    // … and everything downstream is back in the image's own units.
    expect([...f.values]).toEqual(GRID);
    expect(f.direction).toBe('superlevel');
    for (const p of f.pairs) expect(p.birth >= p.death).toBe(true);
  });

  it('one engine call per build: moving t never reaches the engine (SPEC.md §1.5)', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    const f = await buildFiltration(engine, cubical());
    for (const t of [0, 1, 2, 3]) {
      f.bettiAt(t);
      f.aliveAt(t);
      f.containsValue(1, t);
    }
    expect(gudhi.computeCubicalPersistence).toHaveBeenCalledTimes(1);
  });

  it('drops the H2 row the engine can emit: a subset of the plane has none', async () => {
    const engine = await readyEngine();
    const f = await buildFiltration(engine, cubical());
    expect(f.rawPairs.some((p) => p.dimension === 2)).toBe(true);
    expect(f.pairs.some((p) => p.dimension === 2)).toBe(false);
    expect(f.bettiAt(2)).toHaveLength(2);
  });
});

describe('validation mirrors the engine, and fires BEFORE the wasm call', () => {
  it('refuses a construction or a direction it was not given', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await expect(buildFiltration(engine, cubical({ construction: 'cubical' }))).rejects.toThrow(
      /construction must be 'cubical-t'/i,
    );
    await expect(buildFiltration(engine, cubical({ direction: 'below' }))).rejects.toThrow(
      /direction must be 'sublevel'/i,
    );
    expect(gudhi.computeCubicalPersistence).not.toHaveBeenCalled();
  });

  it('refuses a grid whose length does not match width x height', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await expect(buildFiltration(engine, cubical({ width: 4 }))).rejects.toThrow(
      /values has 6 entries but the grid is 4 × 2 = 8/i,
    );
    expect(gudhi.computeCubicalPersistence).not.toHaveBeenCalled();
  });

  it('refuses non-positive or non-integer grid sides', async () => {
    const engine = await readyEngine();
    for (const over of [{ width: 0 }, { height: -1 }, { width: 1.5 }]) {
      await expect(buildFiltration(engine, cubical(over))).rejects.toThrow(
        /width and height must be positive integers/i,
      );
    }
    expect(mockControl.instances[0]!.computeCubicalPersistence).not.toHaveBeenCalled();
  });

  it('refuses a non-finite value, and names the cell it is in', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await expect(
      buildFiltration(engine, cubical({ values: [0, 1, 2, 3, Number.NaN, 5] })),
    ).rejects.toThrow(/index 4 \(column 1, row 1\) must be a finite number/i);
    await expect(
      buildFiltration(engine, cubical({ values: [0, 1, 2, 3, Infinity, 5] })),
    ).rejects.toThrow(/must be a finite number/i);
    expect(gudhi.computeCubicalPersistence).not.toHaveBeenCalled();
  });

  it('refuses a field the V binding does not have, instead of answering in F2', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.instances[0]!;
    await expect(
      buildFiltration(engine, cubical({ construction: 'cubical-v', coeffField: 3 })),
    ).rejects.toThrow(/F2-only implementation/i);
    // …and accepts the field it does have, said explicitly.
    await expect(
      buildFiltration(engine, cubical({ construction: 'cubical-v', coeffField: 2 })),
    ).resolves.toBeTruthy();
    expect(gudhi.computeCubicalPersistence).not.toHaveBeenCalled();
  });

  it('refuses the three-argument form: a cubical complex is not built from a cloud', async () => {
    const engine = await readyEngine();
    // The cloud form with cubical params is not a call this adapter has.
    await expect(
      (buildFiltration as unknown as (...a: unknown[]) => Promise<unknown>)(engine, {
        points: [0, 0],
        weights: [0],
        dimension: 2,
      }),
    ).rejects.toThrow(/GRID form and takes cubical params/i);
  });

  it('copies the grid: the filtration cannot change under the caller afterwards', async () => {
    const engine = await readyEngine();
    const mutable = [...GRID];
    const f = await buildFiltration(engine, cubical({ values: mutable }));
    mutable[0] = 99;
    expect(f.valueAt(0, 0)).toBe(0);
  });
});
