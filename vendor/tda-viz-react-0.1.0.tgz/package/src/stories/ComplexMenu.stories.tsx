/**
 * The four end-to-end stories the complex menu adds to SPEC.md §7 (stories
 * 6–9). Same rule as the first five: every simplex, every pair, every fitted
 * ellipsoid, every grown box and every mosaic vertex on screen is recorded
 * output of the real GUDHI engine (src/__fixtures__/realFiltrations.ts), and
 * every claim these stories make about the numbers is COMPUTED from that output
 * on the spot rather than written into the prose.
 */
import { useMemo, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import type { PersistencePair, Simplex } from 'tda-wasm';
import {
  CIRCLE12_WING,
  CIRCLE12_WING_ESTIMATED_NORMALS,
  ELLIPSE_ELLIPSOID_CECH,
  ELLIPSE_ELLIPSOID_RIPS,
  JITTERED8_KFOLD1,
  JITTERED8_KFOLD2,
  RING6_BOX,
  RING6_BOX_HALFSTEP,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import type { Filtration } from '../filtration/types';
import { useScale } from '../filtration/useScale';
import { Barcode } from '../persistence/Barcode';
import { Field2D } from '../render2d/Field2D';
import { GuaranteeChip } from '../render2d/GuaranteeChip';
import { Nerve2D } from '../render2d/Nerve2D';

const meta = {
  title: 'Acceptance/SPEC §7 complex menu',
  parameters: { layout: 'padded' },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

const mono: React.CSSProperties = { fontFamily: 'ui-monospace, monospace', fontSize: 12 };
const note: React.CSSProperties = { fontSize: 12, opacity: 0.8, maxWidth: 620 };

const key = (s: Simplex) => [...s.vertices].sort((a, b) => a - b).join(',');
const longest = (pairs: readonly PersistencePair[], dim: number): PersistencePair | null => {
  const alive = pairs.filter((p) => p.dimension === dim && Number.isFinite(p.death));
  return alive.length === 0
    ? null
    : alive.reduce((best, p) => (p.death - p.birth > best.death - best.birth ? p : best));
};

/** Field + complex + chip, the composition every menu story uses. */
function Panel({
  label,
  filtration,
  t,
  size = 300,
  padding = 70,
}: {
  label: string;
  filtration: Filtration;
  t: number;
  size?: number;
  padding?: number;
}) {
  return (
    <figure style={{ margin: 0 }}>
      <figcaption style={{ ...mono, marginBottom: 4 }}>{label}</figcaption>
      <div style={{ position: 'relative', width: size, height: size }}>
        <Field2D filtration={filtration} t={t} width={size} height={size} padding={padding} />
        <div style={{ position: 'absolute', top: 0, left: 0 }}>
          <Nerve2D filtration={filtration} t={t} width={size} height={size} padding={padding} />
        </div>
      </div>
      <GuaranteeChip filtration={filtration} />
    </figure>
  );
}

/**
 * §7 story 6 — Ellipsoid-Rips vs ellipsoid-Čech: the SAME cloud, the SAME
 * ellipsoids, the same scale. The union of ellipsoids on screen is identical in
 * both panels, and so is the 1-skeleton — the minimal intersection radius of a
 * PAIR is the pairwise touch radius, so the Čech builder reuses the flag
 * builder's edge births verbatim.
 *
 * From dimension 2 up they part company: every shared simplex is born no
 * EARLIER in the nerve, and on this cloud 8 of them are born strictly later
 * (the numbers below are computed, not quoted). So the H₁ picture is not the
 * same picture even where the simplices are, and only ONE of the two is
 * equivalent to the union of ellipsoids beside it — the ellipsoidal Čech
 * complex, whose ellipsoids are convex, whose finite intersections are therefore
 * contractible, and to which the nerve lemma applies. Its flag sibling shares
 * the shapes and the scale and is still not a nerve: three ellipses can meet
 * pairwise long before they meet as a triple.
 */
export const Story6EllipsoidFlagVsNerve: Story = {
  render: function Story6() {
    const flag = recordedFiltration(ELLIPSE_ELLIPSOID_RIPS);
    const nerve = recordedFiltration(ELLIPSE_ELLIPSOID_CECH);
    const [t, setT] = useState(1.2);

    const facts = useMemo(() => {
      const nerveByKey = new Map(nerve.simplices.map((s) => [key(s), s.filtration]));
      let edges = 0;
      let edgeMaxDelta = 0;
      let shared = 0;
      let laterInNerve = 0;
      let earlierInNerve = 0;
      for (const s of flag.simplices) {
        const other = nerveByKey.get(key(s));
        if (other === undefined) continue;
        shared++;
        if (s.vertices.length === 2) {
          edges++;
          edgeMaxDelta = Math.max(edgeMaxDelta, Math.abs(other - s.filtration));
        } else if (s.vertices.length > 2) {
          if (other > s.filtration) laterInNerve++;
          if (other < s.filtration) earlierInNerve++;
        }
      }
      return {
        edges,
        edgeMaxDelta,
        shared,
        laterInNerve,
        earlierInNerve,
        flagOnly: flag.simplices.length - shared,
        h1Flag: longest(flag.pairs, 1),
        h1Nerve: longest(nerve.pairs, 1),
      };
    }, [flag, nerve]);

    const life = (p: PersistencePair | null) =>
      p
        ? `${p.birth.toFixed(4)} → ${p.death.toFixed(4)} (lifetime ${(p.death - p.birth).toFixed(4)})`
        : 'none';

    return (
      <div style={{ display: 'grid', gap: 12, maxWidth: 760 }}>
        <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          <Panel label="ellipsoid-Rips (flag)" filtration={flag} t={t} />
          <Panel label="ellipsoid-Čech (nerve)" filtration={nerve} t={t} />
        </div>
        <label style={mono}>
          t = {t.toFixed(3)} (both panels; `ellipsoid-2r` in both, so the scales ARE comparable){' '}
          <input
            type="range"
            min={0}
            max={1.6}
            step={0.01}
            value={t}
            onChange={(e) => setT(Number.parseFloat(e.target.value))}
            style={{ width: 280, verticalAlign: 'middle' }}
          />
        </label>
        <div style={mono} data-testid="ellipsoid-comparison">
          {facts.edges} shared edges, max birth difference {facts.edgeMaxDelta.toExponential(1)} —
          the 1-skeletons agree
          <br />
          of {facts.shared} shared simplices, {facts.laterInNerve} are born strictly LATER in the
          nerve and {facts.earlierInNerve} earlier (earlier is impossible; it is checked, not
          assumed)
          <br />
          simplices the flag complex has and the nerve does not: {facts.flagOnly}
          <br />
          longest H₁, flag: {life(facts.h1Flag)}
          <br />
          longest H₁, nerve: {life(facts.h1Nerve)}
        </div>
        <p style={note}>
          Same shapes, same scale, different complexes — and only the right-hand one is homotopy
          equivalent to the union of ellipsoids drawn under it. Reading the left-hand triangle as
          &quot;three ellipsoids overlap&quot; is the mistake the chip exists to prevent.
        </p>
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <Barcode filtration={flag} t={t} width={340} height={180} />
          <Barcode filtration={nerve} t={t} width={340} height={180} />
        </div>
      </div>
    );
  },
};

/**
 * §7 story 7 — Wing, exact normals vs estimated. Both panels are wing
 * filtrations of the same 12-point circle with the same q and θ; the left was
 * built with the exact outward radial normals (on a circle, the radial IS the
 * normal of Eq. 3.1), the right with a neighbourhood size k and normals the
 * engine estimated internally.
 *
 * BOTH draw their hexagons, and both draw the engine's own: `computeWingGeometry`
 * reads back the normal and the unit outline the builder actually used, so the
 * polygon on screen is `point + ε · outline[v]` with nothing re-derived in this
 * library. The k-mode panel used to draw nothing at all, because the estimated
 * normals never left the engine.
 *
 * What the panels contrast now is PROVENANCE. Every shape reports where its
 * normal came from — `supplied` on the left, `osculating` on the right, and
 * `tangent` at a point whose circle fit degenerated into the PCA fallback — and
 * the counts below are computed from the filtrations, not written into this
 * prose. On THIS cloud the two complexes are identical (84 simplices, zero birth
 * difference) and the drawings agree to about 1e-8, because a circle is where
 * the osculating estimate is exact. That agreement is a property of this cloud,
 * measured, not a guarantee: at an inflection the estimate flips sides, and the
 * `normalSource` on each wing is what tells a reviewer which case they are
 * looking at.
 */
export const Story7WingExactVsEstimated: Story = {
  render: function Story7() {
    const exact = recordedFiltration(CIRCLE12_WING);
    const estimated = recordedFiltration(CIRCLE12_WING_ESTIMATED_NORMALS);
    const scale = useScale(exact, { initialT: 0.35 });

    const facts = useMemo(() => {
      const byKey = new Map(estimated.simplices.map((s) => [key(s), s.filtration]));
      let same = 0;
      let differing = 0;
      let maxDelta = 0;
      for (const s of exact.simplices) {
        const other = byKey.get(key(s));
        if (other === undefined) {
          differing++;
          continue;
        }
        same++;
        maxDelta = Math.max(maxDelta, Math.abs(other - s.filtration));
      }
      // How far apart the two DRAWINGS are, at a fixed scale: the accuracy of
      // the osculating fit on this cloud, measured rather than claimed.
      let shapeDelta = 0;
      for (let i = 0; i < exact.cloud.points.length / 2; i++) {
        const a = exact.shapeAt(i, 0.5).outline;
        const b = estimated.shapeAt(i, 0.5).outline;
        a.forEach((vertex, v) => {
          for (let d = 0; d < 2; d++) {
            shapeDelta = Math.max(shapeDelta, Math.abs(b[v][d] - vertex[d]));
          }
        });
      }
      const provenance = (f: typeof exact) => {
        const counts = new Map<string, number>();
        for (const source of f.wing.normalSources) {
          counts.set(source, (counts.get(source) ?? 0) + 1);
        }
        return [...counts].map(([source, n]) => `${n}× ${source}`).join(', ');
      };
      return {
        same,
        differing,
        maxDelta,
        shapeDelta,
        onlyInEstimated: estimated.simplices.length - same,
        exactProvenance: provenance(exact),
        estimatedProvenance: provenance(estimated),
      };
    }, [exact, estimated]);

    return (
      <div style={{ display: 'grid', gap: 12, maxWidth: 760 }}>
        <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          <Panel
            label="wing, exact normals (supplied)"
            filtration={exact}
            t={scale.t}
            padding={90}
          />
          <Panel
            label="wing, estimated from k (osculating)"
            filtration={estimated}
            t={scale.t}
            padding={90}
          />
        </div>
        <label style={mono}>
          ε = {scale.t.toFixed(3)}{' '}
          <input
            type="range"
            min={0}
            max={1}
            step={0.005}
            value={scale.t}
            onChange={(e) => scale.setT(Number.parseFloat(e.target.value))}
            style={{ width: 280, verticalAlign: 'middle' }}
          />
        </label>
        <div style={mono} data-testid="wing-comparison">
          shared simplices: {facts.same} · only in the exact build: {facts.differing} · only in the
          estimated build: {facts.onlyInEstimated} · max birth difference on shared simplices:{' '}
          {facts.maxDelta.toExponential(2)}
          <br />
          normal provenance — left: {facts.exactProvenance} · right: {facts.estimatedProvenance}
          <br />
          max vertex difference between the two drawings at ε = 0.5:{' '}
          {facts.shapeDelta.toExponential(2)}
        </div>
        <p style={note}>
          Both hexagons are the engine&apos;s own: <code>computeWingGeometry</code> returns the
          normal the builder used and the unit outline its birth solver intersects, so each polygon
          is <code>point + ε · outline[v]</code> and nothing in this library re-derives it. The
          right-hand panel is therefore drawable even though its normals were fitted inside the
          engine — and every shape says so, which is the honest form of the old refusal: an
          estimated normal is a weaker normal, not an absent one, and its wing is exactly as
          trustworthy as the births it produced.
        </p>
      </div>
    );
  },
};

/**
 * §7 story 8 — Box, two step sizes. The same 6-point ring, grown with π = 0.25
 * and π = 0.125. Every bar endpoint is a multiple of the step (checked below,
 * not asserted in prose), the shape at t is the box of the last COMPLETED step,
 * and between grid values nothing moves.
 *
 * The two diagrams are NOT comparable. A bottleneck distance between them
 * mostly measures the two grids: halving the step halves the quantum every
 * birth and death is rounded to, so the same geometric event lands on a
 * different number. That is why a box filtration carries its `quantization` and
 * why the chip refuses to let the diagram be read as a measurement.
 */
export const Story8BoxTwoStepSizes: Story = {
  render: function Story8() {
    const coarse = recordedFiltration(RING6_BOX);
    const fine = recordedFiltration(RING6_BOX_HALFSTEP);
    const [t, setT] = useState(0.5);

    const onGrid = (f: typeof coarse) => {
      const step = f.quantization.step;
      const offGrid = f.simplices.filter(
        (s) => Math.abs(s.filtration / step - Math.round(s.filtration / step)) > 1e-9,
      ).length;
      const h1 = longest(f.pairs, 1);
      return { step, steps: f.quantization.steps, offGrid, h1, count: f.simplices.length };
    };
    const a = onGrid(coarse);
    const b = onGrid(fine);

    return (
      <div style={{ display: 'grid', gap: 12, maxWidth: 760 }}>
        <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          <Panel label={`box, π = ${a.step}`} filtration={coarse} t={t} padding={80} />
          <Panel label={`box, π = ${b.step}`} filtration={fine} t={t} padding={80} />
        </div>
        <label style={mono}>
          t = {t.toFixed(3)} → step {Math.floor(t / a.step + 1e-9)} on the left, step{' '}
          {Math.floor(t / b.step + 1e-9)} on the right{' '}
          <input
            type="range"
            min={0}
            max={1.5}
            step={0.005}
            value={t}
            onChange={(e) => setT(Number.parseFloat(e.target.value))}
            style={{ width: 280, verticalAlign: 'middle' }}
          />
        </label>
        <div style={mono} data-testid="box-quantization">
          π = {a.step}: {a.steps} steps, {a.count} simplices, {a.offGrid} filtration values off the
          grid
          <br />π = {b.step}: {b.steps} steps, {b.count} simplices, {b.offGrid} filtration values
          off the grid
          <br />
          longest H₁ on the coarse grid: {a.h1 ? `${a.h1.birth} → ${a.h1.death}` : 'none'} · on the
          fine grid: {b.h1 ? `${b.h1.birth} → ${b.h1.death}` : 'none'}
        </div>
        <p style={note}>
          <strong>These two diagrams are not comparable.</strong> Both are honest one-parameter box
          filtrations of the same points; their values live on different grids, so a distance
          between them is mostly a distance between the grids. Compare box filtrations only at equal
          π.
        </p>
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <Barcode filtration={coarse} t={t} width={340} height={170} />
          <Barcode filtration={fine} t={t} width={340} height={170} />
        </div>
      </div>
    );
  },
};

/**
 * §7 story 9 — k-fold cover, k = 1 vs k = 2, on the same 8-point jittered
 * lattice. At k = 1 every mosaic vertex is a singleton, so the vertices ARE the
 * points and the filtration reproduces the alpha complex (the engine's own
 * claim, checked against the live engine in
 * src/engine/__tests__/buildFiltrationMenu.integration.test.ts). At k = 2 there
 * are more vertices than points, each drawn at its pair's barycentre as a hollow
 * diamond — while the BALLS still grow at √t around the input points, because
 * the cover is a cover of the points and only the vertices are subsets.
 */
export const Story9KFoldK1VsK2: Story = {
  render: function Story9() {
    const k1 = recordedFiltration(JITTERED8_KFOLD1);
    const k2 = recordedFiltration(JITTERED8_KFOLD2);
    const [t, setT] = useState(0.6);

    const sizes = (f: typeof k1) => {
      const subsets = f.vertexSubsets ?? [];
      const set = new Set(subsets.map((s) => s.length));
      const pointCount = f.cloud.points.length / f.cloud.dimension;
      return {
        pointCount,
        vertexCount: f.vertexCount,
        k: [...set].join('/'),
        atBarycentre: subsets.filter((s) => s.length > 1).length,
      };
    };
    const a = sizes(k1);
    const b = sizes(k2);

    return (
      <div style={{ display: 'grid', gap: 12, maxWidth: 760 }}>
        <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          <Panel label="k = 1: vertices are the points" filtration={k1} t={t} padding={60} />
          <Panel label="k = 2: vertices are pairs" filtration={k2} t={t} padding={60} />
        </div>
        <label style={mono}>
          t = {t.toFixed(3)} (squared radius: the balls have radius √t ={' '}
          {Math.sqrt(Math.max(t, 0)).toFixed(3)}){' '}
          <input
            type="range"
            min={0}
            max={1.5}
            step={0.005}
            value={t}
            onChange={(e) => setT(Number.parseFloat(e.target.value))}
            style={{ width: 280, verticalAlign: 'middle' }}
          />
        </label>
        <div style={mono} data-testid="kfold-comparison">
          k = 1: {a.vertexCount} vertices over {a.pointCount} points, subset size {a.k},{' '}
          {a.atBarycentre} vertices away from an input point
          <br />k = 2: {b.vertexCount} vertices over {b.pointCount} points, subset size {b.k},{' '}
          {b.atBarycentre} vertices away from an input point
        </div>
        <p style={note}>
          The 3D cloud is drawn from above (the 2D surfaces project by dropping z). A renderer that
          placed vertices from `cloud.points` would draw the right-hand complex on 8 points and
          silently discard every simplex whose vertex index is ≥ 8; `vertexCount !== n` is the check
          that catches it.
        </p>
      </div>
    );
  },
};
