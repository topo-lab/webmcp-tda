/**
 * The five end-to-end acceptance stories of SPEC.md §7. These are the
 * definition of done for v2: every one renders the filtration as the object
 * — the user moves t, everything follows — and every simplex and pair on
 * screen is recorded output of the real GUDHI engine
 * (src/__fixtures__/realFiltrations.ts). Nothing is synthesized.
 */
import { useEffect, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  CIRCLE24_ALPHA,
  CIRCLE50_RIPS_CAP2,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../__fixtures__/realFiltrations';
import { TdaEngine } from '../compute/TdaEngine';
import { buildFiltration } from '../engine/buildFiltration';
import type { BallFiltration } from '../filtration/types';
import { useScale } from '../filtration/useScale';
import { Barcode } from '../persistence/Barcode';
import { BettiCurve } from '../persistence/BettiCurve';
import { Field2D } from '../render2d/Field2D';
import { Nerve2D } from '../render2d/Nerve2D';
import { PointCloud2D } from '../render2d/PointCloud2D';
import { ScaleControl } from '../render2d/ScaleControl';

const meta = {
  title: 'Acceptance/SPEC §7',
  parameters: { layout: 'padded' },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

const mono: React.CSSProperties = { fontFamily: 'ui-monospace, monospace', fontSize: 12 };

function Stage({ filtration, t }: { filtration: BallFiltration; t: number }) {
  return (
    <div style={{ position: 'relative', width: 320, height: 320 }}>
      <Field2D filtration={filtration} t={t} />
      <div style={{ position: 'absolute', top: 0, left: 0 }}>
        <Nerve2D filtration={filtration} t={t} />
      </div>
      <div style={{ position: 'absolute', top: 0, left: 0 }}>
        <PointCloud2D
          points={filtration.cloud.points}
          weights={filtration.cloud.weights}
          pointRadius={2.5}
          color="#111827"
        />
      </div>
    </div>
  );
}

/**
 * §7 story 1 — Unweighted circle, alpha. Move t: the annulus thickens, the
 * nerve forms a ring at the first critical value (t = sin²(π/24)) and fills
 * as t approaches 1 (the squared circumradius, where the H₁ loop dies). The
 * barcode playhead tracks the same t — the picture and the summary can never
 * disagree because both are functions of one filtration and one t.
 */
export const Story1UnweightedCircleAlpha: Story = {
  render: function Story1() {
    const filtration = recordedFiltration(CIRCLE24_ALPHA);
    const scale = useScale(filtration, { initialT: 0.05 });
    return (
      <div style={{ display: 'grid', gap: 12, maxWidth: 720 }}>
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <Stage filtration={filtration} t={scale.t} />
          <div style={{ display: 'grid', gap: 8 }}>
            <Barcode filtration={filtration} t={scale.t} width={340} height={200} />
            <BettiCurve filtration={filtration} t={scale.t} width={340} height={140} />
          </div>
        </div>
        <ScaleControl filtration={filtration} t={scale.t} onChange={scale.setT} />
        <div style={mono}>
          <button type="button" onClick={scale.playing ? scale.pause : scale.play}>
            {scale.playing ? 'pause' : 'play'}
          </button>{' '}
          β = [{filtration.bettiAt(scale.t).join(', ')}] · {filtration.simplicesAt(scale.t).length}{' '}
          / {filtration.simplices.length} simplices
        </div>
      </div>
    );
  },
};

/**
 * §7 story 2 — Weighted cloud: three points, one heavy (w = 0.5). At t = 0
 * the heavy ball already has radius √0.5 ≈ 0.707 while the light points are
 * still points. The nerve edges to the heavy point appear at t ≈ 0.658 and
 * 0.766 — BEFORE the light–light edge at t = 0.89. Weights reorder the
 * filtration; that is the capability this library exists to show.
 */
export const Story2WeightedCloud: Story = {
  render: function Story2() {
    const filtration = recordedFiltration(WEIGHTED3_ALPHA);
    const scale = useScale(filtration, { initialT: 0 });
    const edges = filtration
      .simplicesAt(scale.t)
      .filter((s) => s.vertices.length === 2)
      .map((s) => `[${[...s.vertices].sort((a, b) => a - b).join('–')}]`);
    return (
      <div style={{ display: 'grid', gap: 12, maxWidth: 720 }}>
        <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
          <Stage filtration={filtration} t={scale.t} />
          <Barcode filtration={filtration} t={scale.t} width={340} height={160} />
        </div>
        <ScaleControl filtration={filtration} t={scale.t} onChange={scale.setT} />
        <div style={mono}>
          weights = [0.5, 0, 0] (point 0 is heavy) · edges present: {edges.join(' ') || 'none'}
          <br />
          heavy–light edges enter at t ≈ 0.658 / 0.766; the light–light edge at t = 0.89
        </div>
      </div>
    );
  },
};

/**
 * §7 story 2b — A NEGATIVE weight is rejected by the adapter with a clear
 * error, up front, before the engine is touched. The engine's own failure
 * is opaque ("Alpha complex computation failed: undefined"); the adapter
 * never lets a user see it. This story renders the real rejection — it does
 * not draw a fiction of a negative-weight filtration, because the engine
 * cannot compute one (SPEC §1.2).
 */
export const Story2NegativeWeightRejected: Story = {
  render: function Story2b() {
    const [error, setError] = useState<string | null>(null);
    useEffect(() => {
      // Validation is up-front: the (uninitialized) engine is never touched.
      buildFiltration(
        new TdaEngine({ createWorker: null }),
        { points: [0, 0, 2, 0], weights: [-0.25, 0], dimension: 2 },
        { complexType: 'alpha' },
      ).then(
        () => setError('UNEXPECTED: the adapter accepted a negative weight'),
        (e: unknown) => setError(e instanceof Error ? e.message : String(e)),
      );
    }, []);
    return (
      <div style={{ maxWidth: 560 }}>
        <p style={{ ...mono, fontWeight: 600 }}>
          buildFiltration(engine, {'{'} weights: [-0.25, 0], … {'}'}, {'{'} complexType:
          &apos;alpha&apos; {'}'})
        </p>
        <pre
          data-testid="negative-weight-error"
          style={{
            ...mono,
            whiteSpace: 'pre-wrap',
            background: '#fef2f2',
            color: '#991b1b',
            padding: 12,
            borderRadius: 6,
          }}
        >
          {error ?? 'validating…'}
        </pre>
        <p style={{ fontSize: 12, opacity: 0.75 }}>
          No picture is drawn: a filtration the engine cannot compute is an error state, not an
          illustration.
        </p>
      </div>
    );
  },
};

/**
 * §7 story 3 — Rips vs Čech on the same cloud. The slider sets the DRAWN
 * ball radius r for both panels; because t means edge length for Rips and
 * ball radius for Čech (SPEC §1.3), that is t = 2r on the left and t = r on
 * the right — comparing at the same raw t would draw different balls and
 * prove nothing. Between r = 0.5 and r ≈ 0.577 the Rips panel contains a
 * triangle although its three balls share NO common point (highlighted red);
 * the Čech nerve honestly refuses it until r = 1/√3, the circumradius.
 */
export const Story3RipsVsCech: Story = {
  render: function Story3() {
    const rips = recordedFiltration(TRIANGLE_RIPS);
    const cech = recordedFiltration(TRIANGLE_CECH);
    const [r, setR] = useState(0.53);
    const tRips = 2 * r;
    const tCech = r;

    const cechTriangles = new Set(
      cech
        .simplicesAt(tCech)
        .filter((s) => s.vertices.length === 3)
        .map((s) => [...s.vertices].sort((a, b) => a - b).join(',')),
    );
    const ripsOnly = rips
      .simplicesAt(tRips)
      .filter((s) => s.vertices.length === 3)
      .map((s) => [...s.vertices].sort((a, b) => a - b))
      .filter((vs) => !cechTriangles.has(vs.join(',')));

    const panel = (
      label: string,
      filtration: BallFiltration,
      t: number,
      highlight?: number[][],
    ) => (
      <figure style={{ margin: 0 }}>
        <figcaption style={{ ...mono, marginBottom: 4 }}>{label}</figcaption>
        <div style={{ position: 'relative', width: 280, height: 280 }}>
          <Field2D filtration={filtration} t={t} width={280} height={280} padding={40} />
          <div style={{ position: 'absolute', top: 0, left: 0 }}>
            <Nerve2D
              filtration={filtration}
              t={t}
              width={280}
              height={280}
              padding={40}
              highlightTriangles={highlight}
            />
          </div>
        </div>
      </figure>
    );

    return (
      <div style={{ display: 'grid', gap: 12, maxWidth: 720 }}>
        <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
          {panel(`Rips at t = ${tRips.toFixed(3)} (balls r = t/2)`, rips, tRips, ripsOnly)}
          {panel(`Čech at t = ${tCech.toFixed(3)} (balls r = t)`, cech, tCech)}
        </div>
        <label style={mono}>
          shared ball radius r = {r.toFixed(3)}{' '}
          <input
            type="range"
            min={0.3}
            max={0.75}
            step={0.005}
            value={r}
            onChange={(e) => setR(Number.parseFloat(e.target.value))}
            style={{ width: 280, verticalAlign: 'middle' }}
          />
        </label>
        <div style={mono}>
          {ripsOnly.length > 0
            ? 'highlighted: a Rips triangle that is NOT a nerve triangle — all three edges exist, but the three balls share no common point (flag complex, SPEC §1.4)'
            : r < 0.5
              ? 'no triangle yet in either complex'
              : 'r ≥ 1/√3 ≈ 0.577: the three balls now share a point, so the Čech nerve contains the triangle too'}
        </div>
      </div>
    );
  },
};

/**
 * §7 story 4 — Snapping. The ⟨ ⟩ buttons of useScale jump between the
 * filtration's criticalValues: the ONLY moments the complex changes. Each
 * step changes the simplex count exactly once; the slider between events
 * changes nothing, because nothing happens between events (SPEC §3.3).
 */
export const Story4Snapping: Story = {
  render: function Story4() {
    const filtration = recordedFiltration(CIRCLE24_ALPHA);
    const scale = useScale(filtration);
    const cvs = filtration.criticalValues;
    const eventIndex = cvs.filter((cv) => cv <= scale.t).length;
    return (
      <div style={{ display: 'grid', gap: 12, maxWidth: 720 }}>
        <Stage filtration={filtration} t={scale.t} />
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', ...mono }}>
          <button type="button" onClick={scale.snapToPrev} data-testid="snap-prev">
            ⟨ prev event
          </button>
          <button type="button" onClick={scale.snapToNext} data-testid="snap-next">
            next event ⟩
          </button>
          <span>
            event {eventIndex} / {cvs.length} · t = {scale.t.toFixed(6)} ·{' '}
            {filtration.simplicesAt(scale.t).length} simplices · β = [
            {filtration.bettiAt(scale.t).join(', ')}]
          </span>
        </div>
        <ScaleControl filtration={filtration} t={scale.t} onChange={scale.setT} />
      </div>
    );
  },
};

/**
 * §7 story 5 — Honesty. A 2D circle under Rips at cap 2: the raw engine
 * output REALLY contains 150 spurious H₂ pairs (unfilled 2-boundaries of the
 * truncated complex — correct homology of the truncation, not topology of a
 * plane). They are present in `rawPairs` for inspection and absent from
 * `pairs`; no chart in this library can draw them. The counts below are
 * computed live from the recorded engine output, and the same regression
 * runs against the live engine in buildFiltration.integration.test.ts (and
 * at full scale — 18,424 pairs at maxEdgeLength 2.2 — in
 * pipeline.integration.test.ts).
 */
export const Story5Honesty: Story = {
  render: function Story5() {
    const filtration = recordedFiltration(CIRCLE50_RIPS_CAP2);
    const count = (pairs: readonly { dimension: number }[], d: number) =>
      pairs.filter((p) => p.dimension === d).length;
    const dims = [0, 1, 2];
    return (
      <div style={{ display: 'grid', gap: 12, maxWidth: 720 }}>
        <table
          style={{ ...mono, borderCollapse: 'collapse', width: 360 }}
          data-testid="honesty-table"
        >
          <thead>
            <tr>
              <th style={{ textAlign: 'left' }}>degree</th>
              <th>rawPairs (computed)</th>
              <th>pairs (presentable)</th>
            </tr>
          </thead>
          <tbody>
            {dims.map((d) => (
              <tr key={d} style={{ borderTop: '1px solid #e5e7eb' }}>
                <td>H{d}</td>
                <td style={{ textAlign: 'center' }}>{count(filtration.rawPairs, d)}</td>
                <td style={{ textAlign: 'center' }}>{count(filtration.pairs, d)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <Barcode filtration={filtration} height={300} />
        <p style={{ fontSize: 12, opacity: 0.75, maxWidth: 560 }}>
          The H₂ row is the point: 150 real computed pairs, zero presentable ones. Points in ℝ²
          carry no homology above degree 1 (Nerve theorem), so every H₂ pair of a capped Rips
          complex on a 2D cloud is a truncation artifact. The library withholds them — it never
          pretends they were not computed.
        </p>
      </div>
    );
  },
};
