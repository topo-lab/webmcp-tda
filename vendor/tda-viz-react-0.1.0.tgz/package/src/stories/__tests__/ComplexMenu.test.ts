/**
 * The numbers SPEC.md §7 (stories 6–9) and the README quote about the complex
 * menu's fixtures.
 *
 * The stories compute these live, so they cannot drift; the docs cannot. This
 * file is what keeps the prose honest: regenerate the fixtures, change the
 * engine, and any of these claims that stops being true fails here instead of
 * quietly becoming a false sentence in a spec.
 */
import { describe, expect, it } from 'vitest';
import type { Simplex } from 'tda-wasm';
import {
  CIRCLE12_WING,
  CIRCLE12_WING_ESTIMATED_NORMALS,
  ELLIPSE_ELLIPSOID_CECH,
  ELLIPSE_ELLIPSOID_RIPS,
  JITTERED8_KFOLD1,
  JITTERED8_KFOLD2,
  RING6_BOX,
  RING6_BOX_HALFSTEP,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';

const key = (s: Simplex) => [...s.vertices].sort((a, b) => a - b).join(',');

describe('§7 story 6 — ellipsoid flag vs nerve, same shapes and same scale', () => {
  const flag = recordedFiltration(ELLIPSE_ELLIPSOID_RIPS);
  const nerve = recordedFiltration(ELLIPSE_ELLIPSOID_CECH);
  const nerveByKey = new Map(nerve.simplices.map((s) => [key(s), s.filtration]));

  it('draws the SAME ellipsoids from both builds, at every t', () => {
    for (let i = 0; i < flag.cloud.points.length / 2; i++) {
      for (const t of [0.4, 1.2]) {
        expect(nerve.shapeAt(i, t)).toEqual(flag.shapeAt(i, t));
      }
    }
  });

  it('has 40 shared edges whose births agree exactly (SPEC.md §7 story 6)', () => {
    let edges = 0;
    let maxDelta = 0;
    for (const s of flag.simplices) {
      if (s.vertices.length !== 2) continue;
      const other = nerveByKey.get(key(s));
      expect(other).toBeDefined();
      edges++;
      maxDelta = Math.max(maxDelta, Math.abs(other! - s.filtration));
    }
    expect(edges).toBe(40);
    expect(maxDelta).toBe(0);
  });

  it('has 8 higher simplices born strictly LATER in the nerve, and none earlier', () => {
    let later = 0;
    let earlier = 0;
    for (const s of flag.simplices) {
      if (s.vertices.length < 3) continue;
      const other = nerveByKey.get(key(s));
      if (other === undefined) continue;
      if (other > s.filtration) later++;
      if (other < s.filtration) earlier++;
    }
    expect(later).toBe(8);
    // The direction is the whole claim: a nerve simplex can never be born
    // before its flag counterpart, because a common point implies pairwise
    // intersection and not the reverse.
    expect(earlier).toBe(0);
  });
});

describe('§7 story 7 — wing, exact normals vs estimated', () => {
  const exact = recordedFiltration(CIRCLE12_WING);
  const estimated = recordedFiltration(CIRCLE12_WING_ESTIMATED_NORMALS);

  it('produces the IDENTICAL complex on a circle: 84 simplices, no drift', () => {
    // A circle is where the osculating-circle estimate is exact. That is a
    // property of this cloud and not a general guarantee, which is why the
    // provenance of each normal is reported rather than assumed (below).
    expect(exact.simplices).toHaveLength(84);
    expect(estimated.simplices).toHaveLength(84);
    const byKey = new Map(estimated.simplices.map((s) => [key(s), s.filtration]));
    for (const s of exact.simplices) {
      expect(byKey.get(key(s))).toBe(s.filtration);
    }
  });

  it('draws both, and labels which normal each hexagon was built from', () => {
    expect(exact.shapesAvailable).toBe(true);
    expect(estimated.shapesAvailable).toBe(true);
    expect(exact.shapeAt(0, 0.5).normalSource).toBe('supplied');
    expect(estimated.shapeAt(0, 0.5).normalSource).toBe('osculating');
    // Nothing fell back to the PCA tangent on a circle: every estimated normal
    // came from a real osculating fit, and the story says so from these counts.
    expect(estimated.wing.normalSources.filter((s) => s === 'tangent')).toHaveLength(0);
  });

  it('draws hexagons that agree to the accuracy of the fit, not by construction', () => {
    // The complexes are identical (above), and on a circle the osculating
    // estimate recovers the outward radial, so the two drawings very nearly
    // coincide. NEARLY: the agreement is the fit's accuracy on this cloud —
    // measured below, ~1e-8 on a wing of size 0.5 — and nothing guarantees it on
    // a cloud with an inflection. The difference between the panels is
    // provenance, which is why provenance is what the record reports.
    let maxDelta = 0;
    for (let i = 0; i < exact.cloud.points.length / 2; i++) {
      const a = exact.shapeAt(i, 0.5).outline;
      const b = estimated.shapeAt(i, 0.5).outline;
      a.forEach((vertex, v) => {
        for (let d = 0; d < 2; d++) maxDelta = Math.max(maxDelta, Math.abs(b[v][d] - vertex[d]));
      });
    }
    expect(maxDelta).toBeGreaterThan(0);
    expect(maxDelta).toBeLessThan(1e-6);
  });
});

describe('§7 story 8 — box at two step sizes, and why they are not comparable', () => {
  const coarse = recordedFiltration(RING6_BOX);
  const fine = recordedFiltration(RING6_BOX_HALFSTEP);

  it('puts every filtration value on its own grid, in both builds', () => {
    for (const f of [coarse, fine]) {
      const step = f.quantization.step;
      const offGrid = f.simplices.filter(
        (s) => Math.abs(s.filtration / step - Math.round(s.filtration / step)) > 1e-9,
      );
      expect(offGrid).toHaveLength(0);
    }
  });

  it('is the same cloud on grids of 0.25 and 0.125 — the story\u2019s whole point', () => {
    expect(coarse.quantization.step).toBe(0.25);
    expect(fine.quantization.step).toBe(0.125);
    expect(fine.cloud.points).toEqual(coarse.cloud.points);
    // Halving the step doubles the number of steps: same geometry, finer grid,
    // and therefore values that cannot be compared bar for bar.
    expect(fine.quantization.steps).toBe(2 * coarse.quantization.steps);
  });
});

describe('§7 story 9 — k-fold cover at k = 1 and k = 2', () => {
  const k1 = recordedFiltration(JITTERED8_KFOLD1);
  const k2 = recordedFiltration(JITTERED8_KFOLD2);

  it('has 8 singleton vertices at k = 1: the vertices ARE the points', () => {
    expect(k1.vertexCount).toBe(8);
    expect(new Set((k1.vertexSubsets ?? []).map((s) => s.length))).toEqual(new Set([1]));
    for (let v = 0; v < k1.vertexCount; v++) {
      const i = k1.vertexSubsets![v][0];
      expect([...k1.vertexPosition(v)]).toEqual([
        k1.cloud.points[i * 3],
        k1.cloud.points[i * 3 + 1],
        k1.cloud.points[i * 3 + 2],
      ]);
    }
  });

  it('has 22 pair vertices at k = 2, each at its pair\u2019s barycentre', () => {
    expect(k2.vertexCount).toBe(22);
    expect(new Set((k2.vertexSubsets ?? []).map((s) => s.length))).toEqual(new Set([2]));
    expect(k2.vertexCount).toBeGreaterThan(8);
    for (let v = 0; v < k2.vertexCount; v++) {
      const [a, b] = k2.vertexSubsets![v];
      const pos = k2.vertexPosition(v);
      for (let axis = 0; axis < 3; axis++) {
        expect(pos[axis]).toBeCloseTo(
          (k2.cloud.points[a * 3 + axis] + k2.cloud.points[b * 3 + axis]) / 2,
          12,
        );
      }
    }
  });

  it('still grows BALLS at \u221At around the input points, at both k', () => {
    for (const f of [k1, k2]) {
      expect(f.shapeKind).toBe('ball');
      expect(f.convention).toBe('alpha');
      const shape = f.shapeAt(3, 0.36);
      expect(shape.radius).toBeCloseTo(0.6, 12);
      expect([...shape.center]).toEqual([
        f.cloud.points[9],
        f.cloud.points[10],
        f.cloud.points[11],
      ]);
    }
  });
});
