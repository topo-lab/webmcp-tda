import { describe, expect, it } from 'vitest';
import { ENGINE_SURFACE, type ComplexType } from '../engine';

/**
 * The types module mirrors the engine surface actually available in tda-wasm
 * (SPEC.md §6). "The package may only expose what exists."
 */
describe('engine surface (SPEC.md §6)', () => {
  it('mirrors the bindings tda-wasm actually exposes', () => {
    expect(ENGINE_SURFACE.rips.binding).toBe('computeRipsComplex');
    expect(ENGINE_SURFACE.alpha.binding).toBe('computeWeightedAlphaComplex3D');
    expect(ENGINE_SURFACE.cech.binding).toBe('computeCechComplex');
    expect(ENGINE_SURFACE.witness.binding).toBe('computeEuclideanWitnessComplex');
    expect(ENGINE_SURFACE.cubical.binding).toBe('computeCubicalPersistence');
  });

  it('records alpha as 3D-only at the binding level (the one real dimensional asymmetry)', () => {
    expect(ENGINE_SURFACE.alpha.pointDimensions).toBe('3d-only');
    expect(ENGINE_SURFACE.rips.pointDimensions).toBe('any');
    expect(ENGINE_SURFACE.cech.pointDimensions).toBe('any');
    expect(ENGINE_SURFACE.cubical.pointDimensions).toBe('grid');
  });

  it('labels experimental backends honestly (SPEC.md §5)', () => {
    expect(ENGINE_SURFACE.rips.status).toBe('experimental');
    expect(ENGINE_SURFACE.witness.status).toBe('experimental');
    expect(ENGINE_SURFACE.alpha.status).toBe('stable');
    expect(ENGINE_SURFACE.cech.status).toBe('stable');
    expect(ENGINE_SURFACE.cubical.status).toBe('stable');
  });

  it('records rips as GUDHI-native Rips_complex with the manual path as explicit fallback (tda-wasm 0.2.0)', () => {
    expect(ENGINE_SURFACE.rips.note).toContain('GUDHI-native Rips_complex');
    expect(ENGINE_SURFACE.rips.note).toContain('fallback');
    expect(ENGINE_SURFACE.rips.note).not.toContain('in-flight');
  });

  it('wires rips/alpha/cech into the v1 pipeline, and cubical through its own shape', () => {
    expect(ENGINE_SURFACE.rips.wired).toBe(true);
    expect(ENGINE_SURFACE.alpha.wired).toBe(true);
    expect(ENGINE_SURFACE.cech.wired).toBe(true);
    // TODO(SPEC.md §6): wire witness once its params (landmarks) are designed.
    expect(ENGINE_SURFACE.witness.wired).toBe(false);
    // Cubical takes image/grid input, not point clouds. It is wired — but into
    // its OWN pipeline shape, `buildFiltration(engine, params)` with no cloud,
    // returning a GridFiltration rather than a member of the shape-growing
    // union (SPEC.md §3.1b). That is why it is absent from `ComplexType`
    // below, which is the point-cloud pipeline's own list.
    expect(ENGINE_SURFACE.cubical.wired).toBe(true);
    expect(ENGINE_SURFACE.cubical.pointDimensions).toBe('grid');
  });

  it('ComplexType covers exactly the wired point-cloud complexes', () => {
    const wired: ComplexType[] = ['rips', 'alpha', 'cech'];
    expect(wired).toHaveLength(3);
  });
});
