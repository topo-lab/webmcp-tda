/**
 * Types mirroring the engine surface actually available in tda-wasm
 * (SPEC.md §6). The package may only expose what exists.
 */
import type { AlphaComplexResult, PersistenceDiagram, PersistenceResult } from 'tda-wasm';

// Re-export the core tda-wasm types so consumers never need to import the
// wasm package directly for typing.
export type {
  AlphaComplexResult,
  BettiNumbers,
  ModuleOptions,
  PersistenceDiagram,
  PersistencePair,
  PersistenceResult,
  Point3D,
  Simplex,
} from 'tda-wasm';

/**
 * Point-cloud complexes wired into the v1 pipeline.
 *
 * TODO(SPEC.md §6): 'witness' (weak) exists in tda-wasm
 * (`computeEuclideanWitnessComplex`) but needs landmark params designed
 * before wiring. Cubical takes image/grid input, not point clouds — it needs
 * its own pipeline shape.
 */
export type ComplexType = 'rips' | 'alpha' | 'cech';

/** Result of building a simplicial complex (generic, despite the wasm name). */
export type ComplexResult = AlphaComplexResult;

/** Parameters for the points → complex → persistence pipeline (SPEC.md §4). */
export interface TdaParams {
  complexType: ComplexType;
  /** Max edge length for Rips; acts as max radius for Čech; ignored by alpha
   * (whose filtration is intrinsic). */
  maxEdgeLength: number;
  /** Simplex-dimension cap. Default 2 (SPEC.md §5); raising to 3 is what makes
   * a real β₂ reachable, at several-fold simplex cost. */
  maxSimplexDimension: number;
  /** Coefficient field characteristic (default 2). */
  coeffField: number;
}

/** Everything one pipeline run produces. */
export interface PipelineResult {
  complex: ComplexResult;
  persistence: PersistenceResult;
  diagram: PersistenceDiagram;
}

/** Honesty label carried by every engine binding (SPEC.md §5). */
export type EngineBindingStatus = 'stable' | 'experimental';
/** Which ambient point dimensions a binding accepts. */
export type EnginePointDimensions = 'any' | '3d-only' | 'grid';

/** One row of the SPEC.md §6 engine-surface table. */
export interface EngineBindingInfo {
  /** Name of the underlying WASM binding. */
  binding: string;
  /** Which ambient point dimensions the binding accepts. */
  pointDimensions: EnginePointDimensions;
  /** Honesty label (SPEC.md §5): experimental backends are labeled, always. */
  status: EngineBindingStatus;
  /** Whether this package's v1 pipeline exposes it. */
  wired: boolean;
  note: string;
}

/**
 * The SPEC.md §6 table, as data. Keep in sync with the spec and with what
 * tda-wasm actually ships; `src/types/__tests__/engine.test.ts` guards it.
 */
export const ENGINE_SURFACE = {
  rips: {
    binding: 'computeRipsComplex',
    pointDimensions: 'any',
    status: 'experimental',
    wired: true,
    note: 'Default is GUDHI-native Rips_complex (tda-wasm 0.2.0), still labeled Experimental upstream; the former manual simplex-tree path is retained as an explicit, differential-tested fallback.',
  },
  alpha: {
    binding: 'computeWeightedAlphaComplex3D',
    pointDimensions: '3d-only',
    status: 'stable',
    wired: true,
    note: '3D-only at the binding level. 2D clouds are embedded at z=0 in the compute layer (SPEC.md §6).',
  },
  cech: {
    binding: 'computeCechComplex',
    pointDimensions: 'any',
    status: 'stable',
    wired: true,
    note: 'maxEdgeLength acts as the max ball radius.',
  },
  witness: {
    binding: 'computeEuclideanWitnessComplex',
    pointDimensions: 'any',
    status: 'experimental',
    wired: false,
    note: 'Weak witness only; strong variant not wired in tda-wasm. TODO(SPEC.md §6): design landmark params, then wire.',
  },
  cubical: {
    binding: 'computeCubicalPersistence',
    pointDimensions: 'grid',
    status: 'stable',
    wired: true,
    note:
      "Image/grid data, not point clouds: buildFiltration(engine, { complexType: 'cubical', … }) " +
      'takes the grid and no cloud, and returns a GridFiltration (SPEC.md §3.1b). Two ' +
      'constructions, T (values on pixels) and V (values on vertices), and they disagree. ' +
      'Routed through the general binding rather than computeCubicalPersistence2D, whose ' +
      'dimension order transposes a non-square grid.',
  },
} as const satisfies Record<string, EngineBindingInfo>;
