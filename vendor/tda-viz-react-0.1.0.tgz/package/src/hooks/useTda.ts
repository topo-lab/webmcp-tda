import { useContext } from 'react';
import type { TdaEngine } from '../compute/TdaEngine';
import { TdaContext } from './TdaProvider';

/** Wasm boot state (SPEC.md §4): `{ isReady, error }`. */
export function useTda(): { isReady: boolean; error: string | null } {
  const ctx = useContext(TdaContext);
  if (!ctx) throw new Error('useTda must be used inside a <TdaProvider>');
  return { isReady: ctx.isReady, error: ctx.error };
}

/** The engine owned by the nearest <TdaProvider>. */
export function useTdaEngine(): TdaEngine {
  const ctx = useContext(TdaContext);
  if (!ctx) throw new Error('useTdaEngine must be used inside a <TdaProvider>');
  return ctx.engine;
}
