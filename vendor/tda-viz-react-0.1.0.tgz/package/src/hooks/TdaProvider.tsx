/**
 * <TdaProvider> owns wasm init + the worker-backed engine, once per app
 * (SPEC.md §4).
 */
import { createContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { TdaEngine, type TdaEngineOptions } from '../compute/TdaEngine';

export interface TdaContextValue {
  engine: TdaEngine;
  /** True once the wasm module has booted. */
  isReady: boolean;
  /** Boot failure message; a real state, never masked (SPEC.md §5). */
  error: string | null;
}

export const TdaContext = createContext<TdaContextValue | null>(null);

export interface TdaProviderProps {
  children: ReactNode;
  /** Inject a pre-built engine (tests, advanced hosts). The provider will not
   * dispose an injected engine. */
  engine?: TdaEngine;
  /** Options for the engine the provider creates when none is injected. */
  engineOptions?: TdaEngineOptions;
}

export function TdaProvider({ children, engine: injectedEngine, engineOptions }: TdaProviderProps) {
  const engineRef = useRef<TdaEngine | null>(null);
  if (engineRef.current === null) {
    engineRef.current = injectedEngine ?? new TdaEngine(engineOptions);
  }
  const engine = engineRef.current;
  const ownsEngine = injectedEngine === undefined;

  const [isReady, setIsReady] = useState(engine.isReady());
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    engine.initialize().then(
      () => {
        if (!cancelled) setIsReady(true);
      },
      (err: unknown) => {
        if (!cancelled) setError(err instanceof Error ? err.message : String(err));
      },
    );
    return () => {
      cancelled = true;
      if (ownsEngine) engine.dispose();
    };
  }, [engine, ownsEngine]);

  return <TdaContext.Provider value={{ engine, isReady, error }}>{children}</TdaContext.Provider>;
}
