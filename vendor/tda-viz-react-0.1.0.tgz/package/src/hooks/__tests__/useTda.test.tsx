import { render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
// The factory routes 'tda-wasm' to our manual mock; importing the mock file
// directly yields the SAME module instance, so mockControl steers the mock
// the code under test sees.
import { mockControl } from '../../../__mocks__/tda-wasm';
import { TdaProvider } from '../TdaProvider';
import { useTda, useTdaEngine } from '../useTda';

vi.mock('tda-wasm', () => import('../../../__mocks__/tda-wasm'));

function Probe() {
  const { isReady, error } = useTda();
  return (
    <div>
      <span data-testid="ready">{String(isReady)}</span>
      <span data-testid="error">{error ?? 'none'}</span>
    </div>
  );
}

function EngineProbe() {
  const engine = useTdaEngine();
  return <span data-testid="engine-ready">{String(engine.isReady())}</span>;
}

beforeEach(() => {
  mockControl.reset();
  vi.clearAllMocks();
});

describe('TdaProvider + useTda (wasm boot state, SPEC.md §4)', () => {
  it('reports isReady=false during boot, then true once wasm initializes', async () => {
    render(
      <TdaProvider>
        <Probe />
      </TdaProvider>,
    );
    expect(screen.getByTestId('ready')).toHaveTextContent('false');
    await waitFor(() => expect(screen.getByTestId('ready')).toHaveTextContent('true'));
    expect(screen.getByTestId('error')).toHaveTextContent('none');
    expect(mockControl.instances).toHaveLength(1);
  });

  it('reports the boot error as a real state (never fake readiness)', async () => {
    mockControl.failNextInit = true;
    render(
      <TdaProvider>
        <Probe />
      </TdaProvider>,
    );
    await waitFor(() => expect(screen.getByTestId('error')).toHaveTextContent(/mock init failure/));
    expect(screen.getByTestId('ready')).toHaveTextContent('false');
  });

  it('throws when used outside a TdaProvider', () => {
    // Silence React's error boundary logging for the expected throw.
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {});
    expect(() => render(<Probe />)).toThrow(/TdaProvider/);
    spy.mockRestore();
  });

  it('exposes the exact provider-owned engine and rejects engine access outside the provider', async () => {
    const outsideError = vi.spyOn(console, 'error').mockImplementation(() => {});
    expect(() => render(<EngineProbe />)).toThrow(/useTdaEngine.*TdaProvider/);
    outsideError.mockRestore();

    render(
      <TdaProvider>
        <EngineProbe />
      </TdaProvider>,
    );
    await waitFor(() => expect(screen.getByTestId('engine-ready')).toHaveTextContent('true'));
    expect(mockControl.instances).toHaveLength(1);
  });
});
