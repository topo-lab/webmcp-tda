import { render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
// The factory routes 'tda-wasm' to our manual mock; importing the mock file
// directly yields the SAME module instance, so mockControl steers the mock
// the code under test sees.
import { mockControl } from '../../../__mocks__/tda-wasm';
import { TdaProvider } from '../TdaProvider';
import { useTda } from '../useTda';

vi.mock('tda-wasm', () => import('../../../__mocks__/tda-wasm'));

function Probe() {
  const { isReady, error } = useTda();
  return (
    <div>
      <span data-testid="ready">{String(isReady)}</span>
      <span data-testid="error">{error ?? 'none'}</span>
    </div>
  );
}

beforeEach(() => {
  mockControl.reset();
  vi.clearAllMocks();
});

describe('TdaProvider + useTda (wasm boot state, SPEC.md §4)', () => {
  it('reports isReady=false during boot, then true once wasm initializes', async () => {
    render(
      <TdaProvider>
        <Probe />
      </TdaProvider>,
    );
    expect(screen.getByTestId('ready')).toHaveTextContent('false');
    await waitFor(() => expect(screen.getByTestId('ready')).toHaveTextContent('true'));
    expect(screen.getByTestId('error')).toHaveTextContent('none');
    expect(mockControl.instances).toHaveLength(1);
  });

  it('reports the boot error as a real state (never fake readiness)', async () => {
    mockControl.failNextInit = true;
    render(
      <TdaProvider>
        <Probe />
      </TdaProvider>,
    );
    await waitFor(() => expect(screen.getByTestId('error')).toHaveTextContent(/mock init failure/));
    expect(screen.getByTestId('ready')).toHaveTextContent('false');
  });

  it('throws when used outside a TdaProvider', () => {
    // Silence React's error boundary logging for the expected throw.
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {});
    expect(() => render(<Probe />)).toThrow(/TdaProvider/);
    spy.mockRestore();
  });
});
