# tda-viz-react — package spec

**Status:** v2, founder-corrected 2026-08-23; complex menu added 2026-09-01.
Supersedes v1 entirely.
**License:** MIT (see §9)
**Repo:** `topo-lab/tda-viz-react`, private.

---

## 0. What this is, stated once

A React library for visualizing a **filtration** of a point cloud — the
one-parameter family of topological spaces you get by growing a **shape**
around every point — and the complex that family induces.

For most of the engine's constructions that shape is a ball, and the ball is
still the case to think with. But it is not the general case, and saying
"ball" as if it were is exactly the kind of convenient inaccuracy this spec
exists to prevent. The engine also grows **ellipsoids** (fitted per point from
a local PCA frame), a 2D concave **wing** hexagon around an estimated normal,
and axis-aligned **boxes** that grow in whole steps. And in one construction —
the k-fold cover — the shapes are still balls but the complex's **vertices are
not the points**: a vertex is a k-subset of the input. The library's job is to
carry all of that honestly, per construction, and never to draw a circle where
the mathematics grew something else (§1.3, §3.1).

The object of study is the family itself, indexed by scale. Not a barcode.
Not a diagram. Those are *summaries* of the family and this library can draw
them, but they are the last thing it does, not the first.

Every component answers one question: **at scale t, what does the space look
like, and what is the complex it induces?** The user moves t. Everything else
follows.

### Why v1 was wrong

v1 shipped a results-display library: components that draw a barcode after a
computation finishes. That is the compute-then-stare pattern the Explorer's
own VISION.md rejects, with better typography. The growing balls were an
illustration in one component's corner. They are the subject. v2 inverts this.

### What this package is NOT responsible for

Computation. `tda-wasm` computes complexes and persistence. This package
organizes that capability and makes the *process* visible. It owns no
topology algorithm and must never grow one.

---

## 1. The mathematics the components must respect

This section is normative. A component that violates it is wrong, not merely
ugly.

### 1.1 The filtration

Given points p₁…pₙ ∈ ℝᵈ, the **sublevel filtration** at scale t is the union of
the growing shapes

    X_t = ⋃ᵢ S_i(t)

with S_i(s) ⊆ S_i(t) whenever s ≤ t, so X_s ⊆ X_t. Moving t forward never
removes anything. This inclusion is the whole reason persistence is well
defined, and the UI must never break it: a display that makes something vanish
as t increases is lying about the filtration.

The familiar case is S_i(t) = B(pᵢ, r_i(t)) with r_i non-decreasing, and it
covers Rips, Čech, alpha and the k-fold cover. The other shapes are just as
monotone, and monotone for the same reason — they are all **homothetic about
their point**, scaled by a factor that increases with t:

| Shape | S_i(t) | Monotone because |
|---|---|---|
| ball | B(pᵢ, rᵢ(t)) | rᵢ non-decreasing |
| ellipsoid | semi-axes (t/2)·profileᵢ along a FIXED frameᵢ | the profile and frame do not move with t |
| wing | the engine's unit wing at scale t around a FIXED normal αᵢ | every defining vector scales linearly with t (`wing_complex.hpp`, homothety note) |
| box | the engine's grown box at step ⌊t/π⌋ | the growth rule only ever adds width, and the step index is non-decreasing |

Two consequences the library is required to respect. First, the ellipsoid and
wing shapes are monotone **only because their frame / normal is fixed at build
time**: re-estimating either per scale would break the inclusions and the
persistence beside them would be the persistence of nothing. Second, the box
shape exists only on the grid — the shape at t is a *lookup* of the last
completed step, never an interpolation, because an interpolated box is a shape
the filtration never contained.

### 1.2 Weights

A **weighted point cloud** assigns each point a weight wᵢ. In the alpha / power
filtration the ball around pᵢ has squared radius **t + wᵢ** (Edelsbrunner's
convention; `tda-wasm`'s `computeWeightedAlphaComplex3D` takes `(x, y, z, w)`
with exactly this meaning). So:

- At a given t, heavier points have larger balls.
- Radii are therefore **per point**, not one shared scalar. This is the
  single fact v1's `GrowingBalls2D` got wrong (one radius for all points).

**Engine constraint (verified 2026-08-24):** `computeWeightedAlphaComplex3D`
throws on any wᵢ < 0 (`"Weight at point i must be non-negative"`). So the
general power-filtration case of a point with wᵢ < −t — "not yet born,
imaginary radius" — is mathematically real but **unreachable through this
engine**. The library must not simulate it. The adapter validates wᵢ ≥ 0 up
front and throws a clear error rather than letting the WASM call fail
opaquely. With wᵢ ≥ 0, every point is present at t = 0 with radius √wᵢ ≥ 0,
and heavier points simply start larger and stay larger.

An unweighted cloud is the special case wᵢ = 0 ∀i. The library treats
unweighted as weighted-with-zeros; there is no separate unweighted path.

### 1.3 Which shape to draw at t

The shape on screen must match the filtration's indexing, or the picture
contradicts the barcode beside it. Each construction indexes t differently, and
the library must name which convention it is drawing:

| Complex | Convention | Index t means | Shape drawn at t |
|---|---|---|---|
| Vietoris–Rips | `rips` | edge length | ball, radius t/2 — two balls touch exactly when points are t apart |
| Čech | `cech` | ball radius | ball, radius t |
| Alpha / weighted alpha | `alpha` | squared radius | ball, radius √(t + wᵢ), per point |
| k-fold cover | `alpha` | squared radius, unweighted | ball, radius √t, around the **input points** (§3.1: the vertices are subsets) |
| Ellipsoid-Rips, ellipsoid-Čech | `ellipsoid-2r` | **twice** the ellipsoid radius (the Rips-comparable scale the engine emits) | ellipsoid, semi-axes (t/2)·profileᵢ along frameᵢ |
| Wing | `wing-eps` | the wing scale ε itself | the (q, θ)-hexagon: spine half-length q·t, wing edges of length t at ±θ — the engine's unit outline, scaled |
| Box | `box-step` | step × π | the engine's box at step ⌊t/π⌋ |

Four things this table is load-bearing about.

1. The k-fold cover deliberately reuses `alpha`. Its values are squared radii
   and it refuses weights, so the radius law is `alpha`'s law with wᵢ = 0 —
   inventing a fourth ball convention that computes the same number would make
   every convention-keyed table in every renderer grow an entry for nothing.
   What is different about the k-fold cover is vertex identity and its
   guarantee, and those are carried separately.
2. Both ellipsoid complexes emit **2 × radius**, deliberately, so their values
   are comparable to each other and to a Rips edge length. They are therefore
   **not** comparable to `cech`, which emits the radius itself. Halve before
   comparing; the library never silently rescales one into the other.
3. Box values are **grid values**, not measurements. A box filtration carries
   its step π (§3.1 `quantization`), a renderer must say so, and two box
   diagrams at different π are not comparable — a bottleneck distance between
   them mostly measures the grids.
4. Only `rips`, `cech` and `alpha` have a radius at all. `radiusAt` exists on
   ball filtrations and nowhere else, so a component that draws discs takes a
   ball filtration and refusing an ellipsoid one is a **type error, not a
   runtime surprise** (§3.1). There is still no default convention, because a
   wrong default silently produces a picture that disagrees with the homology.

### 1.4 The nerve, and the guarantee every filtration must carry

The **nerve** of a cover is the simplicial complex with a k-simplex for every
k+1 sets with a common point. The **Nerve theorem** says it is homotopy
equivalent to X_t when the sets are convex (balls, ellipsoids and boxes all
are). So for a nerve, the complex on screen and the union of shapes on screen
are *the same space* up to homotopy, and the library should make that identity
visible: a simplex appears exactly when its shapes start overlapping.

A **flag complex** is the flag complex of the pairwise-intersection graph. It
is cheaper, it is what several of the source papers actually build, and it is
*not* a nerve: three shapes can meet pairwise long before they share a point,
so a flag triangle is not a claim that three shapes overlap.

Which one a construction is, is not a matter of presentation. It is a fact
about the construction, and this library carries it as **data on every
filtration** — a `guarantee` with a machine-readable `kind` and the exact chip
text. The wording is fixed by tda-wasm's own SPEC FR-6 and reproduced
verbatim; a test asserts every string character for character and fails if a
flag complex is ever labelled a nerve:

| Complex | kind | label (verbatim) |
|---|---|---|
| Rips | `flag` | `flag complex (Rips-type)` |
| Ellipsoid-Rips | `flag` | `flag complex (Rips-type)` |
| Wing | `flag` | `flag complex (Rips-type)` |
| Čech | `nerve` | `true nerve (Cech)` |
| Ellipsoid-Čech | `nerve` | `true nerve (ellipsoidal Cech)` |
| k-fold cover | `nerve` | `exact (order-k Delaunay nerve)` |
| Box | `nerve` | `nerve (= flag, by Helly for boxes); step-quantized` |
| Alpha / weighted alpha | `nerve` | `alpha complex (exact combinatorics)` |

The reasons, because a label with no argument behind it is decoration:

- **Čech** is the nerve of the ball cover by definition; **alpha** is the nerve
  of the cover by ball ∩ power cell — convex pieces, so a good cover — which is
  why it has far fewer simplices for the same homology.
- **Ellipsoid-Čech** is a nerve because at every radius the sets are
  ellipsoids, hence convex, so every subfamily intersection is empty or
  contractible; that is a good cover and the nerve lemma applies
  (Giunti–Hill–Ye). Its flag sibling shares the same ellipsoids and the same
  scale, and is still not a nerve — the two must never be presented as the same
  object.
- **Box** is a nerve because axis-aligned boxes are Helly axiswise: a family
  that meets pairwise already shares a point (Alvarado–Gupta–Krishnamoorthy
  Lemma 2.24). Downgrading it to a Rips-type tag is as much a violation as
  inflating the other two, and the `step-quantized` half of the tag is not
  optional (§1.3).
- **k-fold cover** is exact because the Almost Nerve lemma
  (Edelsbrunner–Osang) makes the persistence of the order-k mosaic *equal*
  multicover persistence. What is exact is the homotopy type; the values are
  still doubles.
- **Rips**, **ellipsoid-Rips** and **wing** are flag complexes built from
  pairwise intersections, which is what their source papers build and say they
  build (Canova–Kališnik–Moser–Rieck–Žegarac Def. 2.2; Weng–Zhao Eq. 3.5).

### 1.5 What ε does and does not do

Persistence is a function of the cloud, the weights, the complex type and the
dimension cap. It is **not** a function of t. The engine is called once per
BUILD — per (cloud, weights, params) — and moving t only filters what is drawn.
This is a hard rule because the alternative — recomputing on every scrub —
makes the instrument unusable and obscures the fact that the barcode already
contains every t.

"Once per build" is not "one function call": a build has always been complex +
persistence, and the shape-bearing paths add a third, geometry-only call —
`computeEllipsoidGeometry` for the ellipsoids, `computeWingGeometry` for the
wings — so the drawn shapes come from the same fitting, and the same normal
resolution, as the simplices. The rule that matters is that **none of them ever
runs again because t moved**.

### 1.6 Honesty (carried from v1, still binding)

- Never synthesize a simplex or a persistence pair. Empty / computing / error
  are real states.
- Nerve-filter: drop H_k for k ≥ d. Points in ℝᵈ carry no homology above
  degree d−1; anything above is a Rips truncation artifact.
- A complex capped at dimension c cannot resolve H_c. Never display truncated
  top-dimension as topology.
- Label experimental engine paths. Never upgrade a status for marketing.
- Carry the guarantee (§1.4) as data, not as prose in a component. A renderer
  that has to compose its own honesty chip will eventually compose the wrong
  one.
- Never invent geometry the engine did not return, and never re-derive geometry
  it does. ONE case is reported rather than filled in today: a box filtration
  built without retaining its boxes. It says `shapesAvailable: false` with a
  reason, and asking it for a shape throws instead of returning a default.
  The wing was the other case until the engine gained `computeWingGeometry`
  (2026-09-02), which returns the normal the builder used — including one it
  estimated internally from k — and the unit outline its birth solver
  intersects. Every wing filtration is now drawable, EXACTLY: the polygon is
  `point + t · outline[v]`, and this library does not rebuild the hexagon from
  (q, θ, α). Provenance travels with each wing as `normalSource`
  (`supplied` | `osculating` | `tangent`) instead of as a refusal, because an
  estimated normal is a weaker normal, not an absent one, and a reviewer has to
  be able to see which one a picture rests on.

---

## 2. Architecture

Three layers, as before, but the middle one is now the point.

```
engine     tda-wasm adapter: one build per (cloud, weights, params)
   ↓
filtration HEADLESS. The central abstraction. See §3.
   ↓
render     2D (SVG / Canvas)   |   3D (PlayCanvas)   |   summaries (barcode, diagram)
```

`engine` and `filtration` import nothing from `playcanvas`, `three` or
`d3`. Enforced by ESLint `no-restricted-imports` and a test that proves the
rule fires. Unchanged from v1; this part was right.

---

## 3. The filtration layer (the contract)

### 3.1 Types

```ts
/** A point cloud with per-point weights. Unweighted = all zeros. */
interface WeightedCloud {
  points: number[];        // flat, length n·dimension
  weights: number[];       // length n; all 0 for unweighted
  dimension: 2 | 3;
}

type BallConvention  = 'rips' | 'cech' | 'alpha';
type ShapeConvention = 'ellipsoid-2r' | 'wing-eps' | 'box-step';
type RadiusConvention = BallConvention | ShapeConvention;   // §1.3

type FiltrationComplexType =
  | 'rips' | 'cech' | 'alpha' | 'kfold'
  | 'ellipsoid-rips' | 'ellipsoid-cech' | 'wing' | 'box';

/** The growing shape at t, ALREADY scaled — the renderer does no scale math. */
type GrowingShape =
  | { kind: 'ball';      center: readonly number[]; radius: number }
  | { kind: 'ellipsoid'; center: readonly number[];
      frame: readonly (readonly number[])[];   // orthonormal, from local PCA
      semiAxes: readonly number[] }            // LENGTHS at t = (t/2)·profile
  | { kind: 'wing';      center: readonly number[]; normal: readonly number[];
      normalSource: 'supplied' | 'osculating' | 'tangent' | 'isolated';
      spineHalfLength: number; wingLength: number; theta: number;
      outline: readonly (readonly number[])[] }  // A, B, C, D, C', B'
  | { kind: 'box';       lower: readonly number[]; upper: readonly number[];
      step: number };                            // ⌊t/π⌋, the engine's own box

/** §1.4, machine-readable. The label is verbatim; tests pin every character. */
interface ComplexGuarantee { kind: 'nerve' | 'flag'; label: string }

/** Non-null exactly when values are grid values (the box filtration, §1.3). */
interface FiltrationQuantization { step: number; steps: number }

/** Common to every filtration. Built once, queried per frame. */
interface FiltrationBase {
  readonly cloud: WeightedCloud;
  readonly convention: RadiusConvention;
  readonly complexType: FiltrationComplexType;
  readonly guarantee: ComplexGuarantee;
  readonly maxSimplexDimension: number;

  readonly simplices: readonly Simplex[];       // sorted ascending
  readonly pairs: readonly PersistencePair[];   // Nerve-filtered (§1.6)
  readonly rawPairs: readonly PersistencePair[];
  readonly tMax: number;
  readonly criticalValues: readonly number[];
  readonly quantization: FiltrationQuantization | null;

  readonly shapeKind: 'ball' | 'ellipsoid' | 'wing' | 'box';
  readonly shapesAvailable: boolean;              // §1.6: box without boxes only
  readonly shapesUnavailableReason: string | null;

  readonly vertexKind: 'point' | 'subset';
  readonly vertexCount: number;
  readonly vertexSubsets: readonly (readonly number[])[] | null;
  readonly vertexPositions: readonly number[];    // flat, vertexCount·dimension
  vertexPosition(v: number): readonly number[];

  simplicesAt(t: number): readonly Simplex[];     // O(log n), memoized
  aliveAt(t: number): readonly PersistencePair[];
  bettiAt(t: number): number[];
}

interface BallFiltration extends FiltrationBase {
  readonly shapeKind: 'ball';
  readonly convention: BallConvention;
  radiusAt(i: number, t: number): number;   // BALLS ONLY (§1.3, point 4)
  shapeAt(i: number, t: number): BallShape;
}
interface EllipsoidFiltration extends FiltrationBase {
  readonly shapeKind: 'ellipsoid';
  readonly convention: 'ellipsoid-2r';
  readonly ellipsoid: { neighborhoodSize: number; axesMode: number | 'pca' };
  shapeAt(i: number, t: number): EllipsoidShape;
  unitShape(i: number): EllipsoidProfile;         // frame + UNIT profile (§3.1a)
}
interface WingFiltration extends FiltrationBase {
  readonly shapeKind: 'wing';
  readonly convention: 'wing-eps';
  readonly shapesAvailable: true;                 // always: see §1.6
  readonly shapesUnavailableReason: null;
  readonly wing: {
    q: number; theta: number;
    normals: readonly number[];                   // the ones the builder USED
    normalSources: readonly WingNormalSource[];   // per point, where from
  };
  shapeAt(i: number, t: number): WingShape;
  unitShape(i: number): WingProfile;              // the engine's unit wing
}
interface BoxFiltration extends FiltrationBase {
  readonly shapeKind: 'box';
  readonly convention: 'box-step';
  readonly quantization: FiltrationQuantization;   // never null here
  readonly box: { alpha: number; maxBirthStep: number };
  shapeAt(i: number, t: number): BoxShape;
  boxesAtStep(step: number): readonly BoxShape[];  // one STEP's row (§3.1a)
}

type Filtration =
  | BallFiltration | EllipsoidFiltration | WingFiltration | BoxFiltration;
```

Four decisions in that record are normative, not stylistic.

**`Filtration` is a discriminated union on `shapeKind`.** A shape renderer
switches on it exhaustively; a ball renderer takes `BallFiltration` and cannot
be handed a wing at all. This is the §1.3 rule enforced by the compiler instead
of by a code review, and it is why `radiusAt` lives on the ball member only.

**Two index spaces, kept apart.** `shapeAt(i, t)` and `radiusAt(i, t)` take an
**input point** index — in every construction the engine offers, the shapes grow
around input points. `simplices[].vertices` and `vertexPosition(v)` take a
**vertex** index. They coincide unless `vertexKind` is `'subset'`, which today
means the k-fold cover: vertex v stands for `vertexSubsets[v]`, a k-subset of
the input, and is drawn at that subset's barycentre (`vertexPositions`, flat and
allocation-free, is the same law the engine's own review page uses). A renderer
that positions vertices from `cloud.points` is wrong for the k-fold cover, and
`vertexCount !== n` is the check that catches it.

**`quantization` is null, never zero.** A step of 0 would read as "no
quantization" and as "infinitely fine grid" at the same time.

**`shapeAt` throws when the geometry does not exist** (§1.6, last bullet),
having said so in advance through `shapesAvailable` / `shapesUnavailableReason`.
A renderer checks once and draws the complex alone; the alternative — returning
some default shape — is the failure mode this whole section exists to prevent.

### 3.1a The unscaled shape, for renderers that scale on the GPU

`shapeAt(i, t)` is the right call for a CPU drawing that rebuilds per frame. A
GPU renderer does the opposite: it uploads per-instance geometry ONCE and applies
t as a uniform in the vertex shader (§1.5), so it needs the geometry BEFORE t
scales it. The record therefore exposes it directly:

| Member | Accessor | Returns |
|---|---|---|
| ellipsoid | `unitShape(i)` | centre, the fixed frame, the engine's UNIT semi-axis profile — `shapeAt(i, t).semiAxes` is `(t/2)·` this |
| wing | `unitShape(i)` | centre, normal, `normalSource`, curvature diagnostics, and the engine's six unit outline offsets — `shapeAt(i, t).outline[v]` is `centre + max(t, 0)·` this |
| box | `boxesAtStep(step)` | one whole STEP of grown boxes, in input-point order: a row of the engine's `(steps + 1) × n` records |
| ball | — | its t-invariant data is the centre and the weight, which `cloud` already carries and `radiusAt` already interprets |

Why this is contract and not convenience. `<Field3D>` used to recover the
ellipsoid profile as `shapeAt(i, 2).semiAxes`, which is EXACT under
`ellipsoid-2r` — at t = 2 the factor t/2 is 1 — but it put the scale law in the
renderer, and §1.3 exists to keep it out of there. The equivalence is still
pinned by a test, precisely so the accessor cannot drift from the law it is the
unscaled end of. Boxes had a worse version of the same problem: getting every
step meant `shapeAt(i, s·π)` in a double loop, i.e. each call site reproducing
the grid arithmetic of `⌊t/π⌋`. `boxesAtStep` takes a step INDEX and refuses a t
value by name.

### 3.2 Construction

```ts
buildFiltration(engine, cloud, params): Promise<Filtration>
```

Overloaded so the params pick the member: ball params give a `BallFiltration`,
ellipsoid params an `EllipsoidFiltration`, and so on. One BUILD per (cloud,
weights, params) (§1.5); `shapeAt`, `radiusAt` and `simplicesAt` are pure
functions of the result and t, cheap enough to call every animation frame.

| `complexType` | Required params | Binding | Notes |
|---|---|---|---|
| `alpha` | — | `computeWeightedAlphaComplex3D` | the only weighted path; cap is the triangulation's own dimension |
| `rips` | `maxEdgeLength` | `computeRipsComplex` | unweighted only |
| `cech` | `maxEdgeLength` (= max ball radius) | `computeCechComplex` | unweighted only |
| `kfold` | `k`; optional `maxSquaredRadius` | `computeKFoldCoverComplex` | 3D + unweighted + distinct points only |
| `ellipsoid-rips` | `neighborhoodSize`, `axesMode`, `maxFiltration` | `computeEllipsoidRipsComplex` + `computeEllipsoidGeometry` | 2D/3D, unweighted |
| `ellipsoid-cech` | same | `computeEllipsoidCechComplex` + `computeEllipsoidGeometry` | same |
| `wing` | `q`, `theta`, and EXACTLY one of `normals` / `neighborhoodSize` | `computeWingComplex` + `computeWingGeometry` | 2D + unweighted only; both normal modes drawable |
| `box` | `stepSize` (π), `alpha`; `retainBoxes` defaults **true** | `computeBoxFiltration` | 2D/3D, unweighted; duplicates fine |
| `witness` | — | — | refused: no weighted witness filtration exists (§8 Q3) |

Rules the adapter enforces, all of them mirroring the engine so a caller reads
a sentence instead of a WASM abort:

- **Weights.** Weighted clouds route to `computeWeightedAlphaComplex3D`; 2D
  weighted clouds embed at z = 0 in the engine adapter (this is where that
  embedding belongs, and nowhere else). Every other builder ignores weights at
  the binding, so handing one a weighted cloud **throws**. Silently dropping
  the weights would produce a picture of a different filtration.
- **Dimension.** `kfold` is 3D-only (its level-by-level construction rests on
  Edelsbrunner–Osang Theorem 5); `wing` is 2D-only (Weng–Zhao §6: 3D is open
  research). Both refuse the other dimension by name.
- **Degeneracy.** `kfold` rejects coincident input, naming both indices, because
  a repeated point breaks the order-k mosaic — the engine rejects it too, rather
  than returning a mosaic with vertices missing.
- **Cutoffs.** Non-positive `maxSquaredRadius`, `maxEps`, `stepSize`,
  `maxFiltration` and `maxSteps` are refused. `maxFiltration` is **required**
  for both ellipsoid paths, and that is stricter than the engine: every pair of
  ellipsoids eventually touches, so an uncut build asks for the complete
  complex. A default cutoff would be an invented parameter (the same reason
  `maxEdgeLength` has no default).
- **Ranges.** `q ∈ [0, 1]`, `θ ∈ (0, π/2]`, `alpha ∈ [0, 1]`, `axesMode ≥ 1` or
  `'pca'`, `neighborhoodSize` an integer ≥ 2, `k` a positive integer with
  `n ≥ k + 3`.
- **Wing normals.** Exactly one of `normals` (flat 2n, roughly unit — the engine
  requires |α|² ∈ (0.25, 4) and then normalizes) or `neighborhoodSize`. BOTH
  modes are drawable: the adapter makes a second, geometry-only call to
  `computeWingGeometry` with the same `(points, q, theta, normalsOrK)`, so the
  drawn wing is the wing whose births the complex recorded, and the record hands
  back the normals the builder actually used. The two modes differ in
  `normalSource`, not in drawability (§1.6).

### 3.3 The scale controller

```ts
useScale(filtration): { t, setT, play, pause, playing, snapToNext, snapToPrev }
```

The single source of truth for t. `snapToNext`/`snapToPrev` jump between
`criticalValues`, because the interesting moments of a filtration are the
moments something changes, and a continuous slider skips over them.

For a box filtration the `criticalValues` are grid values (§1.3), so snapping
lands on multiples of π by construction — which is the honest behaviour, and
another reason `quantization` is on the record rather than in a comment.

An application that sweeps t holds exactly ONE animation loop, through
`startAnimationLoop` / `stopAnimationLoop` (`src/state/animationLoop.ts`,
promoted from the site 2026-09-03): a single module-level
`requestAnimationFrame` slot that starting another loop cancels, so two live
loops are unrepresentable. `activeLoopCount()` is 0 or 1 by construction and is
what a test asserts. `useScale`'s own `play` predates the registry and still
holds its own frame; a consumer that needs the invariant across surfaces drives
t from the registry instead.

### 3.4 What the complex menu changed in the record

Additive, except for three deliberate breaks. They are breaks in the TYPES; no
ball filtration behaves differently at runtime.

1. **`Filtration` is a union.** Code that takes a `Filtration` and calls
   `radiusAt` must narrow on `shapeKind === 'ball'` (or take a
   `BallFiltration`). This is the point of the change: the alternative is a
   `radiusAt` that throws for wings at frame time, or worse, returns a number.
2. **`complexType` lost `'witness'` and gained the menu.** Witness filtrations
   were never constructible — `buildFiltration` has always thrown for them —
   so the old union described a state that could not exist. `'witness'` remains
   a valid *params* value precisely so that the refusal keeps its clear error.
3. **`createFiltration` takes the convention explicitly** and per-shape
   geometry (`ellipsoid` / `wing` / `box`, plus optional `vertexSubsets`),
   instead of deriving the convention from the complex type. The k-fold cover is
   why: its complex type is `kfold` and its convention is `alpha`.
4. **The wing record carries GEOMETRY, not normals** (2026-09-02).
   `createFiltration` takes `wing.geometry` — `computeWingGeometry` output, one
   record per point, required — where it used to take `wing.normals` and allow
   null. `WingFiltration.wing.normals` survives as the flat array of normals the
   builder actually used, and is no longer nullable, joined by
   `normalSources`. A wing filtration's `shapesAvailable` is now `true` in the
   type, so code that branched on it for wings is dead code rather than wrong
   code.

`<ScaleControl>` therefore declares `filtration: BallFiltration`. That is not a
temporary narrowing to make the compiler quiet: it reads out the drawn RADIUS
that t implies, and a radius is not defined for an ellipsoid, a wing or a box.

`<Field2D>` takes the whole union and switches on `shapeKind` exhaustively —
that is what the union is for, and `shapeAt` is what makes it possible without
a scale law per shape in the renderer. `<Field3D>` takes
`BallFiltration | EllipsoidFiltration | BoxFiltration`: the wing complex is 2D
only, in the engine and in the mathematics (`WASM_HONESTY.md`: "3D is open
research and is not attempted"), so a 3D wing surface would be drawing a shape
nobody has defined.

---

## 4. Render

Components take a `Filtration` and a `t`. They never take raw pairs or raw
simplices; the filtration object is the interface.

Two obligations the menu adds to this layer, both of which are the next task's
work and are recorded here because they are contract, not taste:

- A surface that draws shapes switches on `shapeKind` exhaustively and uses
  `shapeAt` — or `unitShape` / `boxesAtStep` if it scales on the GPU (§3.1a); it
  never re-derives a scale law (§1.1). When `shapesAvailable` is false it draws
  the complex and shows `shapesUnavailableReason`.
- A surface that draws vertices uses `vertexPositions` / `vertexPosition`, not
  `cloud.points`. `<Nerve2D>` and `<Nerve3D>` do (2026-09-01), so the k-fold
  mosaic is drawable: vertex v sits at the barycentre of `vertexSubsets[v]`, and
  both surfaces mark those vertices with a glyph of their own and state on the
  drawing that they are subsets, not points (§8 Q5). Read-only all the way down:
  `pointsToPositions` takes `readonly number[]`, so packing `vertexPositions`
  for the GPU copies nothing.

### 4.0 The honest label is a component, not prose

`<GuaranteeChip filtration>` renders `filtration.guarantee.label` **verbatim**
and nothing composed: the wording is the library's (§1.4), and a renderer that
assembles its own chip will eventually assemble the wrong one. It renders, from
the same record and only when the record says so, the two facts that travel
with particular constructions:

- the **quantization** warning for a box filtration — `step π = …, m steps` plus
  `bar endpoints are grid values; diagrams at different π are not comparable`
  (§1.3 point 3);
- the **subset-vertex** sentence for the k-fold cover — vertices are k-subsets
  of the input drawn at their barycentres, with the two counts, because
  `vertexCount ≠ n` is the fact a reader has to be told (§3.1).

Every story that draws a complex shows it. Plain HTML, main entry: it sits
beside a 2D SVG stage or over a PlayCanvas canvas equally well.

`<ConstructionIndex entries selectedId onSelect panelId>` is the honest way to
OFFER constructions (2026-09-03, promoted from the site's Atlas): a two-band
index whose bands are the guarantee kinds, headed and explained in the library's
own words (`BAND_HEADING`, `BAND_RULE`, `BAND_ORDER` in
`src/filtration/guarantees.ts`). Selecting a construction is therefore always an
act of reading its classification. An entry may be `disabled` — listed in its
class, not selectable, and given no reason by the index, because the omission is
the engine's rule and `buildFiltration`'s own message is what a consumer surfaces
— and the index may be `locked` for a lesson that teaches one construction.

### 4.1 The stage — the primary surface

`<PointCloud2D>` is the controlled input surface that precedes a filtration. Callers may also provide one disk radius per point in data units; the component projects those radii with the same aspect-preserving scale and does not invent a filtration convention. A separate final-radius array may reserve a stable viewport, preventing growth animations from rescaling or clipping the cover.
When `editable` and `onPointsChange` are provided, the caller selects an explicit
`move` or `edit` interaction mode. Move maps pointer drags back through the fixed
projection captured at drag start; edit uses one click or Enter to open the
built-in accessible `(x, y)` coordinate dialog. A caller may replace that dialog
through `promptForPoint`. Optional labelled coordinate axes and calibrated ticks
are controlled by `showAxes`; they use the same projection as the points. The
component owns no point data and never recomputes topology. Optional `edges` are
caller-supplied 1-skeleton records drawn beneath the points; the component filters
or synthesizes none of them.

| Component | Entry | Draws at scale t |
|---|---|---|
| `<Field2D>` | main | ⋃ᵢ S_i(t) as a single merged region — the space X_t itself, not n overlapping shapes. Whatever `shapeAt` returns: discs, ellipses, wing hexagons, boxes. Must render union, so overlaps read as one region. |
| `<Nerve2D>` | main | Simplices of the complex at t, over the field, at `vertexPosition(v)`. A nerve simplex draws exactly when its shapes overlap. |
| `<Field3D>` | /3d | Same union, as instanced spheres / oriented ellipsoids / boxes, labelled an approximation (§8 Q2). |
| `<Nerve3D>` | /3d | Simplices at t. Tetrahedra never filled (would hide H₂). |

`<Field2D>` rendering union rather than overlapping shapes is not cosmetic:
overlapping translucent shapes visually double-count the intersection, which
is exactly the region the complex cares about. Canvas with a union fill, or SVG
with an `evenodd`-free merged path, is required; **the shipped surface is the
SVG merged path** (§8 Q1), one `<path>` element for the whole union with
`fill-rule: nonzero`. Every subpath must wind the same way — under nonzero
winding, two overlapping subpaths of opposite handedness cancel and punch a
hole where the shapes agree.

### 4.2 Weights on screen

Weight is visible per point: radius differs per point at every t. A story
must demonstrate a cloud where one heavy point's ball already dominates at
t = 0 and reaches its neighbours well before the light points reach each
other, so the nerve edges to the heavy point appear first.

### 4.3 Summaries

`<Barcode>`, `<PersistenceDiagram>`, `<BettiCurve>`, `<PersistenceImage>`
survive from v1 but now take `(filtration, t)` and draw the playhead from t.
They are secondary surfaces and the docs must frame them as such.

### 4.4 Scale control

`<ScaleControl>` (renamed from `EpsilonPlayhead`, because ε implies a
specific convention and the control must be honest about which one it is).
Shows `t`, the convention, the drawn radius it implies, and snap-to-event
buttons. Controlled; owns nothing.

---

## 5. Engine surface

From `tda-wasm` as of 2026-09-01 (branch `feat/complex-menu`). The adapter
exposes only what exists.

| Complex | Binding | Weights | Dimension | Shape / vertices |
|---|---|---|---|---|
| Weighted alpha | `computeWeightedAlphaComplex3D` | **yes** (x,y,z,w) | 3D at binding; 2D embeds at z=0 | ball / points |
| Rips | `computeRipsComplex` | no → adapter throws | any | ball / points |
| Čech | `computeCechComplex` | no → adapter throws | any | ball / points |
| k-fold cover | `computeKFoldCoverComplex` | no → adapter throws | **3D only**, distinct points | ball at √t / **k-subsets** (`mosaicVertices`) |
| Ellipsoid-Rips | `computeEllipsoidRipsComplex` | no → adapter throws | 2D/3D | ellipsoid / points |
| Ellipsoid-Čech | `computeEllipsoidCechComplex` | no → adapter throws | 2D/3D | ellipsoid / points |
| Ellipsoid geometry | `computeEllipsoidGeometry` | — | 2D/3D | the fitted frames + semi-axis profiles, for drawing |
| Wing | `computeWingComplex` | no → adapter throws | **2D only** | concave hexagon / points |
| Wing geometry | `computeWingGeometry` | — | **2D only** | the normal the builder used + its provenance + the unit outline, for drawing |
| Box | `computeBoxFiltration` | no → adapter throws | 2D/3D | axis-aligned box, on a π grid / points |
| Witness (weak) | `computeEuclideanWitnessComplex` | no | any; vertex ids index the landmark subset | not wired (§8 Q3) |

Weighted alpha is the only weighted path and is therefore the **primary**
complex for this library, not an afterthought. Rips is the cheap fallback.
Everything else on the menu is unweighted at the binding, which is a property
of the mathematics as much as of the bindings: multicover persistence is proved
for unweighted points (Edelsbrunner–Osang Theorem 5 does not carry to weights),
and the ellipsoid, wing and box constructions are defined without weights.

Two things about this surface made the adapter awkward, and both are recorded
because they are the engine's design, not this library's:

1. ~~**Wing normals are not exposed.** `computeWingComplex(…, k)` estimates
   osculating-circle normals internally and returns only the complex, so a wing
   built that way cannot be drawn without re-estimating — and a re-estimate is a
   *different* wing than the one whose births are on screen. The library reports
   the shape as unavailable (§1.6) rather than drawing an approximation.~~
   **Fixed upstream (2026-09-02): `computeWingGeometry`.** It returns, per point,
   the unit normal the builder used, where that normal came from
   (`normalSource`), the curvature diagnostics behind the |κ| clamp, and the six
   unit-scale outline offsets of the same `unit_wing()` the birth solver
   intersects. So the k mode is drawable, the drawing is EXACT rather than a
   re-derivation, and the special case is gone: this library scales the returned
   offsets and never rebuilds the hexagon from (q, θ, α). What replaces the
   refusal is provenance on every wing (§1.6).
2. **Box shapes are opt-in.** `includeBoxes` returns `(steps + 1) × n` box
   records or nothing at all; there is no binding for a single step. This library
   defaults it ON, because the growing shape is the subject, accepts the memory,
   and exposes the engine's rows as they are through `boxesAtStep` (§3.1a) so a
   renderer neither re-slices them nor redoes the grid arithmetic.

---

## 6. What gets rebuilt

| v1 | v2 |
|---|---|
| `GrowingBalls2D` (one radius, translucent discs) | `<Field2D>` (per-point radius, union region) |
| `ComplexOverlay2D` (takes raw simplices) | `<Nerve2D>` (takes Filtration) |
| `ComplexMesh3D` | `<Nerve3D>` (takes Filtration) |
| `PointCloud2D/3D` (unweighted) | keep, add weight glyph; 2D also supports controlled drag and exact-coordinate editing |
| `EpsilonPlayhead` | `<ScaleControl>` with convention + snapping |
| `usePipeline` | `buildFiltration` + `useScale` |
| Barcode/Diagram/Betti/Image | keep, re-key on `(filtration, t)` |
| `CycleHighlight3D` | keep; unchanged contract |
| homepage hero | must show the union growing and the nerve forming, with weights |

---

## 7. Stories that must exist

Beyond per-component coverage, these end-to-end stories are the acceptance
test for v2:

1. **Unweighted circle, alpha.** Move t; watch the annulus thicken and the
   nerve form a ring, then fill. Barcode playhead tracks t.
2. **Weighted cloud.** Three points, one heavy (w = 0.5, others w = 0). At
   t = 0 the heavy ball has radius √0.5 while the light ones are points. The
   nerve edges to the heavy point appear before the light–light edge. Negative
   weights are rejected by the adapter with a clear error (engine constraint,
   §1.2) — a story asserts that rejection rather than pretending to draw it.
3. **Rips vs Čech on the same cloud.** Same t, same points, different
   complexes; the Rips triangle that is not a nerve triangle is highlighted
   and labelled.
4. **Snapping.** Step through critical values and see exactly one change per
   step.
5. **Honesty.** 2D circle at cap 2: the 18,424 spurious H₂ pairs are gone from
   the filtration's `pairs` and present in `rawPairs`.

The complex menu adds four more. They shipped with the shape renderers
(2026-09-01) in `src/stories/ComplexMenu.stories.tsx`, on recorded engine
output, and every number they state about the fixtures is COMPUTED in the story
rather than written into its prose:

6. **Ellipsoid-Rips vs ellipsoid-Čech, same cloud, same ellipsoids.** Identical
   shapes on screen and identical 1-skeletons — 40 shared edges, maximum birth
   difference 0 — but no shared simplex is born earlier in the nerve and 8 are
   born strictly later, so the H₁ picture is not the same picture even where the
   simplices are. The chips read `flag complex (Rips-type)` and
   `true nerve (ellipsoidal Cech)`, and the story says which of the two the
   union of ellipsoids beside it is actually equivalent to (the nerve).
7. **Wing, exact normals vs estimated.** Both builds draw their hexagons, and
   both draw the ENGINE's: each polygon is `point + ε · outline[v]` from
   `computeWingGeometry`, so the k-mode build — which used to draw nothing — is
   drawable without any re-estimation. On a circle the two complexes are
   *identical* (84 simplices, zero birth difference) and the two drawings agree
   to ~1e-8, both computed in the story rather than quoted. What the panels
   contrast is PROVENANCE: `supplied` on the left, `osculating` on the right, and
   the story states that the agreement is the fit's accuracy on this cloud rather
   than a guarantee — at an inflection the estimate flips sides, and
   `normalSource` is what tells a reader which case they are looking at.
8. **Box, two step sizes.** The same 6-point ring at π = 0.25 and π = 0.125:
   every filtration value is on its own grid (0 off-grid values in either), the
   drawn box is the last completed step, and the story states outright that the
   two diagrams are not comparable.
9. **k-fold cover, k = 1 vs k = 2.** At k = 1 the mosaic has 8 singleton
   vertices over 8 points and the filtration reproduces alpha (the engine's own
   claim, checked against the live engine in
   `buildFiltrationMenu.integration.test.ts`). At k = 2 there are 22 vertices
   over the same 8 points, each drawn at its pair's barycentre, while the balls
   still grow around the input points at √t.

---

## 8. Open questions

1. ~~`<Field2D>` union rendering: Canvas (fast, raster) vs SVG merged path
   (crisp, slow above ~500 points). Start Canvas; SVG if someone needs print.~~
   **Decided (2026-09-01): the SVG merged path.** The objection to SVG was node
   count, and a merged union path has none — it is ONE `<path>` element whatever
   n is, and the per-t work is building its `d` string, which is the same
   O(n) traversal the canvas path was. What tipped it is the shape menu: a
   rotated ellipse is one `A` command and a concave hexagon is one polygon, so
   the declarative form states each shape once, where the canvas form is a
   branch of imperative calls whose union property is invisible in the source.
   The remaining cost is string allocation per frame; above a few thousand
   shapes a canvas fallback is still the right answer, and nothing in the
   contract prevents adding one — `shapeSubpath` is the only shape-specific
   code and it is already separate from the component.
2. 3D union: marching cubes over the SDF is correct but heavy; an
   instanced-sphere approximation is cheap but double-counts overlaps. Start
   with instanced spheres and `depthWrite` tricks, label it approximate.
3. Witness complex in a weighted setting is not defined by the engine. Out of
   scope until it is.
4. ~~Union rendering for non-ball shapes. `<Field2D>`'s union argument (§4.1)
   applies unchanged to ellipsoids, wings and boxes — overlaps double-count the
   region the complex is about — but a merged path over rotated ellipses and
   concave hexagons is harder than over discs. Decide per shape in the renderer
   task; boxes are the easy case, wings the awkward one.~~
   **Resolved (2026-09-01): one merged path for all four kinds**, no per-shape
   decision needed. The wing turned out not to be the awkward case: nonzero
   winding fills a simple concave polygon correctly, and the hexagon's
   handedness cannot flip between points, because its signed area is a
   continuous, nowhere-zero function of the unit normal α (the renderer
   normalizes handedness anyway rather than resting the union on that argument).
   One 2D refusal remains, and it is honesty, not difficulty: a **3D** ellipsoid
   seen from above is refused because dropping z draws the ellipse of `frame[0]`,
   `frame[1]`, which is a central slice and not the ellipsoid's outline. Balls
   and axis-aligned boxes project to their exact silhouettes, so those are drawn.
   The second refusal — a wing whose normals the engine estimated internally —
   is gone as of 2026-09-02: `computeWingGeometry` hands back those normals and
   the outline built from them, so the wing is drawn exactly (§1.6, §5).
5. ~~Should a k-fold cover surface draw the balls at all? The mosaic vertices are
   subsets, so a ball and a vertex are different objects on the same canvas.
   Drawing both is the honest picture of the construction, but it needs a visual
   grammar that does not read as one thing.~~
   **Decided (2026-09-01): draw both, in two grammars.** The balls are the cover
   and the mosaic vertices are the complex; hiding either would hide half the
   construction. A ball is a filled region at an input point; a subset vertex is
   a hollow diamond in 2D and an opaque cube marker in 3D, at a barycentre where
   no input point sits. Both surfaces also SAY it — 2D on the drawing, 3D in the
   entity's `userData` and in the chip beside the canvas — with the vertex count
   against the point count, because `vertexCount ≠ n` is the fact that makes the
   picture legible. What was rejected: spokes from each subset vertex to its
   member points. They carry the membership, but on a canvas whose other line
   segments are 1-simplices they would read as simplices, which is a worse lie
   than leaving membership to a hover title (`data-subset`, `<title>`).
6. Multi-parameter box filtrations. The engine's source paper is
   multiparameter; the shipped binding is a one-parameter slice at fixed
   `alpha`. Out of scope until the engine offers more.

---

## 9. Distribution

Unchanged: private repo, a `file:` dependency on the engine checkout,
unpublished until the founder's go-public gate lifts. The dependency currently
resolves to `file:../wt-menu` — the engine's `feat/complex-menu` worktree is
the only checkout that carries the menu builders — and goes back to
`file:../tda-wasm` when that branch merges. The test setup externalizes the
package by its RESOLVED root, not by name, because a `file:` dependency is a
symlink (README, "Consuming tda-wasm"). License: MIT. History: this package was
GPL-3.0-or-later while the engine (`tda-wasm`) linked CGAL; the engine
relicensed to MIT on 2026-08-27 when CGAL was removed (tda-wasm 0.2.0), and
the founder's umbrella decision is MIT.
