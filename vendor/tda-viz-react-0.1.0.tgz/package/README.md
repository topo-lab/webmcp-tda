# tda-viz-react

React components for visualizing a **filtration** of a point cloud — the
one-parameter family of spaces X_t you get by growing a shape around every
point — and the simplicial complex that family induces. Eight constructions
ship: the shape is a ball (with **per-point radii under weights**), an
anisotropic ellipsoid, a curvature-adaptive wing, or an axis-aligned box, and
the complex is either a true **nerve** or a **flag** complex — a distinction
this library carries as data on every filtration rather than as prose in a
component.

A ninth path takes no cloud at all: the **cubical** filtration of a grid of
values by a threshold, in the engine's two conventions — values on pixels, or
values on grid vertices — which are different filtrations of the same numbers
and say so. Built on [`tda-wasm`](https://github.com/topo-lab/tda-wasm).

**Read [SPEC.md](./SPEC.md) first.** This package is spec-driven (SDD) and
test-driven (TDD): the spec is the contract (v2 — the filtration is the
object; barcodes and diagrams are summaries), and every module here landed
tests-first. Do not implement features the spec does not describe.

**Status:** v2. Not published to any registry while `tda-wasm` is
unpublished (`private: true`).

**License:** MIT. (Was GPL-3.0-or-later — inherited, not chosen — while
`tda-wasm` linked CGAL; the engine relicensed to MIT on 2026-08-27 when CGAL
was removed. SPEC.md §9.)

## Architecture (SPEC.md §2)

Three layers; the middle one is the point:

```
engine      (headless)  tda-wasm adapter: ONE build per (cloud, weights, params)  src/engine/
   ↓                    (+ wasm init / worker plumbing in src/compute/)
filtration  (headless)  THE CENTRAL ABSTRACTION: shapeAt, radiusAt,               src/filtration/
                        simplicesAt, aliveAt, bettiAt, criticalValues,
                        guarantee, quantization — queried per frame
   ↓
render      (React)     2D stage (canvas/SVG) | 3D stage (PlayCanvas) | summaries        src/render2d/ src/render3d/ src/persistence/
```

`src/engine/`, `src/filtration/`, `src/compute/` and `src/state/` must never
import `playcanvas`, `three`, or `d3`. This is enforced by an ESLint
`no-restricted-imports` rule (`eslint.config.js`), and the rule itself is
regression-tested in `src/__tests__/lintBoundary.test.ts`.

## The core loop (SPEC.md §3)

```tsx
import {
  TdaProvider, useTdaEngine, buildFiltration, useScale,
  Field2D, Nerve2D, ScaleControl, Barcode, type Filtration,
} from 'tda-viz-react';

// ONE engine call per (cloud, weights, params). Weighted clouds route to the
// weighted alpha complex: the ball around p_i has squared radius t + w_i, so
// radii are PER POINT. Negative weights are rejected up front with a clear
// error (the engine's own failure is opaque); weighted rips/cech THROW
// instead of silently drawing a different filtration.
const filtration = await buildFiltration(
  engine,
  { points, weights, dimension: 2 }, // unweighted = all-zero weights
  { complexType: 'alpha' },
);

function Instrument({ filtration }: { filtration: Filtration }) {
  // The single source of truth for t; snapToNext/snapToPrev jump between
  // criticalValues, the only moments the complex changes.
  const { t, setT } = useScale(filtration);
  return (
    <>
      <Field2D filtration={filtration} t={t} />  {/* X_t: ONE merged region  */}
      <Nerve2D filtration={filtration} t={t} />  {/* the complex it induces  */}
      <ScaleControl filtration={filtration} t={t} onChange={setT} />
      <Barcode filtration={filtration} t={t} />  {/* a summary, playhead at t */}
    </>
  );
}
```

Moving t filters what is drawn. It never recomputes: persistence is a
function of the cloud, the weights, and the parameters — not of t
(SPEC.md §1.5).

### The `Filtration` union (SPEC.md §3.1)

`Filtration` is a **discriminated union** over `shapeKind`, not one interface
with optional fields:

```ts
type Filtration = BallFiltration | EllipsoidFiltration | WingFiltration | BoxFiltration;
```

Common to all four: `simplices`, `pairs` (Nerve-filtered), `rawPairs`, `tMax`,
`criticalValues`, `convention`, `guarantee`, `quantization`, `vertexKind`,
`simplicesAt(t)`, `aliveAt(t)`, `bettiAt(t)`, and `shapeAt(i, t)`, which returns
the growing shape **already scaled** to t so no renderer holds the scale law.

What the union buys, per member: `radiusAt` exists on `BallFiltration` **only**,
so handing a disc renderer an ellipsoid filtration is a type error rather than a
runtime surprise; `EllipsoidFiltration` and `WingFiltration` add `unitShape(i)`;
`BoxFiltration` adds `boxesAtStep(step)` and a non-null `quantization`. Every
member carries `tMax`, `criticalValues` and `convention` regardless, which is
why `<ScaleControl>` (below) takes the whole union rather than narrowing to
`BallFiltration`: only its radius readout needs to switch on `shapeKind`.

### The complex menu (SPEC.md §5)

Not every construction grows a ball. `shapeAt(i, t)` returns the growing shape
already scaled to t, and `shapeKind` discriminates the `Filtration` union so a
ball renderer cannot be handed a wing:

| `complexType` | Shape at t | Vertices | Guarantee (verbatim chip) |
|---|---|---|---|
| `alpha` | ball, √(t + wᵢ) | points | `alpha complex (exact combinatorics)` |
| `rips` | ball, t/2 | points | `flag complex (Rips-type)` |
| `cech` | ball, t | points | `true nerve (Cech)` |
| `kfold` | ball, √t, around the INPUT points | **k-subsets** | `exact (order-k Delaunay nerve)` |
| `ellipsoid-rips` | ellipsoid, semi-axes (t/2)·profile | points | `flag complex (Rips-type)` |
| `ellipsoid-cech` | ellipsoid, same fitting and scale | points | `true nerve (ellipsoidal Cech)` |
| `wing` | concave hexagon, spine q·t, edges t at ±θ (the engine's unit outline, scaled) | points | `flag complex (Rips-type)` |
| `box` | axis-aligned box at step ⌊t/π⌋ | points | `nerve (= flag, by Helly for boxes); step-quantized` |

And one construction that is not in that menu at all, because it is not built
from a cloud (SPEC.md §3.1b):

| `complexType` | Input | t means | Guarantee (verbatim chip) |
|---|---|---|---|
| `cubical` (`cubical-t`) | a grid of values on PIXELS | a threshold: the set {f ≤ t} (or {f ≥ t}) | `top-dimensional-cell filtration (T-filtration)` |
| `cubical` (`cubical-v`) | the same grid, values on VERTICES | the same threshold, on the lower star | `vertex lower-star filtration (V-filtration)` |

The two are different filtrations of the same numbers and give different
diagrams — under T two low pixels touching corner to corner share a vertex and
are connected from the start; under V two low vertices touching corner to corner
have no edge between them. Neither is defaulted to. `buildFiltration` takes the
grid in its params and **no cloud**:

```ts
const image = await buildFiltration(engine, {
  complexType: 'cubical',
  values,            // row-major, width · height finite numbers
  width,
  height,
  construction: 'cubical-t',   // or 'cubical-v'
  direction: 'sublevel',       // or 'superlevel'
});
image.bettiAt(t);              // [β₀, β₁]
image.containsValue(v, t);     // is a cell carrying value v inside at t?
```

The `guarantee` (`{ kind: 'nerve' | 'flag'; label }`) is data on the
filtration, not prose in a component: a flag complex is never labelled a
nerve, and a test fails the build if one ever is (SPEC.md §1.4).
`<GuaranteeChip filtration={...} />` prints `guarantee.label` verbatim and
composes nothing — a renderer that has to assemble its own honesty chip will
eventually assemble the wrong one. `COMPLEX_GUARANTEES` exports the whole table
for anything that needs it outside a render (the homepage's Atlas imports it at
build time rather than retyping eight strings).

### Geometry before t scales it (SPEC.md §3.1a)

`shapeAt(i, t)` suits a CPU drawing that rebuilds per frame. A GPU renderer
uploads per-instance geometry once and applies t as a shader uniform, so it asks
for the unscaled record instead:

```ts
ellipsoid.unitShape(i);   // centre, the FIXED frame, the engine's unit semi-axis
                          // profile: shapeAt(i, t).semiAxes === (t/2) * this
wing.unitShape(i);        // centre, normal, normalSource, curvature diagnostics,
                          // and six unit outline offsets A, B, C, D, C', B':
                          // shapeAt(i, t).outline[v] === centre + t * this
box.boxesAtStep(step);    // one whole STEP of the engine's grown boxes, in
                          // input-point order (a step INDEX, never a t value)
```

A ball has none: its t-invariant data is the centre and the weight, which
`cloud` already carries and `radiusAt` already interprets.

`<Field3D>` uses all three. Before them it recovered the ellipsoid profile as
`shapeAt(i, 2).semiAxes` — exact under `ellipsoid-2r`, because at t = 2 the
factor t/2 is 1, but it put the scale law in the renderer instead of in the
filtration layer, which is what SPEC.md §1.3 exists to prevent. The equivalence
is still pinned by a test so the accessor cannot drift from the law.

### Components (SPEC.md §4)

| Component | Entry | Takes | Draws |
|---|---|---|---|
| `<Field2D>` | main | `Filtration` | X_t = ⋃ᵢ S_i(t) as ONE merged SVG path — discs, ellipses, wing hexagons or boxes, per `shapeKind`; `strokeColor` adds a contour masked to ∂(⋃ᵢ S_i(t)), the union's boundary rather than n outlines; `showShapeOutlines` adds every shape's own boundary under it, buried arcs included |
| `<Nerve2D>` | main | `Filtration` | the simplices present at t, over the field, at `vertexPosition(v)`; subset vertices get their own glyph |
| `<Grid2D>` | main | `GridFiltration` | the set the threshold names on a grid of values — one SVG rect per value, the set that is IN inked by how early the sweep reached it, the rest empty; names the construction in the engine's own words and types no wording of its own |
| `<PointCloud2D>` | main or /2d | flat points (+ weights), optional caller-supplied edges, data-unit disk radii, and axes | the cloud, with a √wᵢ weight glyph; explicit `move` and `edit` tools keep drag separate from the built-in exact-coordinate dialog |
| `<ScaleControl>` | main | `Filtration` | t, its convention, the radius it implies (ball) or the scale value under its own convention (ellipsoid / wing / box), snap-to-event |
| `<GuaranteeChip>` | main | `Filtration` or `GridFiltration` | `guarantee.label` verbatim, + the quantization and subset-vertex facts; a grid gets the engine's name for its cubical convention and its own ink |
| `<ConstructionIndex>` | main | entries `{ id, name, kind, figure?, disabled? }` | the two-band index — COMMON INTERSECTION over PAIRWISE INTERSECTION, in the library's own words (`BAND_HEADING`, `BAND_RULE`); arrow keys within a band, Tab between bands; `locked` for a lesson |
| `<Barcode>` `<PersistenceDiagram>` `<BettiCurve>` `<PersistenceImage>` | main | `Filtration` | summaries, with a playhead at t (SPEC.md §4.3). `<Barcode>` also takes a `GridFiltration`, and draws a superlevel sweep's downward bars between their endpoints |
| `<PlayCanvasStage>` | /3d | — | the WebGPU-first canvas every 3D component renders into; on device failure (rejection, a resolved null device, or a throwing constructor) it reports `error`/`deviceType` on context and `data-device` on its root, and renders `fallback` (or its own one-sentence message) instead of a blank canvas — never silent |
| `<Field3D>` | /3d | ball / ellipsoid / box `Filtration` | the union, as instanced spheres, oriented ellipsoids or the engine's grown boxes — labelled an approximation; a wing filtration is refused (2D only) |
| `<Nerve3D>` | /3d | `Filtration` | simplices at t at `vertexPosition(v)`, plus cube markers for subset vertices; tetrahedra never filled |
| `<DepthSlice3D>` | /3d | k-fold cover `Filtration` | the covering depth on a plane through the cloud — every pixel counts the balls of radius √t containing it, in four stepped colours with depth 0 transparent; exact per fragment, with `coveringDepthAt` as the shaders' stated oracle |
| `<KFoldCover3D>` | /3d | k-fold cover `Filtration` | the k-fold cover as a SOLID you can orbit — the region covered by at least k balls of radius √t, traced per fragment as the isosurface of d₍ₖ₎ with analytic normals and fragment depth from the hit point; optionally the one-fold cover (the plain union) as a translucent shell from the same shader at k = 1; exact, with `kthNearestDistanceSquared` as the shaders' stated oracle |
| `<PointCloud3D>` | /3d | flat points (+ weights) | instanced markers |
| `<CycleHighlight3D>` | /3d | simplices | one cycle emphasized |

### One animation loop (DESIGN.md §Motion)

```ts
import { startAnimationLoop, stopAnimationLoop, activeLoopCount } from 'tda-viz-react';

const stop = startAnimationLoop('instrument', (deltaSeconds) => setT((t) => t + speed * deltaSeconds));
// starting another loop cancels this one; activeLoopCount() is 0 or 1 by construction
```

A single module-level `requestAnimationFrame` slot (`src/state/animationLoop.ts`).
Two live loops are unrepresentable rather than forbidden by convention, which is
what lets an application assert the invariant from the outside by counting
pending frame callbacks. Promoted from the site on 2026-09-03 together with
`<ConstructionIndex>`; the site consumes both from the library's source through
`site/src/lib/library.ts`.

### Scale conventions (SPEC.md §1.3 — normative)

| Convention | Index t means | Shape drawn at t |
|---|---|---|
| `rips` | edge length | ball, radius t/2 |
| `cech` | ball radius | ball, radius t |
| `alpha` | squared radius | ball, radius √(t + wᵢ), per point (k-fold: √t) |
| `ellipsoid-2r` | **twice** the ellipsoid radius | semi-axes (t/2)·profile along the fitted frame |
| `wing-eps` | the wing scale ε | spine half-length q·t, wing edges of length t — `point + ε · outline[v]` from `computeWingGeometry` |
| `box-step` | step × π | the engine's box at step ⌊t/π⌋ |
| — (`cubical`) | a THRESHOLD, not a scale | nothing: the cells are fixed, and t decides which are in (SPEC.md §1.3 point 5) |

Every component that draws a shape reads the convention from the filtration
and displays it. Two traps the record closes: `ellipsoid-2r` values are twice
`cech` values (halve before comparing), and `box-step` values are **grid
values** — a box filtration carries `quantization = { step, steps }` so an axis
can say so, and two box diagrams at different steps are not comparable.

## Four entry points (SPEC.md §2)

```ts
// Main entry: engine adapter, filtration layer, hooks, 2D stage, summaries.
// Never pulls PlayCanvas into your bundle.
import { buildFiltration, useScale, Field2D, Nerve2D, Barcode } from 'tda-viz-react';

// Lightweight SVG point input only: no engine adapter or WASM graph.
import { PointCloud2D } from 'tda-viz-react/2d';

import { createFiltration } from 'tda-viz-react/filtration';

// 3D entry: PlayCanvas components ONLY. Requires the optional peer
// playcanvas.
import { Field3D, Nerve3D, PointCloud3D } from 'tda-viz-react/3d';
```

`npm run build` fails if the main entry's import graph ever reaches
`playcanvas` (`scripts/check-entry-isolation.mjs`).

`<Field3D>` is labelled an **approximation** (instanced translucent spheres
double-count overlaps; the exact SDF union is future work, SPEC.md §8 Q2).
`<Nerve3D>` never fills tetrahedra — a solid 3-simplex would hide the cavity
an H₂ class describes.
`<DepthSlice3D>` and `<KFoldCover3D>` make the opposite claim, and it is the
reason they exist: the union `<Field3D>` approximates is the one-fold cover, so
for a k-fold cover it says nothing about k. The slice counts, per fragment, and
is exact. `<KFoldCover3D>` draws the same region as the solid it actually is —
a k-fold cover is three-dimensional, and a disc on a plane is a cross-section
of it, not a picture of it — by sphere-tracing the isosurface d₍ₖ₎ = √t, which
is exact for the same reason: the surface is where the predicate changes, not
a smoothed field near it.

## Honesty constraints (SPEC.md §1.6 — non-negotiable)

- Never synthesize a simplex or a persistence pair. Empty / computing /
  error are real states with real renderings.
- `Filtration.pairs` is Nerve-filtered (H_k for k ≥ ambient dimension is a
  truncation artifact, not topology); `Filtration.rawPairs` keeps everything
  the engine computed, for inspection.
- `Filtration.bettiAt` is honesty-sliced through `reliableBettiSlice`: a 2D
  cloud at cap 2 exposes β₀…β₁ only.
- The canonical regression — **a 50-point 2D circle at cap 2 must NOT report
  β₂ = 150** — runs against the real WASM engine in
  `src/compute/__tests__/pipeline.integration.test.ts` and end-to-end
  through the adapter in
  `src/engine/__tests__/buildFiltration.integration.test.ts`.
- Honest labelling is the library's job: every filtration carries its
  `guarantee` (SPEC.md §1.4), and the chip text is asserted character for
  character against tda-wasm's SPEC FR-6.
- Never invent geometry the engine did not return, and never re-derive geometry
  it does. One case is left: a box filtration built with `retainBoxes: false` has
  no boxes, so it reports `shapesAvailable: false` with a reason and `shapeAt`
  throws rather than returning a default. Wings are always drawable —
  `computeWingGeometry` returns the normal the builder used (including one it
  estimated internally from a neighbourhood size k) and the unit outline its
  birth solver intersects, so the polygon is `point + t · outline[v]` exactly and
  this library never rebuilds the hexagon from (q, θ, α). Which normal a wing
  rests on travels with it as `normalSource`: `supplied` | `osculating` |
  `tangent`.
- Stories and fixtures replay **recorded real engine output**
  (`src/__fixtures__/realFiltrations.ts`, regenerated by
  `scripts/generate-fixtures.mjs`), never hand-authored topology.

## Stack

React + TypeScript + Vite (library mode) + Tailwind CSS + Zustand (vanilla
store in the headless state layer) + Storybook + Vitest + React Testing
Library (the 3D tree is tested against PlayCanvas's null graphics device) +
ESLint + Prettier.

## Consuming `tda-wasm`

Both repositories are private, and until `tda-wasm@0.2.0` exists on npm, the
development dependency resolves to a sibling source checkout. Clone and build
the engine beside this package (requires access to the private repo):

```
topoLab/
├── tda-wasm/        (the engine; build dist/ first)
└── tda-viz-react/
```

```bash
(cd ../tda-wasm && npm ci && npm run build)
npm ci
npm run build
```

After the engine registry release, replace only the development dependency with
`"tda-wasm": "^0.2.0"`; the peer dependency already records that consumer
contract.

A `file:` dependency is a **symlink** in `node_modules`, which matters for the
test setup: Vite resolves the symlink, so `tda-wasm` arrives as
`…/wt-menu/dist/index.js` and a name pattern like `/tda-wasm/` never matches
it. `vitest.config.ts` therefore externalizes the package by its **resolved
root** (`require.resolve('tda-wasm')`), which is independent of the checkout's
name — otherwise the Emscripten module goes through the transform pipeline and
fails with "Cannot read properties of undefined (reading 'module')".
`npm install && npm test` works from a clean clone.

In browsers, pass `engineOptions` to `TdaProvider` (or `TdaEngineOptions` to
`TdaEngine`) to control where `persistent_cohomology.wasm` loads from
(`moduleOptions.locateFile`, `wasmUrl` for the worker).

### Worker strategy (inherited from v1, labeled)

Only the Rips pipeline runs off-thread; alpha and Čech are main-thread
(SPEC.md §8). Worker dispatch always falls back to the main thread on any
failure. The bundled worker chunk has not yet been verified in a real
browser; treat it as best-effort until a consuming app exercises it.

## Commands

```bash
npm test              # vitest (includes real-wasm integration suites)
npm run typecheck     # tsc --noEmit
npm run lint          # eslint (includes the layer-boundary rule)
npm run build         # vite lib build + entry-isolation check
npm run docs          # TypeDoc reference -> docs/api/ (gitignored, built on demand)
npm run storybook     # component workbench (per-component + SPEC §7 acceptance stories)
npm run format        # prettier
node scripts/generate-fixtures.mjs   # regenerate recorded engine fixtures
```

## Homepage (`site/`)

A separate Vite app with its own `package.json`. See
[`site/README.md`](./site/README.md) and, for every visual decision,
[`DESIGN.md`](./DESIGN.md).

```bash
cd site
npm install
npm run gen:data           # recompute every figure's data with the real engine
npm run dev                # pick any free port
npm test
npm run build              # -> site/dist (needs `npm run build-storybook` and `npm run docs` here first)
npm run build:standalone    # -> site/dist-standalone/index.html, ONE self-contained file
```

Two pages on hash routes: `#/` is the landing page — the identity line, one
claim, the carousel, three plain facts and the install line, on the **cool
bright ground** (`--ground #f5f7fb`, founder decision 2026-09-06) — and `#/docs`
is the documentation, on warm paper, which carries the API, the ledger, the
honesty rules and the Atlas. `--ink` is no longer either page's ground; it keeps
machine text, and lends `--ink-3` to the pictures as `--line-on-ground`.

**The carousel** is the landing page's one bold move: four plates, one stage,
one mounted at a time. It is a `tablist` rather than a slider, because the four
are alternatives and not a sequence, grouped and labelled by dimension — and
that grouping is mathematics, since the k-fold cover is 3D only by construction
and the wing complex is 2D only.

| Plate | Dataset | Construction | Payload |
| --- | --- | --- | --- |
| 2D | noisy circle, 40 of tda-wasm's 60-point fixture | Čech, a true nerve | `slide-noisy-circle-cech.json` |
| 2D | figure eight, a seeded lemniscate of 64 points | weighted alpha, weights 0 | `slide-figure-eight-alpha.json` |
| 3D | 40-point weighted sphere | weighted alpha, exact union surface | `hero3d.json` |
| 3D | FCC and HCP, the 4×4×3 Barlow stackings | order-k cover, k = 1…4 | `slide-fcc-hcp-kfold.json` |

Everything in those payloads is real engine output written at build time by
`npm run gen:data`; the page computes no topology, and moving t only filters
what is drawn. The plane plates are drawn by the library's own `<Field2D>` and
`<Nerve2D>` through one shared projection, and the lattice plate by
`<KFoldCover3D>`, `<Nerve3D>` and `<PointCloud3D>` in a single
`<PlayCanvasStage>` — one application, so one frame shows one t on both
packings, and a control under the stage chooses the cover's multiplicity. PlayCanvas is
downloaded only when a 3D tab is opened.

**One animation loop** is structural here rather than arbitrated: exactly one
tabpanel is mounted, so only the active slide can register with the library's
single-slot registry, and `site/src/__tests__/designSystem.test.ts` fails if a
second panel ever appears. The carousel's own 12-second auto-advance runs on an
interval rather than an animation frame — chrome does not take the frame the
mathematics is using — and it stops for the session the moment a reader picks a
plate.

**The Atlas** is the documentation's instrument: one plate, all six 2D
constructions on one shared cloud, one animating at a time. It sits on `#/docs`
rather than the first screen because its apparatus — figure numbers, a
calibrated ruler, a barcode, registration marks, unbacked counters — is what a
reader consults with a question. Three things about it are worth knowing from
here:

- Its index is the classification, not a tab bar. The constructions sit under
  **COMMON INTERSECTION** and **PAIRWISE INTERSECTION**, so selecting one is
  always an act of reading its guarantee. The index is the library's own
  `<ConstructionIndex>`, and the sweep is the library's one loop slot; the site
  takes both from `src/` through `site/src/lib/library.ts`.
- Its guarantee wording is **imported** from `src/filtration/guarantees.ts` at
  data-generation time, so the page cannot drift from the strings this library
  asserts character for character.
- Unbacked simplices — shapes that meet pairwise but share no common point — are
  drawn hollow, and counted by joining each flag complex against its nerve
  counterpart. The **wing complex has no nerve counterpart here**, so its count
  is not computable and the page says so instead of showing a number. A test
  fails if a wing plate ever renders one.

## Acceptance stories (SPEC.md §7)

All five live in `src/stories/Acceptance.stories.tsx` and render from
recorded real engine output:

1. Unweighted circle, alpha — annulus thickens, nerve rings then fills,
   barcode playhead tracks t.
2. Weighted cloud — heavy ball has radius √0.5 at t = 0; nerve edges to the
   heavy point appear first. A companion story renders the adapter's real
   rejection of a negative weight.
3. Rips vs Čech — a Rips triangle whose balls share no common point,
   highlighted and labelled.
4. Snapping — exactly one change per critical value.
5. Honesty — 150 real spurious H₂ pairs in `rawPairs`, absent from `pairs`.

Story 10, one array under both cubical conventions, lives in
`src/render2d/Grid2D.stories.tsx` beside the rest of that component's stories;
its Betti numbers are counted from the filtration on the spot.

The complex menu's four (SPEC.md §7 stories 6–9) live in
`src/stories/ComplexMenu.stories.tsx`, and every number they state about the
fixtures is computed in the story rather than written into its prose:

6. Ellipsoid-Rips vs ellipsoid-Čech — same ellipsoids, identical 1-skeletons,
   8 shared simplices born strictly later in the nerve; only the nerve is
   equivalent to the union on screen.
7. Wing, exact normals vs estimated — identical complexes on this cloud, and
   both draw the engine's own hexagons; what differs is `normalSource`.
8. Box at π = 0.25 vs π = 0.125 — values on the grid, and the two diagrams are
   not comparable.
9. k-fold at k = 1 vs k = 2 — 8 vertices over 8 points, then 22, each at its
   pair's barycentre, while the balls still grow at √t on the input points.

## TODO (do not build ahead of the spec)

- `<Field3D>` exact union via marching cubes over the SDF — SPEC.md §8 Q2
- witness complex wiring (weighted witness is undefined by the engine) — SPEC.md §8 Q3
- alpha/Čech off the main thread — SPEC.md §8 (inherited)

## Local addresses

With [portless](https://github.com/vercel-labs/portless) installed, `portless` in
`site/` serves the landing page and docs at https://tda-viz.localhost and
`portless` at the repository root serves Storybook at
https://tda-viz-storybook.localhost — no port numbers to remember. The
`portless.json` files carry the names.
