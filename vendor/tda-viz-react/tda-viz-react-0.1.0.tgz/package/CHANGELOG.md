# Changelog

Notable changes to `tda-viz-react`. Dates are the day the work landed on `main`.

## Unreleased

### Changed (breaking)

- **The public API uses the engine's names.** The remaining 0.2 spellings are
  renamed to those of `@topolab/tda-wasm` 0.3, with no aliases:
  `initialize()` is `load()`, `computePipeline` / `computePipelineAsync` are
  `persistence` / `persistenceAsync`, `coeffField` is `coeff`,
  `maxSimplexDimension` is `maxSimplexDim` (params, `Filtration` and the
  honesty helpers; the constants are `*_MAX_SIMPLEX_DIM`), the Čech
  `maxEdgeLength` is `maxRadius`, the ellipsoid `neighborhoodSize` / `axesMode`
  are `neighbors` / `axes`, the wing `maxEps` is `maxEpsilon` and its
  `normals` / `neighborhoodSize` are one `normals` (array or count), and the
  box `alpha` / `retainBoxes` are `growth` / `boxes`. `ComplexResult` and
  `EllipsoidAxesMode` are removed in favour of the engine's `Complex` and
  `EllipsoidAxes`. `TdaParams` is a union with one cutoff per complex type,
  and `setParams` takes a `TdaParamsPatch`. The adapter's own checks throw
  `TypeError` (wrong type) or `RangeError` (out of range) instead of `Error`,
  including the removed ellipsoid `maxFiltration`, now a `TypeError`. Values,
  units and results are unchanged. The full table is
  [docs/MIGRATION.md](docs/MIGRATION.md).
- **The ellipsoid cutoff is split by unit (2026-10-12).** `maxFiltration` is
  removed from `EllipsoidFiltrationParams`. Ellipsoid Rips takes
  `maxEdgeLength`, in twice-radius units; ellipsoid Čech takes `maxRadius`, in
  radius units. With the 0.3 engine, ellipsoid Čech values are the radius,
  half the 0.2 values, so one shared name would have kept compiling while
  doubling the Čech cutoff. There is no alias: a caller that still passes
  `maxFiltration` gets a type error, and an untyped caller gets an `Error`
  naming the replacement. Migration: `{ complexType: 'ellipsoid-rips',
  maxFiltration: c }` becomes `{ complexType: 'ellipsoid-rips', maxEdgeLength: c }`;
  `{ complexType: 'ellipsoid-cech', maxFiltration: c }` (a 0.2 twice-radius
  cutoff) becomes `{ complexType: 'ellipsoid-cech', maxRadius: c / 2 }`. The
  types `EllipsoidRipsFiltrationParams` and `EllipsoidCechFiltrationParams`
  are exported beside the union `EllipsoidFiltrationParams`.

### Docs

- **Generated API reference (2026-09-14).** `npm run docs` builds a TypeDoc
  reference for the four public entries (`index`, `2d`, `3d`, `filtration`)
  into `docs/api/`, gitignored and built on demand. The site's postbuild copies
  it to `site/dist/api/`, beside the Storybook it already bundles, and the
  documentation page's API section links to it: the hand-written entries there
  are a curated tour, the reference is the whole surface.
  `typedoc.json` runs with `treatWarningsAsErrors` and
  `validation.notDocumented` scoped to the export kinds, so an export that
  lands without a JSDoc fails `npm run docs`.
- **JSDoc on every public export (2026-09-14).** The convention had been a
  module-level block at the top of each file, which documents the module and
  leaves the symbols under it undocumented: 93 exports across 30 files. Each
  now carries its own JSDoc, distilled from the module block. Recorded fixtures
  are tagged `@internal` and excluded by path; they were already absent from
  every package entry, and neither the site nor the Explorer imports them.

- **WebGPU preprocess decision note (2026-09-10).** [`docs/WEBGPU_PREPROCESS.md`](./docs/WEBGPU_PREPROCESS.md): UTILIZE A (WebGPU distances → WASM Ripser), EVALUATE B (Ripser++ CUDA oracle), PARK C (GPU residual reduction). Linked from [`docs/README.md`](./docs/README.md). No shaders; not a GPU-PH claim.

### Added

- **A cubical filtration path: a grid of values and a threshold, in the
  engine's two conventions (2026-09-08).** `buildFiltration(engine, params)` —
  two arguments, no cloud — accepts
  `{ complexType: 'cubical', values, width, height, construction, direction }`
  and returns a `GridFiltration`: the grid it was built from, the diagram, and
  `containsValue(value, t)`, the one predicate that says which cells are inside
  at a threshold. It is a SIBLING of `Filtration`, not a ninth member of it
  (`AnyFiltration` is the union, discriminated by a new `domain` field), because
  a grid has no `cloud`, no `shapeAt`, no `simplices` and no scale convention,
  and a union member for which five of its own fields are meaningless would push
  a narrowing check into every existing consumer. A component that draws growing
  shapes keeps taking `Filtration` and cannot be handed a grid by mistake.
  - `construction` is `'cubical-t'` (a value is a PIXEL; faces take the minimum
    of the cells around them) or `'cubical-v'` (a value is a grid VERTEX; edges
    and squares take the maximum of their vertices — the lower star). Both are
    required, neither is defaulted, and they are **different filtrations of the
    same numbers**: under T two low pixels that touch corner to corner share a
    vertex and are connected from the start, and under V two low vertices that
    touch corner to corner have no edge between them, because a square lattice
    has no diagonals. On `0 2 2 / 2 0 2 / 2 2 0` — hand-computed, stated in the
    test, and checked against the live engine — T reports one component and V
    reports three.
  - `direction` is `'sublevel'` ({f ≤ t}, sweeping up) or `'superlevel'`
    ({f ≥ t}, sweeping down). The engine computes sublevel only, so a superlevel
    build is the sublevel filtration of −f with the endpoints negated back into
    the image's own units — exact for both constructions, since min(−v) =
    −max(v), and asserted against the engine rather than assumed. Its diagram
    runs downward (birth ≥ death), which is the direction the sweep goes and not
    a defect to normalise away.
  - The guarantee is a third kind, `'cubical'`, in its own table
    (`GRID_GUARANTEES`). The nerve/flag pair classifies complexes built from
    intersections of growing shapes; a cubical complex is not in that argument
    at all, since nothing grows and there is no cover whose nerve it might be —
    the complex IS the thresholded set's own cells. The two labels are tda-wasm's
    own phrases for the conventions, quoted, and the test reads the engine's
    `README.md` off disk and fails if either is no longer in it verbatim.
    `COMPLEX_GUARANTEES` deliberately stays at its eight point-cloud keys.
- **`<Grid2D>`**, the grid domain's stage — one SVG rect per grid value, the set
  the threshold names inked and the rest left empty, so the line between them is
  the threshold. Ink strength is DEPTH (how early the sweep reached a value,
  normalised across the grid's own range), which keeps the whole field on one
  colour token — `color` defaults to `var(--grid-ink, currentColor)` and
  `gridColor` to `var(--grid-rule, currentColor)`, with `opacity`, `minShade`,
  `gridWidth` and `gridOpacity` beside them and no palette value written into
  the component. It draws every cell at every t, because a silhouette shows
  where the sweep has been and never where it has got to; `minShade` is above 0
  because a cell at the threshold IS in the complex. `data-cell-basis` records
  whether a value is a pixel or a lattice vertex. The SVG contains no `<text>`
  at all: the caption below it is `filtration.guarantee.label`, the engine's
  phrase, plus one sentence of this library's own about which side is filled.
- **`<GuaranteeChip>` and `<Barcode>` take either domain.** The chip renders a
  grid's cubical label verbatim, gives it its own ink (`var(--cubical, …)`,
  because two different claims in one colour read as one claim) and carries the
  grid's size and the fact that the other convention would give a different
  diagram — `data-testid="guarantee-chip-grid"`, `data-domain`. The barcode
  draws a cubical diagram with no extra plumbing, and a bar now runs BETWEEN its
  endpoints rather than from the first to the second, so a superlevel sweep's
  downward pairs are bars instead of zero-width slivers; an essential class of a
  downward sweep runs to the LEFT edge. Identical output for every ascending
  filtration.
- **Recorded cubical fixtures** (`scripts/generate-fixtures.mjs`, section 9):
  `DIAGONAL3_CUBICAL_T` / `_V` (the hand-computed 3 × 3), `TWORINGS10_CUBICAL_T`
  / `_V` / `_T_SUPER` (two 5 × 5 rings touching at one corner: T counts one dark
  region, V counts two, both count two loops), `TWOHOLE11X9_CUBICAL_T` / `_V`
  and `WELLS24_CUBICAL_V` (a smooth height field, for a sweep with more than two
  thresholds). Restored by a new `recordedGridFiltration`, which is separate
  from `recordedFiltration` for the same reason the types are: a grid record has
  no cloud and no simplices to share.

### Fixed

- **The fixture generator runs again, and stale fixtures fail the tests.**
  `scripts/fixture-inputs.json` still passed the ellipsoid `maxFiltration`
  removed on 2026-10-12, so `scripts/generate-fixtures.mjs` threw at
  `ELLIPSE_ELLIPSOID_RIPS`. The inputs now pass `maxEdgeLength` (Rips) and
  `maxRadius` (Čech) with the same numbers the 0.3 adapter forwarded before the
  split, and the regenerated `realFiltrations.ts` is byte-identical apart from
  its "Regenerate" comment. `npm run fixtures` builds `dist/` and regenerates;
  `npm run fixtures:check` exits 1 on a stale file, and a Vitest case runs the
  same generator on `src/` and compares, so `npm test` catches it too.

- **The T-construction is routed through the engine's GENERAL cubical binding,
  not its 2D convenience wrapper.** GUDHI's bitmap reads its cell array with
  `sizes[0]` varying fastest, so a row-major image of `width` columns must be
  handed `[width, height]`; tda-wasm's `computeCubicalPersistence2D` builds
  `{height, width}` instead, which is a transpose on a square grid — harmless,
  and why it went unnoticed — and a scramble on any other. Measured on an 11 × 9
  two-hole image, the wrapper reports three components and no loop where the
  image has one component and two loops, and it disagrees with itself on an
  image and its transpose. `TdaEngine.computeCubicalPersistence2D` therefore
  calls `computeCubicalPersistence([width, height], values)`, and the shipped
  regression asserts that a grid and its transpose give the same diagram. The
  engine itself is unchanged; this is reported upstream rather than patched here.

- **`<Field2D>` draws the union's BOUNDARY, on request.** `strokeColor` already
  existed and stroked the merged path, which drew every shape's whole outline —
  buried arcs included, the double-counting the single nonzero fill exists to
  prevent, drawn back in as line. The contour is now masked to the region
  outside the fill, so what is drawn is `∂(⋃ᵢ Sᵢ(t))`: the stroke is laid down at
  twice the asked width and its inner half is masked away, leaving a line of the
  asked width just outside the region and leaving a buried arc with nothing.
  New `strokeWidth` (default `0.8`, the value it always stroked at) and
  `strokeOpacity` (default `1`) set the weight and the strength. The union fill
  keeps `data-testid="field-2d-union"`; the contour is a second element,
  `data-testid="field-2d-contour"`, present only when `strokeColor` is given.
- **`<Field2D showShapeOutlines>`** draws every shape's own boundary — each
  disc, ellipse, wing and box outline, *including the arcs buried inside the
  union*, which the masked contour necessarily leaves out. With
  `shapeOutlineColor` (defaults to `color`), `shapeOutlineWidth` (0.5) and
  `shapeOutlineOpacity` (0.35). Off by default. It is not a second geometry:
  the union's path already IS every shape's outline, one subpath per shape, so
  this strokes the identical `d` with no fill and an outline cannot drift from
  the region it lies in. Painted between the union fill and the contour —
  `data-testid="field-2d-outlines"`.
- **`<Nerve2D showNotes>`** gates the two explanatory notes the component sets
  inside its own SVG — the subset-vertex legend, and the guarantee sentence a
  flag complex carries. On by default, because a flag picture that does not say
  what a simplex means is the decorative-guarantee failure SPEC.md §1.4 exists
  to prevent. A caller may turn them off only because it states the guarantee
  itself; the machine-readable `data-guarantee` attribute is not a note and is
  never suppressed.
- **`<Nerve2D>` exposes the ink weights it owns.** `edgeWidth` (1),
  `edgeOpacity` (0.65), `triangleOpacity` (0.28), `vertexRadius` (2),
  `vertexOpacity` (0.8), `vertexHaloColor` (off) and `vertexHaloWidth` (1.2).
  Every default is the value the component already drew at, so no existing
  caller changes. The halo is painted with `paint-order: stroke`, under the
  disc, so the visible ring is a break in the ink around a point rather than a
  ring on top of it — which is what keeps a vertex from reading as an edge
  crossing on a dense 1-skeleton. Subset vertices are untouched: their glyph is
  a hollow diamond, and a halo would fill it.

- **`<KFoldCover3D>` (`tda-viz-react/3d`)** — the k-fold cover as a SOLID
  region you can orbit (SPEC.md §4.6). `<DepthSlice3D>` paints the region's
  cross-section on one plane exactly; a k-fold cover is inherently
  three-dimensional, and the shape of the lobes, the neck two of them join
  through and how many there are cannot be read off a disc. This traces the
  region itself.
  - Exactness comes from an identity, not from a grid: with `d₍ₖ₎(x)` the k-th
    smallest distance to the centres, `depth(x) ≥ k ⇔ d₍ₖ₎(x)² ≤ t`, so the
    cover is the sublevel set of `d₍ₖ₎` and its boundary is the isosurface
    `d₍ₖ₎ = √t`. `d₍ₖ₎` is 1-Lipschitz, so `d₍ₖ₎ − √t` is a safe sphere-tracing
    step; the outward normal is `(x − c₍ₖ₎)/|x − c₍ₖ₎|`, analytic, with no
    finite differences. No marching cubes, no metaballs, no smoothed field.
  - `colorUnion` adds the ONE-fold cover — the plain union of the balls — as a
    translucent shell in front, drawn by the SAME shader at `k = 1`. That is
    the argument: the union is what `<Field3D>` approximates, and it says
    nothing about `k`.
  - `kthNearestDistanceSquared` / `insideKFoldCover`
    (`src/render3d/kfoldCover.ts`) are the pure-TypeScript oracle both shader
    languages transcribe, tested against an independent brute force and against
    `coveringDepthAt`, which the identity says must agree pointwise. The motif
    geometry is pinned to the same numbers `<DepthSlice3D>` uses: both depth-4
    lobes open at `t = 0.375`, and the segment between the two hole centres is
    covered four times from `t = 0.6700` (HCP, holes sharing a face) against
    `t = 0.7525` (FCC, holes sharing only an edge).
  - The ray is rebuilt per fragment from `view_position` and the box surface
    position — `matrix_viewProjectionInverse` is NOT a renderer-set uniform in
    playcanvas 2.21.4 (only the TAA render pass resolves that name), so a
    shader asking for it would silently receive an identity matrix. Fragment
    depth is written from the hit point (`gl_FragDepth` /
    `@builtin(frag_depth)`), so `<Nerve3D>` edges and `<PointCloud3D>` points
    in the same stage occlude correctly.
  - Stated limits: at most 256 centres, `k ≤ 8` (the k smallest squared
    distances are selected in registers), and the march is capped at 128 steps
    — a ray that has not landed by then is discarded, not drawn at a guessed
    position. Centres upload once per cloud; moving `t` writes one uniform per
    pass.
  - Exported alongside `kthNearestDistanceSquared`, `kthNearestCentreIndex`,
    `insideKFoldCover`, `cloudBounds`, `boxTriangles`, `coverEpsilon`,
    `MAX_COVER_CENTRES`, `MAX_COVER_K` and `COVER_MAX_STEPS` from
    `tda-viz-react/3d`.
- **Storybook: `3D/KFoldCover3D`** — the two eight-sphere motifs at four scales
  and the 48-sphere `fcc_48` / `hcp_48` lattices, all at `k = 4` with the union
  shell on, orbitable and scrubbable, with every filtration built at story load
  through `buildFiltration` against the real engine.
- **`Filtration.coverMultiplicity`** — the `k` a k-fold cover was built at now
  travels with the filtration; `null` for every other construction, which has no
  multiplicity. `<KFoldCover3D>` defaults its own `k` to it. Backwards-
  compatible: `createFiltration` takes it as an optional input and otherwise
  falls back to the size of the first vertex subset.
- **`<DepthSlice3D>` (`tda-viz-react/3d`)** — the covering depth of a k-fold
  cover, painted on a plane through the cloud (SPEC.md §4.5). Every pixel counts
  the balls of squared radius `t` that contain it and takes its colour from that
  count: depth 0 transparent, then 1, 2, 3 and ≥ 4 in four caller-supplied
  colours. The union `<Field3D>` draws is the one-fold cover, so for `k > 1` it
  says nothing about `k`; this is the picture the construction is actually
  about, and unlike `<Field3D>` it is exact rather than an approximation — the
  fragment shader evaluates `#{ i : |x − cᵢ|² ≤ t }` with no distance field, no
  blur and no accumulated alpha standing in for a count.
  - `coveringDepthAt` (`src/render3d/depthSlice.ts`) is the same formula in pure
    TypeScript, named in both the GLSL and the WGSL as their oracle, and tested
    against an independent brute force. The two eight-sphere motifs pin the
    geometry: both open a pair of depth-4 regions at `t = 0.375`, the squared
    circumradius of four touching unit spheres, and the pair merges at
    `t = 0.6700` for HCP (eclipsed, holes sharing a face) against `t = 0.7525`
    for FCC (staggered, holes sharing only an edge).
  - Refuses anything that is not a 3D k-fold cover filtration.
  - Centres upload once per cloud, as a 256-entry uniform array; moving `t`
    writes one uniform and re-uploads nothing. Above 256 centres the component
    throws rather than counting a prefix of the cloud.
  - Exported alongside `coveringDepthAt`, `sliceFrame`, `slicePoint`,
    `cloudCentroid`, `cloudBoundingRadius` and `MAX_DEPTH_SLICE_CENTRES` from
    `tda-viz-react/3d`.
  - Array uniforms are set under their `[0]` name (`uCentres[0]`, `uRamp[0]`),
    which is what both backends resolve in `device.scope`: WebGL2 takes the
    name from `gl.getActiveUniform()` (`webgl/webgl-shader-input.js:47`) and
    WebGPU from `UniformFormat`, which appends the suffix itself
    (`uniform-buffer-format.js:117-118`). Setting the bare name binds nothing,
    silently, and left the slice painting a black disc at the world origin in a
    real browser. A source-level test now parses both shader languages for
    array declarations and requires a matching `[0]` parameter, because a
    `NullGraphicsDevice` test can never see this.
- **Storybook: `3D/DepthSlice3D`** — the FCC-versus-HCP comparison at three
  scales, with both filtrations built at story load through `buildFiltration`
  against the real engine at `k = 4`.
- **Homepage (`site/`): the FCC-versus-HCP plate draws the k-fold cover as a
  SOLID** (founder decision, 2026-09-07: "those things are inherently 3D; you
  cannot just draw a 2D disk"). `<KFoldCover3D>` replaces `<DepthSlice3D>` on
  that plate: the region covered at least k times is opaque, the rest of the
  union is a dimmed translucent shell around it, and nothing outside the union
  is drawn. The order-k nerve is drawn thin over it and the centres as ink
  points.
  - A segmented `radiogroup` under the stage chooses **k = 1, 2, 3, 4** (default
    4, roving tabindex, arrow keys / Home / End). Changing k swaps both the
    cover's multiplicity and the nerve's filtration, keeping `t` — a different k
    is a different construction, so the payload carries all eight builds
    (two clouds × four k, 887 kB raw / 124 kB gzipped, nothing subsampled).
  - The caption's join values (t = 0.665 for HCP, 0.748 for FCC) are shown at
    k = 4 only, because they are k = 4 facts. Below it the caption states, from
    the payload's own counts, that the two covers are not told apart: finite H₁
    bars longer than 1e-3 come to 126/132 at k = 1, 180/194 at k = 2, 58/69 at
    k = 3, and 0/6 at k = 4.
- **Homepage (`site/`): the landing page is redesigned around a carousel**
  (founder decisions, 2026-09-06; DESIGN.md §Which ground / §Layout / §Motion).
  The page moves off the ink ground onto a cool bright one (`--ground #f5f7fb`,
  with `--ground-2`, `--rule-on-ground`, `--text-on-ground`,
  `--text-on-ground-dim`, `--line-on-ground` and `--field-on-ground`), and the
  two viewers become four plates in one stage: noisy circle · Čech, figure
  eight · alpha, sphere · weighted alpha, and FCC versus HCP at the order-4
  cover. `--ink` is no longer a page ground; it keeps machine text and lends
  `--ink-3` to the pictures as their line colour.
  - The plane plates are drawn by the library's own `<Field2D>` and `<Nerve2D>`
    on one shared projection, and the lattice plate by `<DepthSlice3D>` and
    `<Nerve3D>` in a single `<PlayCanvasStage>`.
  - Three new build-time generators run the real engine into `site/src/data/`;
    the four plates' payloads come to 69,630 bytes gzipped.
  - One animation loop is now structural on that page rather than arbitrated:
    the carousel mounts exactly one `tabpanel`, and a test fails if a second
    one ever appears.
  - `site/scripts/generate-atlas-data.mjs` read its fixture from a `wt-menu`
    worktree that no longer exists; it reads tda-wasm's copy now, and the
    regenerated `atlas.json` is byte-identical.
