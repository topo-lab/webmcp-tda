import type { Diagram } from '@topolab/tda-wasm';
import { diagramPairs } from '../compute/diagram';
import type { PersistencePair } from '../types/engine';
export function diagramFromPairs(pairs: PersistencePair[]): Diagram {
  const groups: number[][] = [];
  for (const p of pairs) {
    groups[p.dimension] ??= [];
    groups[p.dimension].push(p.birth, p.death);
  }
  return {
    pairs: Array.from({ length: groups.length }, (_, i) => Float64Array.from(groups[i] ?? [])),
    scale: 'value',
    coeff: 2,
  };
}
export function inspectPipeline(result: { diagram: Diagram }) {
  const pairs = diagramPairs(result.diagram);
  const byDimension = new Map<number, PersistencePair[]>();
  const pairsByDimension: Record<number, number> = {};
  let dimension = 0;
  for (const p of pairs) {
    if (!byDimension.has(p.dimension)) byDimension.set(p.dimension, []);
    byDimension.get(p.dimension)!.push(p);
    pairsByDimension[p.dimension] = (pairsByDimension[p.dimension] ?? 0) + 1;
    dimension = Math.max(dimension, p.dimension);
  }
  const essential = pairs.filter((p) => p.death === Infinity);
  return {
    persistence: { pairs, pairsByDimension, essentialCount: essential.length, dimension },
    diagram: { pairs, byDimension, essential },
  };
}
