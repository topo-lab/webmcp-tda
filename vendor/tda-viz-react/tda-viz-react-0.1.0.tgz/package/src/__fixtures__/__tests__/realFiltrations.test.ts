// @vitest-environment node
//
// The committed fixtures are exactly what the generator writes today, run
// against the REAL engine and this checkout's library source. Ways this goes
// stale, each of which fails here:
//   - an input passes a parameter the library or the engine no longer takes
//     (the generator throws);
//   - the engine or the library computes a different simplex, pair, ellipsoid,
//     wing or box (the regenerated source differs);
//   - realFiltrations.ts or fixture-header.txt is edited by hand;
//   - the runtime is not the version the header names (the generator throws);
//   - the output is not byte-stable from one run to the next.
// `npm run fixtures:check` is the same comparison against the built dist/.
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import { renderRealFiltrations } from '../../../scripts/fixture-records.mjs';
import { TdaEngine } from '../../compute/TdaEngine';
import { buildFiltration } from '../../engine/buildFiltration';

const committedPath = new URL('../realFiltrations.ts', import.meta.url);

describe('recorded fixtures', () => {
  it('realFiltrations.ts is what scripts/generate-fixtures.mjs writes', async () => {
    const first = await renderRealFiltrations({ TdaEngine, buildFiltration });
    const second = await renderRealFiltrations({ TdaEngine, buildFiltration });
    expect(second.source).toBe(first.source);
    const committed = readFileSync(committedPath, 'utf8');
    // Line by line first, so a failure names the first stale record rather
    // than printing two 20,000-line strings.
    const generatedLines = first.source.split('\n');
    const committedLines = committed.split('\n');
    const firstDiff = generatedLines.findIndex((line, i) => line !== committedLines[i]);
    expect(
      firstDiff === -1 ? null : { line: firstDiff + 1, generated: generatedLines[firstDiff] },
      'regenerate with `npm run fixtures` and review the diff',
    ).toBeNull();
    expect(first.source === committed).toBe(true);
  }, 120_000);
});
