// <Barcode> re-keyed on (filtration, t) — SPEC.md §4.3. It draws exactly
// filtration.pairs (the Nerve-filtered set); the playhead tracks t.
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  CIRCLE50_RIPS_CAP2,
  TWORINGS10_CUBICAL_T,
  TWORINGS10_CUBICAL_T_SUPER,
  WEIGHTED3_ALPHA,
  recordedFiltration,
  recordedGridFiltration,
} from '../../__fixtures__/realFiltrations';
import { Barcode } from '../Barcode';

// 4 pairs: three H0 (one essential, born at -0.5) + one H1. Real engine output.
const weighted = recordedFiltration(WEIGHTED3_ALPHA);
const honesty = recordedFiltration(CIRCLE50_RIPS_CAP2);

const empty = recordedFiltration({
  name: 'EMPTY',
  cloud: { points: [], weights: [], dimension: 2 },
  complexType: 'rips',
  convention: 'rips',
  maxSimplexDim: 2,
  simplices: [],
  rawPairs: [],
});

describe('<Barcode> (summary of the filtration, SPEC.md §4.3)', () => {
  it('renders exactly one bar per Nerve-filtered pair — display may hide, never invent', () => {
    render(<Barcode filtration={weighted} />);
    expect(screen.getAllByTestId('tda-bar')).toHaveLength(4);
  });

  it('never draws the raw truncation artifacts: 51 bars for the honesty circle, not 201', () => {
    render(<Barcode filtration={honesty} />);
    expect(screen.getAllByTestId('tda-bar')).toHaveLength(51);
    const dims = screen.getAllByTestId('tda-bar').map((b) => b.getAttribute('data-dimension'));
    expect(dims.filter((d) => d === '2')).toHaveLength(0); // the 150 spurious H2 stay in rawPairs
  });

  it('renders the empty state honestly: no pairs, no bars', () => {
    render(<Barcode filtration={empty} />);
    expect(screen.queryAllByTestId('tda-bar')).toHaveLength(0);
    expect(screen.getByRole('img')).toHaveAttribute('data-empty', 'true');
  });

  it('groups bars by dimension, ordered by birth within each group', () => {
    render(<Barcode filtration={weighted} />);
    const dims = screen
      .getAllByTestId('tda-bar')
      .map((b) => Number(b.getAttribute('data-dimension')));
    expect(dims).toEqual([...dims].sort((a, b) => a - b));
  });

  it('marks essential (death = Infinity) bars instead of inventing a death time', () => {
    render(<Barcode filtration={weighted} />);
    const essential = screen
      .getAllByTestId('tda-bar')
      .filter((b) => b.getAttribute('data-essential') === 'true');
    expect(essential).toHaveLength(1);
    expect(essential[0]!.getAttribute('data-dimension')).toBe('0');
  });

  it('draws the playhead only when t is provided', () => {
    const { rerender } = render(<Barcode filtration={weighted} t={0.5} />);
    expect(screen.getByTestId('barcode-playhead')).toBeInTheDocument();
    rerender(<Barcode filtration={weighted} />);
    expect(screen.queryByTestId('barcode-playhead')).not.toBeInTheDocument();
  });

  it('spans the filtration domain including negative weighted births (t = -w)', () => {
    // The essential H0 class is born at -0.5, the heavy vertex's entry.
    const width = 500;
    const padding = 16;
    render(<Barcode filtration={weighted} t={-0.5} width={width} padding={padding} />);
    const line = screen.getByTestId('barcode-playhead');
    // The playhead at the very start of the filtration sits at the left edge.
    expect(Number(line.getAttribute('x1'))).toBeCloseTo(padding, 5);
  });

  it('positions the playhead within the plot area', () => {
    const width = 500;
    render(<Barcode filtration={weighted} t={0.5} width={width} />);
    const line = screen.getByTestId('barcode-playhead');
    const x = Number(line.getAttribute('x1'));
    expect(x).toBeGreaterThan(0);
    expect(x).toBeLessThan(width);
    expect(line.getAttribute('x1')).toBe(line.getAttribute('x2'));
  });

  it('passes className through', () => {
    render(<Barcode filtration={weighted} className="my-barcode" />);
    expect(screen.getByRole('img')).toHaveClass('my-barcode');
  });
});

/**
 * A grid filtration's diagram is the same object as any other (SPEC.md §3.1b),
 * so the barcode a consumer already has draws it without a second component.
 */
describe('<Barcode> over the grid domain', () => {
  it('draws a cubical diagram’s bars, one per pair, with no extra plumbing', () => {
    const f = recordedGridFiltration(TWORINGS10_CUBICAL_T);
    render(<Barcode filtration={f} t={0} />);
    expect(screen.getAllByTestId('tda-bar')).toHaveLength(f.pairs.length);
    expect(
      screen.getAllByTestId('tda-bar').filter((b) => b.getAttribute('data-essential')),
    ).toHaveLength(1);
  });

  it('a SUPERLEVEL diagram runs downward, and its bars still have width', () => {
    const f = recordedGridFiltration(TWORINGS10_CUBICAL_T_SUPER);
    // Every finite pair has birth >= death: the sweep goes the other way.
    expect(f.pairs.filter((p) => Number.isFinite(p.death)).every((p) => p.birth >= p.death)).toBe(
      true,
    );
    render(<Barcode filtration={f} t={1} />);
    const bars = screen.getAllByTestId('tda-bar');
    expect(bars).toHaveLength(f.pairs.length);
    // A bar is drawn BETWEEN its endpoints, not from the first to the second,
    // so a descending pair is a bar and not a zero-width sliver.
    for (const b of bars) expect(Number(b.getAttribute('width'))).toBeGreaterThan(0);
  });

  it('an essential class of a downward sweep runs to the LEFT edge', () => {
    const f = recordedGridFiltration(TWORINGS10_CUBICAL_T_SUPER);
    render(<Barcode filtration={f} t={1} width={480} padding={16} />);
    const essential = screen
      .getAllByTestId('tda-bar')
      .filter((b) => b.getAttribute('data-essential') === 'true');
    expect(essential).toHaveLength(1);
    expect(Number(essential[0].getAttribute('x'))).toBe(16);
  });
});
