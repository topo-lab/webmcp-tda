/** Lightweight SVG-only entry point for interactive point-cloud consumers. */
export {
  PointCloud2D,
  type PointCloud2DEdge,
  type PointCloud2DInteractionMode,
  type PointCloud2DProps,
  type PointCoordinatePrompt,
} from './render2d/PointCloud2D';

export { BallSlice2D, ballSliceShapes, type BallSlice2DProps } from './render2d/BallSlice2D';
