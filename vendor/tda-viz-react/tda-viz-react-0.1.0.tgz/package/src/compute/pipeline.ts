import { cechComplex, ripsComplex, persistence } from '@topolab/tda-wasm';
import type { Complex, PointCloud } from '@topolab/tda-wasm';
import type { PipelineResult, TdaParams } from '../types/engine';

// The full Čech builder can put a face one representable value above a
// coface. Raise that coface (never lower a face), and use the SAME repaired
// values for drawing and reduction. Larger violations remain errors.
function nextUp(value: number): number {
  if (value === Infinity) return value;
  if (value === 0) return Number.MIN_VALUE;
  const bytes = new DataView(new ArrayBuffer(8));
  bytes.setFloat64(0, value);
  bytes.setBigUint64(0, bytes.getBigUint64(0) + (value > 0 ? 1n : -1n));
  return bytes.getFloat64(0);
}

export function closeCechRoundoff(complex: Complex): Complex {
  const keys = new Map<string, number>();
  const vertices = Array.from({ length: complex.filtrations.length }, (_, i) =>
    Array.from(complex.vertices.subarray(complex.offsets[i], complex.offsets[i + 1])),
  );
  vertices.forEach((vs, i) => keys.set(vs.join(','), i));
  const ordered = vertices.map((_, i) => i).sort((a, b) => vertices[a].length - vertices[b].length);
  let repaired: Float64Array | null = null;
  for (const i of ordered) {
    const vs = vertices[i];
    let value = (repaired ?? complex.filtrations)[i];
    if (vs.length < 2) continue;
    for (let j = 0; j < vs.length; j++) {
      const face = keys.get(vs.filter((_, k) => j !== k).join(','));
      if (face === undefined) continue; // persistence reports a missing face
      const birth = (repaired ?? complex.filtrations)[face];
      if (birth <= value) continue;
      if (birth > nextUp(complex.filtrations[i])) {
        throw new RangeError('Čech complex has a face born more than one ulp after its coface');
      }
      repaired ??= complex.filtrations.slice();
      value = repaired[i] = birth;
    }
  }
  return repaired ? { ...complex, filtrations: repaired } : complex;
}

/** Build and reduce the exact displayed skeleton, on either thread. */
export function skeletonPersistence(points: PointCloud, params: TdaParams): PipelineResult {
  let complex: Complex;
  switch (params.complexType) {
    case 'rips':
      complex = ripsComplex(points, {
        maxEdgeLength: params.maxEdgeLength,
        maxSimplexDim: params.maxSimplexDim,
      });
      break;
    case 'cech':
      // cechPersistence's Delaunay–Čech output is a different simplex inventory.
      complex = closeCechRoundoff(
        cechComplex(points, {
          maxRadius: params.maxRadius,
          maxSimplexDim: params.maxSimplexDim,
        }),
      );
      break;
    case 'alpha':
      throw new Error('Weighted alpha and its z=0 embedding belong in buildFiltration');
    default:
      throw new Error(`Unknown complex type: ${String((params as TdaParams).complexType)}`);
  }
  return { complex, diagram: persistence(complex, { coeff: params.coeff }) };
}
