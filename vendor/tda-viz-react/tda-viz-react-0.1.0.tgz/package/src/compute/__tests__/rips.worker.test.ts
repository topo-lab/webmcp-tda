import { afterEach, describe, expect, it, vi } from 'vitest';
import type { RipsPipelineRequest, RipsPipelineResponse } from '../workerTypes';
vi.mock('@topolab/tda-wasm', () => import('../../../__mocks__/tda-wasm'));
type Listener = (event: { data: RipsPipelineRequest }) => void;
const request = (id: number, wasmUrl?: string): RipsPipelineRequest => ({
  type: 'rips-pipeline',
  id,
  points: Float64Array.of(0, 0, 1, 0, 0, 1),
  dimension: 2,
  maxEdgeLength: 1,
  maxSimplexDim: 2,
  coeff: 3,
  wasmUrl,
});
async function harness() {
  vi.resetModules();
  const { mockControl } =
    (await import('@topolab/tda-wasm')) as unknown as typeof import('../../../__mocks__/tda-wasm');
  mockControl.reset();
  vi.clearAllMocks();
  let listener: Listener | undefined;
  const postMessage = vi.fn<(response: RipsPipelineResponse) => void>();
  vi.stubGlobal('addEventListener', (_type: string, callback: Listener) => {
    listener = callback;
  });
  vi.stubGlobal('postMessage', postMessage);
  await import('../rips.worker');
  if (!listener) throw new Error('Missing worker listener');
  return { listener, postMessage, control: mockControl };
}
afterEach(() => vi.unstubAllGlobals());
describe('0.3 worker protocol', () => {
  it('returns structured-clone-safe native results and forwards options', async () => {
    const h = await harness();
    h.listener({ data: request(7, '/tda.wasm') });
    await vi.waitFor(() => expect(h.postMessage).toHaveBeenCalledTimes(1));
    const response = h.postMessage.mock.calls[0][0];
    expect(response.type).toBe('result');
    if (response.type !== 'result') throw new Error(response.error);
    expect(response.id).toBe(7);
    expect(response.result.diagram.coeff).toBe(3);
    expect(response.result.diagram.pairs[0]).toBeInstanceOf(Float64Array);
    const cloned = structuredClone(response.result);
    expect(Array.from(cloned.diagram.pairs[0])).toEqual(
      Array.from(response.result.diagram.pairs[0]),
    );
    expect(Array.from(cloned.complex.vertices)).toEqual(
      Array.from(response.result.complex.vertices),
    );
    expect(h.control.api.load).toHaveBeenCalledWith('/tda.wasm');
    expect(h.control.api.persistence).toHaveBeenCalledWith(response.result.complex, { coeff: 3 });
  });
  it('preserves request identity across jobs', async () => {
    const h = await harness();
    h.listener({ data: request(11) });
    h.listener({ data: request(12) });
    await vi.waitFor(() => expect(h.postMessage).toHaveBeenCalledTimes(2));
    expect(h.postMessage.mock.calls.map(([r]) => r.id).sort()).toEqual([11, 12]);
  });
  it('reports an engine refusal without a partial result', async () => {
    const h = await harness();
    h.control.failNextCompute = true;
    h.listener({ data: request(21) });
    await vi.waitFor(() => expect(h.postMessage).toHaveBeenCalledTimes(1));
    expect(h.postMessage.mock.calls[0][0]).toEqual({
      type: 'error',
      id: 21,
      error: 'mock compute failure',
      name: 'Error',
    });
  });
  it('can retry after a failed load', async () => {
    const h = await harness();
    h.control.failNextInit = true;
    h.listener({ data: request(31) });
    await vi.waitFor(() => expect(h.postMessage).toHaveBeenCalledTimes(1));
    expect(h.postMessage.mock.calls[0][0]).toEqual({
      type: 'load-error',
      id: 31,
      error: 'mock init failure',
    });
    h.listener({ data: request(32) });
    await vi.waitFor(() => expect(h.postMessage).toHaveBeenCalledTimes(2));
    expect(h.postMessage.mock.calls[1][0]).toMatchObject({ type: 'result', id: 32 });
  });
  it('ignores other protocols', async () => {
    const h = await harness();
    h.listener({ data: { type: 'other' } as unknown as RipsPipelineRequest });
    await Promise.resolve();
    expect(h.postMessage).not.toHaveBeenCalled();
  });
});
