import { describe, expect, it } from 'vitest';
import { flatten, materialize } from '@topolab/tda-wasm';
import { closeCechRoundoff } from '../pipeline';

describe('full Čech roundoff closure', () => {
  const triangle = (edge: number, face: number) =>
    flatten(
      [
        { vertices: [0], filtration: 0 },
        { vertices: [1], filtration: 0 },
        { vertices: [2], filtration: 0 },
        { vertices: [0, 1], filtration: edge },
        { vertices: [0, 2], filtration: 1 },
        { vertices: [1, 2], filtration: 1 },
        { vertices: [0, 1, 2], filtration: face },
      ],
      'radius',
    );
  it('raises a one-ulp coface and leaves the original complex untouched', () => {
    const original = triangle(1 + Number.EPSILON, 1);
    const repaired = closeCechRoundoff(original);
    expect(materialize(repaired).find((s) => s.vertices.length === 3)?.filtration).toBe(
      1 + Number.EPSILON,
    );
    expect(original.filtrations[6]).toBe(1);
    expect(repaired.scale).toBe('radius');
  });
  it('rejects larger violations rather than hiding them with a global epsilon', () => {
    expect(() => closeCechRoundoff(triangle(1 + 2 * Number.EPSILON, 1))).toThrow(
      /more than one ulp/,
    );
  });
  it('does not copy or perturb a monotone complex', () => {
    const original = triangle(1, 2);
    expect(closeCechRoundoff(original)).toBe(original);
  });
});
