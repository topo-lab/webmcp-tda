import { inspectPipeline } from '../../__fixtures__/inspectPipeline';
import { materialize } from '@topolab/tda-wasm';
// @vitest-environment node
// Failure modes: an ambient bound can erase genuine flag-complex homology;
// removing that bound alone can expose cap artifacts; summaries can disagree
// with kept pairs; construction context can be lost at the store boundary.
// These real-engine cases have independent combinatorial oracles: the hexagon
// at sqrt(3) < t < 2 is an octahedral boundary, while four mutually adjacent
// points give a tetrahedron whose cap-2 boundary is filled at cap 3.
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { buildFiltration } from '../../engine/buildFiltration';
import { createTdaStore } from '../../state/tdaStore';
import { filterRealHomology, reliableBettiSlice } from '../../state/honesty';
import { TdaEngine } from '../TdaEngine';

describe('construction-aware homology against real WASM', () => {
  const engine = new TdaEngine({ createWorker: null });
  const hexagon = Array.from({ length: 6 }, (_, i) => [
    Math.cos((i * Math.PI) / 3),
    Math.sin((i * Math.PI) / 3),
  ]).flat();
  beforeAll(() => engine.load());
  afterAll(() => engine.dispose());

  it('preserves the planar hexagon Rips sphere at cap 3, including all summaries', async () => {
    const params = {
      complexType: 'rips' as const,
      maxEdgeLength: 1.8,
      maxSimplexDim: 3,
      coeff: 2,
    };
    const raw = engine.persistence(hexagon, 2, params);
    expect(materialize(raw.complex).filter((s) => s.vertices.length === 1)).toHaveLength(6);
    expect(materialize(raw.complex).filter((s) => s.vertices.length === 2)).toHaveLength(12);
    expect(materialize(raw.complex).filter((s) => s.vertices.length === 3)).toHaveLength(8);
    expect(materialize(raw.complex).filter((s) => s.vertices.length === 4)).toHaveLength(0);
    expect(inspectPipeline(raw).persistence.pairsByDimension[2]).toBe(1);
    const filtered = filterRealHomology(raw, 2, params);
    expect(inspectPipeline(filtered).persistence.pairsByDimension[2]).toBe(1);
    expect(inspectPipeline(filtered).diagram.byDimension.get(2)).toHaveLength(1);
    expect(inspectPipeline(filtered).diagram.essential.some((p) => p.dimension === 2)).toBe(true);
    const f = await buildFiltration(
      engine,
      { points: hexagon, dimension: 2, weights: Array(6).fill(0) },
      params,
    );
    expect(f.pairs.filter((p) => p.dimension === 2)).toHaveLength(1);
    expect(f.aliveAt(1.8).some((p) => p.dimension === 2)).toBe(true);
    expect(f.bettiAt(1.8)).toEqual([1, 0, 1]);
    const store = createTdaStore({ points: hexagon, dimension: 2, params });
    store.getState().finishCompute(raw);
    expect(store.getState().result?.diagram.pairs[2]).toHaveLength(2);
  });

  it('withholds a cap-2 tetrahedral boundary and verifies it fills at cap 3', async () => {
    const points = [0, 0, 1, 0, 1, 1, 0, 1];
    const cloud = { points, dimension: 2 as const, weights: Array(4).fill(0) };
    const cap2 = await buildFiltration(engine, cloud, {
      complexType: 'rips',
      maxEdgeLength: 1.5,
      maxSimplexDim: 2,
    });
    expect(cap2.rawPairs.filter((p) => p.dimension === 2)).toHaveLength(1);
    expect(cap2.pairs.some((p) => p.dimension === 2)).toBe(false);
    expect(cap2.bettiAt(1.5)).toEqual([1, 0]);
    const cap3 = await buildFiltration(engine, cloud, {
      complexType: 'rips',
      maxEdgeLength: 1.5,
      maxSimplexDim: 3,
    });
    expect(cap3.bettiAt(1.5)).toEqual([1, 0, 0]);
  });

  it('uses cap alone for flags and the ambient bound for nerves/cubical', () => {
    for (const complexType of ['rips', 'ellipsoid-rips', 'wing'] as const) {
      expect(
        reliableBettiSlice([1, 0, 1], { maxSimplexDim: 3, ambientDim: 2, complexType }),
      ).toEqual([1, 0, 1]);
    }
    for (const complexType of [
      'cech',
      'ellipsoid-cech',
      'alpha',
      'box',
      'kfold',
      'cubical',
    ] as const) {
      expect(
        reliableBettiSlice([1, 0, 1], { maxSimplexDim: 3, ambientDim: 2, complexType }),
      ).toEqual([1, 0]);
    }
  });
});
