import { beforeEach, describe, expect, it, vi } from 'vitest';
import { mockControl, CANNED_PAIRS, flatten, materialize } from '../../../__mocks__/tda-wasm';
import { diagramPairs } from '../diagram';
import type { PipelineResult } from '../../types/engine';
import type { RipsPipelineRequest, RipsPipelineResponse } from '../workerTypes';
import { TdaEngine } from '../TdaEngine';
vi.mock('@topolab/tda-wasm', () => import('../../../__mocks__/tda-wasm'));
const DEFAULT_PARAMS = {
  complexType: 'rips' as const,
  maxEdgeLength: 1,
  maxSimplexDim: 2,
  coeff: 2,
};
const CECH_PARAMS = {
  complexType: 'cech' as const,
  maxRadius: 0.75,
  maxSimplexDim: 1,
  coeff: 3,
};
const SQUARE_2D = [0, 0, 1, 0, 1, 1, 0, 1];
/** Minimal fake Worker capturing requests and answering on demand. */
class FakeWorker {
  listeners = new Map<string, Array<(event: unknown) => void>>();
  requests: RipsPipelineRequest[] = [];
  transfers: Transferable[][] = [];
  terminated = false;
  throwOnPost = false;
  autoRespond: ((req: RipsPipelineRequest) => RipsPipelineResponse) | null = null;

  addEventListener(type: string, listener: (event: unknown) => void) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type)!.push(listener);
  }

  postMessage(request: RipsPipelineRequest, transfer: Transferable[] = []) {
    if (this.throwOnPost) throw new Error('structured clone failed');
    this.requests.push(request);
    this.transfers.push(transfer);
    if (this.autoRespond) {
      const response = this.autoRespond(request);
      queueMicrotask(() => this.emit('message', { data: response }));
    }
  }

  terminate() {
    this.terminated = true;
  }

  emit(type: string, event: unknown) {
    for (const listener of this.listeners.get(type) ?? []) listener(event);
  }
}

function workerResult(): PipelineResult {
  return {
    complex: flatten([{ vertices: [0], filtration: 0 }], 'edgeLength'),
    diagram: { pairs: [Float64Array.of(0, Infinity)], scale: 'edgeLength', coeff: 2 },
  };
}
beforeEach(() => {
  mockControl.reset();
  vi.clearAllMocks();
});

describe('0.3 runtime coordination', () => {
  it('shares one load and reports the loaded binary version', async () => {
    const engine = new TdaEngine({ createWorker: null, wasmUrl: '/tda.wasm' });
    const first = engine.load();
    expect(engine.load()).toBe(first);
    await first;
    expect(mockControl.api.load).toHaveBeenCalledTimes(1);
    expect(mockControl.api.load).toHaveBeenCalledWith('/tda.wasm');
    expect(engine.runtimeVersion()).toBe('0.3.0');
  });
  it('allows retry after loading fails', async () => {
    mockControl.failNextInit = true;
    const engine = new TdaEngine({ createWorker: null });
    await expect(engine.load()).rejects.toThrow('mock init failure');
    expect(engine.isReady()).toBe(false);
    await engine.load();
    expect(engine.isReady()).toBe(true);
  });
  it('requires load() before synchronous and asynchronous work', async () => {
    const engine = new TdaEngine({ createWorker: null });
    expect(() => engine.persistence(SQUARE_2D, 2, DEFAULT_PARAMS)).toThrow(/Call load\(\) first/);
    await expect(engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS)).rejects.toThrow(
      /Call load\(\) first/,
    );
  });
  it('keeps one typed diagram and reduces the exact Rips skeleton', async () => {
    const engine = new TdaEngine({ createWorker: null });
    await engine.load();
    const result = engine.persistence(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(materialize(result.complex).length).toBeGreaterThan(0);
    expect(diagramPairs(result.diagram)).toEqual(CANNED_PAIRS);
    expect(Object.keys(result).sort()).toEqual(['complex', 'diagram']);
    expect(mockControl.api.ripsComplex).toHaveBeenCalledWith(
      { coords: new Float64Array(SQUARE_2D), d: 2 },
      { maxEdgeLength: 1, maxSimplexDim: 2 },
    );
    expect(mockControl.api.persistence).toHaveBeenCalledWith(result.complex, { coeff: 2 });
  });
  it('uses full Čech and leaves weighted alpha embedding to the adapter', async () => {
    const engine = new TdaEngine({ createWorker: null });
    await engine.load();
    const result = engine.persistence(SQUARE_2D, 2, CECH_PARAMS);
    // The Čech cutoff is a radius and reaches the engine as maxRadius, unchanged.
    expect(mockControl.api.cechComplex).toHaveBeenCalledWith(
      { coords: new Float64Array(SQUARE_2D), d: 2 },
      { maxRadius: 0.75, maxSimplexDim: 1 },
    );
    expect(mockControl.api.persistence).toHaveBeenCalledWith(result.complex, { coeff: 3 });
    expect(() =>
      engine.persistence(SQUARE_2D, 2, { complexType: 'alpha', maxSimplexDim: 2, coeff: 2 }),
    ).toThrow(/buildFiltration/);
  });
  it('does not unload a runtime used by another coordinator; supports effect remount', async () => {
    const a = new TdaEngine(),
      b = new TdaEngine();
    await Promise.all([a.load(), b.load()]);
    a.dispose();
    expect(a.isReady()).toBe(false);
    expect(b.isReady()).toBe(true);
    expect(mockControl.api.unload).not.toHaveBeenCalled();
    expect(() => b.persistence(SQUARE_2D, 2, DEFAULT_PARAMS)).not.toThrow();
    await a.load();
    expect(a.isReady()).toBe(true);
  });
  it('cancels a load overtaken by disposal and then remounts safely', async () => {
    const engine = new TdaEngine();
    const old = engine.load();
    engine.dispose();
    const remount = engine.load();
    await expect(old).rejects.toMatchObject({ name: 'AbortError' });
    await remount;
    expect(engine.isReady()).toBe(true);
  });
});

describe('worker requests and failure boundaries', () => {
  it('uses a worker, transfers only a job-owned coordinate copy, and preserves typed arrays', async () => {
    const worker = new FakeWorker();
    worker.autoRespond = (req) => ({ type: 'result', id: req.id, result: workerResult() });
    const engine = new TdaEngine({
      createWorker: () => worker as unknown as Worker,
      wasmUrl: '/tda.wasm',
    });
    await engine.load();
    const result = await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(result).toEqual(workerResult());
    expect(worker.requests[0].wasmUrl).toBe('/tda.wasm');
    expect(worker.requests[0]).toMatchObject({ maxEdgeLength: 1, maxSimplexDim: 2, coeff: 2 });
    expect(worker.transfers[0]).toEqual([worker.requests[0].points.buffer]);
    expect(SQUARE_2D).toHaveLength(8);
    expect(mockControl.api.ripsComplex).not.toHaveBeenCalled();
  });
  it('rejects computation refusals without retrying on the main thread', async () => {
    const worker = new FakeWorker();
    worker.autoRespond = (req) => ({
      type: 'error',
      id: req.id,
      error: 'invalid cap',
      name: 'RangeError',
    });
    const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
    await engine.load();
    await expect(engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS)).rejects.toMatchObject({
      name: 'RangeError',
      message: 'invalid cap',
    });
    await expect(engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS)).rejects.toBeInstanceOf(
      RangeError,
    );
    expect(mockControl.api.ripsComplex).not.toHaveBeenCalled();
  });
  it.each([
    ['RangeError', RangeError],
    ['TypeError', TypeError],
    ['Error', Error],
  ] as const)('rebuilds a worker %s with its own class and message', async (name, ErrorClass) => {
    const worker = new FakeWorker();
    worker.autoRespond = (req) => ({ type: 'error', id: req.id, error: `bad ${name}`, name });
    const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
    await engine.load();
    const error = await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS).then(
      () => null,
      (e: unknown) => e,
    );
    expect(error).toBeInstanceOf(ErrorClass);
    expect(error).toMatchObject({ name, message: `bad ${name}` });
    if (ErrorClass === Error) {
      expect(error).not.toBeInstanceOf(RangeError);
      expect(error).not.toBeInstanceOf(TypeError);
    }
  });
  it('rebuilds an unknown worker error name as an Error that keeps the name', async () => {
    const worker = new FakeWorker();
    worker.autoRespond = (req) => ({ type: 'error', id: req.id, error: 'odd', name: 'OddError' });
    const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
    await engine.load();
    const error = await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS).then(
      () => null,
      (e: unknown) => e,
    );
    expect(error).toBeInstanceOf(Error);
    expect(error).toMatchObject({ name: 'OddError', message: 'odd' });
  });
  it.each(['toString', 'constructor', '__proto__'])(
    'rebuilds a worker error named %s as an Error, not an inherited property',
    async (name) => {
      const worker = new FakeWorker();
      worker.autoRespond = (req) => ({ type: 'error', id: req.id, error: 'odd', name });
      const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
      await engine.load();
      const error = await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS).then(
        () => null,
        (e: unknown) => e,
      );
      expect(error).toBeInstanceOf(Error);
      expect(error).toMatchObject({ name, message: 'odd' });
    },
  );
  it('falls back to the main thread when the worker cannot load the runtime, then retires it', async () => {
    const worker = new FakeWorker();
    worker.autoRespond = (req) => ({
      type: 'load-error',
      id: req.id,
      error: 'failed to fetch /missing/tda.wasm',
    });
    const factory = vi.fn(() => worker as unknown as Worker);
    const engine = new TdaEngine({ createWorker: factory, wasmUrl: '/missing/tda.wasm' });
    await engine.load();
    const result = await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(diagramPairs(result.diagram)).toEqual(CANNED_PAIRS);
    expect(mockControl.api.ripsComplex).toHaveBeenCalledTimes(1);
    expect(worker.terminated).toBe(true);
    await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(worker.requests).toHaveLength(1);
    expect(factory).toHaveBeenCalledTimes(1);
    expect(mockControl.api.ripsComplex).toHaveBeenCalledTimes(2);
  });
  it('falls back after a transport error, then retires the failed worker', async () => {
    const worker = new FakeWorker();
    const factory = vi.fn(() => worker as unknown as Worker);
    const engine = new TdaEngine({ createWorker: factory });
    await engine.load();
    const pending = engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    worker.emit('error', { message: 'worker crashed' });
    expect(diagramPairs((await pending).diagram)).toEqual(CANNED_PAIRS);
    await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(worker.terminated).toBe(true);
    expect(factory).toHaveBeenCalledTimes(1);
  });
  it('falls back on postMessage failure and does not retry the worker', async () => {
    const worker = new FakeWorker();
    worker.throwOnPost = true;
    const factory = vi.fn(() => worker as unknown as Worker);
    const engine = new TdaEngine({ createWorker: factory });
    await engine.load();
    await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(factory).toHaveBeenCalledTimes(1);
    expect(worker.terminated).toBe(true);
  });
  it('settles every pending request on disposal and never falls back from cancellation', async () => {
    const worker = new FakeWorker();
    const engine = new TdaEngine({ createWorker: () => worker as unknown as Worker });
    await engine.load();
    const a = engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS),
      b = engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    engine.dispose();
    await expect(a).rejects.toMatchObject({ name: 'AbortError' });
    await expect(b).rejects.toMatchObject({ name: 'AbortError' });
    expect(worker.terminated).toBe(true);
    expect(mockControl.api.ripsComplex).not.toHaveBeenCalled();
  });
  it('ignores stale IDs and reuses the worker for subsequent jobs', async () => {
    const worker = new FakeWorker();
    const factory = vi.fn(() => worker as unknown as Worker);
    const engine = new TdaEngine({ createWorker: factory });
    await engine.load();
    let settled = false;
    const pending = engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS).then((r) => {
      settled = true;
      return r;
    });
    worker.emit('message', { data: { type: 'result', id: 999, result: workerResult() } });
    await Promise.resolve();
    expect(settled).toBe(false);
    worker.emit('message', {
      data: { type: 'result', id: worker.requests[0].id, result: workerResult() },
    });
    await pending;
    worker.autoRespond = (req) => ({ type: 'result', id: req.id, result: workerResult() });
    await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(factory).toHaveBeenCalledTimes(1);
  });
  it('uses the main thread when workers are absent or an unshareable source was supplied', async () => {
    vi.stubGlobal('Worker', undefined);
    try {
      const engine = new TdaEngine();
      await engine.load();
      expect(
        diagramPairs((await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS)).diagram),
      ).toEqual(CANNED_PAIRS);
      const factory = vi.fn();
      const bytesEngine = new TdaEngine({ wasmSource: new Uint8Array(), createWorker: factory });
      await bytesEngine.load();
      await bytesEngine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
      expect(factory).not.toHaveBeenCalled();
    } finally {
      vi.unstubAllGlobals();
    }
  });
  it('runs Čech on the main thread and retires a throwing worker factory', async () => {
    const factory = vi.fn(() => {
      throw new Error('blocked');
    });
    const engine = new TdaEngine({ createWorker: factory });
    await engine.load();
    await engine.persistenceAsync(SQUARE_2D, 2, CECH_PARAMS);
    expect(factory).not.toHaveBeenCalled();
    await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    await engine.persistenceAsync(SQUARE_2D, 2, DEFAULT_PARAMS);
    expect(factory).toHaveBeenCalledTimes(1);
  });
});
