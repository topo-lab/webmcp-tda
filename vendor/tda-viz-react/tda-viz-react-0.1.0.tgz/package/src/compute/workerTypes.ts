import type { PipelineResult } from '../types/engine';

/**
 * Message protocol between TdaEngine and the Rips worker.
 * Only Rips runs off-thread. Native Complex and Diagram typed arrays are
 * structured-cloned once at the worker boundary.
 */
export interface RipsPipelineRequest {
  type: 'rips-pipeline';
  id: number;
  /** Transferred, not copied. */
  points: Float64Array;
  dimension: number;
  maxEdgeLength: number;
  maxSimplexDim: number;
  coeff: number;
  /** Optional URL for tda.wasm inside the worker. */
  wasmUrl?: string;
}

/**
 * What the Rips worker sends back: a completed pipeline result, an engine
 * refusal (`error`, rethrown to the caller), or a failure to load the runtime
 * (`load-error`, after which the coordinator falls back to the main thread).
 */
export type RipsPipelineResponse =
  | { type: 'result'; id: number; result: PipelineResult; runtimeVersion?: string }
  | { type: 'error'; id: number; error: string; name?: string }
  | { type: 'load-error'; id: number; error: string };
