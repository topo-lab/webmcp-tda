/** A worker has its own realm and therefore its own 0.3 runtime. */
import { load, version } from '@topolab/tda-wasm';
import { skeletonPersistence } from './pipeline';
import type { RipsPipelineRequest, RipsPipelineResponse } from './workerTypes';

const scope = globalThis as unknown as {
  addEventListener(type: 'message', listener: (event: { data: RipsPipelineRequest }) => void): void;
  postMessage(message: RipsPipelineResponse): void;
};

async function handleRequest(request: RipsPipelineRequest): Promise<void> {
  if (request?.type !== 'rips-pipeline') return;
  try {
    await load(request.wasmUrl);
  } catch (error) {
    scope.postMessage({
      type: 'load-error',
      id: request.id,
      error: error instanceof Error ? error.message : String(error),
    });
    return;
  }
  try {
    const result = skeletonPersistence(
      { coords: request.points, d: request.dimension },
      {
        complexType: 'rips',
        maxEdgeLength: request.maxEdgeLength,
        maxSimplexDim: request.maxSimplexDim,
        coeff: request.coeff,
      },
    );
    scope.postMessage({ type: 'result', id: request.id, result, runtimeVersion: version() });
  } catch (error) {
    scope.postMessage({
      type: 'error',
      id: request.id,
      error: error instanceof Error ? error.message : String(error),
      name: error instanceof Error ? error.name : 'Error',
    });
  }
}
scope.addEventListener('message', (event) => {
  void handleRequest(event.data);
});
