import { load, isLoaded, version } from '@topolab/tda-wasm';
import type { LoadSource } from '@topolab/tda-wasm';
import type { PipelineResult, RipsTdaParams, TdaParams } from '../types/engine';
import { skeletonPersistence } from './pipeline';
import type { RipsPipelineRequest, RipsPipelineResponse } from './workerTypes';

/** Runtime source and optional worker factory for one coordinator. */
export interface TdaEngineOptions {
  /** Public tda.wasm URL, used on the main thread and in the worker. */
  wasmUrl?: string;
  /** An alternative main-thread source. With no wasmUrl, workers are disabled. */
  wasmSource?: LoadSource;
  /** undefined uses a module worker; null disables workers. */
  createWorker?: (() => Worker | null) | null;
}

function defaultWorkerFactory(): Worker | null {
  if (typeof Worker === 'undefined') return null;
  return new Worker(new URL('./rips.worker.ts', import.meta.url), { type: 'module' });
}

class WorkerTransportError extends Error {}

/** The engine throws only these classes; anything else becomes an Error keeping its name. */
const WORKER_ERROR_CLASSES: Record<string, ErrorConstructor> = { RangeError, TypeError, Error };

function rebuildWorkerError(name: string | undefined, message: string): Error {
  const ErrorClass =
    (name && Object.hasOwn(WORKER_ERROR_CLASSES, name) && WORKER_ERROR_CLASSES[name]) || Error;
  const error = new ErrorClass(message);
  if (name && error.name !== name) error.name = name;
  return error;
}
interface WorkerJob {
  resolve: (result: PipelineResult | null) => void;
  reject: (error: Error) => void;
}

/** App/worker coordination. The 0.3 runtime itself has application lifetime. */
export class TdaEngine {
  private loadPromise: Promise<void> | null = null;
  private ready = false;
  private generation = 0;
  private ripsWorker: Worker | null = null;
  private ripsWorkerUnavailable = false;
  private requestId = 0;
  private jobs = new Map<number, WorkerJob>();

  constructor(private readonly options: TdaEngineOptions = {}) {}

  /** Load the application runtime; concurrent calls share one load. */
  load(): Promise<void> {
    if (this.loadPromise) return this.loadPromise;
    const generation = this.generation;
    const pending = load(this.options.wasmSource ?? this.options.wasmUrl)
      .then(() => {
        if (generation !== this.generation)
          throw new DOMException('Engine load cancelled', 'AbortError');
        this.ready = true;
      })
      .catch((error: unknown) => {
        if (generation === this.generation) this.loadPromise = null;
        throw error;
      });
    this.loadPromise = pending;
    return pending;
  }

  /** Whether this coordinator and the underlying runtime are ready. */
  isReady(): boolean {
    return this.ready && isLoaded();
  }

  /** Refuse computation until this coordinator has loaded. */
  ensureReady(): void {
    if (!this.isReady()) throw new Error('TdaEngine is not ready. Call load() first.');
  }

  /** Read the loaded binary version, rather than package metadata. */
  runtimeVersion(): string {
    this.ensureReady();
    return version();
  }

  /** The displayed Rips or full Čech skeleton and its diagram, computed synchronously. */
  persistence(points: number[], dimension: number, params: TdaParams): PipelineResult {
    this.ensureReady();
    return skeletonPersistence({ coords: new Float64Array(points), d: dimension }, params);
  }

  /** `persistence`, with Rips in a worker when available; falls back to the main thread if the worker fails. */
  async persistenceAsync(
    points: number[],
    dimension: number,
    params: TdaParams,
  ): Promise<PipelineResult> {
    this.ensureReady();
    const generation = this.generation;
    if (params.complexType === 'rips') {
      try {
        const result = await this.ripsInWorker(points, dimension, params);
        if (generation !== this.generation) throw new DOMException('Engine disposed', 'AbortError');
        if (result) return result;
      } catch (error) {
        if (!(error instanceof WorkerTransportError)) throw error;
        // A failed transport or a worker that cannot load the runtime falls back.
        // Engine refusals keep their class and message.
      }
    }
    if (generation !== this.generation) throw new DOMException('Engine disposed', 'AbortError');
    return this.persistence(points, dimension, params);
  }

  private getWorker(): Worker | null {
    if (this.ripsWorkerUnavailable || this.options.createWorker === null) return null;
    if (this.options.wasmSource !== undefined && this.options.wasmUrl === undefined) return null;
    if (this.ripsWorker) return this.ripsWorker;
    try {
      const worker = (this.options.createWorker ?? defaultWorkerFactory)();
      if (!worker) {
        this.ripsWorkerUnavailable = true;
        return null;
      }
      worker.addEventListener('message', this.handleWorkerMessage as unknown as EventListener);
      worker.addEventListener('error', this.handleWorkerError as unknown as EventListener);
      worker.addEventListener('messageerror', this.handleWorkerError as unknown as EventListener);
      this.ripsWorker = worker;
      return worker;
    } catch (error) {
      this.disableWorker(new WorkerTransportError(String(error)));
      return null;
    }
  }

  private handleWorkerMessage = (event: { data: RipsPipelineResponse }) => {
    const response = event.data;
    const job = this.jobs.get(response.id);
    if (!job) return;
    if (response.type === 'load-error') {
      this.disableWorker(new WorkerTransportError(response.error));
      return;
    }
    this.jobs.delete(response.id);
    if (response.type === 'result') job.resolve(response.result);
    else job.reject(rebuildWorkerError(response.name, response.error));
  };

  private handleWorkerError = (event: { message?: string }) => {
    this.disableWorker(new WorkerTransportError(event.message ?? 'Worker transport failed'));
  };

  private disableWorker(error: Error): void {
    this.ripsWorkerUnavailable = true;
    this.ripsWorker?.terminate();
    this.ripsWorker = null;
    for (const job of this.jobs.values()) job.reject(error);
    this.jobs.clear();
  }

  private ripsInWorker(
    points: number[],
    dimension: number,
    params: RipsTdaParams,
  ): Promise<PipelineResult | null> {
    const worker = this.getWorker();
    if (!worker) return Promise.resolve(null);
    const id = ++this.requestId;
    const pointArray = new Float64Array(points); // transfer only this job's copy
    const request: RipsPipelineRequest = {
      type: 'rips-pipeline',
      id,
      points: pointArray,
      dimension,
      maxEdgeLength: params.maxEdgeLength,
      maxSimplexDim: params.maxSimplexDim,
      coeff: params.coeff,
      wasmUrl: this.options.wasmUrl,
    };
    return new Promise((resolve, reject) => {
      this.jobs.set(id, { resolve, reject });
      try {
        worker.postMessage(request, [pointArray.buffer]);
      } catch (error) {
        this.disableWorker(new WorkerTransportError(String(error)));
      }
    });
  }

  /** Release this coordinator. Never unload a runtime shared by other providers. */
  dispose(): void {
    this.generation++;
    this.ready = false;
    this.loadPromise = null;
    this.disableWorker(new DOMException('Engine disposed', 'AbortError'));
    this.ripsWorkerUnavailable = false;
  }
}
