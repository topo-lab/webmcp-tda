import type { Diagram } from '@topolab/tda-wasm';
import type { PersistencePair } from '../types/engine';

/** Materialize only at the renderer boundary; Diagram remains authoritative. */
export function diagramPairs(diagram: Diagram): PersistencePair[] {
  const result: PersistencePair[] = [];
  diagram.pairs.forEach((pairs, dimension) => {
    for (let i = 0; i < pairs.length; i += 2) {
      result.push({ dimension, birth: pairs[i], death: pairs[i + 1] });
    }
  });
  return result;
}
