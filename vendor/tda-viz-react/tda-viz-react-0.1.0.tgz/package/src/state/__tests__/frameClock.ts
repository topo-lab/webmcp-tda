/**
 * A deterministic frame clock for tests: it stands in for `requestAnimationFrame`
 * and `cancelAnimationFrame`, and reports how many callbacks are pending, so an
 * invariant can be asserted from OUTSIDE the registry — by counting the frames
 * the whole tree is waiting on rather than trusting anyone's bookkeeping.
 *
 * Three copies of this lived in the tests (the registry's own, the Atlas loop
 * test, the Atlas flash test), and none of them could say what a tab that went
 * away does. `hide()` does: rAF stops, time does not, exactly as a browser holds
 * a hidden tab.
 *
 * React-free on purpose. A test that renders passes `act` as `around`, so React
 * commits between steps instead of at the end of one long batch — which is what
 * lets an effect that depends on the last step's state see it.
 *
 * Fake timers are optional and are driven when present: with
 * `vi.useFakeTimers({ toFake: [...] })` active, every step also moves them, so
 * a `setInterval` and the frames stay on one timeline. Leave `requestAnimationFrame`
 * out of `toFake`; this clock owns it.
 */
import { vi } from 'vitest';

export interface FrameClockOptions {
  /** Wrap each step, e.g. React's `act`, so state settles between steps. */
  around?: (step: () => void) => unknown;
}

export interface FrameClock {
  /** How many frame callbacks are waiting right now. */
  readonly liveCallbacks: number;
  /** Frame callbacks ever requested since the clock was installed. */
  readonly requested: number;
  /** The timestamp the next frame will not go below, in ms. */
  readonly now: number;
  /** Move time forward `ms` and run one frame. */
  advance(ms?: number): void;
  /** Move time forward `ms` in frames of `step` ms. */
  run(ms: number, step?: number): void;
  /**
   * Hide the tab for `ms`: `document.hidden` is true, `visibilitychange` fires,
   * time (and any fake timers) move on, and NO frame callback runs — then the
   * tab returns and `visibilitychange` fires again. The frame after this is the
   * first the page sees, and its timestamp carries the whole absence.
   */
  hide(ms: number): void;
  /** Drop every pending callback. */
  reset(): void;
}

function setHidden(hidden: boolean): void {
  if (hidden) {
    Object.defineProperty(document, 'hidden', { configurable: true, get: () => true });
    Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' });
  } else {
    // Back to jsdom's own getters on the prototype.
    Reflect.deleteProperty(document, 'hidden');
    Reflect.deleteProperty(document, 'visibilityState');
  }
  document.dispatchEvent(new Event('visibilitychange'));
}

export function installFrameClock({
  around = (step) => step(),
}: FrameClockOptions = {}): FrameClock {
  const pending = new Map<number, FrameRequestCallback>();
  let nextHandle = 1;
  let requested = 0;
  let now = 0;

  vi.stubGlobal('requestAnimationFrame', (callback: FrameRequestCallback) => {
    const handle = nextHandle++;
    requested++;
    pending.set(handle, callback);
    return handle;
  });
  vi.stubGlobal('cancelAnimationFrame', (handle: number) => {
    pending.delete(handle);
  });

  const moveTime = (ms: number) => {
    now += ms;
    if (vi.isFakeTimers()) vi.advanceTimersByTime(ms);
  };

  const runFrame = () => {
    const due = [...pending.values()];
    pending.clear();
    for (const callback of due) callback(now);
  };

  const advance = (ms = 16) => {
    around(() => {
      moveTime(ms);
      runFrame();
    });
  };

  return {
    get liveCallbacks() {
      return pending.size;
    },
    get requested() {
      return requested;
    },
    get now() {
      return now;
    },
    advance,
    run(ms, step = 16) {
      for (let left = ms; left > 1e-9; left -= step) advance(Math.min(step, left));
    },
    hide(ms) {
      around(() => setHidden(true));
      around(() => moveTime(ms));
      around(() => setHidden(false));
    },
    reset() {
      pending.clear();
    },
  };
}
