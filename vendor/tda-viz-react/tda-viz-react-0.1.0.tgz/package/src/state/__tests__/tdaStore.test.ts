import { diagramFromPairs, inspectPipeline } from '../../__fixtures__/inspectPipeline';
import { describe, expect, it } from 'vitest';
import type { PersistencePair } from '../../types/engine';

import type { PipelineResult } from '../../types/engine';
import { DEFAULT_MAX_SIMPLEX_DIM } from '../honesty';
import { DEFAULT_TDA_PARAMS, createTdaStore } from '../tdaStore';

function pair(dimension: number, birth: number, death: number): PersistencePair {
  return { dimension, birth, death };
}

function pipelineResult(pairs: PersistencePair[]): PipelineResult {
  return {
    complex: {
      vertices: new Int32Array(),
      offsets: Uint32Array.of(0),
      filtrations: new Float64Array(),
      scale: 'value',
    },
    diagram: diagramFromPairs(pairs),
  };
}

describe('createTdaStore (headless state layer, SPEC.md §2)', () => {
  it('is a vanilla zustand store — usable without React', () => {
    const store = createTdaStore();
    expect(typeof store.getState).toBe('function');
    expect(typeof store.subscribe).toBe('function');
  });

  it('starts idle with spec defaults', () => {
    const s = createTdaStore().getState();
    expect(s.points).toEqual([]);
    expect(s.dimension).toBe(2);
    expect(s.params).toEqual(DEFAULT_TDA_PARAMS);
    expect(s.params.maxSimplexDim).toBe(DEFAULT_MAX_SIMPLEX_DIM);
    expect(s.params.coeff).toBe(2);
    expect(s.status).toBe('idle');
    expect(s.result).toBeNull();
    expect(s.rawResult).toBeNull();
    expect(s.error).toBeNull();
  });

  it('setPoints stores the cloud and invalidates stale results', () => {
    const store = createTdaStore();
    store.getState().finishCompute(pipelineResult([pair(0, 0, Infinity)]));
    store.getState().setPoints([0, 0, 1, 0, 0, 1], 2);
    const s = store.getState();
    expect(s.points).toEqual([0, 0, 1, 0, 0, 1]);
    expect(s.dimension).toBe(2);
    expect(s.status).toBe('idle');
    expect(s.result).toBeNull();
    expect(s.rawResult).toBeNull();
  });

  it('setParams merges partial params and invalidates stale results', () => {
    const store = createTdaStore();
    store.getState().finishCompute(pipelineResult([pair(0, 0, Infinity)]));
    store.getState().setParams({ complexType: 'cech', maxRadius: 0.8 });
    const s = store.getState();
    // Čech's cutoff is a radius; the Rips edge length does not travel with it.
    expect(s.params).toEqual({
      complexType: 'cech',
      maxRadius: 0.8,
      maxSimplexDim: DEFAULT_MAX_SIMPLEX_DIM,
      coeff: 2,
    });
    expect(s.result).toBeNull();
    expect(s.status).toBe('idle');
  });

  it('startCompute marks computing and clears prior error', () => {
    const store = createTdaStore();
    store.getState().failCompute('boom');
    store.getState().startCompute();
    const s = store.getState();
    expect(s.status).toBe('computing');
    expect(s.error).toBeNull();
  });

  it('finishCompute stores the raw result AND the honesty-filtered result', () => {
    const store = createTdaStore();
    store.getState().setPoints([0, 0, 1, 0, 0, 1], 2);
    const raw = pipelineResult([
      pair(0, 0, Infinity),
      pair(1, 0.4, 0.9),
      pair(2, 0.6, 0.7), // truncation artifact in ambient 2D — must be filtered
    ]);
    store.getState().finishCompute(raw);
    const s = store.getState();
    expect(s.status).toBe('ready');
    expect(s.rawResult).toBe(raw);
    expect(s.result).not.toBeNull();
    expect(
      inspectPipeline(s.result!).persistence.pairs.filter((p) => p.dimension >= 2),
    ).toHaveLength(0);
    expect(
      inspectPipeline(s.rawResult!).persistence.pairs.filter((p) => p.dimension >= 2),
    ).toHaveLength(1);
  });

  it('failCompute records the error as a real state (never a synthesized result)', () => {
    const store = createTdaStore();
    store.getState().startCompute();
    store.getState().failCompute('wasm exploded');
    const s = store.getState();
    expect(s.status).toBe('error');
    expect(s.error).toBe('wasm exploded');
    expect(s.result).toBeNull();
    expect(s.rawResult).toBeNull();
  });

  it('reset returns to the initial state', () => {
    const store = createTdaStore();
    store.getState().setPoints([1, 2], 2);
    store.getState().failCompute('x');
    store.getState().reset();
    const s = store.getState();
    expect(s.points).toEqual([]);
    expect(s.status).toBe('idle');
    expect(s.error).toBeNull();
  });
});
