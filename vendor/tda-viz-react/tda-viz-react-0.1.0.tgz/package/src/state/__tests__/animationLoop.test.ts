/**
 * The one-loop invariant, asserted from the outside: by counting the
 * animation-frame callbacks pending on the global, not by trusting the
 * registry's own bookkeeping. A stray `requestAnimationFrame` that bypassed
 * the registry would show up here as a second pending callback.
 */
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  activeLoopCount,
  activeLoopId,
  startAnimationLoop,
  stopAnimationLoop,
} from '../animationLoop';

/** A controllable rAF that also reports how many callbacks are pending. */
function installFrameClock() {
  const pending = new Map<number, FrameRequestCallback>();
  let nextHandle = 1;
  let now = 0;

  vi.stubGlobal('requestAnimationFrame', (callback: FrameRequestCallback) => {
    const handle = nextHandle++;
    pending.set(handle, callback);
    return handle;
  });
  vi.stubGlobal('cancelAnimationFrame', (handle: number) => {
    pending.delete(handle);
  });

  return {
    get liveCallbacks() {
      return pending.size;
    },
    advance(ms = 16) {
      now += ms;
      const due = [...pending.entries()];
      pending.clear();
      for (const [, callback] of due) callback(now);
    },
    reset() {
      pending.clear();
    },
  };
}

let clock: ReturnType<typeof installFrameClock>;

beforeEach(() => {
  clock = installFrameClock();
});

afterEach(() => {
  stopAnimationLoop();
  clock.reset();
  vi.unstubAllGlobals();
});

describe('the animation loop registry', () => {
  it('starts empty and stops safely when nothing runs', () => {
    expect(activeLoopCount()).toBe(0);
    expect(activeLoopId()).toBeNull();
    expect(() => stopAnimationLoop()).not.toThrow();
    expect(clock.liveCallbacks).toBe(0);
  });

  it('holds at most one loop, whatever a caller does', () => {
    startAnimationLoop('a', () => {});
    expect(activeLoopCount()).toBe(1);
    expect(activeLoopId()).toBe('a');
    expect(clock.liveCallbacks).toBe(1);

    startAnimationLoop('b', () => {});
    expect(activeLoopCount()).toBe(1);
    expect(activeLoopId()).toBe('b');
    expect(clock.liveCallbacks).toBe(1);

    startAnimationLoop('c', () => {});
    startAnimationLoop('d', () => {});
    expect(activeLoopCount()).toBe(1);
    expect(clock.liveCallbacks).toBe(1);
  });

  it('stops the previous loop rather than leaving it ticking', () => {
    const first = vi.fn();
    startAnimationLoop('a', first);
    clock.advance();
    expect(first).toHaveBeenCalledTimes(1);

    startAnimationLoop('b', () => {});
    clock.advance();
    clock.advance();
    expect(first).toHaveBeenCalledTimes(1);
    expect(clock.liveCallbacks).toBe(1);
  });

  it('reports the seconds since the previous frame, and zero on the first', () => {
    const deltas: number[] = [];
    startAnimationLoop('a', (delta) => deltas.push(delta));
    clock.advance(16);
    clock.advance(32);
    clock.advance(8);
    expect(deltas[0]).toBe(0);
    expect(deltas[1]).toBeCloseTo(0.032);
    expect(deltas[2]).toBeCloseTo(0.008);
  });

  it('ignores a stale stop from a loop that has already been replaced', () => {
    const stopA = startAnimationLoop('a', () => {});
    startAnimationLoop('b', () => {});
    stopA();
    expect(activeLoopId()).toBe('b');
    expect(activeLoopCount()).toBe(1);
    expect(clock.liveCallbacks).toBe(1);
  });

  it('releases the frame when its own stop is called', () => {
    const stop = startAnimationLoop('a', () => {});
    stop();
    expect(activeLoopCount()).toBe(0);
    expect(clock.liveCallbacks).toBe(0);
  });

  it('does not re-request a frame after being stopped from inside its own tick', () => {
    startAnimationLoop('a', () => stopAnimationLoop());
    clock.advance();
    expect(activeLoopCount()).toBe(0);
    expect(clock.liveCallbacks).toBe(0);
  });
});

/**
 * A hidden tab pauses requestAnimationFrame but not time. Without a resync the
 * first frame after the tab returns carries the whole gap as its delta, and every
 * clock that integrates delta (the 24 s sweep, the lesson tween) leaps by that
 * much: a 30 s absence moves a 24 s sweep through more than a full period.
 *
 * Failure modes, listed before the code that answers them:
 *  1. the first delta after the tab returns is the hidden gap, not zero;
 *  2. the resync eats more than that one frame, so ordinary frames afterwards are wrong;
 *  3. becoming hidden disturbs the clock of a loop that is still being delivered frames;
 *  4. the visibility listener outlives the loop (stop, or replacement);
 *  5. the listener is attached twice when a loop replaces another;
 *  6. a visibility change with nothing running does anything at all.
 */
describe('a tab that was hidden', () => {
  let hidden = false;

  const setHidden = (value: boolean) => {
    hidden = value;
    document.dispatchEvent(new Event('visibilitychange'));
  };

  beforeEach(() => {
    hidden = false;
    vi.spyOn(document, 'hidden', 'get').mockImplementation(() => hidden);
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('delivers zero, not the hidden gap, on the first frame after it returns', () => {
    const deltas: number[] = [];
    startAnimationLoop('a', (delta) => deltas.push(delta));
    clock.advance(16);
    clock.advance(16);
    deltas.length = 0;

    setHidden(true);
    setHidden(false);
    clock.advance(30_000); // first frame after returning, stamped 30 s later
    clock.advance(16);
    clock.advance(16);

    expect(deltas[0]).toBe(0);
    expect(deltas[1]).toBeCloseTo(0.016);
    expect(deltas[2]).toBeCloseTo(0.016);
  });

  it('leaves the clock alone while the tab is only becoming hidden', () => {
    const deltas: number[] = [];
    startAnimationLoop('a', (delta) => deltas.push(delta));
    clock.advance(16);
    setHidden(true);
    clock.advance(16); // a frame already in flight is still delivered
    expect(deltas[1]).toBeCloseTo(0.016);
  });

  it('holds exactly one visibility listener while a loop runs, and none after', () => {
    const add = vi.spyOn(document, 'addEventListener');
    const remove = vi.spyOn(document, 'removeEventListener');
    const visibility = (spy: typeof add) =>
      spy.mock.calls.filter(([type]) => type === 'visibilitychange').length;

    const stop = startAnimationLoop('a', () => {});
    expect(visibility(add)).toBe(1);

    startAnimationLoop('b', () => {}); // replacement must not add a second listener
    expect(visibility(add) - visibility(remove)).toBe(1);

    stop(); // stale stop of a replaced loop: still one live listener
    expect(visibility(add) - visibility(remove)).toBe(1);

    stopAnimationLoop();
    expect(visibility(add) - visibility(remove)).toBe(0);
  });

  it('does nothing when no loop is running', () => {
    expect(() => {
      setHidden(true);
      setHidden(false);
    }).not.toThrow();
    expect(activeLoopCount()).toBe(0);
    expect(clock.liveCallbacks).toBe(0);
  });
});
