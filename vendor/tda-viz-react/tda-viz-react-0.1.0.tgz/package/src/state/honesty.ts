/**
 * Presentation rules for Betti numbers and truncated complexes
 * (SPEC.md §5 — correctness requirements, not style preferences).
 *
 * A cap c can leave c-cycles unfilled, so report only degrees below c unless
 * completeness is separately established. This is a computational bound.
 * A nerve of a good cover in R^d (or a cubical subset of R^d) additionally has
 * no homology in degree >= d. This geometric bound DOES NOT apply to flag
 * complexes: a planar hexagon's Rips complex can be an octahedral sphere.
 * Pass construction context to keep these two statements separate.
 *
 * ON A GRID (SPEC.md §3.1b) the same two rules apply and, unusually, neither is
 * doing the other's work. A 2D cubical complex is COMPLETE — every square that
 * belongs in it is there — so there is no truncation artifact for the cap to
 * withhold; the cap is 2 because a 2D grid has no 3-cells, not because anything
 * was left out. And the ambient bound is 2 because a thresholded subset of the
 * plane has no H2. The two coincide at k = 2, so a grid reports β0 and β1, and
 * the H2 row the T-construction's binding can emit (its cells go up to
 * dimension 2) is dropped by `filterRealHomology` / `isRealHomologyDim` for the
 * ambient reason alone. `createGridFiltration` passes 2 for both, deliberately
 * and separately.
 *
 * TODO(SPEC.md §5): port `hiddenBettiNote` and `simplexCostHint` from
 * tda-explorer when the package grows user-facing messaging for withheld
 * dimensions.
 */
import type { Diagram } from '@topolab/tda-wasm';
import type { FiltrationComplexType } from '../filtration/types';
import { FLAG_COMPLEX_TYPES } from '../filtration/guarantees';

/** A cloud construction, or the cubical subset represented by a grid. */
export type HomologyConstruction = FiltrationComplexType | 'cubical';

/** Default cap on simplex dimension: enough for H0 and H1, cheap enough to be interactive. */
export const DEFAULT_MAX_SIMPLEX_DIM = 2;
/** Lowest cap the library accepts: a 1-skeleton, so H0 only. */
export const MIN_MAX_SIMPLEX_DIM = 1;
/** Highest cap the library accepts. Above this the complex stops being interactive. */
export const MAX_MAX_SIMPLEX_DIM = 4;

/**
 * Whether a degree is compatible with the construction's geometric model.
 * Flag-complex homology is not bounded by input ambient dimension.
 * Omitted construction preserves the legacy nerve interpretation; callers
 * handling arbitrary complexes must pass it. This helper does not check caps.
 */
export function isRealHomologyDim(
  homologyDim: number,
  ambientDim: number,
  complexType?: HomologyConstruction,
): boolean {
  return homologyDim >= 0 && (isFlagConstruction(complexType) || homologyDim < ambientDim);
}

function isFlagConstruction(complexType?: HomologyConstruction): boolean {
  return (
    complexType !== undefined &&
    complexType !== 'cubical' &&
    FLAG_COMPLEX_TYPES.includes(complexType)
  );
}

/** The two bounds that decide how many Betti numbers may be shown. */
export interface ReliableBettiOptions {
  /** Highest simplex dimension the complex was (or will be) built to. */
  maxSimplexDim: number;
  /** Ambient dimension of the point cloud (2 for circle, 3 for sphere/torus). */
  ambientDim: number;
  /** Omitted means the legacy nerve interpretation, not an unknown flag complex. */
  complexType?: HomologyConstruction;
}

/**
 * How many Betti numbers are safe to show, starting at β0.
 * Returns k such that β0 … β_{k-1} are reportable as topology.
 */
export function reliableBettiLength({
  maxSimplexDim,
  ambientDim,
  complexType,
}: ReliableBettiOptions): number {
  const cap = Math.max(0, Math.floor(maxSimplexDim));
  const ambient = Math.max(0, Math.floor(ambientDim));
  return isFlagConstruction(complexType) ? cap : Math.max(0, Math.min(cap, ambient));
}

/** Slice of `betti` that may be shown as topology (never the truncated top dim). */
export function reliableBettiSlice(
  betti: number[] | undefined,
  opts: ReliableBettiOptions,
): number[] {
  if (!betti || betti.length === 0) return [];
  return betti.slice(0, reliableBettiLength(opts));
}

/**
 * Filter by construction interpretation and, when supplied, cap reliability.
 * An ambient bound applies to nerves/cubical subsets, never to flag complexes.
 * The two-argument form retains its legacy nerve interpretation. Pass both
 * construction and cap when presenting output from a capped computation.
 *
 * Recomputes persistence summary fields from the kept pairs so counts stay
 * consistent. The canonical regression: a 50-point 2D circle at cap 2 must
 * NOT report β₂ = 150.
 *
 * This function only ever *removes* computed pairs; it never invents any.
 */
export function filterRealHomology<R extends { diagram: Diagram }>(
  result: R,
  ambientDim: number,
  options: { complexType?: HomologyConstruction; maxSimplexDim?: number } = {},
): R {
  const cap =
    options.maxSimplexDim === undefined ? Infinity : Math.max(0, Math.floor(options.maxSimplexDim));
  return {
    ...result,
    diagram: {
      ...result.diagram,
      pairs: result.diagram.pairs.map((pairs, dim) =>
        dim < cap && isRealHomologyDim(dim, ambientDim, options.complexType)
          ? pairs
          : new Float64Array(),
      ),
    },
  };
}
