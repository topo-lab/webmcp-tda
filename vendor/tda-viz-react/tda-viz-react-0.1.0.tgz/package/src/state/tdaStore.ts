/**
 * Headless state layer (SPEC.md §2): point cloud, params, results, honesty
 * filtering. Vanilla Zustand — usable without React (a future native shell
 * can drive it directly). React components bind via `useStore` in their own
 * layer.
 */
import { createStore } from 'zustand/vanilla';
import type { PipelineResult, TdaParams, TdaParamsPatch } from '../types/engine';
import { DEFAULT_MAX_SIMPLEX_DIM, filterRealHomology } from './honesty';

/** Where the store is in one compute cycle. */
export type ComputeStatus = 'idle' | 'computing' | 'ready' | 'error';

/** Starting parameters: a Rips complex capped at dimension 2 over Z/2. */
export const DEFAULT_TDA_PARAMS: TdaParams = Object.freeze({
  complexType: 'rips',
  maxEdgeLength: 1,
  maxSimplexDim: DEFAULT_MAX_SIMPLEX_DIM,
  coeff: 2,
});

/** The data half of the store: input, parameters, status and results. */
export interface TdaStateData {
  /** Flat coordinates [x0, y0, (z0,) x1, ...]. */
  points: number[];
  /** Ambient dimension of the cloud. */
  dimension: number;
  params: TdaParams;
  status: ComputeStatus;
  error: string | null;
  /** Unfiltered engine output — what was actually computed. */
  rawResult: PipelineResult | null;
  /** Honesty-filtered output — what may be presented (SPEC.md §5). */
  result: PipelineResult | null;
}

/** The action half of the store. Every one of them is a synchronous state write. */
export interface TdaStateActions {
  /** Replace the cloud and its ambient dimension; clears any previous result. */
  setPoints: (points: number[], dimension: number) => void;
  /**
   * Merge parameter changes; clears any previous result. The params keep only
   * the cutoff their complex type uses (`maxEdgeLength` for Rips, `maxRadius`
   * for Čech), so a patch that switches the type should carry its cutoff.
   */
  setParams: (patch: TdaParamsPatch) => void;
  /** Mark a compute as running. */
  startCompute: () => void;
  /** Store an engine result; the honesty-filtered view is derived from it. */
  finishCompute: (raw: PipelineResult) => void;
  /** Record a compute failure. The message is a real state, never masked (SPEC.md §5). */
  failCompute: (message: string) => void;
  /** Return to the initial state, keeping nothing. */
  reset: () => void;
}

/** The whole store state: data plus actions. */
export type TdaState = TdaStateData & TdaStateActions;

const INITIAL_DATA: TdaStateData = {
  points: [],
  dimension: 2,
  params: DEFAULT_TDA_PARAMS,
  status: 'idle',
  error: null,
  rawResult: null,
  result: null,
};

/** Results computed for other inputs are stale — clear, never display. */
const INVALIDATED = {
  status: 'idle' as const,
  error: null,
  rawResult: null,
  result: null,
};

function mergeParams(params: TdaParams, patch: TdaParamsPatch): TdaParams {
  const merged: TdaParamsPatch = { ...params, ...patch };
  const maxSimplexDim = merged.maxSimplexDim ?? params.maxSimplexDim;
  const coeff = merged.coeff ?? params.coeff;
  switch (merged.complexType ?? params.complexType) {
    case 'rips':
      return { complexType: 'rips', maxEdgeLength: merged.maxEdgeLength!, maxSimplexDim, coeff };
    case 'cech':
      return { complexType: 'cech', maxRadius: merged.maxRadius!, maxSimplexDim, coeff };
    case 'alpha':
      return { complexType: 'alpha', maxSimplexDim, coeff };
  }
}

/**
 * Create a headless store. Vanilla Zustand, so it works without React; the
 * React binding lives in the hooks layer (SPEC.md §2).
 */
export function createTdaStore(initial?: Partial<TdaStateData>) {
  return createStore<TdaState>()((set) => ({
    ...INITIAL_DATA,
    ...initial,
    setPoints: (points, dimension) => set({ points, dimension, ...INVALIDATED }),
    setParams: (patch) => set((s) => ({ params: mergeParams(s.params, patch), ...INVALIDATED })),
    startCompute: () => set({ status: 'computing', error: null }),
    finishCompute: (raw) =>
      set((s) => ({
        status: 'ready',
        error: null,
        rawResult: raw,
        result: filterRealHomology(raw, s.dimension, s.params),
      })),
    failCompute: (message) =>
      set({ status: 'error', error: message, rawResult: null, result: null }),
    reset: () => set({ ...INITIAL_DATA }),
  }));
}

/** The store object `createTdaStore` returns. */
export type TdaStore = ReturnType<typeof createTdaStore>;
