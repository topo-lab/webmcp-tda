/**
 * The engine adapter (SPEC.md §2, §3.2): one engine BUILD per
 * (cloud, weights, params). Everything downstream — shapeAt, radiusAt,
 * simplicesAt, the whole UI — is a pure function of the result and t
 * (SPEC.md §1.5). Nothing here is ever called again because t moved.
 *
 * Validation happens HERE, up front, and mirrors the engine's own rules so a
 * caller sees a sentence instead of a WASM abort: negative weights, weighted
 * clouds handed to unweighted builders, 3D-only and 2D-only constructions,
 * non-positive cutoffs, coincident input for the k-fold cover. The engine
 * rejects all of those too, some of them opaquely ("Alpha complex computation
 * failed: undefined"), and the adapter must never let that reach a user.
 *
 * The checks throw as the engine does: `TypeError` for a value of the wrong
 * type, `RangeError` for a value out of range, each naming the parameter.
 *
 * The z=0 embedding of 2D clouds into the 3D-only weighted alpha binding
 * lives here and nowhere else.
 */
import * as tda from '@topolab/tda-wasm';
import type { EllipsoidAxes, PointCloud } from '@topolab/tda-wasm';
import { diagramPairs } from '../compute/diagram';
import type { TdaEngine } from '../compute/TdaEngine';
import { createFiltration } from '../filtration/createFiltration';
import { createGridFiltration } from '../filtration/createGridFiltration';
import type {
  AnyFiltration,
  BallFiltration,
  BoxFiltration,
  EllipsoidFiltration,
  Filtration,
  GridConstruction,
  GridDirection,
  GridFiltration,
  WeightedCloud,
  WingFiltration,
} from '../filtration/types';
import { DEFAULT_MAX_SIMPLEX_DIM } from '../state/honesty';

interface CommonFiltrationParams {
  /** Simplex-dimension cap (default 2, SPEC.md §1.6). */
  maxSimplexDim?: number;
  /** Coefficient field characteristic (default 2). */
  coeff?: number;
}

/** Weighted alpha: the filtration is intrinsic, so it takes no scale. */
export interface AlphaFiltrationParams extends CommonFiltrationParams {
  complexType: 'alpha';
  /**
   * Not accepted: alpha's honest cap is the triangulation's own dimension, so
   * there is nothing to choose and a supplied cap would be silently dropped.
   */
  maxSimplexDim?: undefined;
}

/** Vietoris–Rips: `maxEdgeLength` is the max edge length. Required. */
export interface RipsFiltrationParams extends CommonFiltrationParams {
  complexType: 'rips';
  maxEdgeLength?: number;
}

/** Čech: `maxRadius` is the max ball radius (the engine's MEB radius). Required. */
export interface CechFiltrationParams extends CommonFiltrationParams {
  complexType: 'cech';
  maxRadius?: number;
}

/** Witness: refused. The engine has no weighted witness filtration (§8 Q3). */
export interface WitnessFiltrationParams extends CommonFiltrationParams {
  complexType: 'witness';
}

/**
 * k-fold cover: the order-k Delaunay mosaic filtered by SQUARED radius.
 * 3D and unweighted only, and it refuses coincident input by index.
 */
export interface KFoldFiltrationParams extends CommonFiltrationParams {
  complexType: 'kfold';
  /** Cover multiplicity k ≥ 1. Needs at least k + 3 points. */
  k: number;
  /**
   * Drop simplices born after this squared radius. Cost grows quickly with k,
   * so bounding it is the usual way to keep a browser call cheap.
   */
  maxSquaredRadius?: number;
}

/** Fitting shared by both ellipsoid complexes: they grow the same ellipsoids. */
interface EllipsoidFittingParams extends CommonFiltrationParams {
  /** k, the local PCA neighbourhood. Integer ≥ 2; counts the point itself. */
  neighbors: number;
  /** Tangent-to-normal semi-axis ratio q ≥ 1, or 'pca' for singular values. */
  axes: EllipsoidAxes;
}

/** Ellipsoid Rips: a FLAG complex whose values are twice the ellipsoid radius. */
export interface EllipsoidRipsFiltrationParams extends EllipsoidFittingParams {
  complexType: 'ellipsoid-rips';
  /**
   * Cutoff in twice-radius units (the values this complex emits).
   * REQUIRED, and not because the engine demands it: every pair of ellipsoids
   * eventually touches, so an uncut build asks for the complete complex.
   */
  maxEdgeLength: number;
}

/** Ellipsoid Čech: a true nerve whose values are the ellipsoid radius. */
export interface EllipsoidCechFiltrationParams extends EllipsoidFittingParams {
  complexType: 'ellipsoid-cech';
  /**
   * Cutoff in radius units (the values this complex emits), half the
   * ellipsoid Rips cutoff that covers the same ellipsoids. REQUIRED, as for
   * ellipsoid Rips.
   */
  maxRadius: number;
}

/**
 * Ellipsoid complexes: `ellipsoid-rips` is a FLAG complex, `ellipsoid-cech`
 * is a true nerve, and both grow the same ellipsoids. Each takes its cutoff in
 * its own units: `maxEdgeLength` (twice radius) or `maxRadius` (radius).
 */
export type EllipsoidFiltrationParams =
  EllipsoidRipsFiltrationParams | EllipsoidCechFiltrationParams;

/** 2D curvature-adaptive wing complex (flag / Rips-type, never a nerve). */
export interface WingFiltrationParams extends CommonFiltrationParams {
  complexType: 'wing';
  /** Spine half-length / wing-length ratio q ∈ [0, 1]. */
  q: number;
  /** Wing angle θ ∈ (0, π/2], radians. */
  theta: number;
  /**
   * Where the normals come from, as the engine takes them: flat unit normals,
   * length 2n (exact-sampling mode), or a count k ≥ 2, the neighbourhood for
   * estimated osculating-circle normals. Both modes are drawable: `wings` reads
   * the estimated normals back out of the builder, and every wing carries where
   * its normal came from (`WingShape.normalSource`).
   */
  normals: readonly number[] | number;
  /** Omit edges with birth > maxEpsilon. */
  maxEpsilon?: number;
}

/** Box filtration: a nerve by Helly, on a grid of multiples of `stepSize`. */
export interface BoxFiltrationParams extends CommonFiltrationParams {
  complexType: 'box';
  /** π > 0: the growth increment AND the filtration grid spacing. */
  stepSize: number;
  /** Growth aggressiveness in [0, 1]; the paper's experiments use ~0.5. */
  growth: number;
  /** Stop after this many steps. Omit to run to the paper's m. */
  maxSteps?: number;
  /**
   * Keep the grown boxes so `shapeAt` can draw them. Default TRUE here: the
   * growing shape is this library's subject (SPEC.md §0). Costs
   * (steps + 1) · n box records; set false for a summary-only build.
   */
  boxes?: boolean;
}

/**
 * The cubical filtration of a GRID OF VALUES — the one construction here that
 * takes no cloud (SPEC.md §3.1b).
 *
 * It is passed WITHOUT a second argument, `buildFiltration(engine, params)`,
 * because there is no cloud to pass and an ignored parameter is worse than a
 * shorter call: a caller who hands this one a cloud has misunderstood what a
 * cubical complex is built from, and the signature should say so rather than
 * silently discard it. The grid travels in the params for the same reason the
 * box filtration's step does — it is the thing the construction is OF.
 */
export interface CubicalFiltrationParams {
  complexType: 'cubical';
  /** Row-major values, `width * height` finite numbers. */
  values: Float64Array | readonly number[];
  /** Values per row: pixels under `cubical-t`, grid vertices under `cubical-v`. */
  width: number;
  /** Rows: pixels under `cubical-t`, grid vertices under `cubical-v`. */
  height: number;
  /**
   * Which convention the values live in. REQUIRED, and deliberately without a
   * default: the two give different diagrams on the same numbers (SPEC.md
   * §1.3), so a default here would be the library quietly choosing what the
   * picture means.
   */
  construction: GridConstruction;
  /**
   * Which side of the threshold to filter by. REQUIRED for the same reason:
   * the sublevel and superlevel diagrams of one image are different diagrams,
   * and neither is the obvious one.
   */
  direction: GridDirection;
  /**
   * Prime coefficient field for either construction (default 2).
   */
  coeff?: number;
}

/** The constructions whose growing shape is a ball. */
export type BallFiltrationParams =
  AlphaFiltrationParams | RipsFiltrationParams | CechFiltrationParams | KFoldFiltrationParams;

/** Parameters for any cloud construction `buildFiltration` accepts. */
export type FiltrationParams =
  | BallFiltrationParams
  | WitnessFiltrationParams
  | EllipsoidFiltrationParams
  | WingFiltrationParams
  | BoxFiltrationParams;

function validateCloud(cloud: WeightedCloud): void {
  const { points, weights, dimension } = cloud;
  if (points.length % dimension !== 0) {
    throw new RangeError(
      `points length ${points.length} is not a multiple of dimension ${dimension}`,
    );
  }
  const count = points.length / dimension;
  if (weights.length !== count) {
    throw new RangeError(
      `weights length ${weights.length} does not match the points count ${count} ` +
        '(one weight per point; use 0 for unweighted points, SPEC.md §1.2)',
    );
  }
  for (let i = 0; i < points.length; i++) {
    if (!Number.isFinite(points[i])) {
      throw new RangeError(`coordinate at index ${i} must be finite, got ${points[i]}`);
    }
  }
  for (let i = 0; i < weights.length; i++) {
    if (!Number.isFinite(weights[i]) || weights[i] < 0) {
      throw new RangeError(
        `weight at index ${i} must be non-negative and finite, got ${weights[i]} ` +
          '(the engine rejects negative weights; the general power filtration with ' +
          'w < 0 is unreachable through tda-wasm, SPEC.md §1.2)',
      );
    }
  }
}

/**
 * Every builder except weighted alpha ignores weights at the engine boundary.
 * Handing one a weighted cloud would silently draw a DIFFERENT filtration, so
 * refuse (SPEC.md §3.2).
 */
function requireUnweighted(cloud: WeightedCloud, subject: string): void {
  if (cloud.weights.some((w) => w !== 0)) {
    throw new RangeError(
      `${subject}: this builder ignores weights at the engine boundary (SPEC.md §3.2), and ` +
        'this cloud has nonzero weights. Use complexType "alpha" (the only weighted path), ' +
        'or zero the weights explicitly to draw the unweighted filtration.',
    );
  }
}

function requireDimension(cloud: WeightedCloud, complexType: string, dimension: 2 | 3): void {
  if (cloud.dimension !== dimension) {
    const why =
      dimension === 3
        ? 'the level-by-level order-k construction relies on Edelsbrunner–Osang Theorem 5, ' +
          'which is stated for 3D point sets'
        : 'the wing construction is 2D only (Weng–Zhao §6 item 1: the 3D case is open ' +
          'research, and the engine will not attempt it)';
    throw new RangeError(
      `${complexType} requires a ${dimension}D cloud, got ${cloud.dimension}D — ${why}.`,
    );
  }
}

function requirePositive(name: string, value: unknown, complexType: string): void {
  if (value === undefined) return;
  if (typeof value !== 'number') {
    throw new TypeError(`${complexType}: ${name} must be a number, got ${typeof value}`);
  }
  if (!(value > 0) || !Number.isFinite(value)) {
    throw new RangeError(`${complexType}: ${name} must be a positive finite number, got ${value}`);
  }
}

/**
 * The k-fold cover rejects coincident input by index, because a repeated point
 * breaks the order-k mosaic. Find it here so the message names both indices.
 */
function requireDistinctPoints(cloud: WeightedCloud, complexType: string): void {
  const { points, dimension } = cloud;
  const seen = new Map<string, number>();
  for (let i = 0; i < points.length / dimension; i++) {
    const key = points.slice(i * dimension, (i + 1) * dimension).join(',');
    const previous = seen.get(key);
    if (previous !== undefined) {
      throw new RangeError(
        `${complexType}: input points ${previous} and ${i} coincide at (${key}). The engine ` +
          'rejects coincident input rather than returning a mosaic with vertices missing; ' +
          'perturb the cloud (its own fixtures jitter lattices for exactly this reason).',
      );
    }
    seen.set(key, i);
  }
}

/**
 * The grid, checked the way every other builder checks its input: up front,
 * mirroring the engine's own rules, so a caller reads a sentence instead of a
 * WASM abort (tda-wasm `validateCubicalInput`, which rejects non-positive
 * dimensions, a length mismatch and non-finite values, and whose messages this
 * anticipates rather than waits for).
 *
 * Returns the values as a `Float64Array`, copied: the filtration must not be
 * able to change under the caller's hands after it is built.
 */
function validateGrid(params: CubicalFiltrationParams): Float64Array {
  const { values, width, height, construction, direction } = params;
  if (construction !== 'cubical-t' && construction !== 'cubical-v') {
    throw new (typeof construction === 'string' ? RangeError : TypeError)(
      `cubical: construction must be 'cubical-t' (values on pixels) or 'cubical-v' ` +
        `(values on grid vertices), got ${String(construction)} — the two are different ` +
        'filtrations of the same numbers and there is no default (SPEC.md §1.3).',
    );
  }
  if (direction !== 'sublevel' && direction !== 'superlevel') {
    throw new (typeof direction === 'string' ? RangeError : TypeError)(
      `cubical: direction must be 'sublevel' ({f <= t}) or 'superlevel' ({f >= t}), got ` +
        `${String(direction)} — they are different diagrams of the same image.`,
    );
  }
  if (!Number.isInteger(width) || width < 1 || !Number.isInteger(height) || height < 1) {
    throw new RangeError(
      `cubical: width and height must be positive integers, got ${width} × ${height}`,
    );
  }
  if (values.length !== width * height) {
    throw new RangeError(
      `cubical: values has ${values.length} entries but the grid is ${width} × ${height} ` +
        `= ${width * height}. The array is read ROW-MAJOR, one row of ${width} at a time.`,
    );
  }
  const out = new Float64Array(width * height);
  for (let i = 0; i < out.length; i++) {
    const v = values[i];
    if (typeof v !== 'number' || !Number.isFinite(v)) {
      throw new (typeof v === 'number' ? RangeError : TypeError)(
        `cubical: the value at index ${i} (column ${i % width}, row ${Math.floor(i / width)}) ` +
          `must be a finite number, got ${String(v)}. A NaN or an infinity has no place in ` +
          'the value order the filtration is built from.',
      );
    }
    out[i] = v;
  }
  return out;
}

/** z=0 embedding of 2D clouds into the 3D-only weighted alpha binding. */
function toPoints3D(cloud: WeightedCloud): PointCloud {
  const coords = new Float64Array(cloud.weights.length * 3);
  for (let i = 0; i < cloud.weights.length; i++) {
    coords[3 * i] = cloud.points[i * cloud.dimension];
    coords[3 * i + 1] = cloud.points[i * cloud.dimension + 1];
    coords[3 * i + 2] = cloud.dimension === 3 ? cloud.points[i * 3 + 2] : 0;
  }
  return { coords, d: 3 };
}

/** Fused builder results include their exact computed complex. */
function withComplex<C extends tda.Complex>(result: tda.BuilderPersistence<C>): C {
  if (!result.complex) throw new Error('The engine omitted the requested complex');
  return result.complex;
}

function complexDimension(complex: tda.Complex): number {
  let dimension = 0;
  for (let i = 0; i < complex.filtrations.length; i++) {
    dimension = Math.max(dimension, complex.offsets[i + 1] - complex.offsets[i] - 1);
  }
  return dimension;
}

export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: BallFiltrationParams,
): Promise<BallFiltration>;
export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: EllipsoidFiltrationParams,
): Promise<EllipsoidFiltration>;
export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: WingFiltrationParams,
): Promise<WingFiltration>;
export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: BoxFiltrationParams,
): Promise<BoxFiltration>;
export function buildFiltration(
  engine: TdaEngine,
  cloud: WeightedCloud,
  params: FiltrationParams,
): Promise<Filtration>;
/** The grid domain: no cloud, because a cubical complex is not built from one. */
export function buildFiltration(
  engine: TdaEngine,
  params: CubicalFiltrationParams,
): Promise<GridFiltration>;

/**
 * Build the filtration for one (cloud, weights, params) — or, in the grid
 * domain, for one (grid, params). Moving t afterwards filters what is drawn;
 * it never triggers another engine call.
 */
export async function buildFiltration(
  engine: TdaEngine,
  cloudOrParams: WeightedCloud | CubicalFiltrationParams,
  maybeParams?: FiltrationParams,
): Promise<AnyFiltration> {
  engine.ensureReady();
  if (maybeParams === undefined) {
    if (
      typeof cloudOrParams !== 'object' ||
      cloudOrParams === null ||
      (cloudOrParams as CubicalFiltrationParams).complexType !== 'cubical'
    ) {
      throw new TypeError(
        'buildFiltration was called with two arguments, which is the GRID form and takes ' +
          "cubical params (`{ complexType: 'cubical', values, width, height, construction, " +
          'direction }`). Every cloud construction takes three: (engine, cloud, params).',
      );
    }
    return buildGridFiltration(engine, cloudOrParams as CubicalFiltrationParams);
  }
  const cloud = cloudOrParams as WeightedCloud;
  const params = maybeParams;
  validateCloud(cloud);
  const coeff = params.coeff ?? 2;
  const maxSimplexDim = params.maxSimplexDim ?? DEFAULT_MAX_SIMPLEX_DIM;
  const pointCount = cloud.weights.length;
  const points = { coords: new Float64Array(cloud.points), d: cloud.dimension };

  switch (params.complexType) {
    case 'witness':
      throw new RangeError(
        'witness complexes are not wired into this adapter: the engine exposes only ' +
          'the weak Euclidean witness complex, and a weighted witness filtration is ' +
          'not defined by the engine (SPEC.md §8 Q3).',
      );

    case 'alpha': {
      const diagram = tda.alphaPersistence(toPoints3D(cloud), {
        weights: cloud.weights,
        coeff,
        complex: true,
      });
      const complex = withComplex(diagram);
      return createFiltration({
        cloud,
        convention: 'alpha',
        complexType: 'alpha',
        // Alpha is not truncated by a cap: the triangulation's own dimension is
        // the honest bound for what it can resolve.
        maxSimplexDim: complexDimension(complex),
        simplices: tda.materialize(complex),
        rawPairs: diagramPairs(diagram),
      });
    }

    case 'rips':
    case 'cech': {
      const complexType = params.complexType;
      requireUnweighted(cloud, `${complexType} complexes`);
      const [cutoffName, cutoff, scale] =
        params.complexType === 'rips'
          ? ['maxEdgeLength', params.maxEdgeLength as unknown, 'the max edge length']
          : ['maxRadius', params.maxRadius as unknown, 'the max ball radius'];
      if (typeof cutoff !== 'number') {
        throw new TypeError(
          `${complexType}: ${cutoffName} (${scale}) must be a number, got ${String(cutoff)}. ` +
            'It is required: a default or unbounded scale would be an invented parameter.',
        );
      }
      if (!(cutoff > 0) || !Number.isFinite(cutoff)) {
        throw new RangeError(
          `${complexType}: ${cutoffName} (${scale}) must be a positive finite number, got ` +
            `${cutoff}. A default or unbounded scale would be an invented parameter.`,
        );
      }
      const pipeline = await engine.persistenceAsync(
        cloud.points,
        cloud.dimension,
        complexType === 'rips'
          ? { complexType, maxEdgeLength: cutoff, maxSimplexDim, coeff }
          : { complexType, maxRadius: cutoff, maxSimplexDim, coeff },
      );
      return createFiltration({
        cloud,
        convention: complexType,
        complexType,
        maxSimplexDim,
        simplices: tda.materialize(pipeline.complex),
        rawPairs: diagramPairs(pipeline.diagram),
      });
    }

    case 'kfold': {
      requireUnweighted(cloud, 'the k-fold cover complex');
      requireDimension(cloud, 'the k-fold cover complex', 3);
      if (!Number.isInteger(params.k) || params.k < 1) {
        throw new RangeError(`kfold: k must be a positive integer, got ${params.k}`);
      }
      if (pointCount < params.k + 3) {
        throw new RangeError(
          `kfold: the order-${params.k} mosaic in 3D needs at least k + 3 = ${params.k + 3} ` +
            `points, got ${pointCount}`,
        );
      }
      requirePositive('maxSquaredRadius', params.maxSquaredRadius, 'kfold');
      requireDistinctPoints(cloud, 'kfold');

      const diagram = tda.kFoldCoverPersistence(points, {
        k: params.k,
        maxSquaredRadius: params.maxSquaredRadius,
        maxSimplexDim,
        coeff,
        complex: true,
      });
      const complex = withComplex(diagram);
      return createFiltration({
        cloud,
        // Squared radius with no weights: exactly the alpha radius law, so the
        // balls are drawn at √t — around INPUT POINTS, while the vertices below
        // are k-subsets of them.
        convention: 'alpha',
        complexType: 'kfold',
        maxSimplexDim,
        simplices: tda.materialize(complex),
        rawPairs: diagramPairs(diagram),
        vertexSubsets: complex.mosaicVertices,
        // k travels with the filtration: it is a parameter of the
        // construction, and a renderer of the k-fold COVER (the region covered
        // at least k times) needs it without being told twice.
        coverMultiplicity: params.k,
      });
    }

    case 'ellipsoid-rips':
    case 'ellipsoid-cech': {
      const complexType = params.complexType;
      requireUnweighted(cloud, `${complexType} complexes`);
      if (!Number.isInteger(params.neighbors) || params.neighbors < 2) {
        throw new RangeError(
          `${complexType}: neighbors must be an integer >= 2, got ` +
            `${params.neighbors} (it counts the point itself and is clamped to n)`,
        );
      }
      if (params.axes !== 'pca' && !(Number.isFinite(params.axes) && params.axes >= 1)) {
        throw new RangeError(
          `${complexType}: axes must be a finite tangent-to-normal ratio >= 1 or 'pca', ` +
            `got ${String(params.axes)}`,
        );
      }
      if ('maxFiltration' in params) {
        throw new TypeError(
          `${complexType}: maxFiltration was removed. Pass maxEdgeLength (twice-radius ` +
            'units) for ellipsoid Rips, or maxRadius (radius units) for ellipsoid Čech.',
        );
      }
      const cutoffName = complexType === 'ellipsoid-rips' ? 'maxEdgeLength' : 'maxRadius';
      const cutoff =
        params.complexType === 'ellipsoid-rips' ? params.maxEdgeLength : params.maxRadius;
      if (!(cutoff > 0) || !Number.isFinite(cutoff)) {
        throw new RangeError(
          `${complexType}: ${cutoffName} must be a positive finite cutoff, got ` +
            `${cutoff}. Every pair of ellipsoids eventually touches, so an ` +
            'uncut build asks for the complete complex; the cutoff is in the emitted ' +
            'native units: twice radius for ellipsoid Rips, radius for ellipsoid Čech.',
        );
      }
      if (pointCount < 2) {
        throw new RangeError(`${complexType}: need at least 2 points, got ${pointCount}`);
      }

      const fitting = { neighbors: params.neighbors, axes: params.axes };
      const options = {
        ...fitting,
        maxSimplexDim,
        coeff,
        complex: true,
      };
      const diagram =
        params.complexType === 'ellipsoid-rips'
          ? tda.ellipsoidRipsPersistence(points, {
              ...options,
              maxEdgeLength: params.maxEdgeLength,
            })
          : tda.ellipsoidCechPersistence(points, { ...options, maxRadius: params.maxRadius });
      const complex = withComplex(diagram);
      const geometry = tda.ellipsoids(points, fitting);
      return createFiltration({
        cloud,
        convention: complexType === 'ellipsoid-rips' ? 'ellipsoid-2r' : 'ellipsoid-r',
        complexType,
        maxSimplexDim,
        simplices: tda.materialize(complex),
        rawPairs: diagramPairs(diagram),
        ellipsoid: { geometry, neighbors: params.neighbors, axes: params.axes },
      });
    }

    case 'wing': {
      requireUnweighted(cloud, 'the wing complex');
      requireDimension(cloud, 'the wing complex', 2);
      if (!(params.q >= 0 && params.q <= 1)) {
        throw new RangeError(`wing: q must lie in [0, 1], got ${params.q}`);
      }
      if (!(params.theta > 0 && params.theta <= Math.PI / 2)) {
        throw new RangeError(`wing: theta must lie in (0, pi/2], got ${params.theta}`);
      }
      requirePositive('maxEpsilon', params.maxEpsilon, 'wing');
      if (pointCount < 2) {
        throw new RangeError(`wing: need at least 2 points, got ${pointCount}`);
      }
      const normals: unknown = params.normals;
      if (Array.isArray(normals)) {
        if (normals.length !== pointCount * 2) {
          throw new RangeError(
            `wing: normals must be a flat 2n array, expected ${pointCount * 2} numbers, ` +
              `got ${normals.length}`,
          );
        }
        for (let i = 0; i < pointCount; i++) {
          const len2 = normals[i * 2] ** 2 + normals[i * 2 + 1] ** 2;
          if (!(len2 > 0.25 && len2 < 4) || !Number.isFinite(len2)) {
            throw new RangeError(
              `wing: the normal at point ${i} must be a finite, roughly unit vector ` +
                `(the engine requires |α|² ∈ (0.25, 4) and then normalizes), got ` +
                `(${normals[i * 2]}, ${normals[i * 2 + 1]})`,
            );
          }
        }
      } else if (typeof normals === 'number') {
        if (!Number.isInteger(normals) || normals < 2) {
          throw new RangeError(
            `wing: normals, as a neighbourhood size k, must be an integer >= 2, got ${normals}`,
          );
        }
      } else {
        throw new TypeError(
          'wing: normals must be a flat 2n array of unit normals (the exact-sampling mode) or ' +
            'a neighbourhood size k >= 2 (estimated osculating-circle normals), got ' +
            `${normals === undefined ? 'undefined' : typeof normals}. Both modes draw their ` +
            'wings; they differ in where the normal comes from, which every wing reports as ' +
            '`normalSource`.',
        );
      }

      const fitting = {
        q: params.q,
        theta: params.theta,
        normals: Array.isArray(normals) ? [...(normals as number[])] : (normals as number),
      };
      const diagram = tda.wingPersistence(points, {
        ...fitting,
        maxSimplexDim,
        maxEpsilon: params.maxEpsilon,
        coeff,
        complex: true,
      });
      const complex = withComplex(diagram);
      const geometry = tda.wings(points, fitting);
      return createFiltration({
        cloud,
        convention: 'wing-eps',
        complexType: 'wing',
        maxSimplexDim,
        simplices: tda.materialize(complex),
        rawPairs: diagramPairs(diagram),
        wing: { q: params.q, theta: params.theta, geometry },
      });
    }

    case 'box': {
      requireUnweighted(cloud, 'the box filtration');
      if (!(params.stepSize > 0) || !Number.isFinite(params.stepSize)) {
        throw new RangeError(
          `box: stepSize (π) must be a positive finite number, got ${params.stepSize}. It is ` +
            'both the growth increment and the filtration grid: every birth and death is an ' +
            'exact multiple of it.',
        );
      }
      if (!(params.growth >= 0 && params.growth <= 1)) {
        throw new RangeError(`box: growth must lie in [0, 1], got ${params.growth}`);
      }
      if (
        params.maxSteps !== undefined &&
        (!Number.isInteger(params.maxSteps) || params.maxSteps < 1)
      ) {
        throw new RangeError(`box: maxSteps must be a positive integer, got ${params.maxSteps}`);
      }
      if (pointCount < 1) {
        throw new RangeError('box: need at least 1 point');
      }

      const boxes = params.boxes ?? true;
      const diagram = tda.boxFiltrationPersistence(points, {
        stepSize: params.stepSize,
        growth: params.growth,
        maxSteps: params.maxSteps,
        maxSimplexDim,
        boxes,
        coeff,
        complex: true,
      });
      const result = withComplex(diagram);
      return createFiltration({
        cloud,
        convention: 'box-step',
        complexType: 'box',
        maxSimplexDim,
        simplices: tda.materialize(result),
        rawPairs: diagramPairs(diagram),
        box: {
          stepSize: result.stepSize,
          numSteps: result.numSteps,
          growth: result.growth,
          maxBirthStep: result.maxBirthStep,
          extents: result.boxes ?? null,
        },
      });
    }

    default: {
      const exhausted: never = params;
      throw new RangeError(`Unknown complex type: ${String(exhausted)}`);
    }
  }
}

/**
 * The grid domain (SPEC.md §3.1b). One engine call, and the same §1.5 contract
 * as every other build: moving the threshold afterwards filters what is drawn
 * and never comes back here.
 *
 * SUPERLEVEL IS THE SUBLEVEL FILTRATION OF −f. Neither cubical binding takes a
 * direction — the engine computes sublevel only — so a superlevel build negates
 * the grid, runs the identical binding, and negates the endpoints back into the
 * image's own units. The identity is exact for both constructions because
 * min(−v) = −max(v): under negation the T-construction's minimum-over-pixels
 * rule becomes a maximum and the V-construction's lower star becomes the upper
 * star, which is what a superlevel filtration is. Nothing is approximated and
 * nothing is resampled. The negation lives HERE, at the engine boundary, so
 * that everything downstream — the pairs, the renderer, the barcode — is in
 * image units and no other layer has to remember a sign.
 *
 * A superlevel diagram therefore runs DOWNWARD: birth >= death, because the
 * sweep does. That is not a defect to normalise away; it is the direction the
 * filtration goes, and `GridFiltration.containsValue` is the one predicate
 * that reads it.
 */
async function buildGridFiltration(
  engine: TdaEngine,
  params: CubicalFiltrationParams,
): Promise<GridFiltration> {
  const values = validateGrid(params);
  const { width, height, construction, direction } = params;
  const superlevel = direction === 'superlevel';
  const swept = superlevel ? Array.from(values, (v) => -v) : Array.from(values);

  engine.ensureReady();
  const diagram = tda.cubicalPersistence(
    { values: new Float64Array(swept), shape: [height, width] },
    { construction: construction === 'cubical-t' ? 'T' : 'V', coeff: params.coeff ?? 2 },
  );
  const pairs = diagramPairs(diagram);
  const rawPairs = superlevel
    ? pairs.map((p) => ({ dimension: p.dimension, birth: -p.birth, death: -p.death }))
    : pairs;

  return createGridFiltration({
    values,
    width,
    height,
    construction,
    direction,
    rawPairs,
  });
}
