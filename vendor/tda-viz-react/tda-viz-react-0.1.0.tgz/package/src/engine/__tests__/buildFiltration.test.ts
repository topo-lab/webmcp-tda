// The engine adapter (SPEC.md §3.2): one engine call per (cloud, weights,
// params); validation happens up front so the WASM boundary never fails
// opaquely.
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { mockControl } from '../../../__mocks__/tda-wasm';
import { TdaEngine } from '../../compute/TdaEngine';
import type { WeightedCloud } from '../../filtration/types';
import { buildFiltration } from '../buildFiltration';

vi.mock('@topolab/tda-wasm', () => import('../../../__mocks__/tda-wasm'));

const cloud2D = (weights: number[]): WeightedCloud => ({
  points: [0, 0, 1, 0, 0.5, 1],
  weights,
  dimension: 2,
});

async function readyEngine(): Promise<TdaEngine> {
  const engine = new TdaEngine({ createWorker: null });
  await engine.load();
  return engine;
}

beforeEach(() => {
  mockControl.reset();
  vi.clearAllMocks();
});

describe('buildFiltration: weight validation (SPEC.md §1.2)', () => {
  it('rejects a negative weight with a clear error BEFORE touching the engine', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.api;
    await expect(
      buildFiltration(engine, cloud2D([0, -0.25, 0]), { complexType: 'alpha' }),
    ).rejects.toThrow(/weight.*index 1.*non-negative.*-0\.25/i);
    expect(gudhi.alphaPersistence).not.toHaveBeenCalled();
    expect(gudhi.persistence).not.toHaveBeenCalled();
  });

  it('rejects a non-finite weight', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud2D([0, NaN, 0]), { complexType: 'alpha' }),
    ).rejects.toThrow(/weight.*index 1/i);
  });

  it('rejects a weights array that does not match the point count', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud2D([0, 0]), { complexType: 'alpha' }),
    ).rejects.toThrow(/weights.*2.*points.*3/i);
  });

  it('rejects a points array that is not a multiple of the dimension', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(
        engine,
        { points: [0, 0, 1], weights: [0], dimension: 2 },
        { complexType: 'alpha' },
      ),
    ).rejects.toThrow(/points.*multiple/i);
  });
});

describe('buildFiltration: weighted clouds route to weighted alpha ONLY (SPEC.md §3.2)', () => {
  it('THROWS for rips with any nonzero weight — silently dropping weights would draw a different filtration', async () => {
    const engine = await readyEngine();
    const gudhi = mockControl.api;
    await expect(
      buildFiltration(engine, cloud2D([0, 0.5, 0]), { complexType: 'rips', maxEdgeLength: 2 }),
    ).rejects.toThrow(/rips.*weight/i);
    expect(gudhi.ripsComplex).not.toHaveBeenCalled();
  });

  it('THROWS for cech with any nonzero weight', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud2D([0, 0.5, 0]), { complexType: 'cech', maxRadius: 2 }),
    ).rejects.toThrow(/cech.*weight/i);
  });

  it('accepts rips/cech for all-zero weights (unweighted is weighted-with-zeros)', async () => {
    const engine = await readyEngine();
    const f = await buildFiltration(engine, cloud2D([0, 0, 0]), {
      complexType: 'rips',
      maxEdgeLength: 2,
    });
    expect(f.convention).toBe('rips');
  });

  it('throws for witness: not wired in this adapter (SPEC.md §8 Q3)', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud2D([0, 0, 0]), { complexType: 'witness' }),
    ).rejects.toThrow(/witness.*not wired/i);
  });
});

describe('buildFiltration: engine routing', () => {
  it('embeds 2D weighted clouds at z=0 HERE (and passes weights through)', async () => {
    const engine = await readyEngine();
    await buildFiltration(engine, cloud2D([0.5, 0, 0.1]), { complexType: 'alpha' });
    const gudhi = mockControl.api;
    expect(gudhi.alphaPersistence).toHaveBeenCalledWith(
      { coords: new Float64Array([0, 0, 0, 1, 0, 0, 0.5, 1, 0]), d: 3 },
      { weights: [0.5, 0, 0.1], coeff: 2, complex: true },
    );
  });

  it('passes 3D clouds through without re-embedding', async () => {
    const engine = await readyEngine();
    await buildFiltration(
      engine,
      { points: [1, 2, 3, 4, 5, 6], weights: [0.2, 0], dimension: 3 },
      { complexType: 'alpha' },
    );
    const gudhi = mockControl.api;
    expect(gudhi.alphaPersistence).toHaveBeenCalledWith(
      { coords: new Float64Array([1, 2, 3, 4, 5, 6]), d: 3 },
      { weights: [0.2, 0], coeff: 2, complex: true },
    );
  });

  it('routes rips through the engine with the exact params', async () => {
    const engine = await readyEngine();
    await buildFiltration(engine, cloud2D([0, 0, 0]), {
      complexType: 'rips',
      maxEdgeLength: 0.7,
      maxSimplexDim: 3,
    });
    const gudhi = mockControl.api;
    expect(gudhi.ripsComplex).toHaveBeenCalledWith(
      { coords: new Float64Array([0, 0, 1, 0, 0.5, 1]), d: 2 },
      { maxEdgeLength: 0.7, maxSimplexDim: 3 },
    );
  });

  it('requires maxEdgeLength for rips and maxRadius for cech instead of inventing a default scale', async () => {
    const engine = await readyEngine();
    await expect(
      buildFiltration(engine, cloud2D([0, 0, 0]), { complexType: 'rips' }),
    ).rejects.toThrow(/maxEdgeLength/);
    await expect(
      buildFiltration(engine, cloud2D([0, 0, 0]), { complexType: 'cech' }),
    ).rejects.toThrow(/maxRadius/);
  });

  it('calls the engine EXACTLY ONCE per build; querying the filtration never recomputes (SPEC.md §1.5)', async () => {
    const engine = await readyEngine();
    const f = await buildFiltration(engine, cloud2D([0.5, 0, 0]), { complexType: 'alpha' });
    const gudhi = mockControl.api;
    expect(gudhi.alphaPersistence).toHaveBeenCalledTimes(1);
    expect(gudhi.persistence).not.toHaveBeenCalled();

    f.simplicesAt(0.5);
    f.radiusAt(0, 0.5);
    f.aliveAt(0.5);
    f.bettiAt(0.5);

    expect(gudhi.alphaPersistence).toHaveBeenCalledTimes(1);
    expect(gudhi.persistence).not.toHaveBeenCalled();
  });
});

describe('buildFiltration: the returned Filtration', () => {
  it('nerve-filters pairs and keeps rawPairs (mock pairs include a dim-2 artifact)', async () => {
    const engine = await readyEngine();
    const f = await buildFiltration(engine, cloud2D([0, 0, 0]), {
      complexType: 'rips',
      maxEdgeLength: 2,
    });
    expect(f.rawPairs.some((p) => p.dimension === 2)).toBe(true);
    expect(f.pairs.some((p) => p.dimension === 2)).toBe(false);
  });

  it('sets the radius convention from the complex type', async () => {
    const engine = await readyEngine();
    const alpha = await buildFiltration(engine, cloud2D([0, 0, 0]), { complexType: 'alpha' });
    expect(alpha.convention).toBe('alpha');
    const cech = await buildFiltration(engine, cloud2D([0, 0, 0]), {
      complexType: 'cech',
      maxRadius: 2,
    });
    expect(cech.convention).toBe('cech');
  });

  it("alpha's simplex-dimension cap is the triangulation's own dimension", async () => {
    const engine = await readyEngine();
    const f = await buildFiltration(engine, cloud2D([0, 0, 0]), { complexType: 'alpha' });
    expect(f.maxSimplexDim).toBe(2); // mock complex reports dimension 2
  });
});
