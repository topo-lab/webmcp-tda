// The adapter's parameter names are the engine's (docs/MIGRATION.md): each
// renamed parameter reaches the engine call under the engine's name with the
// caller's value, and each pre-check throws the engine's error class (TypeError
// for a wrong type, RangeError for an out-of-range value) naming the parameter.
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { mockControl } from '../../../__mocks__/tda-wasm';
import { TdaEngine } from '../../compute/TdaEngine';
import type { WeightedCloud } from '../../filtration/types';
import { buildFiltration, type FiltrationParams } from '../buildFiltration';

vi.mock('@topolab/tda-wasm', () => import('../../../__mocks__/tda-wasm'));

const COORDS_2D = new Float64Array([0, 0, 1, 0, 0.5, 1]);
const cloud2D = (weights = [0, 0, 0]): WeightedCloud => ({
  points: [0, 0, 1, 0, 0.5, 1],
  weights,
  dimension: 2,
});
const cloud3D = (n = 8): WeightedCloud => {
  const points: number[] = [];
  for (let i = 0; i < n; i++) points.push(i * 0.9, i * i * 0.31, Math.sin(i) * 0.77);
  return { points, weights: new Array(n).fill(0), dimension: 3 };
};

async function readyEngine(): Promise<TdaEngine> {
  const engine = new TdaEngine({ createWorker: null });
  await engine.load();
  return engine;
}

beforeEach(() => {
  mockControl.reset();
  vi.clearAllMocks();
});

describe('each renamed parameter reaches the engine under its engine name', () => {
  it('rips: maxSimplexDim and coeff', async () => {
    const engine = await readyEngine();
    await buildFiltration(engine, cloud2D(), {
      complexType: 'rips',
      maxEdgeLength: 0.7,
      maxSimplexDim: 3,
      coeff: 5,
    });
    const api = mockControl.api;
    expect(api.ripsComplex).toHaveBeenCalledWith(
      { coords: COORDS_2D, d: 2 },
      { maxEdgeLength: 0.7, maxSimplexDim: 3 },
    );
    expect(api.persistence).toHaveBeenCalledWith(expect.anything(), { coeff: 5 });
  });

  it('cech: maxRadius reaches the engine as maxRadius, with maxSimplexDim and coeff', async () => {
    const engine = await readyEngine();
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'cech',
      maxRadius: 0.8,
      maxSimplexDim: 1,
      coeff: 3,
    });
    const api = mockControl.api;
    expect(api.cechComplex).toHaveBeenCalledWith(
      { coords: COORDS_2D, d: 2 },
      { maxRadius: 0.8, maxSimplexDim: 1 },
    );
    expect(api.persistence).toHaveBeenCalledWith(expect.anything(), { coeff: 3 });
    expect(f.maxSimplexDim).toBe(1);
  });

  it('alpha: coeff', async () => {
    const engine = await readyEngine();
    await buildFiltration(engine, cloud2D(), { complexType: 'alpha', coeff: 7 });
    expect(mockControl.api.alphaPersistence).toHaveBeenCalledWith(
      { coords: new Float64Array([0, 0, 0, 1, 0, 0, 0.5, 1, 0]), d: 3 },
      { weights: [0, 0, 0], coeff: 7, complex: true },
    );
  });

  it('kfold: maxSimplexDim and coeff', async () => {
    const engine = await readyEngine();
    const cloud = cloud3D();
    await buildFiltration(engine, cloud, {
      complexType: 'kfold',
      k: 2,
      maxSimplexDim: 3,
      coeff: 3,
    });
    expect(mockControl.api.kFoldCoverPersistence).toHaveBeenCalledWith(
      { coords: new Float64Array(cloud.points), d: 3 },
      { k: 2, maxSquaredRadius: undefined, maxSimplexDim: 3, coeff: 3, complex: true },
    );
  });

  it('ellipsoid: neighbors, axes, maxSimplexDim and coeff, echoed on the filtration', async () => {
    const engine = await readyEngine();
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'ellipsoid-cech',
      neighbors: 3,
      axes: 'pca',
      maxRadius: 0.5,
      maxSimplexDim: 1,
      coeff: 3,
    });
    expect(mockControl.api.ellipsoidCechPersistence).toHaveBeenCalledWith(
      { coords: COORDS_2D, d: 2 },
      { neighbors: 3, axes: 'pca', maxSimplexDim: 1, maxRadius: 0.5, coeff: 3, complex: true },
    );
    expect(mockControl.api.ellipsoids).toHaveBeenCalledWith(
      { coords: COORDS_2D, d: 2 },
      { neighbors: 3, axes: 'pca' },
    );
    expect(f.ellipsoid).toEqual({ neighbors: 3, axes: 'pca' });
    expect(f.maxSimplexDim).toBe(1);
  });

  it('wing: normals as a count k, maxEpsilon, maxSimplexDim and coeff', async () => {
    const engine = await readyEngine();
    await buildFiltration(engine, cloud2D(), {
      complexType: 'wing',
      q: 0.5,
      theta: 1,
      normals: 3,
      maxEpsilon: 0.9,
      maxSimplexDim: 1,
      coeff: 3,
    });
    expect(mockControl.api.wingPersistence).toHaveBeenCalledWith(
      { coords: COORDS_2D, d: 2 },
      {
        q: 0.5,
        theta: 1,
        normals: 3,
        maxSimplexDim: 1,
        maxEpsilon: 0.9,
        coeff: 3,
        complex: true,
      },
    );
    expect(mockControl.api.wings).toHaveBeenCalledWith(
      { coords: COORDS_2D, d: 2 },
      { q: 0.5, theta: 1, normals: 3 },
    );
  });

  it('wing: normals as a flat array is passed as a copy of that array', async () => {
    const engine = await readyEngine();
    const normals = [1, 0, 0, 1, -1, 0];
    await buildFiltration(engine, cloud2D(), { complexType: 'wing', q: 0, theta: 1, normals });
    const options = mockControl.api.wingPersistence.mock.calls[0][1] as { normals: unknown };
    expect(options.normals).toEqual(normals);
    expect(options.normals).not.toBe(normals);
  });

  it('box: growth and boxes, echoed on the filtration as growth', async () => {
    const engine = await readyEngine();
    const f = await buildFiltration(engine, cloud2D(), {
      complexType: 'box',
      stepSize: 0.25,
      growth: 0.4,
      boxes: false,
      maxSimplexDim: 1,
      coeff: 3,
    });
    expect(mockControl.api.boxFiltrationPersistence).toHaveBeenCalledWith(
      { coords: COORDS_2D, d: 2 },
      {
        stepSize: 0.25,
        growth: 0.4,
        maxSteps: undefined,
        maxSimplexDim: 1,
        boxes: false,
        coeff: 3,
        complex: true,
      },
    );
    expect(f.box.growth).toBe(0.4);
    expect(f.box).not.toHaveProperty('alpha');
  });

  it('cubical: coeff', async () => {
    const engine = await readyEngine();
    await buildFiltration(engine, {
      complexType: 'cubical',
      values: [0, 1, 2, 3],
      width: 2,
      height: 2,
      construction: 'cubical-v',
      direction: 'sublevel',
      coeff: 3,
    });
    expect(mockControl.api.cubicalPersistence).toHaveBeenCalledWith(
      { values: new Float64Array([0, 1, 2, 3]), shape: [2, 2] },
      { construction: 'V', coeff: 3 },
    );
  });
});

describe('pre-checks throw the engine error classes and name the parameter', () => {
  const cases: [string, () => Promise<unknown>, ErrorConstructor, RegExp][] = [
    [
      'cech without maxRadius',
      async () => buildFiltration(await readyEngine(), cloud2D(), { complexType: 'cech' }),
      TypeError,
      /maxRadius/,
    ],
    [
      'cech with a non-positive maxRadius',
      async () =>
        buildFiltration(await readyEngine(), cloud2D(), { complexType: 'cech', maxRadius: 0 }),
      RangeError,
      /maxRadius/,
    ],
    [
      'rips without maxEdgeLength',
      async () => buildFiltration(await readyEngine(), cloud2D(), { complexType: 'rips' }),
      TypeError,
      /maxEdgeLength/,
    ],
    [
      'rips with an infinite maxEdgeLength',
      async () =>
        buildFiltration(await readyEngine(), cloud2D(), {
          complexType: 'rips',
          maxEdgeLength: Infinity,
        }),
      RangeError,
      /maxEdgeLength/,
    ],
    [
      'a negative weight',
      async () =>
        buildFiltration(await readyEngine(), cloud2D([0, -1, 0]), { complexType: 'alpha' }),
      RangeError,
      /weight/,
    ],
    [
      'a weighted cloud for rips',
      async () =>
        buildFiltration(await readyEngine(), cloud2D([0, 1, 0]), {
          complexType: 'rips',
          maxEdgeLength: 1,
        }),
      RangeError,
      /weights/,
    ],
    [
      'a 2D cloud for kfold',
      async () => buildFiltration(await readyEngine(), cloud2D(), { complexType: 'kfold', k: 1 }),
      RangeError,
      /3D cloud/,
    ],
    [
      'ellipsoid neighbors below 2',
      async () =>
        buildFiltration(await readyEngine(), cloud2D(), {
          complexType: 'ellipsoid-rips',
          neighbors: 1,
          axes: 2,
          maxEdgeLength: 1,
        }),
      RangeError,
      /neighbors must be an integer >= 2/,
    ],
    [
      'ellipsoid axes below 1',
      async () =>
        buildFiltration(await readyEngine(), cloud2D(), {
          complexType: 'ellipsoid-rips',
          neighbors: 3,
          axes: 0.5,
          maxEdgeLength: 1,
        }),
      RangeError,
      /axes must be/,
    ],
    [
      'wing without normals',
      async () =>
        buildFiltration(await readyEngine(), cloud2D(), {
          complexType: 'wing',
          q: 0.5,
          theta: 1,
        } as unknown as FiltrationParams),
      TypeError,
      /normals must be/,
    ],
    [
      'wing normals as a count below 2',
      async () =>
        buildFiltration(await readyEngine(), cloud2D(), {
          complexType: 'wing',
          q: 0.5,
          theta: 1,
          normals: 1,
        }),
      RangeError,
      /normals.*integer >= 2/,
    ],
    [
      'wing normals of the wrong length',
      async () =>
        buildFiltration(await readyEngine(), cloud2D(), {
          complexType: 'wing',
          q: 0.5,
          theta: 1,
          normals: [1, 0],
        }),
      RangeError,
      /normals/,
    ],
    [
      'wing maxEpsilon of zero',
      async () =>
        buildFiltration(await readyEngine(), cloud2D(), {
          complexType: 'wing',
          q: 0.5,
          theta: 1,
          normals: 3,
          maxEpsilon: 0,
        }),
      RangeError,
      /maxEpsilon/,
    ],
    [
      'box growth above 1',
      async () =>
        buildFiltration(await readyEngine(), cloud2D(), {
          complexType: 'box',
          stepSize: 0.25,
          growth: 1.5,
        }),
      RangeError,
      /growth must lie in \[0, 1\]/,
    ],
    [
      'a cubical construction that is not a construction',
      async () =>
        buildFiltration(await readyEngine(), {
          complexType: 'cubical',
          values: [0],
          width: 1,
          height: 1,
          construction: 'cubical' as 'cubical-t',
          direction: 'sublevel',
        }),
      RangeError,
      /construction/,
    ],
    [
      'a cubical value that is not a number',
      async () =>
        buildFiltration(await readyEngine(), {
          complexType: 'cubical',
          values: ['0'] as unknown as number[],
          width: 1,
          height: 1,
          construction: 'cubical-t',
          direction: 'sublevel',
        }),
      TypeError,
      /value at index 0/,
    ],
  ];

  it.each(cases)('%s', async (_name, build, ErrorClass, message) => {
    const error = await build().then(
      () => null,
      (e: unknown) => e,
    );
    expect(error).toBeInstanceOf(ErrorClass);
    expect((error as Error).name).toBe(ErrorClass.name);
    expect((error as Error).message).toMatch(message);
  });
});
