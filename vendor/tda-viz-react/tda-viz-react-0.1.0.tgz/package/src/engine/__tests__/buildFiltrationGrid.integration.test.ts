// @vitest-environment node
//
// The grid domain against the REAL tda-wasm engine (no mocks): the two cubical
// conventions, the difference between them, the direction, and the two places
// this path is easy to get quietly wrong (SPEC.md §1.3, §3.1b).
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { TdaEngine } from '../../compute/TdaEngine';
import type { GridConstruction, GridFiltration } from '../../filtration/types';
import { buildFiltration } from '../buildFiltration';

const TIMEOUT = 60_000;

/** One bar per class, as a readable string, sorted so order cannot matter. */
const bars = (f: GridFiltration): string[] =>
  [...f.pairs].map((p) => `H${p.dimension} [${p.birth}, ${p.death})`).sort();

/**
 * THE HAND-COMPUTED EXAMPLE (SPEC.md §1.3). Three low values on the main
 * diagonal of a 3 x 3, everything else high:
 *
 *     0 2 2
 *     2 0 2
 *     2 2 0
 *
 * T-CONSTRUCTION — the nine numbers are nine PIXELS. The three 0-pixels sit
 * corner to corner. Pixel (0,0) and pixel (1,1) share the grid vertex between
 * them, and in the T-construction a face takes the MINIMUM of the cells around
 * it, so that vertex is min(0, 2, 2, 0) = 0 and is present from t = 0. The same
 * holds for (1,1) and (2,2). So at t = 0 the three pixels are already ONE
 * connected piece, joined at two points, and it is contractible — no loop. At
 * t = 2 the rest of the grid arrives and fills it out to a disc. Nothing is
 * ever born and nothing ever dies except the one class that never dies:
 *   H0 [0, ∞)  — and that is the whole diagram.
 *
 * V-CONSTRUCTION — the nine numbers are nine VERTICES of a 3 x 3 lattice, and
 * every edge and square takes the MAXIMUM of its vertices. A square lattice has
 * NO DIAGONAL EDGES, so there is no edge between vertex (0,0) and vertex (1,1);
 * every path between them runs through a vertex valued 2, and every edge out of
 * a 0-vertex therefore enters at max(0, 2) = 2. At t = 0 the complex is three
 * isolated vertices: THREE components. At t = 2 everything enters at once — all
 * nine vertices, all twelve edges, all four squares — and the whole 2 x 2 block
 * is a disc, so two of the three components die there and no loop is ever born:
 *   H0 [0, ∞), H0 [0, 2), H0 [0, 2)
 *
 * One array, two conventions, three components against one. The disagreement is
 * not numerical and no threshold removes it: T reads the grid with diagonal
 * contact and V does not.
 */
const DIAGONAL3 = [0, 2, 2, 2, 0, 2, 2, 2, 0];

/**
 * A NON-SQUARE two-hole image: 11 wide, 9 tall, a low ground with two 3 x 3
 * high blocks punched out of it. One dark region, two holes, so β0 = 1 and
 * β1 = 2 at t = 0 under BOTH conventions — the blocks are far enough apart and
 * from the border that no corner contact is in play and the two constructions
 * have nothing to disagree about.
 *
 * It is non-square ON PURPOSE. `computeCubicalPersistence2D` hands GUDHI's
 * bitmap `{height, width}` where the bitmap reads its cell array with sizes[0]
 * varying fastest, so a row-major image needs `[width, height]`; on a square
 * grid the mistake is a transpose and invisible, and here it is a scramble that
 * reports three components and no loop. This library routes the T-construction
 * through the general binding for exactly that reason, and this fixture is the
 * regression.
 */
function twoHole11x9(): number[] {
  const im = new Array(99).fill(0);
  for (const [ox, oy] of [
    [2, 3],
    [6, 3],
  ]) {
    for (let dy = 0; dy < 3; dy++) {
      for (let dx = 0; dx < 3; dx++) im[(oy + dy) * 11 + ox + dx] = 1;
    }
  }
  return im;
}

/** Same image, transposed: the topology of a picture does not depend on its axes. */
function transpose(values: readonly number[], width: number, height: number): number[] {
  const out: number[] = [];
  for (let x = 0; x < width; x++) for (let y = 0; y < height; y++) out.push(values[y * width + x]);
  return out;
}

describe('the grid domain: real engine', () => {
  const engine = new TdaEngine({ createWorker: null });

  const build = (
    values: readonly number[],
    width: number,
    height: number,
    construction: GridConstruction,
    direction: 'sublevel' | 'superlevel' = 'sublevel',
  ) =>
    buildFiltration(engine, {
      complexType: 'cubical',
      values,
      width,
      height,
      construction,
      direction,
    });

  beforeAll(async () => {
    await engine.load();
  }, TIMEOUT);

  afterAll(() => {
    engine.dispose();
  });

  it(
    'the two conventions disagree on the 3x3 diagonal: T finds ONE component, V finds THREE',
    async () => {
      const t = await build(DIAGONAL3, 3, 3, 'cubical-t');
      const v = await build(DIAGONAL3, 3, 3, 'cubical-v');

      // T: the diagonal pixels meet at shared corner vertices, so they are one
      // piece from the start and nothing else ever happens.
      expect(bars(t)).toEqual(['H0 [0, Infinity)']);
      expect(t.bettiAt(0)).toEqual([1, 0]);
      expect(t.bettiAt(2)).toEqual([1, 0]);

      // V: no diagonal edge exists, so the three low vertices are three
      // components until the high value lets the edges in at 2.
      expect(bars(v)).toEqual(['H0 [0, 2)', 'H0 [0, 2)', 'H0 [0, Infinity)']);
      expect(v.bettiAt(0)).toEqual([3, 0]);
      expect(v.bettiAt(2)).toEqual([1, 0]);

      // Stated as the difference, not as two lists: at t = 0 one convention
      // sees one dark region and the other sees three.
      expect(v.bettiAt(0)[0] - t.bettiAt(0)[0]).toBe(2);

      // Same numbers, same grid, same threshold — the conventions differ and
      // nothing else does.
      expect([...v.values]).toEqual([...t.values]);
      expect(v.criticalValues).toEqual(t.criticalValues);
      expect(t.guarantee.label).not.toBe(v.guarantee.label);
    },
    TIMEOUT,
  );

  it(
    'a two-hole binary image gives beta0 = 1 and beta1 = 2, under both conventions',
    async () => {
      const image = twoHole11x9();
      for (const construction of ['cubical-t', 'cubical-v'] as const) {
        const f = await build(image, 11, 9, construction);
        expect(f.bettiAt(0), construction).toEqual([1, 2]);
        // The holes fill when the bright value arrives, and one region is left.
        expect(f.bettiAt(1), construction).toEqual([1, 0]);
        expect(
          f.pairs.filter((p) => p.dimension === 1),
          construction,
        ).toHaveLength(2);
      }
    },
    TIMEOUT,
  );

  it(
    'REGRESSION: the T-construction reads a NON-SQUARE grid along the right axis',
    async () => {
      // Transposing an image cannot change its homology. The engine's 2D
      // convenience wrapper fails this on any grid whose width and height
      // differ; the general binding this library uses passes it.
      const image = twoHole11x9();
      const upright = await build(image, 11, 9, 'cubical-t');
      const turned = await build(transpose(image, 11, 9), 9, 11, 'cubical-t');
      expect(bars(turned)).toEqual(bars(upright));
      expect(turned.bettiAt(0)).toEqual([1, 2]);
    },
    TIMEOUT,
  );

  it(
    'superlevel is the sublevel filtration of -f, with the endpoints negated back',
    async () => {
      const image = twoHole11x9();
      for (const construction of ['cubical-t', 'cubical-v'] as const) {
        const up = await build(image, 11, 9, construction, 'superlevel');
        const negated = await build(
          image.map((v) => -v),
          11,
          9,
          construction,
        );
        // The identity, asserted against the engine rather than assumed: the
        // superlevel diagram of f is the sublevel diagram of -f with every
        // endpoint negated.
        expect(bars(up), construction).toEqual(
          [...negated.pairs].map((p) => `H${p.dimension} [${-p.birth}, ${-p.death})`).sort(),
        );
        // And it runs DOWNWARD, in the image's own units.
        for (const p of up.pairs) expect(p.birth >= p.death, construction).toBe(true);
        // The bright set at t = 1 is the two blocks and nothing else.
        expect(up.bettiAt(1)[0], construction).toBe(2);
        // By t = 0 the whole image is above the threshold: one region.
        expect(up.bettiAt(0)[0], construction).toBe(1);
      }
    },
    TIMEOUT,
  );

  it(
    'one BUILD: moving the threshold never calls the engine again (SPEC.md §1.5)',
    async () => {
      const f = await build(twoHole11x9(), 11, 9, 'cubical-v');
      const before = f.pairs;
      for (const t of [0, 0.25, 0.5, 1, 2]) {
        f.bettiAt(t);
        f.aliveAt(t);
        f.containsValue(0, t);
      }
      expect(f.pairs).toBe(before);
    },
    TIMEOUT,
  );

  it(
    'V accepts prime fields and has the same planar diagram over F2 and F3',
    async () => {
      const params = {
        complexType: 'cubical' as const,
        values: DIAGONAL3,
        width: 3,
        height: 3,
        construction: 'cubical-v' as const,
        direction: 'sublevel' as const,
      };
      const f2 = await buildFiltration(engine, { ...params, coeff: 2 });
      const f3 = await buildFiltration(engine, { ...params, coeff: 3 });
      expect(f3.rawPairs).toEqual(f2.rawPairs);
      await expect(buildFiltration(engine, { ...params, coeff: 4 })).rejects.toThrow(/prime/);
    },
    TIMEOUT,
  );
});
