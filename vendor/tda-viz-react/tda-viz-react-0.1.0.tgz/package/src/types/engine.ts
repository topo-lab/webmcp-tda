/**
 * Types mirroring the engine surface actually available in tda-wasm
 * (SPEC.md §6). The package may only expose what exists.
 */
import type { Complex, Diagram, Simplex as EngineSimplex } from '@topolab/tda-wasm';

export type { Complex, Diagram, EllipsoidAxes, LoadSource, Scale } from '@topolab/tda-wasm';

/** One native engine simplex, materialized only for the visualization layer. */
export type Simplex = EngineSimplex;

/** A pair materialized once for the visualization/query layer. */
export interface PersistencePair {
  dimension: number;
  birth: number;
  death: number;
}

/**
 * Point-cloud complexes wired into the v1 pipeline.
 *
 * TODO(SPEC.md §6): 'witness' (weak) exists in tda-wasm
 * (`witnessComplex`) but needs landmark params designed
 * before wiring. Cubical takes image/grid input, not point clouds — it needs
 * its own pipeline shape.
 */
export type ComplexType = 'rips' | 'alpha' | 'cech';

interface TdaParamsBase {
  /** Simplex-dimension cap. Default 2 (SPEC.md §5); raising to 3 is what makes
   * a real β₂ reachable, at several-fold simplex cost. */
  maxSimplexDim: number;
  /** Prime coefficient field (default 2). */
  coeff: number;
}

/** Vietoris–Rips: the cutoff is an edge length. */
export interface RipsTdaParams extends TdaParamsBase {
  complexType: 'rips';
  /** Max edge length (a diameter). */
  maxEdgeLength: number;
}

/** Čech: the cutoff is a ball radius. */
export interface CechTdaParams extends TdaParamsBase {
  complexType: 'cech';
  /** Max ball radius. */
  maxRadius: number;
}

/** Weighted alpha: the filtration is intrinsic, so there is no cutoff. */
export interface AlphaTdaParams extends TdaParamsBase {
  complexType: 'alpha';
}

/**
 * Parameters for the points → complex → persistence pipeline (SPEC.md §4).
 * Each complex type names its cutoff by its scale, as the engine does.
 */
export type TdaParams = RipsTdaParams | CechTdaParams | AlphaTdaParams;

/** A change to `TdaParams`: any of its fields, including either cutoff. */
export interface TdaParamsPatch {
  complexType?: ComplexType;
  maxEdgeLength?: number;
  maxRadius?: number;
  maxSimplexDim?: number;
  coeff?: number;
}

/** Everything one pipeline run produces. */
export interface PipelineResult {
  complex: Complex;
  diagram: Diagram;
}

/** Honesty label carried by every engine binding (SPEC.md §5). */
export type EngineBindingStatus = 'stable' | 'experimental';
/** Which ambient point dimensions a binding accepts. */
export type EnginePointDimensions = 'any' | '3d-only' | 'grid';

/** One row of the SPEC.md §6 engine-surface table. */
export interface EngineBindingInfo {
  /** Name of the underlying WASM binding. */
  binding: string;
  /** Which ambient point dimensions the binding accepts. */
  pointDimensions: EnginePointDimensions;
  /** Honesty label (SPEC.md §5): experimental backends are labeled, always. */
  status: EngineBindingStatus;
  /** Whether this package's v1 pipeline exposes it. */
  wired: boolean;
  note: string;
}

/**
 * The SPEC.md §6 table, as data. Keep in sync with the spec and with what
 * tda-wasm actually ships; `src/types/__tests__/engine.test.ts` guards it.
 */
export const ENGINE_SURFACE = {
  rips: {
    binding: 'ripsComplex',
    pointDimensions: 'any',
    status: 'experimental',
    wired: true,
    note: 'Explicit capped flag complex from @topolab/tda-wasm 0.3; the diagram describes the same skeleton.',
  },
  alpha: {
    binding: 'alphaPersistence',
    pointDimensions: '3d-only',
    status: 'stable',
    wired: true,
    note: '3D-only at the binding level. 2D clouds are embedded at z=0 in the compute layer (SPEC.md §6).',
  },
  cech: {
    binding: 'cechComplex',
    pointDimensions: 'any',
    status: 'stable',
    wired: true,
    note: 'maxRadius is the max ball radius.',
  },
  witness: {
    binding: 'witnessComplex',
    pointDimensions: 'any',
    status: 'experimental',
    wired: false,
    note: 'Weak witness only; strong variant not wired in tda-wasm. TODO(SPEC.md §6): design landmark params, then wire.',
  },
  cubical: {
    binding: 'cubicalPersistence',
    pointDimensions: 'grid',
    status: 'stable',
    wired: true,
    note:
      "Image/grid data, not point clouds: buildFiltration(engine, { complexType: 'cubical', … }) " +
      'takes the grid and no cloud, and returns a GridFiltration (SPEC.md §3.1b). Two ' +
      'constructions, T (values on pixels) and V (values on vertices), and they disagree. ' +
      'Uses the NumPy shape [height, width]; the former 0.2 wrapper whose ' +
      'dimension order scrambled rectangular grids is no longer used.',
  },
} as const satisfies Record<string, EngineBindingInfo>;
