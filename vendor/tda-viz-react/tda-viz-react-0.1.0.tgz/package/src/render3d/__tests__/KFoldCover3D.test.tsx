/**
 * <KFoldCover3D> and its tracing oracle.
 *
 * jsdom has no GPU and the harness's `pc.NullGraphicsDevice` never rasterizes,
 * so nothing here can read the traced surface's pixels back. The exactness
 * claim is therefore tested where it actually lives: `kthNearestDistanceSquared`
 * and `insideKFoldCover`, the pure functions the GLSL and WGSL fragment shaders
 * transcribe. They are checked against an INDEPENDENT brute force (a full sort
 * of real distances, a different formulation), against `coveringDepthAt` — the
 * counting oracle <DepthSlice3D> uses, which the order/count identity says must
 * agree — and then against the two eight-sphere motifs whose depth-4 geometry
 * is known in closed form.
 *
 * The component half is the ordinary render3d treatment (see ./harness): a real
 * `pc.Application`, a real scene graph, real material parameters.
 */
import { describe, expect, it } from 'vitest';
import {
  KFOLD_COVER_FRAGMENT_GLSL,
  KFOLD_COVER_FRAGMENT_WGSL,
  KFoldCover3D,
} from '../KFoldCover3D';
import {
  COVER_MAX_STEPS,
  MAX_COVER_CENTRES,
  MAX_COVER_K,
  boxTriangles,
  cloudBounds,
  coverEpsilon,
  insideKFoldCover,
  kthNearestCentreIndex,
  kthNearestDistanceSquared,
} from '../kfoldCover';
import { coveringDepthAt } from '../depthSlice';
import type { Filtration } from '../../filtration/types';
import {
  JITTERED8_KFOLD2,
  TETRA4_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { entity, findEntity, meshInstance, numberParam, renderStage, shaderParam } from './harness';

// ── The independent brute force ──────────────────────────────────────────

/**
 * Deliberately NOT the implementation: real distances via `Math.hypot`, a full
 * ascending sort, and the (k − 1)-th element read off it. If this and the
 * partial selection ever disagree, one of them is wrong.
 */
function bruteForceKth(point: number[], centres: number[], k: number): number {
  const d: number[] = [];
  for (let i = 0; i < centres.length; i += 3) {
    d.push(
      Math.hypot(point[0]! - centres[i]!, point[1]! - centres[i + 1]!, point[2]! - centres[i + 2]!),
    );
  }
  d.sort((a, b) => a - b);
  const kth = d[k - 1];
  return kth === undefined ? Infinity : kth * kth;
}

/** Seeded PRNG, so "random" clouds are the same cloud on every run. */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let x = Math.imul(a ^ (a >>> 15), 1 | a);
    x = (x + Math.imul(x ^ (x >>> 7), 61 | x)) ^ x;
    return ((x ^ (x >>> 14)) >>> 0) / 4294967296;
  };
}

function seededCloud(seed: number, n: number, spread = 2): number[] {
  const rnd = mulberry32(seed);
  const pts: number[] = [];
  for (let i = 0; i < n * 3; i++) pts.push((rnd() - 0.5) * spread);
  return pts;
}

// ── The two eight-sphere motifs ──────────────────────────────────────────
//
// Verbatim from wasm-tda-webapp/public/datasets/motif_{hcp,fcc}_8.json, the
// same eight points DepthSlice3D's tests pin. Eight unit-diameter spheres: a
// hexagonal layer of six with one sphere above and one below. HCP has the
// layers ECLIPSED (A B A), FCC STAGGERED (A B C). Jitter 2e-3, seeds 777 and
// 778 — which is why the closed-form values below are met to a tolerance.

const HCP_POINTS = [
  0.0007, -0.0019, -0.0012, 0.9985, 0.0005, -0.0005, 0.499, 0.867, 0.0005, -0.4989, 0.8668, 0.0014,
  0.4986, -0.8653, 0.0002, -0.4983, -0.8659, -0.0017, 0.5017, 0.2896, 0.8184, 0.4985, 0.2881,
  -0.8183,
];
/** HCP: the two tetrahedral holes share the FACE 0-1-2. */
const HCP_HOLES: [number[], number[]] = [
  [0, 1, 2, 6],
  [0, 1, 2, 7],
];

const FCC_POINTS = [
  -0.0019, 0.0004, 0.0014, 1.0007, 0.0007, 0.0013, 0.502, 0.8671, -0.0006, -0.5009, 0.8653, 0.0018,
  0.4996, -0.8674, -0.0016, -0.4996, -0.8673, 0, 0.5, 0.2875, 0.8185, 0.5014, -0.2888, -0.8169,
];
/** FCC: the two tetrahedral holes share only the EDGE 0-1. */
const FCC_HOLES: [number[], number[]] = [
  [0, 1, 2, 6],
  [0, 1, 4, 7],
];

const pointAt = (pts: number[], i: number) => [pts[i * 3]!, pts[i * 3 + 1]!, pts[i * 3 + 2]!];

/** Circumcentre of a tetrahedron: the deepest point of the hole it surrounds. */
function circumcentre(p: number[][]): number[] {
  const [a, b, c, d] = p as [number[], number[], number[], number[]];
  const sq = (q: number[]) => q[0]! ** 2 + q[1]! ** 2 + q[2]! ** 2;
  const rows = [b, c, d].map((q, i) => [
    2 * (q[0]! - a[0]!),
    2 * (q[1]! - a[1]!),
    2 * (q[2]! - a[2]!),
    sq([b, c, d][i]!) - sq(a),
  ]);
  for (let i = 0; i < 3; i++) {
    let pivot = i;
    for (let j = i + 1; j < 3; j++) {
      if (Math.abs(rows[j]![i]!) > Math.abs(rows[pivot]![i]!)) pivot = j;
    }
    [rows[i], rows[pivot]] = [rows[pivot]!, rows[i]!];
    for (let j = 0; j < 3; j++) {
      if (j === i) continue;
      const f = rows[j]![i]! / rows[i]![i]!;
      for (let k = i; k < 4; k++) rows[j]![k]! -= f * rows[i]![k]!;
    }
  }
  return [rows[0]![3]! / rows[0]![0]!, rows[1]![3]! / rows[1]![1]!, rows[2]![3]! / rows[2]![2]!];
}

/** The smallest t on a fine grid at which `point` lies in the k-fold cover. */
function birthT(point: number[], pts: number[], k: number, step = 0.0005, tMax = 2): number {
  for (let t = 0; t <= tMax; t += step) {
    if (insideKFoldCover(point, pts, k, t)) return t;
  }
  return Infinity;
}

/**
 * The smallest t at which the whole segment between the two hole centres lies
 * inside the k-fold cover — i.e. at which the two lobes have joined into one
 * connected piece. Sampled, exactly as a reader would read it off the picture.
 */
function joinT(
  a: number[],
  b: number[],
  pts: number[],
  k: number,
  samples = 1001,
  step = 0.0005,
  tMax = 2,
): number {
  const segment: number[][] = [];
  for (let i = 0; i < samples; i++) {
    const s = i / (samples - 1);
    segment.push([
      a[0]! + s * (b[0]! - a[0]!),
      a[1]! + s * (b[1]! - a[1]!),
      a[2]! + s * (b[2]! - a[2]!),
    ]);
  }
  for (let t = 0; t <= tMax; t += step) {
    if (segment.every((x) => insideKFoldCover(x, pts, k, t))) return t;
  }
  return Infinity;
}

// ── The oracle ───────────────────────────────────────────────────────────

describe('kthNearestDistanceSquared (the oracle for the GLSL/WGSL)', () => {
  it('agrees with a full sort everywhere on seeded clouds, for every supported k', () => {
    for (const seed of [1, 7, 12345, 987654]) {
      const centres = seededCloud(seed, 40);
      const probes = seededCloud(seed + 1000, 60, 3);
      for (let p = 0; p < probes.length; p += 3) {
        const point = [probes[p]!, probes[p + 1]!, probes[p + 2]!];
        for (let k = 1; k <= MAX_COVER_K; k++) {
          expect(kthNearestDistanceSquared(point, centres, k)).toBeCloseTo(
            bruteForceKth(point, centres, k),
            10,
          );
        }
      }
    }
  });

  it('is ascending in k: d_(1) <= d_(2) <= ... <= d_(8)', () => {
    const centres = seededCloud(31, 25);
    const probes = seededCloud(32, 40, 3);
    for (let p = 0; p < probes.length; p += 3) {
      const point = [probes[p]!, probes[p + 1]!, probes[p + 2]!];
      let previous = -1;
      for (let k = 1; k <= MAX_COVER_K; k++) {
        const d = kthNearestDistanceSquared(point, centres, k);
        expect(d).toBeGreaterThanOrEqual(previous);
        previous = d;
      }
    }
  });

  it('is Infinity when the cloud has fewer than k centres', () => {
    expect(kthNearestDistanceSquared([0, 0, 0], [0, 0, 0, 1, 0, 0], 3)).toBe(Infinity);
    expect(kthNearestDistanceSquared([0, 0, 0], [], 1)).toBe(Infinity);
  });

  it('refuses a k the shader cannot hold in registers', () => {
    for (const bad of [0, -1, 1.5, MAX_COVER_K + 1, 99]) {
      expect(() => kthNearestDistanceSquared([0, 0, 0], [0, 0, 0], bad)).toThrow(
        new RegExp(`\\[1, ${MAX_COVER_K}\\]`),
      );
    }
  });

  it('names the k-th nearest centre, which is where the analytic normal points from', () => {
    const centres = seededCloud(51, 20);
    const probes = seededCloud(52, 30, 3);
    for (let p = 0; p < probes.length; p += 3) {
      const point = [probes[p]!, probes[p + 1]!, probes[p + 2]!];
      for (let k = 1; k <= 5; k++) {
        const s = kthNearestDistanceSquared(point, centres, k);
        const i = kthNearestCentreIndex(point, centres, k);
        expect(i).toBeGreaterThanOrEqual(0);
        const dx = point[0]! - centres[i * 3]!;
        const dy = point[1]! - centres[i * 3 + 1]!;
        const dz = point[2]! - centres[i * 3 + 2]!;
        // The named centre is exactly the one at distance d_(k).
        expect(dx * dx + dy * dy + dz * dz).toBeCloseTo(s, 12);
      }
    }
    expect(kthNearestCentreIndex([0, 0, 0], [0, 0, 0], 2)).toBe(-1);
  });
});

describe('insideKFoldCover (the predicate the shader converges to)', () => {
  it('IS "covering depth at least k" — the order/count identity', () => {
    // depth(x) >= k  <=>  d_(k)(x)^2 <= t. Checked against coveringDepthAt,
    // <DepthSlice3D>'s own oracle, which counts rather than orders.
    for (const seed of [3, 77, 4242]) {
      const centres = seededCloud(seed, 30);
      const probes = seededCloud(seed + 500, 60, 3);
      for (let p = 0; p < probes.length; p += 3) {
        const point = [probes[p]!, probes[p + 1]!, probes[p + 2]!];
        for (let t = 0; t <= 3; t += 0.05) {
          for (let k = 1; k <= 6; k++) {
            expect(insideKFoldCover(point, centres, k, t)).toBe(
              coveringDepthAt(point, centres, t) >= k,
            );
          }
        }
      }
    }
  });

  it('counts a point exactly on the boundary as inside (<=, not <)', () => {
    // Distance 3 from the origin, so d_(1)^2 = 9 exactly.
    expect(insideKFoldCover([3, 0, 0], [0, 0, 0], 1, 9)).toBe(true);
    expect(insideKFoldCover([3, 0, 0], [0, 0, 0], 1, 9 - 1e-12)).toBe(false);
  });

  it('is outside everywhere before any ball is born, and for a negative or NaN t', () => {
    const centres = [0, 0, 0, 1, 0, 0];
    expect(insideKFoldCover([0, 0, 0], centres, 1, 0)).toBe(true);
    expect(insideKFoldCover([0.5, 0, 0], centres, 1, 0)).toBe(false);
    expect(insideKFoldCover([0, 0, 0], centres, 1, -1)).toBe(false);
    expect(insideKFoldCover([0, 0, 0], centres, 1, Number.NaN)).toBe(false);
  });

  it('is nested in k: the 4-fold cover lies inside the 1-fold cover (the union)', () => {
    const centres = seededCloud(13, 20);
    const probes = seededCloud(14, 200, 3);
    for (let p = 0; p < probes.length; p += 3) {
      const point = [probes[p]!, probes[p + 1]!, probes[p + 2]!];
      for (const t of [0.05, 0.2, 0.6, 1.2]) {
        if (insideKFoldCover(point, centres, 4, t)) {
          expect(insideKFoldCover(point, centres, 1, t)).toBe(true);
        }
      }
    }
  });

  it('is monotone in t: the region only grows (SPEC.md §1.1)', () => {
    const centres = seededCloud(21, 16);
    const probes = seededCloud(22, 80, 3);
    for (let p = 0; p < probes.length; p += 3) {
      const point = [probes[p]!, probes[p + 1]!, probes[p + 2]!];
      let wasInside = false;
      for (let t = 0; t <= 4; t += 0.05) {
        const inside = insideKFoldCover(point, centres, 3, t);
        if (wasInside) expect(inside).toBe(true);
        wasInside = inside;
      }
    }
  });
});

describe('the eight-sphere motifs, as SOLIDS (HCP eclipsed vs FCC staggered)', () => {
  const cases = [
    { name: 'HCP', pts: HCP_POINTS, holes: HCP_HOLES, join: 0.67 },
    { name: 'FCC', pts: FCC_POINTS, holes: FCC_HOLES, join: 0.7525 },
  ];

  for (const { name, pts, holes, join } of cases) {
    it(`${name}: both depth-4 lobes open at t = 0.375, the squared circumradius`, () => {
      // Four unit-diameter spheres in mutual contact: their circumcentre is at
      // squared distance 3/8 from each centre, so the lobe opens exactly there.
      for (const tet of holes) {
        const c = circumcentre(tet.map((i) => pointAt(pts, i)));
        expect(insideKFoldCover(c, pts, 4, 0.375 + 0.02)).toBe(true);
        expect(Math.abs(birthT(c, pts, 4) - 0.375)).toBeLessThan(0.02);
      }
    });

    it(`${name}: the two lobes join along the segment between them at t ≈ ${join}`, () => {
      const a = circumcentre(holes[0].map((i) => pointAt(pts, i)));
      const b = circumcentre(holes[1].map((i) => pointAt(pts, i)));
      // Below the join the midpoint of the segment is not yet in the cover:
      // there really are two lobes, not one drawn twice.
      const mid = [0, 1, 2].map((k) => (a[k]! + b[k]!) / 2);
      expect(insideKFoldCover(mid, pts, 4, join - 0.05)).toBe(false);
      expect(Math.abs(joinT(a, b, pts, 4) - join)).toBeLessThan(0.02);
    });
  }

  it('separates the two motifs: a shared face is a shorter way through than a shared edge', () => {
    const j = (pts: number[], holes: [number[], number[]]) =>
      joinT(
        circumcentre(holes[0].map((i) => pointAt(pts, i))),
        circumcentre(holes[1].map((i) => pointAt(pts, i))),
        pts,
        4,
      );
    expect(j(HCP_POINTS, HCP_HOLES)).toBeLessThan(j(FCC_POINTS, FCC_HOLES));
  });

  it('at t = 0.70 the HCP pair is joined and the FCC pair is not', () => {
    // The scale the stories screenshot on both backends.
    const mid = (pts: number[], holes: [number[], number[]]) => {
      const a = circumcentre(holes[0].map((i) => pointAt(pts, i)));
      const b = circumcentre(holes[1].map((i) => pointAt(pts, i)));
      return [0, 1, 2].map((k) => (a[k]! + b[k]!) / 2);
    };
    expect(insideKFoldCover(mid(HCP_POINTS, HCP_HOLES), HCP_POINTS, 4, 0.7)).toBe(true);
    expect(insideKFoldCover(mid(FCC_POINTS, FCC_HOLES), FCC_POINTS, 4, 0.7)).toBe(false);
  });
});

// ── The tracing box ──────────────────────────────────────────────────────

describe('the tracing box', () => {
  it('bounds the cloud and grows by the padding on every side', () => {
    const pts = [0, 0, 0, 2, -1, 4];
    expect(cloudBounds(pts)).toEqual({ min: [0, -1, 0], max: [2, 0, 4] });
    expect(cloudBounds(pts, 0.5)).toEqual({ min: [-0.5, -1.5, -0.5], max: [2.5, 0.5, 4.5] });
    expect(cloudBounds([], 1)).toEqual({ min: [-1, -1, -1], max: [1, 1, 1] });
  });

  it('contains every ball of radius equal to the padding', () => {
    // Nothing outside the grown box can be covered, so the box is a bound and
    // not a crop: the far side of the largest ball is still inside.
    const pts = seededCloud(61, 12);
    const pad = 1.25;
    const b = cloudBounds(pts, pad);
    for (let i = 0; i < pts.length; i += 3) {
      for (let a = 0; a < 3; a++) {
        expect(pts[i + a]! - pad).toBeGreaterThanOrEqual(b.min[a]! - 1e-12);
        expect(pts[i + a]! + pad).toBeLessThanOrEqual(b.max[a]! + 1e-12);
      }
    }
  });

  it('is twelve triangles whose faces wind counter-clockwise from OUTSIDE', () => {
    const b = cloudBounds([0, 0, 0, 1, 2, 3], 0.5);
    const v = boxTriangles(b);
    expect(v.length).toBe(36 * 3);
    const centre = [0, 1, 2].map((a) => (b.min[a]! + b.max[a]!) / 2);
    for (let tri = 0; tri < 12; tri++) {
      const p = [0, 1, 2].map((c) => v.slice((tri * 3 + c) * 3, (tri * 3 + c) * 3 + 3));
      const e1 = [0, 1, 2].map((a) => p[1]![a]! - p[0]![a]!);
      const e2 = [0, 1, 2].map((a) => p[2]![a]! - p[0]![a]!);
      const nx = e1[1]! * e2[2]! - e1[2]! * e2[1]!;
      const ny = e1[2]! * e2[0]! - e1[0]! * e2[2]!;
      const nz = e1[0]! * e2[1]! - e1[1]! * e2[0]!;
      const outward = [0, 1, 2].map((a) => p[0]![a]! - centre[a]!);
      // The right-hand normal points AWAY from the box centre on every face.
      expect(nx * outward[0]! + ny * outward[1]! + nz * outward[2]!).toBeGreaterThan(0);
    }
    // Every corner of the box appears, and nothing outside it.
    for (let i = 0; i < v.length; i += 3) {
      for (let a = 0; a < 3; a++) {
        expect([b.min[a], b.max[a]]).toContain(v[i + a]);
      }
    }
  });

  it('scales the surface epsilon with the scene and floors it', () => {
    const small = coverEpsilon({ min: [0, 0, 0], max: [1, 1, 1] });
    const large = coverEpsilon({ min: [0, 0, 0], max: [1000, 1000, 1000] });
    expect(large).toBeCloseTo(small * 1000, 6);
    expect(coverEpsilon({ min: [0, 0, 0], max: [0, 0, 0] })).toBeGreaterThan(0);
  });
});

// ── The fragment shaders are transcriptions, not variations ──────────────

describe('the fragment shaders transcribe the oracle', () => {
  it('GLSL selects the k smallest SQUARED distances by insert-and-shift', () => {
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('vec3 dv = p - uCentres[i].xyz;');
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('float d2 = dot(dv, dv);');
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('if (d2 >= best[kk - 1]) continue;');
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('best[idx] = best[idx - 1];');
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain(`float best[${MAX_COVER_K}];`);
  });

  it('WGSL runs the same selection', () => {
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('let dv = p - uniform.uCentres[i].xyz;');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('let d2 = dot(dv, dv);');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('if (d2 >= best[kk - 1]) { continue; }');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('best[idx] = best[idx - 1];');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain(`var best: array<f32, ${MAX_COVER_K}>;`);
  });

  it('both sphere-trace the Lipschitz step d_(k) - sqrt(t), capped at the stated count', () => {
    for (const src of [KFOLD_COVER_FRAGMENT_GLSL, KFOLD_COVER_FRAGMENT_WGSL]) {
      expect(src).toContain(`i < ${COVER_MAX_STEPS}`);
      expect(src).toContain('sqrt(kthNearestSq(p, kk)) - radius');
      expect(src).toContain('march += d;');
    }
    // The radius the trace converges to is sqrt(t): the sublevel set of d_(k).
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('float radius = sqrt(uT);');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('let radius = sqrt(uniform.uT);');
  });

  it('both take the normal from the k-th nearest centre, not from finite differences', () => {
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('vec3 nRaw = hitP - c;');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('let nRaw = hitP - c;');
    for (const src of [KFOLD_COVER_FRAGMENT_GLSL, KFOLD_COVER_FRAGMENT_WGSL]) {
      expect(src).not.toMatch(/epsilon\s*\*\s*vec3|gradient/i);
    }
  });

  it('both write the fragment depth from the hit point, in their own clip convention', () => {
    // WebGL2 gets the OpenGL projection (clip z in [-w, w]); WebGPU gets the
    // engine's depth-range-corrected one (clip z in [0, w]).
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('gl_FragDepth = clip.z / clip.w * 0.5 + 0.5;');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('output.fragDepth = clip.z / clip.w;');
    // The depth is the HIT point's, not the box wall's.
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain(
      'vec4 clip = matrix_viewProjection * vec4(hitP, 1.0);',
    );
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain(
      'let clip = uniform.matrix_viewProjection * vec4f(hitP, 1.0);',
    );
  });

  it('both discard rather than guessing a hit', () => {
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('if (!hit) discard;');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('if (!hit) { discard; return output; }');
  });

  it('both reconstruct the ray from view_position, the engine’s own camera uniform', () => {
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('uniform vec3 view_position;');
    expect(KFOLD_COVER_FRAGMENT_GLSL).toContain('vec3 rd = normalize(vWorld - ro);');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('uniform view_position: vec3f;');
    expect(KFOLD_COVER_FRAGMENT_WGSL).toContain('let rd = normalize(input.vWorld - ro);');
    // matrix_viewProjectionInverse is NOT a renderer-set uniform in 2.21.4.
    for (const src of [KFOLD_COVER_FRAGMENT_GLSL, KFOLD_COVER_FRAGMENT_WGSL]) {
      expect(src).not.toContain('matrix_viewProjectionInverse');
    }
  });
});

// ── The component ────────────────────────────────────────────────────────

const KFOLD = recordedFiltration(JITTERED8_KFOLD2);
const COVER_COLOR = '#2dd4bf';
const UNION_COLOR = '#8fa3c8';

describe('<KFoldCover3D> scene graph', () => {
  it('parents a tracing box under the stage root', () => {
    const stage = renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} />);
    const parent = findEntity(stage.root, 'KFoldCover3D');
    expect(parent).not.toBeNull();
    expect(parent!.parent).toBe(stage.root);
    const mi = meshInstance(stage.root, 'KFoldCoverSurface');
    // Twelve triangles: the box is a proxy the trace runs inside, so the
    // geometry carries none of the surface.
    expect(mi.mesh.vertexBuffer.numVertices).toBe(36);
    stage.unmount();
  });

  it('declares its exactness claim, its k and its box in the entity userData', () => {
    const stage = renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} />);
    const parent = entity(stage.root, 'KFoldCover3D') as unknown as {
      userData: Record<string, unknown>;
    };
    expect(String(parent.userData.exactness)).toMatch(/exact/i);
    expect(String(parent.userData.exactness)).toMatch(/isosurface/i);
    expect(parent.userData.centreCount).toBe(KFOLD.cloud.points.length / 3);
    expect(parent.userData.maxSteps).toBe(COVER_MAX_STEPS);
    expect(parent.userData.unionShell).toBe(false);
    stage.unmount();
  });

  it('defaults k to the multiplicity the filtration was BUILT at', () => {
    // The recorded fixture is a k = 2 cover, so the surface is the 2-fold one
    // without the caller repeating the number.
    expect(KFOLD.coverMultiplicity).toBe(2);
    const stage = renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} />);
    expect(numberParam(meshInstance(stage.root, 'KFoldCoverSurface').material, 'uK')).toBe(2);
    stage.unmount();
  });

  it('lets an explicit k override the filtration’s own', () => {
    const stage = renderStage(
      <KFoldCover3D filtration={KFOLD} t={0.4} k={4} colorCover={COVER_COLOR} />,
    );
    expect(numberParam(meshInstance(stage.root, 'KFoldCoverSurface').material, 'uK')).toBe(4);
    stage.unmount();
  });

  it('uploads every centre once, as the INPUT points and not the mosaic vertices', () => {
    const stage = renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} />);
    const mi = meshInstance(stage.root, 'KFoldCoverSurface');
    const centres = shaderParam(mi.material, 'uCentres[0]') as Float32Array;
    const n = KFOLD.cloud.points.length / 3;

    expect(centres).toBeInstanceOf(Float32Array);
    expect(centres.length).toBe(MAX_COVER_CENTRES * 4);
    expect(numberParam(mi.material, 'uCentreCount')).toBe(n);
    for (let i = 0; i < n; i++) {
      expect(centres[i * 4]).toBeCloseTo(KFOLD.cloud.points[i * 3]!, 5);
      expect(centres[i * 4 + 1]).toBeCloseTo(KFOLD.cloud.points[i * 3 + 1]!, 5);
      expect(centres[i * 4 + 2]).toBeCloseTo(KFOLD.cloud.points[i * 3 + 2]!, 5);
    }
    // The mosaic has more vertices than the cloud has points; the balls grow
    // on the points, so the trace must carry the points.
    expect(KFOLD.vertexCount).toBeGreaterThan(n);

    // Scrubbing t must not touch the centres: the SAME array object survives.
    stage.rerender(<KFoldCover3D filtration={KFOLD} t={0.9} colorCover={COVER_COLOR} />);
    expect(shaderParam(meshInstance(stage.root, 'KFoldCoverSurface').material, 'uCentres[0]')).toBe(
      centres,
    );
    stage.unmount();
  });

  it('writes the new t into the uniform when t changes, on both passes', () => {
    const stage = renderStage(
      <KFoldCover3D
        filtration={KFOLD}
        t={0.25}
        colorCover={COVER_COLOR}
        colorUnion={UNION_COLOR}
      />,
    );
    for (const name of ['KFoldCoverSurface', 'KFoldCoverUnionShell']) {
      expect(numberParam(meshInstance(stage.root, name).material, 'uT')).toBeCloseTo(0.25, 12);
    }
    stage.rerender(
      <KFoldCover3D
        filtration={KFOLD}
        t={1.75}
        colorCover={COVER_COLOR}
        colorUnion={UNION_COLOR}
      />,
    );
    for (const name of ['KFoldCoverSurface', 'KFoldCoverUnionShell']) {
      expect(numberParam(meshInstance(stage.root, name).material, 'uT')).toBeCloseTo(1.75, 12);
    }
    stage.unmount();
  });

  it('spans the cloud’s bounding box grown by the largest ball radius', () => {
    const stage = renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} />);
    const mi = meshInstance(stage.root, 'KFoldCoverSurface');
    const positions = new Float32Array(mi.mesh.vertexBuffer.numVertices * 3);
    mi.mesh.getPositions(positions);
    const expected = cloudBounds(KFOLD.cloud.points, Math.sqrt(KFOLD.tMax));
    for (let a = 0; a < 3; a++) {
      const axis = [...positions].filter((_, i) => i % 3 === a);
      expect(Math.min(...axis)).toBeCloseTo(expected.min[a]!, 5);
      expect(Math.max(...axis)).toBeCloseTo(expected.max[a]!, 5);
    }
    stage.unmount();
  });

  it('draws no union shell unless colorUnion is given', () => {
    const stage = renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} />);
    expect(findEntity(stage.root, 'KFoldCoverUnionShell')).toBeNull();
    stage.unmount();
  });

  it('draws the union shell as the SAME shader at k = 1, translucent and depth-read-only', () => {
    const stage = renderStage(
      <KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} colorUnion={UNION_COLOR} />,
    );
    const cover = meshInstance(stage.root, 'KFoldCoverSurface');
    const shell = meshInstance(stage.root, 'KFoldCoverUnionShell');
    // The one-fold cover is the plain union of the balls.
    expect(numberParam(shell.material, 'uK')).toBe(1);
    expect(numberParam(cover.material, 'uK')).toBe(2);
    // The shell must not hide the points and edges drawn after it.
    expect((shell.material as { depthWrite: boolean }).depthWrite).toBe(false);
    expect((cover.material as { depthWrite: boolean }).depthWrite).toBe(true);
    // Both trace the same box, from the same one upload.
    expect(shaderParam(shell.material, 'uCentres[0]')).toBe(
      shaderParam(cover.material, 'uCentres[0]'),
    );
    expect(
      (entity(stage.root, 'KFoldCover3D') as unknown as { userData: Record<string, unknown> })
        .userData.unionShell,
    ).toBe(true);
    stage.unmount();
  });

  it('packs the colours, the opacities and the shininess into uniforms', () => {
    const stage = renderStage(
      <KFoldCover3D
        filtration={KFOLD}
        t={0.4}
        colorCover="#4450b4"
        colorUnion="#dfe4f5"
        unionOpacity={0.4}
        shininess={12}
      />,
    );
    const cover = meshInstance(stage.root, 'KFoldCoverSurface').material;
    const shell = meshInstance(stage.root, 'KFoldCoverUnionShell').material;
    const rgb = shaderParam(cover, 'uColor') as number[];
    expect(rgb[0]).toBeCloseTo(0x44 / 255, 5);
    expect(rgb[1]).toBeCloseTo(0x50 / 255, 5);
    expect(rgb[2]).toBeCloseTo(0xb4 / 255, 5);
    // The k-fold surface is opaque: it is the object, not a hint of it.
    expect(numberParam(cover, 'uOpacity')).toBe(1);
    expect(numberParam(shell, 'uOpacity')).toBeCloseTo(0.4, 12);
    expect(numberParam(cover, 'uShininess')).toBe(12);
    expect(numberParam(shell, 'uShininess')).toBe(12);
    stage.unmount();
  });

  it('defaults the union opacity to 0.18 and the shininess to 24', () => {
    const stage = renderStage(
      <KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} colorUnion={UNION_COLOR} />,
    );
    expect(
      numberParam(meshInstance(stage.root, 'KFoldCoverUnionShell').material, 'uOpacity'),
    ).toBeCloseTo(0.18, 12);
    expect(numberParam(meshInstance(stage.root, 'KFoldCoverSurface').material, 'uShininess')).toBe(
      24,
    );
    stage.unmount();
  });

  it('unmounts without error and takes its entity with it', () => {
    const stage = renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} />);
    expect(findEntity(stage.root, 'KFoldCover3D')).not.toBeNull();
    expect(() => stage.rerender(null)).not.toThrow();
    expect(findEntity(stage.root, 'KFoldCover3D')).toBeNull();
    expect(() => stage.unmount()).not.toThrow();
  });

  it('survives the stage tearing the device down first (the 2026-09-06 contract)', () => {
    const stage = renderStage(
      <KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} colorUnion={UNION_COLOR} />,
    );
    expect(() => stage.unmount()).not.toThrow();
  });
});

describe('<KFoldCover3D> refusals', () => {
  it('refuses a filtration that is not a k-fold cover', () => {
    const alpha = recordedFiltration(TETRA4_ALPHA);
    expect(() =>
      renderStage(<KFoldCover3D filtration={alpha} t={0.4} colorCover={COVER_COLOR} />),
    ).toThrow(/k-fold cover/i);
  });

  it('refuses a 2D cloud: there is no solid to orbit', () => {
    const flat = {
      ...KFOLD,
      cloud: { ...KFOLD.cloud, dimension: 2 },
    } as unknown as Filtration;
    expect(() =>
      renderStage(<KFoldCover3D filtration={flat} t={0.4} colorCover={COVER_COLOR} />),
    ).toThrow(/3D cloud/i);
  });

  it('refuses a k the shader cannot hold in registers', () => {
    for (const bad of [0, 2.5, MAX_COVER_K + 1]) {
      expect(() =>
        renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} k={bad} colorCover={COVER_COLOR} />),
      ).toThrow(new RegExp(`\\[1, ${MAX_COVER_K}\\]`));
    }
  });

  it('refuses a cloud with more centres than the compiled shader can trace', () => {
    const huge = {
      ...KFOLD,
      cloud: { ...KFOLD.cloud, points: seededCloud(9, MAX_COVER_CENTRES + 1) },
    } as unknown as Filtration;
    expect(() =>
      renderStage(<KFoldCover3D filtration={huge} t={0.4} colorCover={COVER_COLOR} />),
    ).toThrow(new RegExp(`at most ${MAX_COVER_CENTRES}`));
  });

  it('supports at least 256 centres', () => {
    expect(MAX_COVER_CENTRES).toBeGreaterThanOrEqual(256);
    const big = {
      ...KFOLD,
      cloud: { ...KFOLD.cloud, points: seededCloud(11, MAX_COVER_CENTRES) },
    } as unknown as Filtration;
    const stage = renderStage(<KFoldCover3D filtration={big} t={0.4} colorCover={COVER_COLOR} />);
    expect(
      numberParam(meshInstance(stage.root, 'KFoldCoverSurface').material, 'uCentreCount'),
    ).toBe(MAX_COVER_CENTRES);
    stage.unmount();
  });
});

// ── Array uniforms bind by a name the shader source does not spell ───────

/**
 * The same regression guard <DepthSlice3D> carries, on this component's own
 * shaders: an ARRAY uniform binds through `device.scope` under a `[0]`-suffixed
 * name on BOTH backends, and setting the bare name writes a slot nothing reads.
 * `pc.NullGraphicsDevice` reflects no uniforms, so what is checkable here is the
 * contract between the two halves — every array the shader source DECLARES must
 * have a parameter set under its `[0]` name. The declarations are parsed out of
 * the shipped shader strings, so a new array uniform cannot be added without
 * being covered.
 */
describe('array uniforms are set under the name the engine binds', () => {
  /** `uniform vec4 uCentres[256];` -> { name: 'uCentres', count: 256, components: 4 } */
  function glslArrays(source: string) {
    const found: Array<{ name: string; count: number; components: number }> = [];
    const re = /uniform\s+(\w+)\s+(\w+)\s*\[\s*(\d+)\s*\]\s*;/g;
    for (const m of source.matchAll(re)) {
      const type = m[1]!;
      const components = type === 'float' ? 1 : Number(type.replace(/\D/g, '')) || 1;
      found.push({ name: m[2]!, count: Number(m[3]), components });
    }
    return found;
  }

  /** `uniform uCentres: array<vec4f, 256>;` -> the same shape. */
  function wgslArrays(source: string) {
    const found: Array<{ name: string; count: number; components: number }> = [];
    const re = /uniform\s+(\w+)\s*:\s*array<\s*(\w+)\s*,\s*(\d+)\s*>\s*;/g;
    for (const m of source.matchAll(re)) {
      const type = m[2]!;
      const components = Number(type.replace(/\D/g, '')) || 1;
      found.push({ name: m[1]!, count: Number(m[3]), components });
    }
    return found;
  }

  const glsl = glslArrays(KFOLD_COVER_FRAGMENT_GLSL);
  const wgsl = wgslArrays(KFOLD_COVER_FRAGMENT_WGSL);

  it('finds the array declarations at all (the parser is load-bearing)', () => {
    expect(glsl.map((a) => a.name).sort()).toEqual(['uCentres']);
    expect(wgsl.map((a) => a.name).sort()).toEqual(['uCentres']);
  });

  it('declares the same arrays, at the same sizes, in both languages', () => {
    expect([...wgsl].sort((a, b) => a.name.localeCompare(b.name))).toEqual(
      [...glsl].sort((a, b) => a.name.localeCompare(b.name)),
    );
  });

  it('sets every declared array under its "[0]" name, fully sized, on both passes', () => {
    const stage = renderStage(
      <KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} colorUnion={UNION_COLOR} />,
    );
    for (const name of ['KFoldCoverSurface', 'KFoldCoverUnionShell']) {
      const mat = meshInstance(stage.root, name).material;
      for (const { name: uniform, count, components } of glsl) {
        const value = shaderParam(mat, `${uniform}[0]`);
        expect(value, `${uniform}[0] is the name both backends resolve`).toBeInstanceOf(
          Float32Array,
        );
        // Fully sized: WebGPU writes the whole uniform-buffer member, so a
        // short array would leave the tail undefined rather than zero.
        expect((value as Float32Array).length).toBe(count * components);
      }
    }
    stage.unmount();
  });

  it('sets the bare name too, so a driver that omits the suffix still binds', () => {
    const stage = renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} />);
    const mat = meshInstance(stage.root, 'KFoldCoverSurface').material;
    for (const { name } of glsl) {
      expect(shaderParam(mat, name)).toBe(shaderParam(mat, `${name}[0]`));
    }
    stage.unmount();
  });

  it('leaves the scalar uniforms on their plain names', () => {
    const stage = renderStage(<KFoldCover3D filtration={KFOLD} t={0.4} colorCover={COVER_COLOR} />);
    const mat = meshInstance(stage.root, 'KFoldCoverSurface').material;
    for (const name of ['uT', 'uK', 'uCentreCount', 'uOpacity', 'uShininess', 'uEpsilon']) {
      expect(typeof shaderParam(mat, name)).toBe('number');
      expect(shaderParam(mat, `${name}[0]`)).toBeUndefined();
    }
    stage.unmount();
  });
});
