/**
 * <PlayCanvasStage>: the container every 3D component mounts into.
 *
 * Real engine, real scene graph, `pc.NullGraphicsDevice` (see ./harness).
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { fireEvent, render, screen } from '@testing-library/react';
import { useEffect } from 'react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import * as pc from 'playcanvas';
import {
  PlayCanvasStage,
  usePlayCanvas,
  DEFAULT_DEVICE_TYPES,
  type PlayCanvasContextValue,
} from '../PlayCanvasStage';
import { entity, nullDevice, renderStage } from './harness';

/** Records the context value on every render it is given. */
function ContextProbe({ onRender }: { onRender: (v: PlayCanvasContextValue) => void }) {
  onRender(usePlayCanvas());
  return <div data-testid="probe" />;
}

afterEach(() => {
  vi.restoreAllMocks();
});

describe('<PlayCanvasStage> mounts children only once the engine exists', () => {
  it('renders children exactly once, always with a live app / camera / rootEntity', () => {
    const seen: PlayCanvasContextValue[] = [];
    const stage = renderStage(<ContextProbe onRender={(v) => seen.push(v)} />);

    expect(screen.getByTestId('probe')).toBeInTheDocument();
    expect(seen).toHaveLength(1);
    // The invariant: a child is NEVER rendered against the null context.
    for (const ctx of seen) {
      expect(ctx.app).toBe(stage.app);
      expect(ctx.camera).toBe(stage.camera);
      expect(ctx.rootEntity).toBe(stage.root);
      expect(ctx.error).toBeNull();
      // pc.NullGraphicsDevice (the seam's test device) is neither production
      // backend, so it reports the same as "no device" — see data-device below.
      expect(ctx.deviceType).toBeNull();
    }
  });

  it('renders no children at all when the engine fails to come up', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {});
    const seen: PlayCanvasContextValue[] = [];
    const onError = vi.fn();

    const { container } = render(
      <PlayCanvasStage
        onError={onError}
        createGraphicsDevice={() => {
          throw new Error('no graphics device in this environment');
        }}
      >
        <ContextProbe onRender={(v) => seen.push(v)} />
      </PlayCanvasStage>,
    );

    expect(seen).toHaveLength(0);
    expect(screen.queryByTestId('probe')).toBeNull();
    expect(warn).toHaveBeenCalled();

    // The default fallback, not a silent blank canvas: onError fires once
    // with the real Error, and the stage root's data attribute reads "none"
    // without a consumer having to touch the context at all.
    expect(onError).toHaveBeenCalledTimes(1);
    const [reportedError] = onError.mock.calls[0]!;
    expect(reportedError).toBeInstanceOf(Error);
    expect(reportedError.message).toBe('no graphics device in this environment');
    expect(container.querySelector('[data-device]')).toHaveAttribute('data-device', 'none');
    expect(screen.getByTestId('playcanvas-stage-fallback')).toBeInTheDocument();
  });

  it('renders a caller-supplied fallback node instead of the default message', () => {
    vi.spyOn(console, 'warn').mockImplementation(() => {});

    render(
      <PlayCanvasStage
        fallback={<div data-testid="custom-fallback">no GPU here</div>}
        createGraphicsDevice={() => {
          throw new Error('no graphics device in this environment');
        }}
      />,
    );

    expect(screen.getByTestId('custom-fallback')).toHaveTextContent('no GPU here');
    expect(screen.queryByTestId('playcanvas-stage-fallback')).toBeNull();
  });

  it('renders a caller-supplied fallback FUNCTION with the real Error', () => {
    vi.spyOn(console, 'warn').mockImplementation(() => {});
    const fallback = vi.fn((error: Error) => (
      <div data-testid="custom-fallback">{error.message}</div>
    ));

    render(
      <PlayCanvasStage
        fallback={fallback}
        createGraphicsDevice={() => {
          throw new Error('no graphics device in this environment');
        }}
      />,
    );

    expect(screen.getByTestId('custom-fallback')).toHaveTextContent(
      'no graphics device in this environment',
    );
    expect(fallback).toHaveBeenCalledTimes(1);
  });

  it('the seam path is synchronous: children mount after the first effect flush', () => {
    // render() flushes passive effects. If the seam awaited createGraphicsDevice
    // the way the default path does, `seen` would still be empty here and
    // every jsdom 3D test would have to waitFor the engine.
    const seen: PlayCanvasContextValue[] = [];
    const { container } = render(
      <PlayCanvasStage createGraphicsDevice={nullDevice}>
        <ContextProbe onRender={(v) => seen.push(v)} />
      </PlayCanvasStage>,
    );

    expect(seen).toHaveLength(1);
    expect(seen[0]!.app).toBeInstanceOf(pc.AppBase);
    expect(seen[0]!.error).toBeNull();
    expect(seen[0]!.deviceType).toBeNull();
    expect(container.querySelector('[data-device]')).toHaveAttribute('data-device', 'none');
    expect(screen.getByTestId('probe')).toBeInTheDocument();
  });
});

describe('<PlayCanvasStage> scene graph', () => {
  it('exposes the real engine objects through context', () => {
    const stage = renderStage(null);

    expect(stage.app).toBeInstanceOf(pc.AppBase);
    expect(stage.app.graphicsDevice).toBeInstanceOf(pc.NullGraphicsDevice);

    expect(stage.camera.name).toBe('MainCamera');
    expect(stage.camera.camera).toBeTruthy();
    expect(stage.camera.parent).toBe(stage.app.root);

    expect(stage.root.name).toBe('TdaRootNode');
    expect(stage.root.parent).toBe(stage.app.root);
    expect(stage.root.children).toHaveLength(0);
  });

  it('builds the key light and the fill light described in the component', () => {
    const stage = renderStage(null);

    const key = entity(stage.app.root, 'DirectionalLight');
    const fill = entity(stage.app.root, 'FillLight');
    expect(key.light?.type).toBe('directional');
    expect(fill.light?.type).toBe('directional');
    expect(key.light?.intensity).toBeCloseTo(1.2, 5);
    expect(fill.light?.intensity).toBeCloseTo(0.5, 5);
  });
});

describe('<PlayCanvasStage> lifecycle', () => {
  it('updates camera and display settings without destroying a device used by child effects', () => {
    const ready = vi.fn();
    const uploaded: pc.GraphicsDevice[] = [];
    function MovingMesh({ step }: { step: number }) {
      const { app } = usePlayCanvas();
      useEffect(() => {
        if (!app) return;
        // This is the operation that used to dereference a null device while
        // Logo Studio rebuilt its shaded mesh after an orbit change.
        const mesh = new pc.Mesh(app.graphicsDevice);
        mesh.setPositions([0, 0, 0, step, 0, 0, 0, 1, 0]);
        mesh.update(pc.PRIMITIVE_TRIANGLES);
        uploaded.push(app.graphicsDevice);
        return () => {
          if (app.graphicsDevice) mesh.destroy();
        };
      }, [app, step]);
      return <div data-testid="moving-mesh" />;
    }
    const tree = (step: number, enableControls = false, autoRotate = false) => (
      <PlayCanvasStage
        createGraphicsDevice={nullDevice}
        onAppReady={ready}
        cameraPosition={[step, 2, 5]}
        targetPosition={[0, step / 10, 0]}
        fov={40 + step}
        clearColor={step === 1 ? '#ffffff' : '#009ecc'}
        enableControls={enableControls}
        autoRotate={autoRotate}
        autoRotateSpeed={2}
      >
        <MovingMesh step={step} />
      </PlayCanvasStage>
    );
    const view = render(tree(1));
    const app = ready.mock.calls[0]![0] as pc.Application;
    const device = app.graphicsDevice;
    const destroy = vi.spyOn(app, 'destroy');
    const camera = entity(app.root, 'MainCamera');
    for (let step = 2; step <= 8; step++) {
      view.rerender(tree(step));
      app.fire('update', 1 / 60);
      expect(camera.getPosition().x).toBeCloseTo(step);
      expect(camera.getPosition().y).toBeCloseTo(2);
      expect(camera.getPosition().z).toBeCloseTo(5);
      expect(camera.camera!.fov).toBe(40 + step);
    }
    expect(camera.camera!.clearColor.g).toBeCloseTo(158 / 255);
    expect(uploaded).toHaveLength(8);
    expect(uploaded.every((item) => item === device)).toBe(true);
    expect(ready).toHaveBeenCalledTimes(1);
    expect(destroy).not.toHaveBeenCalled();

    const canvas = view.container.querySelector('canvas')!;
    const position = camera.getPosition().clone();
    fireEvent.wheel(canvas, { deltaY: 200 });
    app.fire('update', 1);
    expect(camera.getPosition().equals(position)).toBe(true);
    view.rerender(tree(8, true));
    fireEvent.wheel(canvas, { deltaY: 200 });
    app.fire('update', 1);
    expect(camera.getPosition().equals(position)).toBe(false);
    view.rerender(tree(8, false, true));
    const beforeRotation = camera.getPosition().clone();
    app.fire('update', 1);
    expect(camera.getPosition().equals(beforeRotation)).toBe(false);
    expect(destroy).not.toHaveBeenCalled();
    view.unmount();
    expect(destroy).toHaveBeenCalledTimes(1);
  });

  it('destroys the application on unmount', () => {
    const stage = renderStage(null);
    const destroy = vi.spyOn(stage.app, 'destroy');

    expect(destroy).not.toHaveBeenCalled();
    stage.unmount();
    expect(destroy).toHaveBeenCalledTimes(1);
  });

  it('does NOT rebuild the engine when re-rendered with a new inline onAppReady', () => {
    // The regression this guards: an inline arrow prop is a new function on
    // every render of the consumer, so if onAppReady were an effect dependency
    // the whole engine would be torn down and rebuilt every frame.
    const ready = vi.fn();
    const tree = (cb: (a: pc.Application) => void) => (
      <PlayCanvasStage createGraphicsDevice={nullDevice} onAppReady={(a) => cb(a)}>
        <div data-testid="child" />
      </PlayCanvasStage>
    );

    const view = render(tree(ready));
    expect(ready).toHaveBeenCalledTimes(1);
    const app = ready.mock.calls[0]![0] as pc.Application;
    const rootEntity = entity(app.root, 'TdaRootNode');
    const destroy = vi.spyOn(app, 'destroy');

    // Re-render three times, each with a brand-new inline callback identity.
    view.rerender(tree(ready));
    view.rerender(tree(ready));
    view.rerender(tree(ready));

    expect(destroy).not.toHaveBeenCalled();
    expect(ready).toHaveBeenCalledTimes(1);
    expect(entity(app.root, 'TdaRootNode')).toBe(rootEntity);
    expect(screen.getByTestId('child')).toBeInTheDocument();

    view.unmount();
    expect(destroy).toHaveBeenCalledTimes(1);
  });
});

describe('<PlayCanvasStage> default graphics device', () => {
  it('pins the default deviceTypes order as WebGPU then WebGL2', () => {
    // Source-level pin: createGraphicsDevice is async and jsdom has neither
    // backend, so we do not call it. The engine mutates the array it is given
    // (appends NULL); the call site must pass a copy of this constant.
    expect(DEFAULT_DEVICE_TYPES).toEqual([pc.DEVICETYPE_WEBGPU, pc.DEVICETYPE_WEBGL2]);
    const src = readFileSync(
      join(dirname(fileURLToPath(import.meta.url)), '../PlayCanvasStage.tsx'),
      'utf8',
    );
    expect(src).toContain('deviceTypes: [...DEFAULT_DEVICE_TYPES]');
  });
});
