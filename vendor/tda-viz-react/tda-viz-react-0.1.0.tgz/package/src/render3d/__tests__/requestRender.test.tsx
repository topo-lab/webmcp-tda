/**
 * The 3D components tell the stage when they have changed the scene.
 *
 * Written BEFORE the code (CLAUDE.md, Testing Policy). A stage that draws on
 * demand (`renderOnDemand`) only knows about changes something reports. The
 * components are the only things that know, so each of them has to say so, and
 * the ways that can go wrong are:
 *
 *   1. A new scale t writes a uniform (or moves geometry) and nothing asks for a
 *      frame, so the picture stays where it was.
 *   2. A rebuild (a new colour, a new cloud) swaps the entities and nothing asks
 *      for a frame.
 *   3. A component that unmounts takes its entities out of the scene and nothing
 *      asks for a frame, so what it drew stays on screen.
 *   4. An identity-only change (an equal array under a new reference) rebuilds
 *      the point cloud: it destroys and recreates its entity, sphere mesh,
 *      material and instancing buffer for no reason. At 60 Hz, from a parent
 *      that re-renders every frame, that is the allocation churn.
 *      A real change of content must still rebuild.
 *
 * Every assertion is synchronous, straight after React has flushed, so the
 * engine's own rAF loop cannot reset the flag in between.
 */
import type { ReactElement } from 'react';
import { describe, expect, it } from 'vitest';
import { CycleHighlight3D } from '../CycleHighlight3D';
import { DepthSlice3D } from '../DepthSlice3D';
import { Field3D } from '../Field3D';
import { KFoldCover3D } from '../KFoldCover3D';
import { Nerve3D } from '../Nerve3D';
import { PointCloud3D } from '../PointCloud3D';
import {
  CIRCLE24_ALPHA,
  JITTERED8_KFOLD2,
  TETRA4_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import { entity, renderStage } from './harness';

const tetra = recordedFiltration(TETRA4_ALPHA);
const kfold = recordedFiltration(JITTERED8_KFOLD2);
const RAMP: [string, string, string, string] = ['#dfe4f5', '#a3b0e6', '#6a7ad0', '#4450b4'];

const byT: Array<[string, (t: number) => ReactElement]> = [
  ['Nerve3D', (t) => <Nerve3D filtration={tetra} t={t} />],
  ['Field3D', (t) => <Field3D filtration={tetra} t={t} />],
  ['DepthSlice3D', (t) => <DepthSlice3D filtration={kfold} t={t} colors={RAMP} />],
  [
    'KFoldCover3D',
    (t) => <KFoldCover3D filtration={kfold} t={t} colorCover="#4450b4" colorUnion="#6a7ad0" />,
  ],
];

describe('a component that moves t asks for a frame', () => {
  it.each(byT)('%s', (_name, tree) => {
    const stage = renderStage(tree(0.2));
    stage.app.renderNextFrame = false;
    stage.rerender(tree(0.3));
    expect(stage.app.renderNextFrame).toBe(true);
  });
});

const rebuilds: Array<[string, (variant: number) => ReactElement]> = [
  [
    'PointCloud3D',
    (v) => <PointCloud3D points={TETRA4_ALPHA.cloud.points} color={v ? '#ff0000' : '#00ff00'} />,
  ],
  [
    'CycleHighlight3D',
    (v) => (
      <CycleHighlight3D
        points={CIRCLE24_ALPHA.cloud.points}
        dimension={2}
        cycle={[0, 4, 8, 12]}
        color={v ? '#ff0000' : '#00ff00'}
      />
    ),
  ],
  ['Nerve3D', (v) => <Nerve3D filtration={v ? kfold : tetra} t={0.4} />],
];

describe('a component that rebuilds its entities asks for a frame', () => {
  it.each(rebuilds)('%s', (_name, tree) => {
    const stage = renderStage(tree(0));
    stage.app.renderNextFrame = false;
    stage.rerender(tree(1));
    expect(stage.app.renderNextFrame).toBe(true);
  });
});

describe('a component that unmounts asks for a frame', () => {
  it.each([
    ['PointCloud3D', () => <PointCloud3D points={TETRA4_ALPHA.cloud.points} />],
    ['Nerve3D', () => <Nerve3D filtration={tetra} t={0.4} />],
    ['Field3D', () => <Field3D filtration={tetra} t={0.4} />],
    ['KFoldCover3D', () => <KFoldCover3D filtration={kfold} t={0.4} colorCover="#4450b4" />],
  ] as Array<[string, () => ReactElement]>)('%s', (_name, tree) => {
    const stage = renderStage(tree());
    stage.app.renderNextFrame = false;
    stage.rerender(null);
    expect(stage.app.renderNextFrame).toBe(true);
  });
});

describe('<PointCloud3D> and identity-only changes', () => {
  const WEIGHTS = [0, 0.25, 1, 4];

  it('keeps its entity when handed an equal array under a new reference', () => {
    const tree = () => (
      <PointCloud3D points={[...TETRA4_ALPHA.cloud.points]} weights={[...WEIGHTS]} />
    );
    const stage = renderStage(tree());
    const built = entity(stage.root, 'PointCloudInstanced');
    const parent = entity(stage.root, 'PointCloud3D');

    for (let frame = 0; frame < 5; frame++) stage.rerender(tree());

    expect(entity(stage.root, 'PointCloudInstanced')).toBe(built);
    expect(entity(stage.root, 'PointCloud3D')).toBe(parent);
    expect(built.render?.meshInstances).toHaveLength(1);
  });

  it('still rebuilds when the coordinates change', () => {
    const stage = renderStage(<PointCloud3D points={[...TETRA4_ALPHA.cloud.points]} />);
    const built = entity(stage.root, 'PointCloudInstanced');
    const moved = TETRA4_ALPHA.cloud.points.map((v, i) => (i === 0 ? v + 0.5 : v));
    stage.rerender(<PointCloud3D points={moved} />);
    expect(entity(stage.root, 'PointCloudInstanced')).not.toBe(built);
  });

  it('still rebuilds when the weights change', () => {
    const stage = renderStage(
      <PointCloud3D points={TETRA4_ALPHA.cloud.points} weights={[...WEIGHTS]} />,
    );
    const built = entity(stage.root, 'PointCloudInstanced');
    stage.rerender(<PointCloud3D points={TETRA4_ALPHA.cloud.points} weights={[0, 0.25, 1, 5]} />);
    expect(entity(stage.root, 'PointCloudInstanced')).not.toBe(built);
  });

  it('still rebuilds when the number of points changes', () => {
    const stage = renderStage(<PointCloud3D points={[...TETRA4_ALPHA.cloud.points]} />);
    const built = entity(stage.root, 'PointCloudInstanced');
    stage.rerender(<PointCloud3D points={TETRA4_ALPHA.cloud.points.slice(0, 9)} />);
    expect(entity(stage.root, 'PointCloudInstanced')).not.toBe(built);
  });
});

describe('<CycleHighlight3D> and identity-only changes', () => {
  it('keeps its entity when handed equal arrays under new references', () => {
    const tree = () => (
      <CycleHighlight3D
        points={[...CIRCLE24_ALPHA.cloud.points]}
        dimension={2}
        cycle={[0, 4, 8, 12]}
      />
    );
    const stage = renderStage(tree());
    const parent = entity(stage.root, 'CycleHighlight3D');
    for (let frame = 0; frame < 5; frame++) stage.rerender(tree());
    expect(entity(stage.root, 'CycleHighlight3D')).toBe(parent);
  });

  it('still rebuilds when the cycle changes', () => {
    const tree = (cycle: number[]) => (
      <CycleHighlight3D points={CIRCLE24_ALPHA.cloud.points} dimension={2} cycle={cycle} />
    );
    const stage = renderStage(tree([0, 4, 8, 12]));
    const parent = entity(stage.root, 'CycleHighlight3D');
    stage.rerender(tree([0, 4, 8, 13]));
    expect(entity(stage.root, 'CycleHighlight3D')).not.toBe(parent);
  });
});
