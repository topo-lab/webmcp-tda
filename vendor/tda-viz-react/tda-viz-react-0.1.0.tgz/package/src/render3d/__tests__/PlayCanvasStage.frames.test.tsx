/**
 * <PlayCanvasStage>: when it draws, and how its camera settles.
 *
 * Written BEFORE the code (CLAUDE.md, Testing Policy). The ways this can fail,
 * each of which a case below pins:
 *
 *   1. A stage nobody can see keeps drawing. `active={false}` must stop every
 *      render, including one a child asks for, and coming back must repaint.
 *   2. A stage that is paused or static keeps drawing. `renderOnDemand` must
 *      draw only when something asked, and stop again on its own.
 *   3. Asking for a frame is lost. A moving camera, a changed camera prop, a
 *      returning tab and a resize must each produce a frame in on-demand mode.
 *   4. A zero-size layout box (display: none, a collapsed parent) resizes the
 *      backing store to 0 x 0 and draws into it.
 *   5. Moving the window to another display leaves the backing store at the old
 *      pixel ratio, because nothing observed the ratio.
 *   6. The camera settles on a different clock at 30 fps and at 60 fps: the old
 *      `min(1, dt * 10)` is a first-order step, not the exponential it stands in
 *      for.
 *   7. `autoRotate` ignores prefers-reduced-motion.
 *   8. Defaults change. With neither new prop given the stage must behave as it
 *      always did: it draws every frame.
 *
 * The device is the harness's `pc.NullGraphicsDevice`; `render` is stubbed so a
 * "frame" is a counted call, and the engine's own rAF loop (jsdom pretends to be
 * visible) is what drives it. Cases that need determinism call
 * `app.fire('update', dt)` synchronously instead of waiting for a tick.
 */
import { fireEvent, render } from '@testing-library/react';
import type { ReactNode } from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import * as pc from 'playcanvas';
import { PlayCanvasStage, type PlayCanvasStageProps } from '../PlayCanvasStage';
import { entity, nullDevice } from './harness';

// ── Environment stubs ────────────────────────────────────────────────────

const box = { w: 300, h: 150 };

/** jsdom lays nothing out, so a canvas is 0 x 0 unless the test says otherwise. */
function stubCanvasBox() {
  Object.defineProperty(HTMLCanvasElement.prototype, 'clientWidth', {
    configurable: true,
    get: () => box.w,
  });
  Object.defineProperty(HTMLCanvasElement.prototype, 'clientHeight', {
    configurable: true,
    get: () => box.h,
  });
}

function setPixelRatio(value: number) {
  Object.defineProperty(window, 'devicePixelRatio', { configurable: true, value });
}

/** A matchMedia whose queries the test flips and fires by hand. */
function installMatchMedia() {
  const matches = new Map<string, boolean>();
  const listeners = new Map<string, Set<(e: MediaQueryListEvent) => void>>();
  const queries: string[] = [];
  window.matchMedia = ((query: string) => {
    queries.push(query);
    const set = listeners.get(query) ?? new Set();
    listeners.set(query, set);
    return {
      get matches() {
        return matches.get(query) ?? false;
      },
      media: query,
      addEventListener: (_type: string, fn: (e: MediaQueryListEvent) => void) => set.add(fn),
      removeEventListener: (_type: string, fn: (e: MediaQueryListEvent) => void) => set.delete(fn),
    } as unknown as MediaQueryList;
  }) as typeof window.matchMedia;
  return {
    queries,
    listenerCount: (q: string) => listeners.get(q)?.size ?? 0,
    set(query: string, value: boolean) {
      matches.set(query, value);
    },
    fire(query: string) {
      for (const fn of [...(listeners.get(query) ?? [])]) {
        fn({ matches: matches.get(query) ?? false, media: query } as MediaQueryListEvent);
      }
    },
  };
}

const REDUCED = '(prefers-reduced-motion: reduce)';
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

let resizeObservers: Array<(entries: ResizeObserverEntry[]) => void> = [];

beforeEach(() => {
  box.w = 300;
  box.h = 150;
  stubCanvasBox();
  setPixelRatio(1);
  resizeObservers = [];
  globalThis.ResizeObserver = class {
    constructor(cb: (entries: ResizeObserverEntry[]) => void) {
      resizeObservers.push(cb);
    }
    observe() {}
    unobserve() {}
    disconnect() {}
  } as unknown as typeof ResizeObserver;
});

afterEach(() => {
  delete (HTMLCanvasElement.prototype as unknown as Record<string, unknown>).clientWidth;
  delete (HTMLCanvasElement.prototype as unknown as Record<string, unknown>).clientHeight;
  // @ts-expect-error jsdom has no matchMedia; remove whatever a test installed.
  delete window.matchMedia;
  vi.restoreAllMocks();
});

function mount(
  props: Partial<PlayCanvasStageProps> = {},
  children?: ReactNode,
  { stubRender = true }: { stubRender?: boolean } = {},
) {
  const holder: { app: pc.Application | null } = { app: null };
  const tree = (p: Partial<PlayCanvasStageProps>, kids?: ReactNode) => (
    <PlayCanvasStage
      createGraphicsDevice={nullDevice}
      onAppReady={(a) => {
        holder.app = a;
      }}
      {...p}
    >
      {kids}
    </PlayCanvasStage>
  );
  const view = render(tree(props, children));
  const app = holder.app;
  if (!app) throw new Error('stage never created an application');
  // A counted call, not a drawn frame, unless a test needs the engine's own
  // render (it re-fits the backing store to the layout box as it starts).
  const frames = vi.spyOn(app, 'render');
  if (stubRender) frames.mockImplementation(() => {});
  return {
    app,
    frames,
    canvas: view.container.querySelector('canvas')!,
    camera: entity(app.root, 'MainCamera'),
    rerender: (p: Partial<PlayCanvasStageProps>, kids?: ReactNode) => view.rerender(tree(p, kids)),
    unmount: () => view.unmount(),
  };
}

/** Let the engine's own loop run, then say how many frames it drew. */
async function framesIn(m: ReturnType<typeof mount>, ms: number): Promise<number> {
  m.frames.mockClear();
  await sleep(ms);
  return m.frames.mock.calls.length;
}

const yawOf = (camera: pc.Entity, target = [0, 0, 0]) => {
  const p = camera.getPosition();
  return Math.atan2(p.x - target[0]!, p.z - target[2]!);
};

function drag(canvas: HTMLCanvasElement, dx: number) {
  fireEvent.mouseDown(canvas, { clientX: 200, clientY: 100 });
  fireEvent.mouseMove(window, { clientX: 200 - dx, clientY: 100 });
  fireEvent.mouseUp(window);
}

// ── 8. defaults ──────────────────────────────────────────────────────────

describe('defaults are unchanged', () => {
  it('draws every frame when neither active nor renderOnDemand is given', async () => {
    const m = mount();
    expect(m.app.autoRender).toBe(true);
    expect(await framesIn(m, 200)).toBeGreaterThanOrEqual(3);
  });
});

// ── 1. active ────────────────────────────────────────────────────────────

describe('active', () => {
  it('draws nothing while inactive, even when a frame is requested', async () => {
    const m = mount({ active: false });
    expect(m.app.autoRender).toBe(false);
    expect(await framesIn(m, 200)).toBe(0);

    m.app.renderNextFrame = true;
    expect(await framesIn(m, 200)).toBe(0);
  });

  it('repaints once on the way back, then follows its mode', async () => {
    const m = mount({ active: false, renderOnDemand: true });
    expect(await framesIn(m, 100)).toBe(0);

    m.rerender({ active: true, renderOnDemand: true });
    await sleep(150);
    m.frames.mockClear();
    // It came back and drew (the wake frame has already gone by), and an idle
    // on-demand stage does not keep going.
    expect(await framesIn(m, 200)).toBe(0);
    expect(m.app.autoRender).toBe(false);
  });

  it('draws the wake frame when it becomes active again', async () => {
    const m = mount({ active: false, renderOnDemand: true });
    await sleep(60);
    m.frames.mockClear();
    m.rerender({ active: true, renderOnDemand: true });
    await sleep(150);
    expect(m.frames.mock.calls.length).toBeGreaterThanOrEqual(1);
  });

  it('resumes drawing every frame in the default mode', async () => {
    const m = mount({ active: false });
    expect(await framesIn(m, 100)).toBe(0);
    m.rerender({ active: true });
    // The gate reads the prop on the engine's next frame, not at the commit.
    expect(await framesIn(m, 200)).toBeGreaterThanOrEqual(3);
    expect(m.app.autoRender).toBe(true);
  });
});

// ── 2 and 3. renderOnDemand ──────────────────────────────────────────────

describe('renderOnDemand', () => {
  it('goes quiet once nothing has changed', async () => {
    const m = mount({ renderOnDemand: true });
    expect(m.app.autoRender).toBe(false);
    await sleep(150);
    expect(await framesIn(m, 250)).toBe(0);
  });

  it('draws exactly the frame that was asked for', async () => {
    const m = mount({ renderOnDemand: true });
    await sleep(150);
    m.frames.mockClear();
    m.app.renderNextFrame = true;
    await sleep(150);
    expect(m.frames.mock.calls.length).toBe(1);
  });

  it('asks for a frame while the camera is still settling, and stops when it has settled', () => {
    const m = mount({ renderOnDemand: true, cameraPosition: [0, 0, 5] });
    m.app.renderNextFrame = false;
    drag(m.canvas, 100);

    m.app.fire('update', 1 / 60);
    expect(m.app.renderNextFrame).toBe(true);

    let settledAfter = -1;
    for (let i = 0; i < 400; i++) {
      m.app.renderNextFrame = false;
      m.app.fire('update', 1 / 60);
      if (!m.app.renderNextFrame) {
        settledAfter = i;
        break;
      }
    }
    // ln(0.6 / 1e-4) / 10 = 0.87 s: a bounded, short tail, not an asymptote.
    expect(settledAfter).toBeGreaterThan(10);
    expect(settledAfter).toBeLessThan(120);
    // And it landed on the target rather than one tick short of it. (The engine
    // keeps positions in single precision, hence 6 places and not 12.)
    expect(yawOf(m.camera)).toBeCloseTo(0.6, 6);
  });

  it('asks for a frame when a camera or display prop changes', () => {
    const m = mount({
      renderOnDemand: true,
      cameraPosition: [0, 0, 5],
      fov: 45,
      clearColor: '#000000',
    });

    m.app.renderNextFrame = false;
    m.rerender({ renderOnDemand: true, cameraPosition: [1, 0, 5], fov: 45, clearColor: '#000000' });
    expect(m.app.renderNextFrame).toBe(true);

    m.app.renderNextFrame = false;
    m.rerender({ renderOnDemand: true, cameraPosition: [1, 0, 5], fov: 60, clearColor: '#000000' });
    expect(m.app.renderNextFrame).toBe(true);

    m.app.renderNextFrame = false;
    m.rerender({ renderOnDemand: true, cameraPosition: [1, 0, 5], fov: 60, clearColor: '#ffffff' });
    expect(m.app.renderNextFrame).toBe(true);
  });

  it('asks for a frame when the tab becomes visible again', async () => {
    const m = mount({ renderOnDemand: true });
    await sleep(150);
    m.frames.mockClear();
    document.dispatchEvent(new Event('visibilitychange'));
    await sleep(150);
    expect(m.frames.mock.calls.length).toBeGreaterThanOrEqual(1);
  });
});

// ── 4. zero-size layout ──────────────────────────────────────────────────

describe('a zero-size layout box', () => {
  it('is noticed by the frame about to be drawn, before the engine re-fits the backing store to it', async () => {
    // No observer callback at all: the box collapses and the engine ticks. The
    // engine's own render() begins by resizing the canvas to its client box, so
    // this has to be caught by the gate, using the engine's real render.
    const m = mount({}, undefined, { stubRender: false });
    await sleep(60);
    expect(m.canvas.width).toBe(300);

    box.w = 0;
    box.h = 0;
    await sleep(150);
    expect(m.canvas.width).toBe(300);
    expect(m.canvas.height).toBe(150);
    expect(await framesIn(m, 100)).toBe(0);

    box.w = 300;
    box.h = 150;
    resizeObservers[0]!([]);
    await sleep(60);
    expect(await framesIn(m, 150)).toBeGreaterThanOrEqual(2);
  });

  it('neither shrinks the backing store to 0 x 0 nor draws into it', async () => {
    const m = mount();
    expect(m.canvas.width).toBe(300);
    expect(m.canvas.height).toBe(150);
    const observed = resizeObservers[0]!;

    box.w = 0;
    box.h = 0;
    observed([]);
    await sleep(60);
    expect(m.canvas.width).toBe(300);
    expect(m.canvas.height).toBe(150);
    expect(m.app.autoRender).toBe(false);
    expect(await framesIn(m, 150)).toBe(0);
  });

  it('resizes and draws again when the box comes back', async () => {
    const m = mount();
    const observed = resizeObservers[0]!;
    box.w = 0;
    box.h = 0;
    observed([]);
    await sleep(60);

    box.w = 400;
    box.h = 200;
    observed([]);
    await sleep(60);
    expect(m.canvas.width).toBe(400);
    expect(m.canvas.height).toBe(200);
    expect(m.app.autoRender).toBe(true);
    expect(await framesIn(m, 150)).toBeGreaterThanOrEqual(2);
  });
});

// ── 5. pixel ratio ───────────────────────────────────────────────────────

describe('a change of device pixel ratio', () => {
  it('re-applies the ratio and the backing size, capped at 2', () => {
    const media = installMatchMedia();
    const m = mount();
    expect(m.canvas.width).toBe(300);
    expect(m.app.graphicsDevice.maxPixelRatio).toBe(1);

    setPixelRatio(2);
    media.fire('(resolution: 1dppx)');
    expect(m.app.graphicsDevice.maxPixelRatio).toBe(2);
    expect(m.canvas.width).toBe(600);
    expect(m.canvas.height).toBe(300);

    setPixelRatio(3);
    media.fire('(resolution: 2dppx)');
    expect(m.app.graphicsDevice.maxPixelRatio).toBe(2);
    expect(m.canvas.width).toBe(600);

    setPixelRatio(1);
    media.fire('(resolution: 3dppx)');
    expect(m.canvas.width).toBe(300);
  });

  it('asks for a frame, because resizing clears the drawing buffer', () => {
    const media = installMatchMedia();
    const m = mount({ renderOnDemand: true });
    m.app.renderNextFrame = false;
    setPixelRatio(2);
    media.fire('(resolution: 1dppx)');
    expect(m.app.renderNextFrame).toBe(true);
  });

  it('stops listening when the stage unmounts', () => {
    const media = installMatchMedia();
    const m = mount();
    expect(media.listenerCount('(resolution: 1dppx)')).toBe(1);
    m.unmount();
    expect(media.listenerCount('(resolution: 1dppx)')).toBe(0);
  });
});

// ── 6. damping ───────────────────────────────────────────────────────────

describe('camera damping', () => {
  const settle = (fps: number, seconds: number) => {
    const m = mount({ cameraPosition: [0, 0, 5] });
    drag(m.canvas, 100);
    for (let i = 0; i < Math.round(seconds * fps); i++) m.app.fire('update', 1 / fps);
    const yaw = yawOf(m.camera);
    m.unmount();
    return yaw;
  };

  it('reaches the same place after the same time at 30 and at 60 fps', () => {
    const at60 = settle(60, 0.3);
    const at30 = settle(30, 0.3);
    // The drag moved the target by 0.6 rad; what is left is what has not settled.
    expect(Math.abs(at60 - at30)).toBeLessThan(1e-6);
    // And it is the exponential, 1 - e^(-10 t), not some other curve.
    expect((0.6 - at60) / 0.6).toBeCloseTo(Math.exp(-3), 6);
  });
});

// ── 7. reduced motion ────────────────────────────────────────────────────

describe('autoRotate under prefers-reduced-motion', () => {
  const spin = (m: ReturnType<typeof mount>, seconds: number) => {
    const before = yawOf(m.camera);
    for (let i = 0; i < seconds * 60; i++) m.app.fire('update', 1 / 60);
    return Math.abs(yawOf(m.camera) - before);
  };

  it('rotates when motion is welcome', () => {
    const media = installMatchMedia();
    media.set(REDUCED, false);
    const m = mount({ autoRotate: true, autoRotateSpeed: 2, cameraPosition: [0, 0, 5] });
    expect(spin(m, 1)).toBeGreaterThan(0.5);
  });

  it('does not rotate when reduced motion is requested at mount', () => {
    const media = installMatchMedia();
    media.set(REDUCED, true);
    const m = mount({ autoRotate: true, autoRotateSpeed: 2, cameraPosition: [0, 0, 5] });
    expect(spin(m, 3)).toBe(0);
  });

  it('follows the preference as it changes', () => {
    const media = installMatchMedia();
    media.set(REDUCED, false);
    const m = mount({ autoRotate: true, autoRotateSpeed: 2, cameraPosition: [0, 0, 5] });
    expect(spin(m, 0.5)).toBeGreaterThan(0.2);

    media.set(REDUCED, true);
    media.fire(REDUCED);
    // The camera is still arriving at where the rotation had pointed it; let it
    // land, and only then ask whether anything keeps turning.
    spin(m, 2);
    expect(spin(m, 1)).toBe(0);

    media.set(REDUCED, false);
    media.fire(REDUCED);
    expect(spin(m, 0.5)).toBeGreaterThan(0.2);
  });

  it('leaves user-driven orbit alone', () => {
    const media = installMatchMedia();
    media.set(REDUCED, true);
    const m = mount({ autoRotate: true, cameraPosition: [0, 0, 5] });
    drag(m.canvas, 100);
    for (let i = 0; i < 90; i++) m.app.fire('update', 1 / 60);
    expect(yawOf(m.camera)).toBeCloseTo(0.6, 3);
  });
});
