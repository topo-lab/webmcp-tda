import {
  createContext,
  useContext,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';
import * as pc from 'playcanvas';
import {
  dampingFactor,
  parseColor,
  prefersReducedMotion,
  requestRender,
  watchDevicePixelRatio,
  watchReducedMotion,
} from './utils';

export interface PlayCanvasContextValue {
  app: pc.Application | null;
  camera: pc.Entity | null;
  rootEntity: pc.Entity | null;
  /** Active graphics backend actually achieved, or `null` before init / on failure. */
  deviceType: 'webgpu' | 'webgl2' | null;
  /**
   * Set when `createGraphicsDevice` rejects, resolves with a null device
   * (`device.isNull` — WebGPU and WebGL2 both unavailable), or the
   * `pc.Application` constructor throws. `app` stays `null` whenever this is
   * set: a consumer never sees a live app alongside an error.
   */
  error: Error | null;
}

export const PlayCanvasContext = createContext<PlayCanvasContextValue>({
  app: null,
  camera: null,
  rootEntity: null,
  deviceType: null,
  error: null,
});

export function usePlayCanvas(): PlayCanvasContextValue {
  return useContext(PlayCanvasContext);
}

/**
 * Default `createGraphicsDevice` attempt order: WebGPU first, WebGL2 fallback.
 *
 * Passed as a copy (`[...DEFAULT_DEVICE_TYPES]`) because the engine mutates
 * the array it is given — it appends `DEVICETYPE_WEBGL2` if missing, then
 * `DEVICETYPE_NULL` as a last-ditch fallback (playcanvas
 * `createGraphicsDevice`, 2.21.4).
 */
export const DEFAULT_DEVICE_TYPES: [typeof pc.DEVICETYPE_WEBGPU, typeof pc.DEVICETYPE_WEBGL2] = [
  pc.DEVICETYPE_WEBGPU,
  pc.DEVICETYPE_WEBGL2,
];

const GRAPHICS_DEVICE_OPTIONS = {
  antialias: true,
  alpha: true,
  preserveDrawingBuffer: false,
};

export interface PlayCanvasStageProps {
  children?: ReactNode;
  className?: string;
  style?: CSSProperties;
  cameraPosition?: [number, number, number];
  targetPosition?: [number, number, number];
  fov?: number;
  clearColor?: string;
  enableControls?: boolean;
  /**
   * Turn the camera slowly about the target. Suppressed while the user's system
   * asks for reduced motion (`prefers-reduced-motion: reduce`), read at mount and
   * followed as it changes; dragging the camera by hand is unaffected.
   */
  autoRotate?: boolean;
  autoRotateSpeed?: number;
  /**
   * Whether the stage may draw at all. Default `true`.
   *
   * Pass `false` while the stage cannot be seen (scrolled out of view, on a tab
   * that is not selected) and it stops issuing draw calls entirely: the last
   * frame stays on the canvas, the engine's update loop keeps running (so
   * camera damping and your own `update` handlers carry on), and one frame is
   * drawn at the moment it becomes `true` again. A stage drawn into a box with no
   * area does not draw either, whatever this says.
   */
  active?: boolean;
  /**
   * Draw only when something asked for a frame. Default `false`: draw every
   * frame, as the stage always has.
   *
   * A stage that is paused or static then costs no GPU time at all. The
   * components in this package ask for the frame themselves whenever they change
   * the scene (a new `t`, a rebuilt entity, one removed), the stage asks for one
   * when the camera is moving, a camera or display prop changes, the canvas or
   * the device pixel ratio changes, or the tab becomes visible again, and the
   * engine forgets the request once it has drawn. A component of your own that
   * changes the scene outside a React render must set `app.renderNextFrame = true` to
   * be seen.
   */
  renderOnDemand?: boolean;
  /** Called once with the PlayCanvas application, for consumers that need the raw app. */
  onAppReady?: (app: pc.Application) => void;
  /**
   * Called once, exactly when `error` is set on the context (rejection,
   * resolved-null device, or a throw from the `pc.Application` constructor).
   * Fires whether or not `fallback` is supplied.
   */
  onError?: (error: Error) => void;
  /**
   * Rendered in place of `children` while `error` is set. A function receives
   * the `Error` so a consumer can vary its message; a plain node ignores it.
   * With neither this nor `onError`, the stage still never renders a silent
   * blank canvas — it shows its own one-sentence fallback message.
   */
  fallback?: ReactNode | ((error: Error) => ReactNode);
  /**
   * TEST SEAM. Supplies the `pc.GraphicsDevice` instead of letting the
   * default path `await pc.createGraphicsDevice(...)`.
   *
   * jsdom has no WebGL/WebGPU context, so the only way to exercise the real
   * scene graph in a unit test is to hand the engine a `pc.NullGraphicsDevice`
   * (`pc.Application` takes `options.graphicsDevice` and only calls its own
   * `createDevice` when that is absent). When this prop is set the whole
   * mount stays SYNCHRONOUS — no `await` — which the jsdom tests depend on.
   * Production code must leave this undefined.
   */
  createGraphicsDevice?: (canvas: HTMLCanvasElement) => pc.GraphicsDevice;
}

/**
 * Retina cap. Above 2 the pixel count grows faster than the picture improves,
 * and these scenes are fill-rate bound on translucent geometry.
 */
const MAX_PIXEL_RATIO = 2;

/**
 * Camera follow rate, per second: the camera closes `1 - e^(-10 t)` of the
 * distance to where the user pointed it in `t` seconds (see `dampingFactor`).
 */
const DAMPING_RATE = 10;

/**
 * A follower this close to its target has arrived. 1e-4 rad is a fraction of a
 * pixel at any sensible field of view, and snapping there ends the exponential's
 * infinite tail, so an on-demand stage stops asking for frames about 0.9 s after
 * a half-radian drag instead of never.
 */
const SETTLE_EPSILON = 1e-4;

const NULL_CONTEXT: PlayCanvasContextValue = {
  app: null,
  camera: null,
  rootEntity: null,
  deviceType: null,
  error: null,
};

/** Narrow a `pc.GraphicsDevice.deviceType` string to the two real backends, or `null`. */
function toDeviceTypeLiteral(deviceType: string): 'webgpu' | 'webgl2' | null {
  if (deviceType === pc.DEVICETYPE_WEBGPU) return 'webgpu';
  if (deviceType === pc.DEVICETYPE_WEBGL2) return 'webgl2';
  return null;
}

/**
 * One plain sentence, never a raw hex literal (DESIGN.md "Colour": colours
 * come from `var(--token)`) — shown in place of an empty canvas so a consumer
 * never has to infer device failure from a silent black rectangle.
 */
const STAGE_FALLBACK_MESSAGE =
  'This browser has no usable WebGPU or WebGL2 graphics device, so the 3D stage cannot render.';

function DefaultStageFallback() {
  return (
    <div
      data-testid="playcanvas-stage-fallback"
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1.5rem',
        textAlign: 'center',
        fontFamily: 'ui-monospace, monospace',
        fontSize: 13,
        lineHeight: 1.5,
        color: 'var(--text-on-ink-dim, rgb(154, 164, 184))',
        background: 'var(--ink, rgb(10, 15, 28))',
      }}
    >
      {STAGE_FALLBACK_MESSAGE}
    </div>
  );
}

export function PlayCanvasStage({
  children,
  className,
  style,
  cameraPosition = [0, 0, 3.2],
  targetPosition = [0, 0, 0],
  fov = 45,
  clearColor = '#0b1020',
  enableControls = true,
  autoRotate = false,
  autoRotateSpeed = 0.5,
  active = true,
  renderOnDemand = false,
  onAppReady,
  onError,
  fallback,
  createGraphicsDevice,
}: PlayCanvasStageProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [contextValue, setContextValue] = useState<PlayCanvasContextValue>(NULL_CONTEXT);

  // Held in a ref so a consumer passing an inline arrow function does not
  // destroy and rebuild the whole engine on every one of its renders.
  const onAppReadyRef = useRef(onAppReady);
  useEffect(() => {
    onAppReadyRef.current = onAppReady;
  }, [onAppReady]);

  // Same reasoning: read from the effect via a ref rather than made a
  // dependency, so an inline `onError` does not tear down the engine either.
  const onErrorRef = useRef(onError);
  useEffect(() => {
    onErrorRef.current = onError;
  }, [onError]);

  // Same reasoning as onAppReady: the injected-device factory is read once, at
  // engine construction time, and must not be an effect dependency.
  const createGraphicsDeviceRef = useRef(createGraphicsDevice);
  useEffect(() => {
    createGraphicsDeviceRef.current = createGraphicsDevice;
  }, [createGraphicsDevice]);

  // Scalars, not array literals: the effect below must be able to declare its
  // real dependencies without tripping exhaustive-deps on `cameraPosition[0]`.
  const [cameraX, cameraY, cameraZ] = cameraPosition;
  const [targetX, targetY, targetZ] = targetPosition;

  // These are live scene settings, not graphics-device construction options.
  // Recreating the app on camera movement lets child effects use a destroyed
  // device during the same commit (for example Logo Studio's shaded mesh).
  const settingsRef = useRef({
    cameraX,
    cameraY,
    cameraZ,
    targetX,
    targetY,
    targetZ,
    clearColor,
    fov,
    enableControls,
    autoRotate,
    autoRotateSpeed,
    active,
    renderOnDemand,
  });
  useLayoutEffect(() => {
    settingsRef.current = {
      cameraX,
      cameraY,
      cameraZ,
      targetX,
      targetY,
      targetZ,
      clearColor,
      fov,
      enableControls,
      autoRotate,
      autoRotateSpeed,
      active,
      renderOnDemand,
    };
    if (!enableControls) controlsStateRef.current.isDragging = false;
  }, [
    cameraX,
    cameraY,
    cameraZ,
    targetX,
    targetY,
    targetZ,
    clearColor,
    fov,
    enableControls,
    autoRotate,
    autoRotateSpeed,
    active,
    renderOnDemand,
  ]);

  // Switching `active` or `renderOnDemand` changes what the next frame does, so
  // it is asked for here; the frame gate itself reads the ref every frame.
  useLayoutEffect(() => {
    requestRender(contextValue.app);
  }, [contextValue.app, active, renderOnDemand]);

  const controlsStateRef = useRef({
    isDragging: false,
    lastX: 0,
    lastY: 0,
    yaw: 0,
    pitch: 0,
    distance: 3.2,
    targetDistance: 3.2,
    targetYaw: 0,
    targetPitch: 0,
  });

  useLayoutEffect(() => {
    const camera = contextValue.camera;
    if (!camera) return;
    const dx = cameraX - targetX;
    const dy = cameraY - targetY;
    const dz = cameraZ - targetZ;
    const distance = Math.hypot(dx, dy, dz) || 3.2;
    const pitch = Math.asin(Math.max(-1, Math.min(1, dy / distance)));
    const yaw = Math.atan2(dx, dz);
    Object.assign(controlsStateRef.current, {
      yaw,
      targetYaw: yaw,
      pitch,
      targetPitch: pitch,
      distance,
      targetDistance: distance,
    });
    camera.setPosition(cameraX, cameraY, cameraZ);
    camera.lookAt(targetX, targetY, targetZ);
    requestRender(contextValue.app);
  }, [contextValue.app, contextValue.camera, cameraX, cameraY, cameraZ, targetX, targetY, targetZ]);

  useLayoutEffect(() => {
    const camera = contextValue.camera?.camera;
    if (!camera) return;
    camera.clearColor = parseColor(clearColor);
    camera.fov = fov;
    requestRender(contextValue.app);
  }, [contextValue.app, contextValue.camera, clearColor, fov]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let cancelled = false;
    let app: pc.Application | null = null;
    const disposers: Array<() => void> = [];

    /**
     * The one place a mount attempt is given up on for good: warns (kept for
     * anyone grepping logs), publishes `error` on the context so a consumer
     * does not have to infer failure from a timeout, and fires `onError`
     * exactly once. `app`/`camera`/`rootEntity` stay null — a consumer never
     * sees a live app alongside an error.
     */
    const reportError = (e: unknown) => {
      const error = e instanceof Error ? e : new Error(String(e));
      console.warn('PlayCanvas application failed to initialize:', error);
      setContextValue({ app: null, camera: null, rootEntity: null, deviceType: null, error });
      onErrorRef.current?.(error);
    };

    const abortMount = () => {
      for (const d of disposers.splice(0)) d();
      if (app) {
        app.destroy();
        app = null;
      }
    };

    const mount = (device: pc.GraphicsDevice) => {
      const { cameraX, cameraY, cameraZ, targetX, targetY, targetZ, clearColor, fov } =
        settingsRef.current;
      app = new pc.Application(canvas, {
        // `graphicsDevice` wins over `graphicsDeviceOptions`: the engine only
        // builds a device of its own when none is handed to it.
        graphicsDevice: device,
        graphicsDeviceOptions: { ...GRAPHICS_DEVICE_OPTIONS },
      });
      const liveApp = app;
      app.setCanvasFillMode(pc.FILLMODE_NONE);
      app.setCanvasResolution(pc.RESOLUTION_AUTO);
      // The device defaults to min(1, devicePixelRatio), which renders at CSS
      // pixels and looks soft on retina. RESOLUTION_AUTO multiplies the CSS
      // size by min(maxPixelRatio, devicePixelRatio), so raising the cap is
      // all that is needed.
      const applyPixelRatio = () => {
        device.maxPixelRatio = Math.min(
          typeof window === 'undefined' ? 1 : window.devicePixelRatio || 1,
          MAX_PIXEL_RATIO,
        );
      };
      applyPixelRatio();

      // A box with no area has nothing to draw into, and resizing the backing
      // store to 0 x 0 would leave a degenerate projection behind. `sized`
      // says whether the last look at the layout found an area.
      const hasArea = () => canvas.clientWidth > 0 && canvas.clientHeight > 0;
      let sized = hasArea();
      const resizeToBox = () => {
        const live = app;
        if (!live || !live.graphicsDevice) return;
        sized = hasArea();
        if (!sized) return;
        live.resizeCanvas();
        // Resizing the backing store clears it.
        requestRender(live);
      };

      // THE FRAME GATE. The engine draws when `autoRender || renderNextFrame`;
      // 'framerender' fires between its update and that test, so this is the one
      // place that decides whether the frame is drawn, after every `update`
      // handler and every child has had its say. A stage that is not `active`,
      // or has no area, draws nothing and forgets what was asked; one coming
      // back draws once, so scrolling into view never shows a stale canvas.
      let wasDrawing = false;
      const gateFrame = () => {
        const { active, renderOnDemand } = settingsRef.current;
        // The engine's render() begins by re-fitting the backing store to the
        // layout box, so a frame drawn into a box that has just collapsed would
        // shrink it to 0 x 0 before any observer has run. Look first — but only
        // when a frame is about to be drawn, where the engine reads the same
        // property a moment later; an idle on-demand stage reads nothing.
        if (sized && active && (!renderOnDemand || liveApp.renderNextFrame || !wasDrawing)) {
          sized = hasArea();
        }
        const drawing = active && sized;
        liveApp.autoRender = drawing && !renderOnDemand;
        if (!drawing) liveApp.renderNextFrame = false;
        else if (!wasDrawing) liveApp.renderNextFrame = true;
        wasDrawing = drawing;
      };
      gateFrame();
      app.on('framerender', gateFrame);

      app.start();
      if (sized) app.resizeCanvas();

      // Set clear color
      const bg = parseColor(clearColor);
      if (app.scene) {
        app.scene.ambientLight = new pc.Color(0.2, 0.25, 0.35);
      }

      // Camera Entity
      const camera = new pc.Entity('MainCamera', app);
      camera.addComponent('camera', {
        clearColor: bg,
        fov: fov,
        frustumCulling: false,
      });
      app.root.addChild(camera);

      // Initial spherical coordinates calculation
      const dx = cameraX - targetX;
      const dy = cameraY - targetY;
      const dz = cameraZ - targetZ;
      const initialDist = Math.sqrt(dx * dx + dy * dy + dz * dz) || 3.2;
      const initialPitch = Math.asin(Math.max(-1, Math.min(1, dy / initialDist)));
      const initialYaw = Math.atan2(dx, dz);

      controlsStateRef.current = {
        isDragging: false,
        lastX: 0,
        lastY: 0,
        yaw: initialYaw,
        pitch: initialPitch,
        distance: initialDist,
        targetDistance: initialDist,
        targetYaw: initialYaw,
        targetPitch: initialPitch,
      };

      // Lights
      const dirLight = new pc.Entity('DirectionalLight', app);
      dirLight.addComponent('light', {
        type: 'directional',
        color: new pc.Color(1, 0.98, 0.95),
        intensity: 1.2,
      });
      dirLight.setEulerAngles(45, 30, 0);
      app.root.addChild(dirLight);

      const fillLight = new pc.Entity('FillLight', app);
      fillLight.addComponent('light', {
        type: 'directional',
        color: new pc.Color(0.6, 0.75, 1.0),
        intensity: 0.5,
      });
      fillLight.setEulerAngles(-45, -150, 0);
      app.root.addChild(fillLight);

      // Root entity for user scene content
      const rootEntity = new pc.Entity('TdaRootNode', app);
      app.root.addChild(rootEntity);

      // Update loop for smooth orbit camera & auto-rotation
      let reducedMotion = prefersReducedMotion();
      const stopWatchingMotion = watchReducedMotion((reduced) => {
        reducedMotion = reduced;
      });

      const onUpdate = (dt: number) => {
        const { targetX, targetY, targetZ, autoRotate, autoRotateSpeed } = settingsRef.current;
        const state = controlsStateRef.current;
        const rotating = autoRotate && !reducedMotion && !state.isDragging;
        if (rotating) {
          state.targetYaw += dt * autoRotateSpeed * 0.5;
        }

        // Smooth damping interpolation: the exponential, so the camera arrives
        // at the same moment at any frame rate.
        const factor = dampingFactor(dt, DAMPING_RATE);
        state.yaw += (state.targetYaw - state.yaw) * factor;
        state.pitch += (state.targetPitch - state.pitch) * factor;
        state.distance += (state.targetDistance - state.distance) * factor;

        const settled =
          Math.abs(state.targetYaw - state.yaw) < SETTLE_EPSILON &&
          Math.abs(state.targetPitch - state.pitch) < SETTLE_EPSILON &&
          Math.abs(state.targetDistance - state.distance) < SETTLE_EPSILON;
        if (settled) {
          state.yaw = state.targetYaw;
          state.pitch = state.targetPitch;
          state.distance = state.targetDistance;
        }
        // A camera that is turning, or still arriving, is a moving picture.
        if (rotating || !settled) requestRender(liveApp);

        // Position camera on sphere around targetPosition
        const cp = Math.cos(state.pitch);
        const sp = Math.sin(state.pitch);
        const cy = Math.sin(state.yaw);
        const sy = Math.cos(state.yaw);

        const cx = targetX + state.distance * cp * cy;
        const cyPos = targetY + state.distance * sp;
        const cz = targetZ + state.distance * cp * sy;

        camera.setPosition(cx, cyPos, cz);
        camera.lookAt(targetX, targetY, targetZ);
      };

      app.on('update', onUpdate);

      // Mouse / Touch Controls
      const handleMouseDown = (e: MouseEvent) => {
        if (!settingsRef.current.enableControls) return;
        controlsStateRef.current.isDragging = true;
        controlsStateRef.current.lastX = e.clientX;
        controlsStateRef.current.lastY = e.clientY;
      };

      const handleMouseMove = (e: MouseEvent) => {
        const state = controlsStateRef.current;
        if (!state.isDragging || !settingsRef.current.enableControls) return;
        const dxMove = e.clientX - state.lastX;
        const dyMove = e.clientY - state.lastY;
        state.lastX = e.clientX;
        state.lastY = e.clientY;

        state.targetYaw -= dxMove * 0.006;
        state.targetPitch = Math.max(-1.5, Math.min(1.5, state.targetPitch + dyMove * 0.006));
      };

      const handleMouseUp = () => {
        controlsStateRef.current.isDragging = false;
      };

      const handleWheel = (e: WheelEvent) => {
        if (!settingsRef.current.enableControls) return;
        e.preventDefault();
        const zoomDelta = e.deltaY * 0.002;
        const state = controlsStateRef.current;
        state.targetDistance = Math.max(
          0.4,
          Math.min(25, state.targetDistance + zoomDelta * state.targetDistance),
        );
      };

      let touchStartDist = 0;
      const handleTouchStart = (e: TouchEvent) => {
        if (!settingsRef.current.enableControls) return;
        if (e.touches.length === 1) {
          controlsStateRef.current.isDragging = true;
          controlsStateRef.current.lastX = e.touches[0]!.clientX;
          controlsStateRef.current.lastY = e.touches[0]!.clientY;
        } else if (e.touches.length === 2) {
          controlsStateRef.current.isDragging = false;
          const tdx = e.touches[0]!.clientX - e.touches[1]!.clientX;
          const tdy = e.touches[0]!.clientY - e.touches[1]!.clientY;
          touchStartDist = Math.sqrt(tdx * tdx + tdy * tdy);
        }
      };

      const handleTouchMove = (e: TouchEvent) => {
        if (!settingsRef.current.enableControls) return;
        if (e.touches.length === 1 && controlsStateRef.current.isDragging) {
          const tdx = e.touches[0]!.clientX - controlsStateRef.current.lastX;
          const tdy = e.touches[0]!.clientY - controlsStateRef.current.lastY;
          controlsStateRef.current.lastX = e.touches[0]!.clientX;
          controlsStateRef.current.lastY = e.touches[0]!.clientY;

          controlsStateRef.current.targetYaw -= tdx * 0.008;
          controlsStateRef.current.targetPitch = Math.max(
            -1.5,
            Math.min(1.5, controlsStateRef.current.targetPitch + tdy * 0.008),
          );
        } else if (e.touches.length === 2) {
          const tdx = e.touches[0]!.clientX - e.touches[1]!.clientX;
          const tdy = e.touches[0]!.clientY - e.touches[1]!.clientY;
          const dist = Math.sqrt(tdx * tdx + tdy * tdy);
          if (touchStartDist > 0) {
            const factor = touchStartDist / dist;
            controlsStateRef.current.targetDistance = Math.max(
              0.4,
              Math.min(25, controlsStateRef.current.targetDistance * (1 + (factor - 1) * 0.5)),
            );
          }
          touchStartDist = dist;
        }
      };

      const handleTouchEnd = () => {
        controlsStateRef.current.isDragging = false;
        touchStartDist = 0;
      };

      canvas.addEventListener('mousedown', handleMouseDown);
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      canvas.addEventListener('wheel', handleWheel, { passive: false });
      canvas.addEventListener('touchstart', handleTouchStart, { passive: true });
      canvas.addEventListener('touchmove', handleTouchMove, { passive: true });
      canvas.addEventListener('touchend', handleTouchEnd);

      // Resizing writes canvas layout. Defer that write until the next frame
      // so it cannot recursively resize an observed element during delivery.
      let resizeFrame = 0;
      const resizeObserver = new ResizeObserver(() => {
        cancelAnimationFrame(resizeFrame);
        resizeFrame = requestAnimationFrame(resizeToBox);
      });
      resizeObserver.observe(canvas);

      // Nothing tells the observer that the pixel ratio changed under an
      // unchanged CSS size (the window moved to another display), so it is
      // watched separately, and both the cap and the backing size follow it.
      const stopWatchingPixelRatio = watchDevicePixelRatio(() => {
        applyPixelRatio();
        resizeToBox();
      });

      // The canvas keeps its last frame while nothing is drawn, but a tab that
      // comes back, or a GL context the browser gave back, needs a fresh one.
      const onVisibility = () => {
        if (!document.hidden) requestRender(liveApp);
      };
      const onContextRestored = () => requestRender(liveApp);
      document.addEventListener('visibilitychange', onVisibility);
      canvas.addEventListener('webglcontextrestored', onContextRestored);

      disposers.push(() => {
        canvas.removeEventListener('mousedown', handleMouseDown);
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
        canvas.removeEventListener('wheel', handleWheel);
        canvas.removeEventListener('touchstart', handleTouchStart);
        canvas.removeEventListener('touchmove', handleTouchMove);
        canvas.removeEventListener('touchend', handleTouchEnd);
        resizeObserver.disconnect();
        cancelAnimationFrame(resizeFrame);
        stopWatchingPixelRatio();
        stopWatchingMotion();
        document.removeEventListener('visibilitychange', onVisibility);
        canvas.removeEventListener('webglcontextrestored', onContextRestored);

        liveApp.off('update', onUpdate);
        liveApp.off('framerender', gateFrame);
        liveApp.destroy();
        app = null;
      });

      setContextValue({
        app: liveApp,
        camera,
        rootEntity,
        deviceType: toDeviceTypeLiteral(liveApp.graphicsDevice.deviceType),
        error: null,
      });
      onAppReadyRef.current?.(liveApp);
    };

    const injectedFactory = createGraphicsDeviceRef.current;
    if (injectedFactory) {
      // Seam path: fully synchronous. jsdom tests mount children after the
      // first effect flush and must not have to `await waitFor`.
      try {
        mount(injectedFactory(canvas));
      } catch (e) {
        abortMount();
        reportError(e);
        return;
      }
    } else {
      void (async () => {
        let created: pc.GraphicsDevice;
        try {
          // Copy: createGraphicsDevice mutates deviceTypes in place (appends
          // WEBGL2 if missing, then NULL).
          created = (await pc.createGraphicsDevice(canvas, {
            deviceTypes: [...DEFAULT_DEVICE_TYPES],
            ...GRAPHICS_DEVICE_OPTIONS,
          })) as pc.GraphicsDevice;
        } catch (e) {
          if (!cancelled) reportError(e);
          return;
        }
        if (cancelled) {
          created.destroy();
          return;
        }
        // The engine always appends DEVICETYPE_NULL after the requested types,
        // and createGraphicsDevice RESOLVES with that null device rather than
        // rejecting. A null device is not a usable renderer — treat it as init
        // failure so the context reports it, same as an outright rejection.
        if (created.isNull) {
          created.destroy();
          if (!cancelled) {
            reportError(new Error('WebGPU and WebGL2 graphics devices are unavailable'));
          }
          return;
        }
        try {
          mount(created);
        } catch (e) {
          const hadApp = app !== null;
          abortMount();
          if (!hadApp) {
            // Constructor threw before taking ownership — free the device.
            created.destroy();
          }
          if (!cancelled) reportError(e);
        }
      })();
    }

    return () => {
      cancelled = true;
      for (const d of disposers) d();
      setContextValue(NULL_CONTEXT);
    };
  }, []);

  let stageContent: ReactNode = null;
  if (contextValue.error) {
    if (fallback) {
      stageContent = typeof fallback === 'function' ? fallback(contextValue.error) : fallback;
    } else {
      stageContent = <DefaultStageFallback />;
    }
  } else if (contextValue.app) {
    stageContent = children;
  }

  return (
    <div
      className={className}
      // Backend readout without touching the context — `'webgpu' | 'webgl2'`
      // when a real device is up, `'none'` before init, on failure, or for a
      // test/dev device that is neither (e.g. pc.NullGraphicsDevice).
      data-device={contextValue.deviceType ?? 'none'}
      style={{
        position: 'relative',
        width: '100%',
        height: '100%',
        overflow: 'hidden',
        ...style,
      }}
    >
      <canvas
        ref={canvasRef}
        style={{
          width: '100%',
          height: '100%',
          display: 'block',
          outline: 'none',
        }}
      />
      <PlayCanvasContext.Provider value={contextValue}>{stageContent}</PlayCanvasContext.Provider>
    </div>
  );
}
