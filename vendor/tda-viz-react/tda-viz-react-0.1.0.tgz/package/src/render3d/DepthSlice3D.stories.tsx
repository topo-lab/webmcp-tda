/**
 * <DepthSlice3D>: the covering depth of a k-fold cover, on a plane through the
 * cloud.
 *
 * These stories build their filtrations AT STORY LOAD through the library's
 * own `buildFiltration`, against the REAL engine — the same call a consumer
 * makes. Nothing here is recorded or hand-authored: the k = 4 mosaic, and the
 * depth field the slice paints, are what tda-wasm and the arithmetic produce
 * for these eight points. (The site does not run the engine at runtime; a
 * story may, and here it should, because the claim being demonstrated is about
 * the engine's own construction.)
 *
 * WHAT TO LOOK AT. Two eight-sphere motifs, identical apart from how the
 * layers stack: HCP has them ECLIPSED (A B A) and its two tetrahedral holes
 * share a FACE; FCC has them STAGGERED (A B C) and its holes share only an
 * EDGE. Both open a pair of depth-4 regions at t = 0.375, the squared
 * circumradius of four touching unit spheres. Scrub past that and the regions
 * grow toward each other — and the pair merges at t ≈ 0.67 for HCP but not
 * until t ≈ 0.75 for FCC, because a shared face is a shorter way through than
 * a shared edge.
 *
 * That difference is READ OFF THE PICTURE rather than annotated onto it. The
 * slice evaluates |x − cᵢ|² ≤ t per pixel and counts, so the two regions meet
 * on screen exactly when they meet in space.
 */
import { useEffect, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import wasmUrl from '@topolab/tda-wasm/tda.wasm?url';
import { TdaEngine } from '../compute/TdaEngine';
import { buildFiltration } from '../engine/buildFiltration';
import type { Filtration } from '../filtration/types';
import { DepthSlice3D } from './DepthSlice3D';
import { PlayCanvasStage } from './PlayCanvasStage';
import { PointCloud3D } from './PointCloud3D';

// ── The two motifs ───────────────────────────────────────────────────────
//
// Verbatim from wasm-tda-webapp/public/datasets/motif_{hcp,fcc}_8.json (the
// Explorer's own datasets). A Storybook story cannot read that sibling
// checkout's public/ directory, so the eight points travel inline. Eight
// unit-diameter spheres: a hexagonal layer of six with one sphere above and
// one below. Seeds 777 and 778, jitter 2e-3.

interface Motif {
  name: string;
  stacking: string;
  points: number[];
  /** The two tetrahedral holes, as input-point indices. */
  holes: [number[], number[]];
  /** Where the two depth-4 regions merge, from the arithmetic. */
  merge: number;
}

const MOTIFS: Motif[] = [
  {
    name: 'HCP — layers eclipsed (A B A)',
    stacking: 'the two tetrahedral holes share the FACE 0-1-2',
    points: [
      0.0007, -0.0019, -0.0012, 0.9985, 0.0005, -0.0005, 0.499, 0.867, 0.0005, -0.4989, 0.8668,
      0.0014, 0.4986, -0.8653, 0.0002, -0.4983, -0.8659, -0.0017, 0.5017, 0.2896, 0.8184, 0.4985,
      0.2881, -0.8183,
    ],
    holes: [
      [0, 1, 2, 6],
      [0, 1, 2, 7],
    ],
    merge: 0.67,
  },
  {
    name: 'FCC — layers staggered (A B C)',
    stacking: 'the two tetrahedral holes share only the EDGE 0-1',
    points: [
      -0.0019, 0.0004, 0.0014, 1.0007, 0.0007, 0.0013, 0.502, 0.8671, -0.0006, -0.5009, 0.8653,
      0.0018, 0.4996, -0.8674, -0.0016, -0.4996, -0.8673, 0, 0.5, 0.2875, 0.8185, 0.5014, -0.2888,
      -0.8169,
    ],
    holes: [
      [0, 1, 2, 6],
      [0, 1, 4, 7],
    ],
    merge: 0.75,
  },
];

/** k, the cover multiplicity these stories build and the depth the ramp caps at. */
const K = 4;

/**
 * The depth ramp, from DESIGN.md's own colours rather than from any reference
 * picture. The k-fold cover is a NERVE, and `--nerve-on-ink` (#2dd4bf) is the
 * colour this design system already gives a nerve surface drawn on ink — so it
 * names the deepest step, where the cover reaches k, and the three shallower
 * depths are that same hue stepped down toward the ink ground. One hue, four
 * separated weights: the reader is counting, not comparing colours.
 */
const DEPTH_RAMP: [string, string, string, string] = ['#134045', '#1a6865', '#22958b', '#2dd4bf'];

/**
 * Circumcentre of a tetrahedron — the deepest point of the hole its four
 * spheres surround, and where depth 4 first appears. Solved from the three
 * linear equations |x − a|² = |x − b|².
 */
function tetraCircumcentre(p: number[][]): number[] {
  const a = p[0]!;
  const sq = (q: number[]) => q[0]! ** 2 + q[1]! ** 2 + q[2]! ** 2;
  const rows = p
    .slice(1)
    .map((q) => [2 * (q[0]! - a[0]!), 2 * (q[1]! - a[1]!), 2 * (q[2]! - a[2]!), sq(q) - sq(a)]);
  for (let i = 0; i < 3; i++) {
    let pivot = i;
    for (let j = i + 1; j < 3; j++) {
      if (Math.abs(rows[j]![i]!) > Math.abs(rows[pivot]![i]!)) pivot = j;
    }
    [rows[i], rows[pivot]] = [rows[pivot]!, rows[i]!];
    for (let j = 0; j < 3; j++) {
      if (j === i) continue;
      const f = rows[j]![i]! / rows[i]![i]!;
      for (let k = i; k < 4; k++) rows[j]![k]! -= f * rows[i]![k]!;
    }
  }
  return [rows[0]![3]! / rows[0]![0]!, rows[1]![3]! / rows[1]![1]!, rows[2]![3]! / rows[2]![2]!];
}

/**
 * The plane offset that puts BOTH hole centres on the slice.
 *
 * In both motifs the two holes sit at the same x, so the plane x = (hole x)
 * contains the segment along which they merge — which is the one thing the
 * picture has to show. `<DepthSlice3D>` measures the offset from the cloud
 * centroid, so that is what this returns.
 */
function planeOffsetThroughHoles(motif: Motif): number {
  const at = (i: number) => [
    motif.points[i * 3]!,
    motif.points[i * 3 + 1]!,
    motif.points[i * 3 + 2]!,
  ];
  const holeX = motif.holes.map((h) => tetraCircumcentre(h.map(at))[0]!);
  const n = motif.points.length / 3;
  let cx = 0;
  for (let i = 0; i < n; i++) cx += motif.points[i * 3]!;
  return (holeX[0]! + holeX[1]!) / 2 - cx / n;
}

// ── The engine, once per Storybook session ───────────────────────────────

/**
 * One engine for the whole story file. `createWorker: null` keeps the build on
 * the calling thread — there are two small builds and nothing to parallelise —
 * and `locateFile` points the Emscripten runtime at the wasm Vite emitted.
 */
let enginePromise: Promise<TdaEngine> | null = null;
function sharedEngine(): Promise<TdaEngine> {
  if (!enginePromise) {
    const engine = new TdaEngine({
      wasmUrl,
      createWorker: null,
    });
    enginePromise = engine.load().then(() => engine);
  }
  return enginePromise;
}

/** One build per motif, cached: scrubbing t must never call the engine again. */
const builds = new Map<string, Promise<Filtration>>();
function buildMotif(motif: Motif): Promise<Filtration> {
  const cached = builds.get(motif.name);
  if (cached) return cached;
  const built = sharedEngine().then((engine) =>
    buildFiltration(
      engine,
      {
        points: motif.points,
        weights: new Array(motif.points.length / 3).fill(0),
        dimension: 3,
      },
      { complexType: 'kfold', k: K, maxSquaredRadius: 4 },
    ),
  );
  builds.set(motif.name, built);
  return built;
}

// ── The view ─────────────────────────────────────────────────────────────

const caption: React.CSSProperties = {
  fontFamily: 'ui-monospace, monospace',
  fontSize: 12,
  lineHeight: 1.6,
  marginBottom: 8,
};

function MotifPanel({ motif, t }: { motif: Motif; t: number }) {
  const [filtration, setFiltration] = useState<Filtration | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    buildMotif(motif).then(
      (f) => {
        if (live) setFiltration(f);
      },
      (e: unknown) => {
        if (live) setError(e instanceof Error ? e.message : String(e));
      },
    );
    return () => {
      live = false;
    };
  }, [motif]);

  const offset = planeOffsetThroughHoles(motif);

  return (
    <figure style={{ margin: 0, width: 380 }}>
      <figcaption style={caption}>
        <strong>{motif.name}</strong>
        <br />
        {motif.stacking}
        <br />
        the depth-{K} pair merges at t ≈ {motif.merge}
      </figcaption>
      <div style={{ width: 380, height: 320 }}>
        <PlayCanvasStage cameraPosition={[3.6, 0, 0]} fov={45}>
          {filtration ? (
            <>
              <PointCloud3D points={motif.points} dimension={3} size={0.03} />
              <DepthSlice3D
                filtration={filtration}
                t={t}
                plane={{ normal: [1, 0, 0], offset }}
                colors={DEPTH_RAMP}
              />
            </>
          ) : null}
        </PlayCanvasStage>
      </div>
      {error ? (
        <p style={{ ...caption, color: '#b45309' }}>The engine did not load: {error}</p>
      ) : null}
    </figure>
  );
}

/**
 * The comparison itself: the same scale, the same ramp, the same plane
 * construction on both motifs, so the only difference on screen is how the
 * layers stack.
 */
function MotifComparison({ t }: { t: number }) {
  return (
    <div>
      <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>
        {MOTIFS.map((m) => (
          <MotifPanel key={m.name} motif={m} t={t} />
        ))}
      </div>
      <p style={{ ...caption, marginTop: 12, maxWidth: 780 }}>
        t = {t} (a squared radius). Depth 0 is transparent; the four ramp steps are depths 1, 2, 3
        and ≥ {K}. Every pixel counts the balls of radius √t that contain it — the picture is the
        predicate, not a shading of it.
      </p>
    </div>
  );
}

const meta = {
  title: '3D/DepthSlice3D',
  component: MotifComparison,
  parameters: { layout: 'padded' },
  argTypes: { t: { control: { type: 'range', min: 0, max: 1.5, step: 0.005 } } },
} satisfies Meta<typeof MotifComparison>;

export default meta;
type Story = StoryObj<typeof meta>;

/**
 * Just past the birth: t = 0.4, a little above the squared circumradius 0.375.
 * Each motif shows TWO separate depth-4 regions — the two tetrahedral holes —
 * ringed by the shallower depths.
 */
export const TwoHolesOpen: Story = { args: { t: 0.4 } };

/**
 * t = 0.70: the eclipsed pair has merged through its shared face; the
 * staggered pair has not.
 */
export const EclipsedMergesFirst: Story = { args: { t: 0.7 } };

/** t = 0.80: both pairs have merged, and each depth-4 region is one piece. */
export const BothMerged: Story = { args: { t: 0.8 } };
