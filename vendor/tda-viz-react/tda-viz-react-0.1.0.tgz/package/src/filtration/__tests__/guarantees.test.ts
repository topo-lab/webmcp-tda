// @vitest-environment node
//
// Honest labelling is a LIBRARY guarantee, not a consumer's job (SPEC.md §1.4).
// The chip text is fixed by tda-wasm SPEC FR-6 and is asserted here character
// for character: inflating a flag complex to a nerve, or downgrading the box
// filtration's nerve, is a spec violation and must fail the build.
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import {
  COMPLEX_GUARANTEES,
  FLAG_COMPLEX_TYPES,
  GRID_GUARANTEES,
  GRID_GUARANTEE_SOURCE,
  NERVE_COMPLEX_TYPES,
  complexGuarantee,
  gridGuarantee,
} from '../guarantees';
import type { FiltrationComplexType } from '../types';

const ALL_TYPES: FiltrationComplexType[] = [
  'rips',
  'cech',
  'alpha',
  'kfold',
  'ellipsoid-rips',
  'ellipsoid-cech',
  'wing',
  'box',
];

describe('COMPLEX_GUARANTEES: the exact chip text (tda-wasm SPEC FR-6, verbatim)', () => {
  it.each([
    ['rips', 'flag', 'flag complex (Rips-type)'],
    ['ellipsoid-rips', 'flag', 'flag complex (Rips-type)'],
    ['wing', 'flag', 'flag complex (Rips-type)'],
    ['cech', 'nerve', 'true nerve (Cech)'],
    ['ellipsoid-cech', 'nerve', 'true nerve (ellipsoidal Cech)'],
    ['kfold', 'nerve', 'exact (order-k Delaunay nerve)'],
    ['box', 'nerve', 'nerve (= flag, by Helly for boxes); step-quantized'],
    ['alpha', 'nerve', 'alpha complex (exact combinatorics)'],
  ] as const)('%s is a %s labelled "%s"', (complexType, kind, label) => {
    const guarantee = complexGuarantee(complexType);
    expect(guarantee.kind).toBe(kind);
    expect(guarantee.label).toBe(label);
  });

  it('covers every complex type the library can build, with no extras', () => {
    expect(Object.keys(COMPLEX_GUARANTEES).sort()).toEqual([...ALL_TYPES].sort());
    for (const t of ALL_TYPES) expect(complexGuarantee(t)).toBeDefined();
  });

  it('is frozen: a consumer cannot relabel a construction at runtime', () => {
    expect(Object.isFrozen(COMPLEX_GUARANTEES)).toBe(true);
    expect(Object.isFrozen(COMPLEX_GUARANTEES.rips)).toBe(true);
  });
});

describe('a flag complex is NEVER labelled a nerve (SPEC.md §1.4)', () => {
  it.each(FLAG_COMPLEX_TYPES)('%s carries kind "flag"', (complexType) => {
    expect(complexGuarantee(complexType).kind).toBe('flag');
  });

  it.each(FLAG_COMPLEX_TYPES)('%s never says "nerve", "Cech" or "exact" in its label', (t) => {
    // Pairwise intersection is strictly weaker than a common point, so a
    // triangle here is not a claim about three shapes overlapping. Any of
    // these words in the chip would be that claim.
    const { label } = complexGuarantee(t);
    expect(label).not.toMatch(/nerve/i);
    expect(label).not.toMatch(/[čc]ech/i);
    expect(label).not.toMatch(/exact/i);
  });

  it('partitions the menu: every type is either flag or nerve, never both', () => {
    const flag = new Set<string>(FLAG_COMPLEX_TYPES);
    const nerve = new Set<string>(NERVE_COMPLEX_TYPES);
    for (const t of ALL_TYPES) {
      expect(flag.has(t) !== nerve.has(t)).toBe(true);
      expect(complexGuarantee(t).kind).toBe(flag.has(t) ? 'flag' : 'nerve');
    }
  });
});

describe('the box filtration keeps BOTH halves of its tag', () => {
  it('says nerve AND says step-quantized — the quantization half is not optional', () => {
    const { kind, label } = complexGuarantee('box');
    expect(kind).toBe('nerve');
    expect(label).toContain('nerve');
    expect(label).toContain('Helly');
    expect(label).toContain('step-quantized');
  });
});

// ── The grid constructions (SPEC.md §3.1b) ───────────────────────────────

describe('GRID_GUARANTEES: the engine’s own wording for the cubical conventions', () => {
  it.each([
    ['cubical-t', 'top-dimensional-cell filtration (T-construction)'],
    ['cubical-v', 'vertex lower-star filtration (V-filtration)'],
  ] as const)('%s is labelled "%s"', (construction, label) => {
    expect(GRID_GUARANTEES[construction]).toEqual({
      kind: 'cubical',
      construction,
      label,
    });
    expect(gridGuarantee(construction).label).toBe(label);
  });

  /**
   * The load-bearing one. The task these labels do is to name the construction
   * in the ENGINE's words, so this reads the engine's README off disk and fails
   * if either phrase is not in it verbatim. A wording change upstream fails
   * here, which is the signal to requote it — not to invent a new phrase.
   *
   * Whitespace is collapsed first because the README wraps at 80 columns and
   * the T-construction phrase happens to straddle a line break; a line break is
   * not a wording difference.
   */
  it('quotes both labels from tda-wasm’s README, character for character', () => {
    const readme = readFileSync(
      resolve(
        dirname(createRequire(import.meta.url).resolve('@topolab/tda-wasm/package.json')),
        'README.md',
      ),
      'utf8',
    ).replace(/\s+/g, ' ');
    expect(GRID_GUARANTEE_SOURCE).toContain('README');
    for (const g of Object.values(GRID_GUARANTEES)) {
      expect(readme, `the engine's README no longer contains "${g.label}"`).toContain(g.label);
    }
  });

  it('is frozen: a consumer cannot relabel a construction at runtime', () => {
    expect(Object.isFrozen(GRID_GUARANTEES)).toBe(true);
    expect(Object.isFrozen(GRID_GUARANTEES['cubical-t'])).toBe(true);
  });

  /**
   * The grid is deliberately NOT in the point-cloud table. Adding it there
   * would put a cubical complex in the nerve/flag classification, which is a
   * claim about covers and intersections that a cubical complex makes neither
   * way, and would silently grow the construction index every consumer builds
   * from `COMPLEX_GUARANTEES` (SPEC.md §1.4).
   */
  it('stays out of COMPLEX_GUARANTEES: eight cloud constructions, two grid conventions', () => {
    expect(Object.keys(COMPLEX_GUARANTEES)).toHaveLength(8);
    expect(Object.keys(COMPLEX_GUARANTEES)).not.toContain('cubical');
    expect(Object.keys(GRID_GUARANTEES)).toHaveLength(2);
    const cloudKinds = new Set(Object.values(COMPLEX_GUARANTEES).map((g) => g.kind));
    expect(cloudKinds).toEqual(new Set(['nerve', 'flag']));
    expect([...Object.values(GRID_GUARANTEES)].every((g) => g.kind === 'cubical')).toBe(true);
  });

  it('gives the two conventions DIFFERENT labels: they are different filtrations', () => {
    expect(GRID_GUARANTEES['cubical-t'].label).not.toBe(GRID_GUARANTEES['cubical-v'].label);
  });
});
