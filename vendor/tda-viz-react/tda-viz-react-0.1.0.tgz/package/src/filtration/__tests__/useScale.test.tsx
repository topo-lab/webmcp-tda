// The scale controller (SPEC.md §3.3): the single source of truth for t.
import { act, renderHook } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import {
  TRIANGLE_CECH,
  WEIGHTED3_ALPHA,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import {
  activeLoopCount,
  activeLoopId,
  startAnimationLoop,
  stopAnimationLoop,
} from '../../state/animationLoop';
import { installFrameClock, type FrameClock } from '../../state/__tests__/frameClock';
import { useScale } from '../useScale';

const cech = recordedFiltration(TRIANGLE_CECH); // criticalValues [0, 0.5, 0.57735]
const weighted = recordedFiltration(WEIGHTED3_ALPHA); // first critical value -0.5

describe('useScale: t and setT', () => {
  it('starts at the beginning of the filtration (min of 0 and first critical value)', () => {
    const { result } = renderHook(() => useScale(cech));
    expect(result.current.t).toBe(0);
    const w = renderHook(() => useScale(weighted));
    // Weighted vertices enter at t = -w, so the filtration starts below 0.
    expect(w.result.current.t).toBe(-0.5);
  });

  it('setT sets and clamps to [tMin, tMax]', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.setT(0.3));
    expect(result.current.t).toBe(0.3);
    act(() => result.current.setT(99));
    expect(result.current.t).toBe(cech.tMax);
    act(() => result.current.setT(-99));
    expect(result.current.t).toBe(0);
  });
});

describe('useScale: snapping (the interesting moments are the changes)', () => {
  it('snapToNext jumps to the next critical value', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.snapToNext());
    expect(result.current.t).toBe(0.5);
    act(() => result.current.snapToNext());
    expect(result.current.t).toBe(0.57735);
    // No further event: stays put rather than inventing one.
    act(() => result.current.snapToNext());
    expect(result.current.t).toBe(0.57735);
  });

  it('snapToPrev jumps to the previous critical value', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.setT(0.55));
    act(() => result.current.snapToPrev());
    expect(result.current.t).toBe(0.5);
    act(() => result.current.snapToPrev());
    expect(result.current.t).toBe(0);
    act(() => result.current.snapToPrev());
    expect(result.current.t).toBe(0);
  });

  it('snapping from between two events lands exactly on an event, once per step', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.setT(0.51));
    const before = cech.simplicesAt(result.current.t).length;
    act(() => result.current.snapToNext());
    const after = cech.simplicesAt(result.current.t).length;
    expect(result.current.t).toBe(0.57735);
    expect(after).toBe(before + 1); // exactly the triangle appears
  });
});

describe('useScale: playback', () => {
  beforeEach(() => {
    vi.useFakeTimers({ toFake: ['requestAnimationFrame', 'cancelAnimationFrame', 'performance'] });
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  it('play advances t monotonically and pause stops it', () => {
    const { result } = renderHook(() => useScale(cech));
    expect(result.current.playing).toBe(false);
    act(() => result.current.play());
    expect(result.current.playing).toBe(true);
    act(() => void vi.advanceTimersByTime(500));
    const t1 = result.current.t;
    expect(t1).toBeGreaterThan(0);
    act(() => result.current.pause());
    expect(result.current.playing).toBe(false);
    act(() => void vi.advanceTimersByTime(500));
    expect(result.current.t).toBe(t1);
  });

  it('stops at tMax instead of running past the filtration', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.play());
    act(() => void vi.advanceTimersByTime(60_000));
    expect(result.current.t).toBe(cech.tMax);
    expect(result.current.playing).toBe(false);
  });

  it('play from the end restarts from the beginning', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.setT(cech.tMax));
    act(() => result.current.play());
    expect(result.current.t).toBe(0);
    expect(result.current.playing).toBe(true);
  });
});

/**
 * The sweep as one loop in the registry, and a drag that takes control of it.
 *
 * Every way this could fail, written before the change:
 *  1. `play` keeps its own `requestAnimationFrame`, so a second loop started
 *     elsewhere runs BESIDE it: two pending frames where the registry promises
 *     one, and `activeLoopCount()` reads 0 while t is moving.
 *  2. `setT` (a drag of `<ScaleControl>`) leaves `playing` true, so the sweep
 *     keeps writing t while the reader is writing it — the thumb fights the loop.
 *  3. `snapToNext` / `snapToPrev` do the same: a step lands on an event and the
 *     sweep slides off it on the next frame.
 *  4. The loop is not released when playback stops (pause, tMax, unmount), so a
 *     stopped sweep would still hold the app's slot.
 *  5. A hidden tab pauses frames but not time, and the first frame back carries
 *     the whole absence as its delta: t leaps to the end.
 *  6. Whatever else changes, a sweep still takes `playSeconds` (10 by default).
 */
describe('useScale: one loop, and a drag takes control', () => {
  let clock: FrameClock;
  beforeEach(() => {
    clock = installFrameClock({ around: (step) => act(step) });
  });
  afterEach(() => {
    stopAnimationLoop();
    clock.reset();
    vi.unstubAllGlobals();
  });

  it('sweeps through the registry, so a second loop replaces it instead of joining it', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.play());
    expect(activeLoopCount()).toBe(1);
    expect(activeLoopId()).toBe('use-scale');
    expect(clock.liveCallbacks).toBe(1);

    startAnimationLoop('another surface', () => {});
    expect(clock.liveCallbacks).toBe(1);
    expect(activeLoopId()).toBe('another surface');
  });

  it('gives the loop up on pause, at tMax and on unmount', () => {
    const { result, unmount } = renderHook(() => useScale(cech));
    act(() => result.current.play());
    act(() => result.current.pause());
    expect(activeLoopCount()).toBe(0);
    expect(clock.liveCallbacks).toBe(0);

    act(() => result.current.play());
    expect(activeLoopCount()).toBe(1);
    clock.run(20_000);
    expect(result.current.t).toBe(cech.tMax);
    expect(result.current.playing).toBe(false);
    expect(activeLoopCount()).toBe(0);

    act(() => result.current.play());
    expect(activeLoopCount()).toBe(1);
    unmount();
    expect(activeLoopCount()).toBe(0);
    expect(clock.liveCallbacks).toBe(0);
  });

  it('setT during a sweep takes control: paused, and t stays where the drag put it', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.play());
    clock.run(500);
    act(() => result.current.setT(0.1));
    expect(result.current.playing).toBe(false);
    clock.run(500);
    expect(result.current.t).toBe(0.1);
  });

  it('snapping during a sweep pauses it too, so the sweep does not slide off the event', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.play());
    clock.run(200);
    act(() => result.current.snapToNext());
    expect(result.current.playing).toBe(false);
    expect(result.current.t).toBe(0.5);
    clock.run(500);
    expect(result.current.t).toBe(0.5);

    // Resumed from 0.5 and a little past it; the previous event is 0.5 again.
    act(() => result.current.play());
    clock.run(100);
    expect(result.current.t).toBeGreaterThan(0.5);
    act(() => result.current.snapToPrev());
    expect(result.current.playing).toBe(false);
    clock.run(500);
    expect(result.current.t).toBe(0.5);
  });

  it('does not leap when a hidden tab returns: the first frame back reports no elapsed time', () => {
    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.play());
    clock.run(1000);
    const before = result.current.t;
    expect(before).toBeGreaterThan(0);

    clock.hide(30_000);
    clock.advance(16);
    expect(result.current.t).toBe(before);
    expect(result.current.playing).toBe(true);

    clock.advance(16);
    expect(result.current.t).toBeGreaterThan(before);
  });

  it('takes playSeconds for a full sweep, ten by default', () => {
    const fast = renderHook(() => useScale(cech, { playSeconds: 2 }));
    act(() => fast.result.current.play());
    clock.run(1000);
    expect(fast.result.current.t).toBeCloseTo(cech.tMax / 2, 2);
    fast.unmount();

    const { result } = renderHook(() => useScale(cech));
    act(() => result.current.play());
    clock.run(5000);
    expect(result.current.t).toBeCloseTo(cech.tMax / 2, 2);
  });
});
