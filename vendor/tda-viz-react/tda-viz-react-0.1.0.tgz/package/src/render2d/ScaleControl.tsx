/**
 * <ScaleControl> (SPEC.md §4.4): the scrubber for t. Replaces v1's
 * <EpsilonPlayhead>, because "ε" implies a specific convention and the
 * control must be honest about which one it is: it shows t, the convention,
 * a scale readout for what t implies, and snap-to-event buttons over the
 * filtration's criticalValues (the moments something actually changes).
 *
 * ANY filtration (SPEC.md §3.1): `tMax`, `criticalValues` and `convention`
 * exist on every member of the union, which is all the scrubbing and
 * snap-to-event machinery needs. Only the scale READOUT depends on which
 * shape grows — a radius exists for the three ball conventions (rips, Čech,
 * alpha) and for nothing else, so a wing, an ellipsoid or a box gets its own
 * honest line: the scale value t implies and the filtration's own convention,
 * never a "ball radius" invented for a shape that has none.
 *
 * Controlled; owns nothing. Moving it changes what is DRAWN — persistence
 * was computed once and is already complete (SPEC.md §1.5).
 */
import { useMemo } from 'react';
import type { Filtration, RadiusConvention } from '../filtration/types';

/** Props for `<ScaleControl>`. */
export interface ScaleControlProps {
  /**
   * Any filtration. The radius readout only applies where `shapeKind` is
   * `'ball'` (SPEC.md §1.3); every other construction gets the scale value and
   * its own convention label instead (see the module doc comment).
   */
  filtration: Filtration;
  t: number;
  /** Called with the new t on every move. The component owns no state. */
  onChange: (t: number) => void;
  label?: string;
  disabled?: boolean;
  className?: string;
  id?: string;
}

const CONVENTION_TEXT: Record<RadiusConvention, string> = {
  rips: 'Vietoris–Rips · t is edge length · ball radius t/2',
  cech: 'Čech · t is the ball radius',
  alpha: 'alpha · t is squared radius · ball radius √(t + wᵢ) per point',
  'ellipsoid-r': 'ellipsoid Čech · t is the radius · semi-axes t·profile along the fitted frame',
  'ellipsoid-2r':
    'ellipsoid · t is twice the ellipsoid radius · semi-axes (t/2)·profile along the fitted frame',
  'wing-eps': 'wing · t is the wing scale ε · spine half-length q·t, wing edges t at ±θ',
  'box-step': 'box · t is step·π · box at step ⌊t/π⌋, values are grid values',
};

const fmt = (x: number) => x.toFixed(3);

/**
 * The scrubber for t (SPEC.md §4.4). Shows t, the filtration's convention, the
 * scale that t implies, and snap-to-event buttons over `criticalValues`.
 * Controlled; owns nothing.
 */
export function ScaleControl({
  filtration,
  t,
  onChange,
  label = 'Scale',
  disabled = false,
  className,
  id = 'scale-control',
}: ScaleControlProps) {
  const { criticalValues, tMax, convention, cloud } = filtration;
  const tMin = Math.min(0, criticalValues.length > 0 ? criticalValues[0] : 0);
  const domain = tMax - tMin || 1;
  const clamped = Math.min(Math.max(t, tMin), tMax);

  const { nextCv, prevCv } = useMemo(() => {
    let next: number | null = null;
    let prev: number | null = null;
    for (const cv of criticalValues) {
      if (cv > clamped && next === null) next = cv;
      if (cv < clamped) prev = cv;
    }
    return { nextCv: next, prevCv: prev };
  }, [criticalValues, clamped]);

  // The radius the current t implies on screen — ONLY where a radius exists
  // (`shapeKind === 'ball'`, SPEC.md §1.3). Per-point under weights: show the
  // range, because "the" radius does not exist for a weighted cloud either.
  // For every other shape there is no radius law to read out, so the line
  // says what t means under that filtration's own convention instead of
  // stating a radius the construction cannot have.
  const radiusText = useMemo(() => {
    if (filtration.shapeKind !== 'ball') {
      return `no ball radius under ${convention}: scale value t = ${fmt(clamped)}`;
    }
    const n = cloud.weights.length;
    if (n === 0) return '—';
    let lo = Infinity;
    let hi = -Infinity;
    for (let i = 0; i < n; i++) {
      const r = filtration.radiusAt(i, clamped);
      if (r < lo) lo = r;
      if (r > hi) hi = r;
    }
    return hi - lo > 1e-12 ? `${fmt(lo)} – ${fmt(hi)} (per point)` : fmt(lo);
  }, [filtration, cloud, clamped, convention]);

  return (
    <div className={className} data-testid="scale-control" data-convention={convention}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <label
          htmlFor={id}
          style={{ fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase' }}
        >
          {label}
        </label>
        <span
          data-testid="scale-control-t"
          style={{ fontFamily: 'ui-monospace, monospace', fontSize: 12 }}
        >
          t = {fmt(clamped)}
        </span>
      </div>

      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <button
          type="button"
          data-testid="scale-control-prev"
          aria-label="Snap to previous event"
          disabled={disabled || prevCv === null}
          onClick={() => prevCv !== null && onChange(prevCv)}
        >
          ⟨
        </button>
        <input
          id={id}
          type="range"
          min={tMin}
          max={tMax}
          step={domain / 200}
          value={clamped}
          disabled={disabled}
          aria-label={label}
          aria-valuetext={`t ${fmt(clamped)} (${convention} convention)`}
          onChange={(e) => onChange(Number.parseFloat(e.target.value))}
          style={{ flex: 1 }}
        />
        <button
          type="button"
          data-testid="scale-control-next"
          aria-label="Snap to next event"
          disabled={disabled || nextCv === null}
          onClick={() => nextCv !== null && onChange(nextCv)}
        >
          ⟩
        </button>
      </div>

      <p
        data-testid="scale-control-convention"
        style={{
          fontSize: 10,
          opacity: 0.7,
          margin: '4px 0 0',
          fontFamily: 'ui-monospace, monospace',
        }}
      >
        {CONVENTION_TEXT[convention]}
      </p>
      <p
        data-testid="scale-control-radius"
        style={{
          fontSize: 10,
          opacity: 0.7,
          margin: '2px 0 0',
          fontFamily: 'ui-monospace, monospace',
        }}
      >
        {filtration.shapeKind === 'ball' ? `drawn radius at t: ${radiusText}` : radiusText}
      </p>
    </div>
  );
}
