import { useMemo } from 'react';
import type { BallFiltration, BallShape } from '../filtration/types';
import { projectCloud } from './project';
import { unionPath } from './shapePath';

/** Plane position and styling for a geometric cross-section of growing balls. */
export interface BallSlice2DProps {
  filtration: BallFiltration;
  t: number;
  /** Horizontal plane in the original cloud's coordinates. */
  z?: number;
  width?: number;
  height?: number;
  padding?: number;
  color?: string;
  opacity?: number;
}

/** Exact sphere/plane intersections. Scale laws stay in filtration.radiusAt. */
export function ballSliceShapes(filtration: BallFiltration, t: number, z: number): BallShape[] {
  if (
    filtration.cloud.dimension !== 3 ||
    filtration.shapeKind !== 'ball' ||
    filtration.complexType === 'kfold'
  ) {
    throw new Error('BallSlice2D needs a 3D ball union. A k-fold region needs DepthSlice3D.');
  }
  if (!Number.isFinite(z) || !Number.isFinite(t))
    throw new Error('BallSlice2D needs a finite scale and plane.');
  const { points } = filtration.cloud;
  const discs: BallShape[] = [];
  for (let i = 0; i < points.length / 3; i++) {
    const r = filtration.radiusAt(i, t);
    const dz = z - points[3 * i + 2]!;
    const squared = r * r - dz * dz;
    // Tangency has zero area. An absent intersection must not become a disc.
    if (squared <= 0) continue;
    discs.push({
      kind: 'ball',
      center: [points[3 * i]!, points[3 * i + 1]!],
      radius: Math.sqrt(squared),
    });
  }
  return discs;
}

/** A true planar section of the ball union, not a projection of the centres. */
export function BallSlice2D({
  filtration,
  t,
  z = 0,
  width = 640,
  height = 320,
  padding = 20,
  color = 'currentColor',
  opacity = 0.35,
}: BallSlice2DProps) {
  const projection = useMemo(() => {
    const points = filtration.cloud.points;
    let minX = Infinity,
      minY = Infinity,
      maxX = -Infinity,
      maxY = -Infinity;
    for (let i = 0; i < points.length / 3; i++) {
      const r = filtration.radiusAt(i, filtration.tMax);
      minX = Math.min(minX, points[3 * i]! - r);
      maxX = Math.max(maxX, points[3 * i]! + r);
      minY = Math.min(minY, points[3 * i + 1]! - r);
      maxY = Math.max(maxY, points[3 * i + 1]! + r);
    }
    return projectCloud(points.length ? [minX, minY, maxX, maxY] : [], 2, width, height, padding);
  }, [filtration, width, height, padding]);
  const discs = ballSliceShapes(filtration, t, z);
  const d = unionPath((i) => discs[i]!, discs.length, t, projection);
  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      width={width}
      height={height}
      role="img"
      aria-label={`Horizontal section of the ball union at z = ${z.toFixed(3)}`}
      data-testid="ball-slice-2d"
      data-plane-z={z}
      data-section-discs={discs.length}
    >
      <path
        d={d}
        fill={color}
        fillRule="nonzero"
        opacity={opacity}
        data-testid="ball-slice-union"
      />
    </svg>
  );
}
