import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  TETRA4_ALPHA,
  TRIANGLE_CECH,
  recordedFiltration,
} from '../../__fixtures__/realFiltrations';
import type { BallFiltration } from '../../filtration/types';
import { BallSlice2D, ballSliceShapes } from '../BallSlice2D';

describe('exact sections through a ball union', () => {
  const real = recordedFiltration(TETRA4_ALPHA) as BallFiltration;
  it('agrees with independent sphere/plane geometry and keeps the filtration untouched', () => {
    const f = {
      ...real,
      cloud: { points: [0, 0, 0, 3, 0, 3], weights: [0, 0], dimension: 3 as const },
      radiusAt: () => 2,
    };
    const pairs = f.pairs;
    const discs = ballSliceShapes(f, 4, Math.sqrt(3));
    expect(discs[0].radius).toBeCloseTo(1, 12);
    expect(discs[1].radius).toBeCloseTo(Math.sqrt(4 - (3 - Math.sqrt(3)) ** 2), 12);
    expect(ballSliceShapes(f, 4, -2)).toHaveLength(0); // tangent or missed
    expect(f.pairs).toBe(pairs);
    expect(f.cloud.points).toEqual([0, 0, 0, 3, 0, 3]);
  });
  it('reads the actual weighted radius law instead of treating t as radius', () => {
    const f = {
      ...real,
      cloud: { points: [0, 0, 0], weights: [3], dimension: 3 as const },
      radiusAt: (_i: number, t: number) => Math.sqrt(t + 3),
    };
    expect(ballSliceShapes(f, 1, 1)[0].radius).toBeCloseTo(Math.sqrt(3), 12);
    expect(ballSliceShapes(f, 1, 3)).toHaveLength(0);
  });
  it('draws a single union path with no overlap-dependent opacity', () => {
    render(<BallSlice2D filtration={real} t={0.8} z={0} />);
    expect(screen.getByTestId('ball-slice-union')).toHaveAttribute('fill-rule', 'nonzero');
    expect(screen.getByTestId('ball-slice-union').getAttribute('d')).not.toBe('');
    expect(screen.getByTestId('ball-slice-2d')).toHaveAccessibleName(/section.*z = 0/);
  });
  it('refuses a 2D cloud and non-finite planes', () => {
    expect(() =>
      ballSliceShapes(recordedFiltration(TRIANGLE_CECH) as BallFiltration, 1, 0),
    ).toThrow(/3D/);
    expect(() => ballSliceShapes(real, 1, NaN)).toThrow(/finite/);
  });
});
