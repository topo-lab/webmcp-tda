// <GuaranteeChip>: the honest label as a component (SPEC.md §1.4, §1.6).
// The label text is a QUOTATION (tda-wasm SPEC FR-6) and is asserted character
// for character here, exactly as the filtration layer's own guarantee test
// does — a chip that paraphrases is a chip that can inflate.
import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import {
  CIRCLE12_WING,
  CIRCLE24_ALPHA,
  DIAGONAL3_CUBICAL_T,
  DIAGONAL3_CUBICAL_V,
  ELLIPSE_ELLIPSOID_CECH,
  ELLIPSE_ELLIPSOID_RIPS,
  JITTERED8_KFOLD2,
  RING6_BOX,
  TRIANGLE_CECH,
  TRIANGLE_RIPS,
  recordedFiltration,
  recordedGridFiltration,
} from '../../__fixtures__/realFiltrations';
import { GuaranteeChip, QUANTIZATION_WARNING } from '../GuaranteeChip';

describe('<GuaranteeChip> renders the library\u2019s wording, verbatim', () => {
  it.each([
    [TRIANGLE_RIPS, 'flag', 'flag complex (Rips-type)'],
    [TRIANGLE_CECH, 'nerve', 'true nerve (Cech)'],
    [CIRCLE24_ALPHA, 'nerve', 'alpha complex (exact combinatorics)'],
    [JITTERED8_KFOLD2, 'nerve', 'exact (order-k Delaunay nerve)'],
    [RING6_BOX, 'nerve', 'nerve (= flag, by Helly for boxes); step-quantized'],
    [CIRCLE12_WING, 'flag', 'flag complex (Rips-type)'],
    [ELLIPSE_ELLIPSOID_RIPS, 'flag', 'flag complex (Rips-type)'],
    [ELLIPSE_ELLIPSOID_CECH, 'nerve', 'true nerve (ellipsoidal Cech)'],
  ])('$0.name: %s', (rec, kind, label) => {
    render(<GuaranteeChip filtration={recordedFiltration(rec)} />);
    expect(screen.getByTestId('guarantee-chip-label').textContent).toBe(label);
    expect(screen.getByTestId('guarantee-chip')).toHaveAttribute('data-guarantee', kind);
  });

  it('never presents a flag complex as an equivalence', () => {
    render(<GuaranteeChip filtration={recordedFiltration(ELLIPSE_ELLIPSOID_RIPS)} />);
    const meaning = screen.getByTestId('guarantee-chip-meaning').textContent ?? '';
    expect(meaning).toMatch(/PAIRWISE/);
    expect(meaning).not.toMatch(/homotopy equivalent/);
  });

  it('states the equivalence for a nerve, which is what a nerve buys', () => {
    render(<GuaranteeChip filtration={recordedFiltration(ELLIPSE_ELLIPSOID_CECH)} />);
    expect(screen.getByTestId('guarantee-chip-meaning').textContent).toMatch(
      /homotopy equivalent to the union of the shapes at every scale/,
    );
  });

  it('omits the meaning line when asked, keeping the verbatim label', () => {
    render(<GuaranteeChip filtration={recordedFiltration(TRIANGLE_RIPS)} showMeaning={false} />);
    expect(screen.queryByTestId('guarantee-chip-meaning')).toBeNull();
    expect(screen.getByTestId('guarantee-chip-label').textContent).toBe('flag complex (Rips-type)');
  });
});

describe('<GuaranteeChip> quantization (SPEC.md §1.3: grid values, not measurements)', () => {
  it('names π and the comparison convention without prohibiting different resolutions', () => {
    const box = recordedFiltration(RING6_BOX);
    render(<GuaranteeChip filtration={box} />);
    const chip = screen.getByTestId('guarantee-chip');
    expect(chip).toHaveAttribute('data-quantized', 'true');
    const text = screen.getByTestId('guarantee-chip-quantization').textContent ?? '';
    expect(text).toContain(QUANTIZATION_WARNING);
    expect(text).toContain(String(box.quantization.step));
    expect(text).toContain(`${box.quantization.steps} steps`);
    expect(text).toContain('common physical scale');
    expect(text).toContain('matched conventions');
    expect(text).toContain('changing resolution can confound differences');
    expect(text).not.toContain('not comparable');
  });

  it('says nothing about a grid when values are measurements', () => {
    render(<GuaranteeChip filtration={recordedFiltration(CIRCLE24_ALPHA)} />);
    expect(screen.queryByTestId('guarantee-chip-quantization')).toBeNull();
    expect(screen.getByTestId('guarantee-chip')).not.toHaveAttribute('data-quantized');
  });
});

describe('<GuaranteeChip> colour (DESIGN.md "Colour": --nerve / --flag, never a hex literal)', () => {
  it('reads the label colour from --nerve on a nerve, with the DESIGN.md fallback', () => {
    render(<GuaranteeChip filtration={recordedFiltration(TRIANGLE_CECH)} />);
    const style = screen.getByTestId('guarantee-chip-label').getAttribute('style') ?? '';
    expect(style).toContain('var(--nerve, #0f766e)');
    expect(style).not.toMatch(/#15803d/);
  });

  it('reads the label colour from --flag on a flag complex', () => {
    render(<GuaranteeChip filtration={recordedFiltration(TRIANGLE_RIPS)} />);
    const style = screen.getByTestId('guarantee-chip-label').getAttribute('style') ?? '';
    expect(style).toContain('var(--flag, #b45309)');
  });

  it('reads the quantization warning colour from --flag too', () => {
    render(<GuaranteeChip filtration={recordedFiltration(RING6_BOX)} />);
    const style = screen.getByTestId('guarantee-chip-quantization').getAttribute('style') ?? '';
    expect(style).toContain('var(--flag, #b45309)');
  });

  it('never hard-codes a colour outside a var() fallback', () => {
    // A consumer on the ink ground overrides --nerve / --flag on an ancestor;
    // any OTHER hex literal here would need `!important` to be overridden,
    // which is the exact defect this component fixes.
    render(<GuaranteeChip filtration={recordedFiltration(RING6_BOX)} />);
    for (const testId of ['guarantee-chip-label', 'guarantee-chip-quantization'] as const) {
      const style = screen.getByTestId(testId).getAttribute('style') ?? '';
      const hexes = style.match(/#[0-9a-fA-F]{3,6}\b/g) ?? [];
      for (const hex of hexes) {
        const before = style.slice(0, style.indexOf(hex));
        expect(before.endsWith('var(--nerve, ') || before.endsWith('var(--flag, ')).toBe(true);
      }
    }
  });
});

describe('<GuaranteeChip> vertex identity (SPEC.md §3.1: two index spaces)', () => {
  it('says the k-fold vertices are k-subsets drawn at barycentres, with the counts', () => {
    const kfold = recordedFiltration(JITTERED8_KFOLD2);
    render(<GuaranteeChip filtration={kfold} />);
    expect(screen.getByTestId('guarantee-chip')).toHaveAttribute('data-vertex-kind', 'subset');
    const text = screen.getByTestId('guarantee-chip-vertices').textContent ?? '';
    expect(text).toMatch(/2-subsets of the input/);
    expect(text).toMatch(/barycentres/);
    expect(text).toContain(`${kfold.vertexCount} vertices`);
    expect(text).toContain('8 points');
    // The whole point of the sentence: there are more vertices than points.
    expect(kfold.vertexCount).toBeGreaterThan(8);
  });

  it('says nothing when a vertex simply IS a point', () => {
    render(<GuaranteeChip filtration={recordedFiltration(CIRCLE24_ALPHA)} />);
    expect(screen.queryByTestId('guarantee-chip-vertices')).toBeNull();
    expect(screen.getByTestId('guarantee-chip')).toHaveAttribute('data-vertex-kind', 'point');
  });
});

describe('<GuaranteeChip> on a grid filtration (SPEC.md §3.1b)', () => {
  const t = recordedGridFiltration(DIAGONAL3_CUBICAL_T);
  const v = recordedGridFiltration(DIAGONAL3_CUBICAL_V);

  it('renders the ENGINE’s name for the construction, verbatim', () => {
    render(<GuaranteeChip filtration={t} />);
    expect(screen.getByTestId('guarantee-chip-label').textContent).toBe(
      'top-dimensional-cell filtration (T-construction)',
    );
    expect(screen.getByTestId('guarantee-chip-label').textContent).toBe(t.guarantee.label);
  });

  it('gives the other convention the other label, from the same nine numbers', () => {
    render(<GuaranteeChip filtration={v} />);
    expect(screen.getByTestId('guarantee-chip-label').textContent).toBe(
      'vertex lower-star filtration (V-filtration)',
    );
  });

  it('marks the domain and the kind, so a consumer can style or branch on them', () => {
    render(<GuaranteeChip filtration={t} />);
    const chip = screen.getByTestId('guarantee-chip');
    expect(chip).toHaveAttribute('data-domain', 'grid');
    expect(chip).toHaveAttribute('data-guarantee', 'cubical');
    expect(chip).toHaveAttribute('data-complex-type', 'cubical');
    // No quantization (the values are the image's own numbers) and no subset
    // vertices (there are no vertices to be subsets of).
    expect(chip).not.toHaveAttribute('data-quantized');
    expect(chip).not.toHaveAttribute('data-vertex-kind');
    expect(screen.queryByTestId('guarantee-chip-quantization')).toBeNull();
    expect(screen.queryByTestId('guarantee-chip-vertices')).toBeNull();
  });

  it('says what the kind buys: the cells ARE the set, with no lemma in between', () => {
    render(<GuaranteeChip filtration={t} />);
    const meaning = screen.getByTestId('guarantee-chip-meaning').textContent ?? '';
    expect(meaning).toMatch(/no cover, no lemma/i);
    // And it is NOT the nerve sentence: a cubical complex makes a different
    // claim from a nerve, and a chip that reused the wording would say so.
    expect(meaning).not.toMatch(/nerve lemma applies/i);
  });

  it('carries the grid and the fact that the other convention would differ', () => {
    render(<GuaranteeChip filtration={t} />);
    const note = screen.getByTestId('guarantee-chip-grid').textContent ?? '';
    expect(note).toContain('3 × 3');
    expect(note).toContain('pixels');
    expect(note).toMatch(/different diagram/i);
  });

  it('carries its own ink, not the nerve’s: three kinds, three colours', () => {
    const { rerender } = render(<GuaranteeChip filtration={t} />);
    const cubicalInk = screen.getByTestId('guarantee-chip-label').getAttribute('style') ?? '';
    expect(cubicalInk).toContain('--cubical');
    rerender(<GuaranteeChip filtration={recordedFiltration(TRIANGLE_CECH)} />);
    const nerveInk = screen.getByTestId('guarantee-chip-label').getAttribute('style') ?? '';
    expect(nerveInk).toContain('--nerve');
    expect(nerveInk).not.toContain('--cubical');
  });
});
