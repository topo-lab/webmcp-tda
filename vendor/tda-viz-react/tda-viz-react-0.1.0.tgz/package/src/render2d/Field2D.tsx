/**
 * <Field2D>: the space X_t itself — ⋃ᵢ S_i(t) as ONE merged region
 * (SPEC.md §4.1). This is the primary surface: the user moves t and watches the
 * space grow.
 *
 * WHATEVER SHAPE GROWS. The shape is whatever `filtration.shapeAt(i, t)`
 * returns, already scaled to t (SPEC.md §1.1): discs for the ball
 * constructions, ellipses fitted from a local PCA frame, the wing's concave
 * hexagon, axis-aligned boxes on the π grid. This component switches on
 * `shapeKind` exhaustively and re-derives no scale law — that re-derivation is
 * how a picture ends up disagreeing with the barcode beside it (SPEC.md §1.3).
 * Radii and semi-axes are PER POINT (SPEC.md §1.2): heavier points have larger
 * balls at every t.
 *
 * UNION, NOT n SHAPES. Every shape is one subpath of a single SVG `<path>`,
 * filled once with `fill-rule: nonzero`. n translucent shapes would
 * double-count every overlap, and the overlaps are exactly the regions the
 * complex is about. Declarative SVG rather than canvas (SPEC.md §8 Q1): one
 * merged path is one DOM node, so the node-count objection to SVG does not
 * apply, and rotated ellipses and concave hexagons are one path command each.
 *
 * WHAT IT WILL NOT DRAW. When `shapesAvailable` is false — today only a box
 * filtration built without its boxes — this draws no shapes and shows the
 * filtration's own reason (SPEC.md §1.6). A 3D ellipsoid filtration is refused
 * for a different reason: dropping z would draw the ellipse of frame[0],
 * frame[1], which is a central slice and not the ellipsoid's outline.
 *
 * Wings are always drawn, in both normal modes: `computeWingGeometry` hands back
 * the outline the builder used, including for normals the engine estimated from
 * k, so no shape here is ever a re-estimate. Which normal a hexagon came from
 * travels with it as `WingShape.normalSource`.
 *
 * The scale convention is read from the filtration and DISPLAYED — a picture
 * that does not name its convention can silently contradict the barcode.
 */
import { useId, useMemo } from 'react';
import type { Filtration, RadiusConvention } from '../filtration/types';
import { projectCloud } from './project';
import { unionPath } from './shapePath';

/** Props for `<Field2D>`. */
export interface Field2DProps {
  /**
   * Any filtration. `shapeKind` decides what is drawn, and `shapeAt` supplies
   * it already scaled to t — so this surface never has to know which
   * construction produced the shape (SPEC.md §3.1).
   */
  filtration: Filtration;
  /** Current scale. Filters what is drawn; never triggers a recompute (SPEC.md §1.5). */
  t: number;
  width?: number;
  height?: number;
  padding?: number;
  color?: string;
  /** Uniform opacity of the union region. */
  opacity?: number;
  /**
   * Contour of the union's BOUNDARY. Off by default: the region is the subject.
   *
   * When it is on it is not decoration. ∂(⋃ᵢ S_i(t)) is where the nerve
   * theorem's equivalence lives — the edge of the space the complex claims to
   * be homotopy equivalent to — so a drawn contour is the difference between a
   * stain and a stated object.
   *
   * It is the boundary and not n outlines. See the masking note on the render.
   */
  strokeColor?: string;
  /**
   * Width of that contour, in pixels of the drawing box. Ignored without
   * `strokeColor`; 0.8 is the value this component has always stroked at, kept
   * as the default so an existing caller sees no change.
   */
  strokeWidth?: number;
  /** Opacity of the contour. Defaults to 1, so `strokeColor` may carry its own alpha. */
  strokeOpacity?: number;
  /**
   * Draw EVERY SHAPE'S OWN BOUNDARY — each disc, ellipse, wing or box outline,
   * including the arcs buried inside the union. Off by default.
   *
   * The union contour (`strokeColor`) says what the space IS; these say what it
   * is MADE OF. A reader looking at one merged region cannot see how many
   * shapes made it, where they overlap, or that a shape is a disc rather than
   * an ellipse until the outlines are there — and the overlaps are exactly the
   * regions the complex is about (SPEC.md §4.1). Drawn UNDER the contour and
   * meant to be lighter than it: the boundary of the union is a stronger claim
   * than the boundary of one of its parts.
   *
   * NOT a second geometry. The union's own path already IS every shape's
   * outline, concatenated one subpath per shape, so this strokes the identical
   * `d` with no fill. A separate pass calling `shapeAt` again could drift from
   * the region it is drawn over; this cannot.
   */
  showShapeOutlines?: boolean;
  /** Colour of those outlines. Defaults to `color`, the field's own hue. */
  shapeOutlineColor?: string;
  /** Their width, in pixels of the drawing box. Defaults to 0.5: a hairline. */
  shapeOutlineWidth?: number;
  /** Their opacity. Defaults to 0.35, well under a contour's, for the reason above. */
  shapeOutlineOpacity?: number;
  className?: string;
  'aria-label'?: string;
}

/** What t means, per convention (SPEC.md §1.3). Displayed, never assumed. */
const CONVENTION_LABEL: Record<RadiusConvention, string> = {
  rips: 'Vietoris–Rips convention: t is edge length; ball radius t/2',
  cech: 'Čech convention: t is the ball radius; drawn directly',
  alpha: 'alpha convention: t is squared radius; ball radius √(t + wᵢ) per point',
  'ellipsoid-r': 'ellipsoid Čech · t is the radius · semi-axes t·profile along the fitted frame',
  'ellipsoid-2r':
    'ellipsoid convention: t is TWICE the ellipsoid radius; semi-axes (t/2)·profile along the fitted frame',
  'wing-eps': 'wing convention: t is the wing scale ε; spine half-length q·t, wing edges t at ±θ',
  'box-step': 'box convention: t is step × π; the box drawn is the engine’s box at step ⌊t/π⌋',
};

/**
 * Why a drawing of the shapes would be dishonest, or null when it would not.
 * Two sources: the filtration says its geometry does not exist, or this
 * top-down 2D surface cannot show the shape without distorting it.
 */
function shapeRefusal(filtration: Filtration): string | null {
  if (!filtration.shapesAvailable) {
    return (
      filtration.shapesUnavailableReason ??
      'this filtration reports that its growing shapes are unavailable'
    );
  }
  if (filtration.shapeKind === 'ellipsoid' && filtration.cloud.dimension === 3) {
    return (
      'a 3D ellipsoid does not project to the ellipse of frame[0], frame[1]: that is a ' +
      'central slice, not the outline. The complex is drawn; use <Field3D> from ' +
      'tda-viz-react/3d for the shapes.'
    );
  }
  return null;
}

/**
 * The space X_t itself — the union of the growing shapes at scale t, drawn as
 * one merged SVG path (SPEC.md §4.1). Whatever shape the filtration grows is
 * what appears; this component re-derives no scale law.
 */
export function Field2D({
  filtration,
  t,
  width = 320,
  height = 320,
  padding = 16,
  color = '#2563eb',
  opacity = 0.28,
  strokeColor,
  strokeWidth = 0.8,
  strokeOpacity = 1,
  showShapeOutlines = false,
  shapeOutlineColor,
  shapeOutlineWidth = 0.5,
  shapeOutlineOpacity = 0.35,
  className,
  'aria-label': ariaLabel = 'Union of the growing shapes at the current scale',
}: Field2DProps) {
  const { cloud, convention, shapeKind } = filtration;

  const projection = useMemo(
    () => projectCloud(cloud.points, cloud.dimension, width, height, padding),
    [cloud, width, height, padding],
  );

  const refusal = shapeRefusal(filtration);
  // Scoped per instance: two <Field2D>s on one page would otherwise share a
  // mask id, and the second definition would win for both.
  const maskId = `field-2d-outside-${useId()}`;

  // ONE path string for the whole union. Rebuilt when t moves — which is
  // display work on a finished filtration, never a recompute (SPEC.md §1.5).
  const d = useMemo(() => {
    if (refusal) return '';
    const pointCount = cloud.points.length / cloud.dimension;
    return unionPath((i, at) => filtration.shapeAt(i, at), pointCount, t, projection);
  }, [filtration, cloud, t, projection, refusal]);

  return (
    <div
      className={className}
      data-testid="field-2d"
      data-convention={convention}
      data-shape-kind={shapeKind}
      data-shapes-drawn={refusal ? 'false' : 'true'}
    >
      <svg
        role="img"
        aria-label={ariaLabel}
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        style={{ display: 'block' }}
      >
        {/*
          THE CONTOUR IS THE UNION'S BOUNDARY, NOT n OUTLINES, and this mask is
          the whole reason it can be. The union is one path of n subpaths filled
          nonzero; STROKING that path would draw every shape's complete outline,
          including the arcs buried inside a neighbour — the double-counting the
          merged fill exists to avoid, drawn back in as line. ∂(⋃ᵢ S_i) is
          exactly the part of those outlines that is NOT in the union's
          interior, so the stroke is masked to the region outside the fill.

          The stroke is laid down at twice `strokeWidth` and half of it — the
          inner half — is masked away, which leaves a contour of `strokeWidth`
          sitting just outside the region, and leaves a buried arc with nothing:
          every point of it is interior, so every point of it is masked. The
          drawn line is therefore the boundary the nerve theorem talks about,
          within the half-pixel any raster hairline is true to.
        */}
        {d && strokeColor && (
          <mask id={maskId} maskUnits="userSpaceOnUse" x={0} y={0} width={width} height={height}>
            <rect x={0} y={0} width={width} height={height} fill="white" />
            <path d={d} fillRule="nonzero" fill="black" />
          </mask>
        )}
        {d && (
          <path
            data-testid="field-2d-union"
            d={d}
            fill={color}
            fillOpacity={opacity}
            // nonzero, never evenodd: under even-odd every overlap would punch
            // a hole in the union (SPEC.md §4.1).
            fillRule="nonzero"
            stroke="none"
          />
        )}
        {/*
          EVERY SHAPE'S OWN BOUNDARY, buried arcs included — the same path the
          fill above uses, stroked instead of filled, so the outlines cannot
          drift from the region they lie in. Between the fill and the contour in
          paint order: the union's boundary is the stronger claim and stays on
          top of the boundaries of its parts.
        */}
        {d && showShapeOutlines && (
          <path
            data-testid="field-2d-outlines"
            d={d}
            fill="none"
            stroke={shapeOutlineColor ?? color}
            strokeWidth={shapeOutlineWidth}
            strokeOpacity={shapeOutlineOpacity}
            strokeLinejoin="round"
          />
        )}
        {d && strokeColor && (
          <path
            data-testid="field-2d-contour"
            d={d}
            fill="none"
            stroke={strokeColor}
            strokeWidth={strokeWidth * 2}
            strokeOpacity={strokeOpacity}
            // The outline turns corners where two shapes meet; a mitre spikes.
            strokeLinejoin="round"
            mask={`url(#${maskId})`}
          />
        )}
      </svg>
      <p
        data-testid="field-2d-convention"
        style={{
          fontSize: 10,
          opacity: 0.65,
          margin: '4px 0 0',
          fontFamily: 'ui-monospace, monospace',
        }}
      >
        {CONVENTION_LABEL[convention]}
      </p>
      {refusal && (
        <p
          data-testid="field-2d-shapes-unavailable"
          style={{
            fontSize: 10,
            color: '#b45309',
            margin: '2px 0 0',
            fontFamily: 'ui-monospace, monospace',
          }}
        >
          shapes not drawn: {refusal}
        </p>
      )}
    </div>
  );
}
