# tda-viz-react — package spec

**Status:** v2, founder-corrected 2026-08-23; complex menu added 2026-09-01;
distribution section corrected to the checked-out engine dependency 2026-09-04.
Supersedes v1 entirely.
**License:** MIT (see §9)
**Repo:** `topo-lab/tda-viz-react`, private.

---

## 0. What this is, stated once

A React library for visualizing a **filtration** of a point cloud — the
one-parameter family of topological spaces you get by growing a **shape**
around every point — and the complex that family induces.

For most of the engine's constructions that shape is a ball, and the ball is
still the case to think with. But it is not the general case, and saying
"ball" as if it were is exactly the kind of convenient inaccuracy this spec
exists to prevent. The engine also grows **ellipsoids** (fitted per point from
a local PCA frame), a 2D concave **wing** hexagon around an estimated normal,
and axis-aligned **boxes** that grow in whole steps. And in one construction —
the k-fold cover — the shapes are still balls but the complex's **vertices are
not the points**: a vertex is a k-subset of the input. The library's job is to
carry all of that honestly, per construction, and never to draw a circle where
the mathematics grew something else (§1.3, §3.1).

The object of study is the family itself, indexed by scale. Not a barcode.
Not a diagram. Those are *summaries* of the family and this library can draw
them, but they are the last thing it does, not the first.

Every component answers one question: **at scale t, what does the space look
like, and what is the complex it induces?** The user moves t. Everything else
follows.

### Why v1 was wrong

v1 shipped a results-display library: components that draw a barcode after a
computation finishes. That is the compute-then-stare pattern the Explorer's
own VISION.md rejects, with better typography. The growing balls were an
illustration in one component's corner. They are the subject. v2 inverts this.

### What this package is NOT responsible for

Computation. `tda-wasm` computes complexes and persistence. This package
organizes that capability and makes the *process* visible. It owns no
topology algorithm and must never grow one.

---

## 1. The mathematics the components must respect

This section is normative. A component that violates it is wrong, not merely
ugly.

### 1.1 The filtration

Given points p₁…pₙ ∈ ℝᵈ, the **sublevel filtration** at scale t is the union of
the growing shapes

    X_t = ⋃ᵢ S_i(t)

with S_i(s) ⊆ S_i(t) whenever s ≤ t, so X_s ⊆ X_t. Moving t forward never
removes anything. This inclusion is the whole reason persistence is well
defined, and the UI must never break it: a display that makes something vanish
as t increases is lying about the filtration.

The familiar case is S_i(t) = B(pᵢ, r_i(t)) with r_i non-decreasing, and it
covers Rips, Čech, alpha and the k-fold cover. The other shapes are just as
monotone, and monotone for the same reason — they are all **homothetic about
their point**, scaled by a factor that increases with t:

| Shape | S_i(t) | Monotone because |
|---|---|---|
| ball | B(pᵢ, rᵢ(t)) | rᵢ non-decreasing |
| ellipsoid | semi-axes (t/2)·profileᵢ along a FIXED frameᵢ | the profile and frame do not move with t |
| wing | the engine's unit wing at scale t around a FIXED normal αᵢ | every defining vector scales linearly with t (`wing_complex.hpp`, homothety note) |
| box | the engine's grown box at step ⌊t/π⌋ | the growth rule only ever adds width, and the step index is non-decreasing |

Two consequences the library is required to respect. First, the ellipsoid and
wing shapes are monotone **only because their frame / normal is fixed at build
time**: re-estimating either per scale would break the inclusions and the
persistence beside them would be the persistence of nothing. Second, the box
shape exists only on the grid — the shape at t is a *lookup* of the last
completed step, never an interpolation, because an interpolated box is a shape
the filtration never contained.

### 1.2 Weights

A **weighted point cloud** assigns each point a weight wᵢ. In the alpha / power
filtration the ball around pᵢ has squared radius **t + wᵢ** (Edelsbrunner's
convention; `tda-wasm`'s `alphaPersistence` takes `(x, y, z, w)`
with exactly this meaning). So:

- At a given t, heavier points have larger balls.
- Radii are therefore **per point**, not one shared scalar. This is the
  single fact v1's `GrowingBalls2D` got wrong (one radius for all points).

**Engine constraint (verified 2026-08-24):** `alphaPersistence`
throws on any wᵢ < 0 (`"Weight at point i must be non-negative"`). So the
general power-filtration case of a point with wᵢ < −t — "not yet born,
imaginary radius" — is mathematically real but **unreachable through this
engine**. The library must not simulate it. The adapter validates wᵢ ≥ 0 up
front and throws a clear error rather than letting the WASM call fail
opaquely. With wᵢ ≥ 0, every point is present at t = 0 with radius √wᵢ ≥ 0,
and heavier points simply start larger and stay larger.

An unweighted cloud is the special case wᵢ = 0 ∀i. The library treats
unweighted as weighted-with-zeros; there is no separate unweighted path.

### 1.3 Which shape to draw at t

The shape on screen must match the filtration's indexing, or the picture
contradicts the barcode beside it. Each construction indexes t differently, and
the library must name which convention it is drawing:

| Complex | Convention | Index t means | Shape drawn at t |
|---|---|---|---|
| Vietoris–Rips | `rips` | edge length | ball, radius t/2 — two balls touch exactly when points are t apart |
| Čech | `cech` | ball radius | ball, radius t |
| Alpha / weighted alpha | `alpha` | squared radius | ball, radius √(t + wᵢ), per point |
| k-fold cover | `alpha` | squared radius, unweighted | ball, radius √t, around the **input points** (§3.1: the vertices are subsets) |
| Ellipsoid-Rips | `ellipsoid-2r` | **twice** the ellipsoid radius | ellipsoid, semi-axes (t/2)·profileᵢ along frameᵢ |
| Ellipsoid-Čech | `ellipsoid-r` | ellipsoid radius | ellipsoid, semi-axes t·profileᵢ along frameᵢ |
| Wing | `wing-eps` | the wing scale ε itself | the (q, θ)-hexagon: spine half-length q·t, wing edges of length t at ±θ — the engine's unit outline, scaled |
| Box | `box-step` | step × π | the engine's box at step ⌊t/π⌋ |

Four things this table is load-bearing about.

1. The k-fold cover deliberately reuses `alpha`. Its values are squared radii
   and it refuses weights, so the radius law is `alpha`'s law with wᵢ = 0 —
   inventing a fourth ball convention that computes the same number would make
   every convention-keyed table in every renderer grow an entry for nothing.
   What is different about the k-fold cover is vertex identity and its
   guarantee, and those are carried separately.
2. In API 0.3, ellipsoid Rips emits twice radius and ellipsoid Čech emits
   radius. Compare a Čech birth r with a Rips birth 2r. The library retains
   native units, and both 2D and 3D shapes read the convention. Historical
   showcase plates explicitly convert radius to twice-radius at serialization.
3. Box values are **grid values**, not measurements. A box filtration carries
   its step π (§3.1 `quantization`), a renderer must say so, and two box
   diagrams at different π are not comparable — a bottleneck distance between
   them mostly measures the grids.
4. Only `rips`, `cech` and `alpha` have a radius at all. `radiusAt` exists on
   ball filtrations and nowhere else, so a component that draws discs takes a
   ball filtration and refusing an ellipsoid one is a **type error, not a
   runtime surprise** (§3.1). There is still no default convention, because a
   wrong default silently produces a picture that disagrees with the homology.
5. The **cubical** filtration is not in this table, and that is the point. It
   has no convention because it has no shape: the cells are fixed, the values
   are fixed, and t is a THRESHOLD rather than a scale. It lives in its own
   domain (§3.1b) with its own type, and `RadiusConvention` does not grow a
   member for it — a scale law that nothing scales by would be a law with
   nothing to say.

What a cubical filtration must name instead is which **cell a value lives on**,
and there the library is under the same obligation this table imposes:

| Construction | A value belongs to | Faces take | Complex spans |
|---|---|---|---|
| `cubical-t` | a top-dimensional cell (a pixel) | the **minimum** of the cells around them | w × h squares |
| `cubical-v` | a grid vertex | the **maximum** of their vertices (the lower star) | (w−1) × (h−1) squares |

These are two different filtrations of the same numbers and they give different
diagrams, so neither may be defaulted to. The difference is structural, not
numerical: under T two low pixels that touch corner to corner share a vertex,
and that vertex takes the minimum of the pixels around it, so they are connected
from t = 0; under V two low vertices that touch corner to corner have no edge
between them, because a square lattice has no diagonals, so every path between
them climbs through a higher vertex. T reads a grid with diagonal contact, V
does not, and no threshold makes them agree. On `0 2 2 / 2 0 2 / 2 2 0` — the
hand-computed case the tests state — T reports one component and V reports
three.

A cubical filtration also names its **direction**: `sublevel` fills {f ≤ t} and
sweeps up, `superlevel` fills {f ≥ t} and sweeps down. The engine computes
sublevel only, so the adapter builds a superlevel filtration as the sublevel
filtration of −f and negates the endpoints back into the image's own units — an
identity for both constructions, since min(−v) = −max(v), and asserted against
the engine rather than assumed. A superlevel diagram therefore runs downward
(birth ≥ death); `containsValue` is the single predicate that reads the
direction, and every renderer and summary goes through it.

### 1.4 The nerve, and the guarantee every filtration must carry

The **nerve** of a cover is the simplicial complex with a k-simplex for every
k+1 sets with a common point. The **Nerve theorem** says it is homotopy
equivalent to X_t when the sets are convex (balls, ellipsoids and boxes all
are). So for a nerve, the complex on screen and the union of shapes on screen
are *the same space* up to homotopy, and the library should make that identity
visible: a simplex appears exactly when its shapes start overlapping.

A **flag complex** is the flag complex of the pairwise-intersection graph. It
is cheaper, it is what several of the source papers actually build, and it is
*not* a nerve: three shapes can meet pairwise long before they share a point,
so a flag triangle is not a claim that three shapes overlap.

Which one a construction is, is not a matter of presentation. It is a fact
about the construction, and this library carries it as **data on every
filtration** — a `guarantee` with a machine-readable `kind` and the exact chip
text. The wording is fixed by tda-wasm's own SPEC FR-6 and reproduced
verbatim; a test asserts every string character for character and fails if a
flag complex is ever labelled a nerve:

| Complex | kind | label (verbatim) |
|---|---|---|
| Rips | `flag` | `flag complex (Rips-type)` |
| Ellipsoid-Rips | `flag` | `flag complex (Rips-type)` |
| Wing | `flag` | `flag complex (Rips-type)` |
| Čech | `nerve` | `true nerve (Cech)` |
| Ellipsoid-Čech | `nerve` | `true nerve (ellipsoidal Cech)` |
| k-fold cover | `nerve` | `exact (order-k Delaunay nerve)` |
| Box | `nerve` | `nerve (= flag, by Helly for boxes); step-quantized` |
| Alpha / weighted alpha | `nerve` | `alpha complex (exact combinatorics)` |

The reasons, because a label with no argument behind it is decoration:

- **Čech** is the nerve of the ball cover by definition; **alpha** is the nerve
  of the cover by ball ∩ power cell — convex pieces, so a good cover — which is
  why it has far fewer simplices for the same homology.
- **Ellipsoid-Čech** is a nerve because at every radius the sets are
  ellipsoids, hence convex, so every subfamily intersection is empty or
  contractible; that is a good cover and the nerve lemma applies
  (Giunti–Hill–Ye). Its flag sibling shares the same ellipsoids and the same
  scale, and is still not a nerve — the two must never be presented as the same
  object.
- **Box** is a nerve because axis-aligned boxes are Helly axiswise: a family
  that meets pairwise already shares a point (Alvarado–Gupta–Krishnamoorthy
  Lemma 2.24). Downgrading it to a Rips-type tag is as much a violation as
  inflating the other two, and the `step-quantized` half of the tag is not
  optional (§1.3).
- **k-fold cover** is exact because the Almost Nerve lemma
  (Edelsbrunner–Osang) makes the persistence of the order-k mosaic *equal*
  multicover persistence. What is exact is the homotopy type; the values are
  still doubles.
- **Rips**, **ellipsoid-Rips** and **wing** are flag complexes built from
  pairwise intersections, which is what their source papers build and say they
  build (Canova–Kališnik–Moser–Rieck–Žegarac Def. 2.2; Weng–Zhao Eq. 3.5).

**The cubical filtration is a THIRD kind, and it is kept out of the table
above.** The nerve/flag pair classifies complexes built from intersections of
growing shapes, and the whole content of that classification is whether a nerve
lemma applies to the cover. A cubical complex is not in that argument: nothing
grows, nothing intersects, and there is no cover whose nerve it might be. The
complex IS the thresholded set's own cell decomposition, so there is no lemma
standing between the picture and the homology and nothing weaker to withhold.
Filing it under `nerve` would claim an equivalence that is not the one the word
means here; filing it under `flag` would withhold one that was never in doubt.
So it carries `kind: 'cubical'` in a **separate table**, `GRID_GUARANTEES`,
keyed by construction:

| Construction | kind | label (verbatim, the ENGINE's own phrase) |
|---|---|---|
| `cubical-t` | `cubical` | `top-dimensional-cell filtration (T-filtration)` |
| `cubical-v` | `cubical` | `vertex lower-star filtration (V-filtration)` |

Two consequences that are requirements, not notes.

First, **the labels are quoted, not composed.** They are tda-wasm's own words
for the two conventions — the engine ships both bindings, so it is the document
that has to tell them apart — and the test reads the engine's `README.md` off
disk and fails if either phrase is no longer in it verbatim. A wording change
upstream is a signal to requote, never to invent a phrase.

Second, **`COMPLEX_GUARANTEES` stays at eight keys.** A construction index built
from it is an index of the eight point-cloud constructions and must not silently
gain a ninth entry that belongs to a different domain and cannot be built from a
cloud. `<GuaranteeChip>` renders either kind and gives the cubical one its own
ink (`--cubical`), because two different claims drawn in one colour read as one
claim to anybody who reads colour before text.

### 1.5 What ε does and does not do

Persistence is a function of the cloud, the weights, the complex type and the
dimension cap. It is **not** a function of t. The engine is called once per
BUILD — per (cloud, weights, params) — and moving t only filters what is drawn.
This is a hard rule because the alternative — recomputing on every scrub —
makes the instrument unusable and obscures the fact that the barcode already
contains every t.

"Once per build" is not "one function call": a build has always been complex +
persistence, and the shape-bearing paths add a third, geometry-only call —
`ellipsoids` for the ellipsoids, `wings` for the
wings — so the drawn shapes come from the same fitting, and the same normal
resolution, as the simplices. The rule that matters is that **none of them ever
runs again because t moved**.

### 1.6 Honesty (carried from v1, still binding)

- Never synthesize a simplex or a persistence pair. Empty / computing / error
  are real states.
- For nerves of good covers in ℝᵈ, drop H_k for k ≥ d: this is an ambient
  bound on the covered union. Cubical subsets obey the same ambient bound.
  Flag complexes do not: a planar regular hexagon's Rips complex at
  √3 < t < 2 is the octahedral boundary and has H₂ = 1.
- Independently, a complex capped at dimension c cannot generally resolve H_c.
  Withhold degrees ≥ c unless completeness is separately established; retain
  every engine pair in rawPairs. Filtration.pairs and bettiAt apply this cap
  plus the construction-specific ambient rule, never ambient alone for flags.
- Public honesty helpers accept complexType; filterRealHomology additionally
  accepts maxSimplexDim. Omitted construction retains the legacy nerve
  interpretation. Consumers of arbitrary complexes must pass construction.
- Label experimental engine paths. Never upgrade a status for marketing.
- Carry the guarantee (§1.4) as data, not as prose in a component. A renderer
  that has to compose its own honesty chip will eventually compose the wrong
  one.
- Never invent geometry the engine did not return, and never re-derive geometry
  it does. ONE case is reported rather than filled in today: a box filtration
  built without retaining its boxes. It says `shapesAvailable: false` with a
  reason, and asking it for a shape throws instead of returning a default.
  The wing was the other case until the engine gained `wings`
  (2026-09-02), which returns the normal the builder used — including one it
  estimated internally from k — and the unit outline its birth solver
  intersects. Every wing filtration is now drawable, EXACTLY: the polygon is
  `point + t · outline[v]`, and this library does not rebuild the hexagon from
  (q, θ, α). Provenance travels with each wing as `normalSource`
  (`supplied` | `osculating` | `tangent`) instead of as a refusal, because an
  estimated normal is a weaker normal, not an absent one, and a reviewer has to
  be able to see which one a picture rests on.

---

## 2. Architecture

Three layers, as before, but the middle one is now the point.

```
engine     tda-wasm adapter: one build per (cloud, weights, params)
   ↓
filtration HEADLESS. The central abstraction. See §3.
   ↓
render     2D (SVG / Canvas)   |   3D (PlayCanvas)   |   summaries (barcode, diagram)
```

`engine` and `filtration` import nothing from `playcanvas`, `three` or
`d3`. Enforced by ESLint `no-restricted-imports` and a test that proves the
rule fires. Unchanged from v1; this part was right.

---

## 3. The filtration layer (the contract)

### 3.1 Types

```ts
/** A point cloud with per-point weights. Unweighted = all zeros. */
interface WeightedCloud {
  points: number[];        // flat, length n·dimension
  weights: number[];       // length n; all 0 for unweighted
  dimension: 2 | 3;
}

type BallConvention  = 'rips' | 'cech' | 'alpha';
type ShapeConvention = 'ellipsoid-2r' | 'ellipsoid-r' | 'wing-eps' | 'box-step';
type RadiusConvention = BallConvention | ShapeConvention;   // §1.3

type FiltrationComplexType =
  | 'rips' | 'cech' | 'alpha' | 'kfold'
  | 'ellipsoid-rips' | 'ellipsoid-cech' | 'wing' | 'box';

/** The growing shape at t, ALREADY scaled — the renderer does no scale math. */
type GrowingShape =
  | { kind: 'ball';      center: readonly number[]; radius: number }
  | { kind: 'ellipsoid'; center: readonly number[];
      frame: readonly (readonly number[])[];   // orthonormal, from local PCA
      semiAxes: readonly number[] }            // LENGTHS at t = (t/2)·profile
  | { kind: 'wing';      center: readonly number[]; normal: readonly number[];
      normalSource: 'supplied' | 'osculating' | 'tangent' | 'isolated';
      spineHalfLength: number; wingLength: number; theta: number;
      outline: readonly (readonly number[])[] }  // A, B, C, D, C', B'
  | { kind: 'box';       lower: readonly number[]; upper: readonly number[];
      step: number };                            // ⌊t/π⌋, the engine's own box

/** §1.4, machine-readable. The label is verbatim; tests pin every character. */
interface ComplexGuarantee { kind: 'nerve' | 'flag'; label: string }

/** Non-null exactly when values are grid values (the box filtration, §1.3). */
interface FiltrationQuantization { step: number; steps: number }

/** Common to every filtration. Built once, queried per frame. */
interface FiltrationBase {
  readonly cloud: WeightedCloud;
  readonly convention: RadiusConvention;
  readonly complexType: FiltrationComplexType;
  readonly guarantee: ComplexGuarantee;
  readonly maxSimplexDim: number;

  readonly simplices: readonly Simplex[];       // sorted ascending
  readonly pairs: readonly PersistencePair[];   // cap + construction-aware (§1.6)
  readonly rawPairs: readonly PersistencePair[];
  readonly tMax: number;
  readonly criticalValues: readonly number[];
  readonly quantization: FiltrationQuantization | null;

  readonly shapeKind: 'ball' | 'ellipsoid' | 'wing' | 'box';
  readonly shapesAvailable: boolean;              // §1.6: box without boxes only
  readonly shapesUnavailableReason: string | null;

  readonly vertexKind: 'point' | 'subset';
  readonly vertexCount: number;
  readonly vertexSubsets: readonly (readonly number[])[] | null;
  readonly vertexPositions: readonly number[];    // flat, vertexCount·dimension
  vertexPosition(v: number): readonly number[];

  simplicesAt(t: number): readonly Simplex[];     // O(log n), memoized
  aliveAt(t: number): readonly PersistencePair[];
  bettiAt(t: number): number[];
}

interface BallFiltration extends FiltrationBase {
  readonly shapeKind: 'ball';
  readonly convention: BallConvention;
  radiusAt(i: number, t: number): number;   // BALLS ONLY (§1.3, point 4)
  shapeAt(i: number, t: number): BallShape;
}
interface EllipsoidFiltration extends FiltrationBase {
  readonly shapeKind: 'ellipsoid';
  readonly convention: 'ellipsoid-2r' | 'ellipsoid-r';
  readonly ellipsoid: { neighbors: number; axes: number | 'pca' };
  shapeAt(i: number, t: number): EllipsoidShape;
  unitShape(i: number): EllipsoidProfile;         // frame + UNIT profile (§3.1a)
}
interface WingFiltration extends FiltrationBase {
  readonly shapeKind: 'wing';
  readonly convention: 'wing-eps';
  readonly shapesAvailable: true;                 // always: see §1.6
  readonly shapesUnavailableReason: null;
  readonly wing: {
    q: number; theta: number;
    normals: readonly number[];                   // the ones the builder USED
    normalSources: readonly WingNormalSource[];   // per point, where from
  };
  shapeAt(i: number, t: number): WingShape;
  unitShape(i: number): WingProfile;              // the engine's unit wing
}
interface BoxFiltration extends FiltrationBase {
  readonly shapeKind: 'box';
  readonly convention: 'box-step';
  readonly quantization: FiltrationQuantization;   // never null here
  readonly box: { growth: number; maxBirthStep: number };
  shapeAt(i: number, t: number): BoxShape;
  boxesAtStep(step: number): readonly BoxShape[];  // one STEP's row (§3.1a)
}

type Filtration =
  | BallFiltration | EllipsoidFiltration | WingFiltration | BoxFiltration;
```

Four decisions in that record are normative, not stylistic.

**`Filtration` is a discriminated union on `shapeKind`.** A shape renderer
switches on it exhaustively; a ball renderer takes `BallFiltration` and cannot
be handed a wing at all. This is the §1.3 rule enforced by the compiler instead
of by a code review, and it is why `radiusAt` lives on the ball member only.

**Two index spaces, kept apart.** `shapeAt(i, t)` and `radiusAt(i, t)` take an
**input point** index — in every construction the engine offers, the shapes grow
around input points. `simplices[].vertices` and `vertexPosition(v)` take a
**vertex** index. They coincide unless `vertexKind` is `'subset'`, which today
means the k-fold cover: vertex v stands for `vertexSubsets[v]`, a k-subset of
the input, and is drawn at that subset's barycentre (`vertexPositions`, flat and
allocation-free, is the same law the engine's own review page uses). A renderer
that positions vertices from `cloud.points` is wrong for the k-fold cover, and
`vertexCount !== n` is the check that catches it.

**`quantization` is null, never zero.** A step of 0 would read as "no
quantization" and as "infinitely fine grid" at the same time.

**`shapeAt` throws when the geometry does not exist** (§1.6, last bullet),
having said so in advance through `shapesAvailable` / `shapesUnavailableReason`.
A renderer checks once and draws the complex alone; the alternative — returning
some default shape — is the failure mode this whole section exists to prevent.

### 3.1a The unscaled shape, for renderers that scale on the GPU

`shapeAt(i, t)` is the right call for a CPU drawing that rebuilds per frame. A
GPU renderer does the opposite: it uploads per-instance geometry ONCE and applies
t as a uniform in the vertex shader (§1.5), so it needs the geometry BEFORE t
scales it. The record therefore exposes it directly:

| Member | Accessor | Returns |
|---|---|---|
| ellipsoid | `unitShape(i)` | centre, the fixed frame, the engine's UNIT semi-axis profile — `shapeAt(i, t).semiAxes` is `(t/2)·` this for Rips, `t·` this for Čech |
| wing | `unitShape(i)` | centre, normal, `normalSource`, curvature diagnostics, and the engine's six unit outline offsets — `shapeAt(i, t).outline[v]` is `centre + max(t, 0)·` this |
| box | `boxesAtStep(step)` | one whole STEP of grown boxes, in input-point order: a row of the engine's `(steps + 1) × n` records |
| ball | — | its t-invariant data is the centre and the weight, which `cloud` already carries and `radiusAt` already interprets |

Why this is contract and not convenience. `<Field3D>` used to recover the
ellipsoid profile as `shapeAt(i, 2).semiAxes`, which is EXACT under
`ellipsoid-2r` — at t = 2 the factor t/2 is 1 — but it put the scale law in the
renderer, and §1.3 exists to keep it out of there. The equivalence is still
pinned by a test, precisely so the accessor cannot drift from the law it is the
unscaled end of. Boxes had a worse version of the same problem: getting every
step meant `shapeAt(i, s·π)` in a double loop, i.e. each call site reproducing
the grid arithmetic of `⌊t/π⌋`. `boxesAtStep` takes a step INDEX and refuses a t
value by name.

### 3.1b The grid domain — a filtration with no cloud and no shape

A cubical filtration is not a point cloud with growing shapes, and the contract
says so rather than pretending. It is a **grid of values and a threshold**:

```ts
type GridConstruction = 'cubical-t' | 'cubical-v';   // §1.3: which cell a value is on
type GridDirection    = 'sublevel' | 'superlevel';   // §1.3: which side is filled

/** §1.4, and a third kind. The label is the ENGINE's phrase, quoted. */
interface GridGuarantee { kind: 'cubical'; construction: GridConstruction; label: string }

interface GridFiltration {
  readonly domain: 'grid';
  readonly complexType: 'cubical';
  readonly construction: GridConstruction;
  readonly direction: GridDirection;

  readonly values: Float64Array;      // row-major, width · height, all finite
  readonly width: number;
  readonly height: number;

  readonly guarantee: GridGuarantee;
  readonly maxSimplexDim: 2;    // a 2D grid has no 3-cells (§5, honesty)
  readonly pairs: readonly PersistencePair[];      // honesty-filtered
  readonly rawPairs: readonly PersistencePair[];
  readonly tMin: number;              // smallest grid value
  readonly tMax: number;              // largest
  readonly criticalValues: readonly number[];      // the distinct values, ASCENDING
  readonly quantization: null;        // the values are the image's own numbers

  valueAt(x: number, y: number): number;
  containsValue(value: number, t: number): boolean;   // the ONE direction-aware predicate
  aliveAt(t: number): readonly PersistencePair[];
  bettiAt(t: number): number[];                       // [β₀, β₁]
}

type AnyFiltration = Filtration | GridFiltration;     // discriminated by `domain`
```

**It is a sibling type, not a ninth member of `Filtration`.** `Filtration` is
discriminated by `shapeKind` and every member of it grows a shape; a grid grows
nothing, so adding it there would give the union a member for which `shapeAt`,
`cloud`, `simplices`, `radiusAt` and `convention` are all meaningless, and every
existing consumer would have to narrow before touching any of them. Instead
`FiltrationBase` gains `domain: 'cloud'`, the grid carries `domain: 'grid'`, and
`AnyFiltration` is the union of the two. A component that draws shapes keeps
taking `Filtration` and **cannot be handed a grid by mistake**; a component that
accepts either narrows on `domain` once, at the top, and reads only what that
domain has.

**What is deliberately absent.** No `shapeAt`, because nothing grows. No
`cloud`, because the input is an image. No `simplices` array: the engine returns
a diagram, not a cell list, and a cell list this layer synthesised itself would
be geometry the engine never computed (§1.6). No `convention`, because there is
no scale law (§1.3, point 5). No `quantization` — its value is `null`, present
only so the field can be read off any filtration without a `domain` check, and
it is null for a real reason: the grid's values are the image's own numbers, not
a grid this library imposed on them, so there is no π and nothing to warn about.

**`containsValue` is the only place the direction is interpreted**, and
`aliveAt` and `bettiAt` are written through it, so a renderer's fill and the
Betti count beside it cannot disagree about which way the sweep runs. A class is
alive exactly while the sweep has reached its birth and not its death.

**`criticalValues` is ascending, always**, like every other filtration here.
`direction` says which end the sweep starts from; a consumer wanting sweep order
reverses them itself, rather than the library having two orderings for one
field.

**The honesty slice is the same and the reasons are different** (§5). A cubical
complex is COMPLETE — no cap withheld anything — so the cap is 2 because a 2D
grid has no 3-cells, and the ambient bound is 2 because a thresholded subset of
the plane has no H₂. Both are 2, neither is standing in for the other, and
`createGridFiltration` passes them separately. The H₂ row the T-construction's
binding can emit (its cells go up to dimension 2) is dropped for the ambient
reason alone.

### 3.2 Construction

```ts
buildFiltration(engine, cloud, params): Promise<Filtration>
```

Overloaded so the params pick the member: ball params give a `BallFiltration`,
ellipsoid params an `EllipsoidFiltration`, and so on. One BUILD per (cloud,
weights, params) (§1.5); `shapeAt`, `radiusAt` and `simplicesAt` are pure
functions of the result and t, cheap enough to call every animation frame.

| `complexType` | Required params | Binding | Notes |
|---|---|---|---|
| `alpha` | — | `alphaPersistence` | the only weighted path; cap is the triangulation's own dimension |
| `rips` | `maxEdgeLength` | `ripsComplex` | unweighted only |
| `cech` | `maxRadius` (the max ball radius) | `cechComplex` | unweighted only |
| `kfold` | `k`; optional `maxSquaredRadius` | `kFoldCoverComplex` | 3D + unweighted + distinct points only |
| `ellipsoid-rips` | `neighbors`, `axes`, `maxEdgeLength` (twice the radius) | `ellipsoidRipsComplex` + `ellipsoids` | 2D/3D, unweighted |
| `ellipsoid-cech` | `neighbors`, `axes`, `maxRadius` (the radius) | `ellipsoidCechComplex` + `ellipsoids` | same |
| `wing` | `q`, `theta`, `normals` (a flat array of normals, or a count k) | `wingComplex` + `wings` | 2D + unweighted only; both normal modes drawable |
| `box` | `stepSize` (π), `growth`; `boxes` defaults **true** | `boxFiltration` | 2D/3D, unweighted; duplicates fine |
| `witness` | — | — | refused: no weighted witness filtration exists (§8 Q3) |
| `cubical` | `values`, `width`, `height`, `construction`, `direction` | `cubicalPersistence(grid, {construction: "T" | "V", coeff})` | **takes no cloud**: `buildFiltration(engine, params)`, two arguments, returning a `GridFiltration` (§3.1b) |

Rules the adapter enforces, all of them mirroring the engine so a caller reads
a sentence instead of a WASM abort. As in the engine, a value of the wrong type
throws a `TypeError` and a value out of range a `RangeError`, and the message
names the parameter.

- **Weights.** Weighted clouds route to `alphaPersistence`; 2D
  weighted clouds embed at z = 0 in the engine adapter (this is where that
  embedding belongs, and nowhere else). Every other builder ignores weights at
  the binding, so handing one a weighted cloud **throws**. Silently dropping
  the weights would produce a picture of a different filtration.
- **Dimension.** `kfold` is 3D-only (its level-by-level construction rests on
  Edelsbrunner–Osang Theorem 5); `wing` is 2D-only (Weng–Zhao §6: 3D is open
  research). Both refuse the other dimension by name.
- **Degeneracy.** `kfold` rejects coincident input, naming both indices, because
  a repeated point breaks the order-k mosaic — the engine rejects it too, rather
  than returning a mosaic with vertices missing.
- **Cutoffs.** Non-positive `maxSquaredRadius`, `maxEpsilon`, `stepSize`,
  ellipsoid cutoffs and `maxSteps` are refused. The ellipsoid cutoff is
  **required** for both ellipsoid paths (`maxEdgeLength` for ellipsoid Rips,
  `maxRadius` for ellipsoid Čech; the removed `maxFiltration` is refused by name), and that is stricter than the engine: every pair of
  ellipsoids eventually touches, so an uncut build asks for the complete
  complex. A default cutoff would be an invented parameter (the same reason
  the Rips `maxEdgeLength` and the Čech `maxRadius` have no default).
- **Ranges.** `q ∈ [0, 1]`, `θ ∈ (0, π/2]`, `growth ∈ [0, 1]`, `axes ≥ 1` or
  `'pca'`, `neighbors` an integer ≥ 2, `k` a positive integer with
  `n ≥ k + 3`.
- **Wing normals.** `normals` is either a flat 2n array (roughly unit — the engine
  requires |α|² ∈ (0.25, 4) and then normalizes) or a neighbourhood size k, an
  integer ≥ 2, as the engine takes it. BOTH
  modes are drawable: the adapter makes a second, geometry-only call to
  `wings` with the same `(points, q, theta, normals)`, so the
  drawn wing is the wing whose births the complex recorded, and the record hands
  back the normals the builder actually used. The two modes differ in
  `normalSource`, not in drawability (§1.6).
- **Grid.** The cubical branch validates its grid the way every other builder
  validates its cloud, and before the wasm boundary: the sides must be positive
  integers, `values.length` must be `width · height` (read ROW-MAJOR), every
  value must be finite — the message names the column and row of the offender —
  and `construction` and `direction` must each be one of their two members, with
  no default, because the alternatives are different filtrations (§1.3). A
  both constructions forward the requested prime `coeff` to the 0.3
  reducer. The grid is COPIED into the filtration, so a caller mutating its
  array afterwards cannot change what the picture means.
- **Dimension order.** Both constructions receive `{values, shape: [height,
  width]}` in NumPy row-major order. Non-square image and transpose regressions
  check connected components and loops against independent expected results.

### 3.3 The scale controller

```ts
useScale(filtration): { t, setT, play, pause, playing, snapToNext, snapToPrev }
```

The single source of truth for t. `snapToNext`/`snapToPrev` jump between
`criticalValues`, because the interesting moments of a filtration are the
moments something changes, and a continuous slider skips over them.

For a box filtration the `criticalValues` are grid values (§1.3), so snapping
lands on multiples of π by construction — which is the honest behaviour, and
another reason `quantization` is on the record rather than in a comment.

An application that sweeps t holds exactly ONE animation loop, through
`startAnimationLoop` / `stopAnimationLoop` (`src/state/animationLoop.ts`,
promoted from the site 2026-09-03): a single module-level
`requestAnimationFrame` slot that starting another loop cancels, so two live
loops are unrepresentable. `activeLoopCount()` is 0 or 1 by construction and is
what a test asserts. `useScale`'s own `play` predates the registry and still
holds its own frame; a consumer that needs the invariant across surfaces drives
t from the registry instead.

### 3.4 What the complex menu changed in the record

Additive, except for three deliberate breaks. They are breaks in the TYPES; no
ball filtration behaves differently at runtime.

1. **`Filtration` is a union.** Code that takes a `Filtration` and calls
   `radiusAt` must narrow on `shapeKind === 'ball'` (or take a
   `BallFiltration`). This is the point of the change: the alternative is a
   `radiusAt` that throws for wings at frame time, or worse, returns a number.
2. **`complexType` lost `'witness'` and gained the menu.** Witness filtrations
   were never constructible — `buildFiltration` has always thrown for them —
   so the old union described a state that could not exist. `'witness'` remains
   a valid *params* value precisely so that the refusal keeps its clear error.
3. **`createFiltration` takes the convention explicitly** and per-shape
   geometry (`ellipsoid` / `wing` / `box`, plus optional `vertexSubsets`),
   instead of deriving the convention from the complex type. The k-fold cover is
   why: its complex type is `kfold` and its convention is `alpha`.
4. **The wing record carries GEOMETRY, not normals** (2026-09-02).
   `createFiltration` takes `wing.geometry` — `wings` output, one
   record per point, required — where it used to take `wing.normals` and allow
   null. `WingFiltration.wing.normals` survives as the flat array of normals the
   builder actually used, and is no longer nullable, joined by
   `normalSources`. A wing filtration's `shapesAvailable` is now `true` in the
   type, so code that branched on it for wings is dead code rather than wrong
   code.

`<ScaleControl>` declares `filtration: Filtration` (2026-09-05, widened from
`BallFiltration`): `tMax`, `criticalValues` and `convention` — everything the
scrubber and the snap-to-event buttons need — exist on every member of the
union, so narrowing the prop bought nothing but locking consumers with an
ellipsoid, a wing or a box out of the control entirely. Only the scale
READOUT still narrows, on `shapeKind === 'ball'`, exactly per point 1 above:
where a radius is defined it is read out from `radiusAt` (a RANGE under
weights, since per-point radii differ); where it is not, the control states
the scale value and the filtration's own convention instead of inventing a
"ball radius" for a shape that has none.

`<Field2D>` takes the whole union and switches on `shapeKind` exhaustively —
that is what the union is for, and `shapeAt` is what makes it possible without
a scale law per shape in the renderer. `<Field3D>` takes
`BallFiltration | EllipsoidFiltration | BoxFiltration`: the wing complex is 2D
only, in the engine and in the mathematics (`WASM_HONESTY.md`: "3D is open
research and is not attempted"), so a 3D wing surface would be drawing a shape
nobody has defined.

---

## 4. Render

Components take a `Filtration` and a `t`. They never take raw pairs or raw
simplices; the filtration object is the interface.

Two obligations the menu adds to this layer, both of which are the next task's
work and are recorded here because they are contract, not taste:

- A surface that draws shapes switches on `shapeKind` exhaustively and uses
  `shapeAt` — or `unitShape` / `boxesAtStep` if it scales on the GPU (§3.1a); it
  never re-derives a scale law (§1.1). When `shapesAvailable` is false it draws
  the complex and shows `shapesUnavailableReason`.
- A surface that draws vertices uses `vertexPositions` / `vertexPosition`, not
  `cloud.points`. `<Nerve2D>` and `<Nerve3D>` do (2026-09-01), so the k-fold
  mosaic is drawable: vertex v sits at the barycentre of `vertexSubsets[v]`, and
  both surfaces mark those vertices with a glyph of their own and state on the
  drawing that they are subsets, not points (§8 Q5). Read-only all the way down:
  `pointsToPositions` takes `readonly number[]`, so packing `vertexPositions`
  for the GPU copies nothing.

### 4.0 The honest label is a component, not prose

`<GuaranteeChip filtration>` renders `filtration.guarantee.label` **verbatim**
and nothing composed: the wording is the library's (§1.4), and a renderer that
assembles its own chip will eventually assemble the wrong one. It renders, from
the same record and only when the record says so, the two facts that travel
with particular constructions:

- the **quantization** warning for a box filtration — `step π = …, m steps` plus
  `bar endpoints are grid values; diagrams at different π are not comparable`
  (§1.3 point 3);
- the **subset-vertex** sentence for the k-fold cover — vertices are k-subsets
  of the input drawn at their barycentres, with the two counts, because
  `vertexCount ≠ n` is the fact a reader has to be told (§3.1).

Every story that draws a complex shows it. Plain HTML, main entry: it sits
beside a 2D SVG stage or over a PlayCanvas canvas equally well.

Its two colours are read from CSS custom properties, never a hex literal:
`--nerve` (fallback `#0f766e`) and `--flag` (fallback `#b45309`) — the same
token names DESIGN.md's "Colour" section declares for the paper ground. The
quantization warning reuses `--flag`, since it is drawn in the same rust as a
caveat rather than as its own colour decision. A consumer on the ink ground
sets `--nerve` / `--flag` to DESIGN.md's `--nerve-on-ink` / `--flag-on-ink`
pair on an ancestor element and the chip retints with no `!important`, because
a custom property cascades rather than competing on specificity.

`<ConstructionIndex entries selectedId onSelect panelId>` is the honest way to
OFFER constructions (2026-09-03, promoted from the site's Atlas): a two-band
index whose bands are the guarantee kinds, headed and explained in the library's
own words (`BAND_HEADING`, `BAND_RULE`, `BAND_ORDER` in
`src/filtration/guarantees.ts`). Selecting a construction is therefore always an
act of reading its classification. An entry may be `disabled` — listed in its
class, not selectable, and given no reason by the index, because the omission is
the engine's rule and `buildFiltration`'s own message is what a consumer surfaces
— and the index may be `locked` for a lesson that teaches one construction.

### 4.1 The stage — the primary surface

`<PointCloud2D>` is the controlled input surface that precedes a filtration. Callers may also provide one disk radius per point in data units; the component projects those radii with the same aspect-preserving scale and does not invent a filtration convention. A separate final-radius array may reserve a stable viewport, preventing growth animations from rescaling or clipping the cover.
When `editable` and `onPointsChange` are provided, the caller selects an explicit
`move` or `edit` interaction mode. Move maps pointer drags back through the fixed
projection captured at drag start; edit uses one click or Enter to open the
built-in accessible `(x, y)` coordinate dialog. A caller may replace that dialog
through `promptForPoint`. Optional labelled coordinate axes and calibrated ticks
are controlled by `showAxes`; they use the same projection as the points. The
component owns no point data and never recomputes topology. Optional `edges` are
caller-supplied 1-skeleton records drawn beneath the points; the component filters
or synthesizes none of them.

`<PlayCanvasStage>` is the analogous primary surface for `/3d`: every 3D
component in the table below renders into it, and it never hides a failed
graphics device. `pc.createGraphicsDevice` can fail two ways — an outright
rejection, and the one that is easy to miss, a RESOLVED promise carrying a
null device (`device.isNull`, always appended after the requested types as
the engine's last-ditch fallback) — and a throwing `pc.Application`
constructor is a third. All three set `error: Error | null` on the context
alongside a narrowed `deviceType: 'webgpu' | 'webgl2' | null`; `app` is never
non-null alongside a set `error`. The stage root also carries
`data-device="webgpu" | "webgl2" | "none"`, so a test or a consumer reads the
achieved backend without importing the context. A caller supplies `fallback`
(a node, or a function of the `Error`) and `onError` to react to failure; with
neither, the stage still never renders a silent blank canvas — it shows its
own one-sentence message, set from the stage's own tokens (`var(--token)`,
never a raw hex literal, per DESIGN.md "Colour").

Teardown contract: unmounting the whole `<PlayCanvasStage>` subtree destroys
the `pc.Application` (and its graphics device) before any child's own cleanup
runs — React tears down a deleted subtree's passive effects parent-first — so
every 3D component's cleanup must check `deviceIsLive(app)` (`render3d/utils.ts`)
before calling `.destroy()` on a vertex buffer, mesh, material, texture or
entity, rather than assume the device that created it is still there to free
it (WebGL2 is affected; WebGPU's buffer path never touches the now-dead `gl`).

| Component | Entry | Draws at scale t |
|---|---|---|
| `<Field2D>` | main | ⋃ᵢ S_i(t) as a single merged region — the space X_t itself, not n overlapping shapes. Whatever `shapeAt` returns: discs, ellipses, wing hexagons, boxes. Must render union, so overlaps read as one region. |
| `<Nerve2D>` | main | Simplices of the complex at t, over the field, at `vertexPosition(v)`. A nerve simplex draws exactly when its shapes overlap. |
| `<Grid2D>` | main | The set the threshold names on a grid of values — one cell per value, the set that is IN inked by depth and the rest empty (§4.7). Takes a `GridFiltration` only. |
| `<Field3D>` | /3d | Same union, as instanced spheres / oriented ellipsoids / boxes, labelled an approximation (§8 Q2). |
| `<Nerve3D>` | /3d | Simplices at t. Tetrahedra never filled (would hide H₂). |
| `<DepthSlice3D>` | /3d | The covering depth of a k-fold cover on a plane through the cloud: every pixel counts the balls that contain it, in four stepped colours. Exact, not an approximation (§4.5). |
| `<KFoldCover3D>` | /3d | The k-fold cover itself, as a solid region of space: the boundary of { x : depth(x) ≥ k }, sphere-traced per fragment. Optionally the one-fold cover as a translucent shell. Exact, not an approximation (§4.6). |

`<Field2D>` rendering union rather than overlapping shapes is not cosmetic:
overlapping translucent shapes visually double-count the intersection, which
is exactly the region the complex cares about. Canvas with a union fill, or SVG
with an `evenodd`-free merged path, is required; **the shipped surface is the
SVG merged path** (§8 Q1), one `<path>` element for the whole union with
`fill-rule: nonzero`. Every subpath must wind the same way — under nonzero
winding, two overlapping subpaths of opposite handedness cancel and punch a
hole where the shapes agree.

### 4.5 Covering depth — the k-fold cover's own picture

`<DepthSlice3D filtration t plane colors opacity size>` (/3d) draws a planar
slice through the cloud of a k-fold cover filtration on which EVERY PIXEL counts
the balls that contain it, and paints that covering depth with a stepped ramp:
depth 0 transparent, then 1, 2, 3 and ≥ 4 in four caller-supplied colours. It
exists because the union `<Field3D>` draws is the ONE-fold cover, which for
k > 1 is silent about the thing the complex is built from — the region a k-fold
cover is about is the set covered at least k times. Its claim is EXACTNESS, not
resemblance, and it is the one 3D surface here that makes that claim: the
fragment shader evaluates `#{ i : |x − cᵢ|² ≤ t }` per fragment over every
centre in the cloud — no distance field, no blur, no accumulated alpha standing
in for a count — so two depth-k regions meet on screen exactly when they meet in
R³, and the FCC-versus-HCP comparison (holes sharing a face merge at t ≈ 0.67,
holes sharing only an edge at t ≈ 0.75) is READ OFF the picture rather than
annotated onto it. The GLSL and the WGSL are transcriptions of one pure
TypeScript function, `coveringDepthAt` (`src/render3d/depthSlice.ts`), named in
both shaders as their oracle and tested against brute force — jsdom cannot read
GPU pixels back, so the arithmetic is tested where it can be, and the shaders
are held to it at source level. The component REFUSES anything that is not a
3D k-fold cover (`complexType === 'kfold'`, `vertexKind === 'subset'`), because
covering depth needs a multiplicity and painting a Rips complex's ball count
would look like this picture while meaning nothing about the complex beside it.
The centres upload once per cloud as a 256-entry uniform array and moving t
writes one uniform (§1.5); a cloud above that ceiling throws rather than
counting a prefix of itself.

### 4.6 The k-fold cover as a solid

`<KFoldCover3D filtration t k colorCover colorUnion unionOpacity shininess>`
(/3d) draws the k-fold cover ITSELF: not a slice of it, not a mesh fitted to
it, but the region

    C_k(t) = { x ∈ R³ : #{ i : |x − cᵢ| ≤ √t } ≥ k }

as a lit, orbitable surface. It exists because a k-fold cover is inherently
three-dimensional and §4.5's plane, exact as it is, shows one cross-section of
it: the shape of the lobes, the neck two of them join through, and how many
there are cannot be read off a disc. At k = 4 on a Barlow packing the region is
a family of lobes around the tetrahedral holes, opening at t = 0.375 and joining
through a shared FACE (HCP, t ≈ 0.670) or only through a shared EDGE (FCC,
t ≈ 0.7525) — a fact about solids meeting in R³.

EXACTNESS COMES FROM AN IDENTITY, not from a fine enough grid. Let d₍ₖ₎(x) be
the k-th smallest distance from x to the centres. Then

    depth(x) ≥ k   ⇔   d₍ₖ₎(x) ≤ √t   ⇔   d₍ₖ₎(x)² ≤ t

because "at least k of the distances are ≤ √t" and "the k-th smallest of them
is ≤ √t" are the same statement. So the k-fold cover is the SUBLEVEL SET of
d₍ₖ₎ and its boundary is the isosurface d₍ₖ₎ = √t. Three consequences carry the
component: d₍ₖ₎ is 1-Lipschitz (each |x − cᵢ| is, and the k-th order statistic
of 1-Lipschitz functions is), so `d₍ₖ₎(x) − √t` is a safe sphere-tracing step
and the march converges to the surface without overshooting it; the outward
normal at a boundary point is (x − c₍ₖ₎)/|x − c₍ₖ₎| with c₍ₖ₎ the k-th nearest
centre, ANALYTIC, so there are no finite differences and no normal smoothing;
and k = 1 is the plain union of the balls, so the same shader draws the
one-fold cover as a translucent shell in front — which is the argument, since
the union is what `<Field3D>` approximates and it says nothing about k.

There is no marching-cubes mesh anywhere in this. The picture is the predicate,
evaluated along each pixel's own ray, exactly as §4.5's is evaluated at each
pixel's own point. `kthNearestDistanceSquared` / `insideKFoldCover`
(`src/render3d/kfoldCover.ts`) are the pure-TypeScript oracle the GLSL and the
WGSL transcribe, named in both shaders, tested against an independent brute
force and against `coveringDepthAt` — §4.5's counting oracle, which the identity
above says must agree pointwise.

The mechanics, and their limits, are stated rather than hidden: the trace runs
inside a box enclosing the cloud's bounding box grown by √tMax (nothing outside
it can be covered), the centres upload ONCE per cloud as a 256-entry uniform
array and moving t writes one uniform per pass (§1.5), k ≤ 8 because the k
smallest squared distances are selected in registers, and the march is capped at
128 steps — a ray that has not landed by then is DISCARDED, not drawn at a
guessed position. Fragment depth is written from the hit point, so `<Nerve3D>`
edges and `<PointCloud3D>` points in the same stage occlude correctly instead of
sorting against a box wall. The component REFUSES anything that is not a 3D
k-fold cover, for §4.5's reason: without a multiplicity there is no such region.

### 4.7 The grid, drawn as cells

`<Grid2D filtration t width height padding color opacity minShade gridColor
gridWidth gridOpacity>` (main) draws {f ≤ t} — or {f ≥ t} — on the grid of
values, as one SVG rect per value.

It exists because the grid domain has no `<Field2D>` to fall back on. `<Field2D>`
draws ⋃ᵢ S_i(t) and its whole job is to evaluate a scale law; a cubical
filtration has no scale law and no shapes, so this surface calls no `shapeAt`,
names no convention, and refuses a cloud filtration by TYPE rather than at
runtime.

**Its claim is the THRESHOLD, so it draws every cell at every t.** The set that
is inside is inked; the rest is drawn empty — an outline and nothing else — so
the line between them is exactly the threshold. Drawing only the cells that are
in would make the picture a silhouette: the reader could see where the sweep had
been and never where it had got to.

**The ink is depth, and it is an opacity.** A cell's strength is how early the
sweep reached its value, normalised across the grid's own range; the deepest are
solid and a cell that has only just entered is faint but never invisible, since
a cell at the threshold IS in the complex and fading it out would draw the
boundary of the set outside the set. Strength and not hue, so that one custom
property retints the field and no palette is written into the component
(DESIGN.md, Colour: `--grid-ink`, `--grid-rule`, both overridable as props).

**It states which cell a value is on.** Under `cubical-t` a value IS a pixel and
the rects tile the complex exactly; under `cubical-v` a value is a lattice
VERTEX, the squares lie between the vertices, so the complex spans (w−1) × (h−1)
and each rect is the vertex's own half-cell neighbourhood — the drawn field
reaches half a cell past the complex on every side. `data-cell-basis` records
which, because the same array under the two conventions is two pictures of two
different complexes.

**It types no guarantee wording.** The caption under the drawing is the
filtration's own `guarantee.label` — the engine's phrase (§1.4) — plus one
sentence of the library's own about which side of the threshold is filled. The
SVG contains no `<text>` at all, which is the mechanical form of the rule and
what the test asserts.

Its stated limits: 2D only, one rect per value (so the cell count is a DOM size,
which is fine for the grids a browser can draw at all and is not a 4K image
path), and it draws no complex over the field — the cells and the complex are
the same object here, unlike the field/nerve pair on a cloud.

### 4.2 Weights on screen

Weight is visible per point: radius differs per point at every t. A story
must demonstrate a cloud where one heavy point's ball already dominates at
t = 0 and reaches its neighbours well before the light points reach each
other, so the nerve edges to the heavy point appear first.

### 4.3 Summaries

`<Barcode>`, `<PersistenceDiagram>`, `<BettiCurve>`, `<PersistenceImage>`
survive from v1 but now take `(filtration, t)` and draw the playhead from t.
They are secondary surfaces and the docs must frame them as such.

### 4.4 Scale control

`<ScaleControl>` (renamed from `EpsilonPlayhead`, because ε implies a
specific convention and the control must be honest about which one it is).
Shows `t`, the convention, the drawn radius it implies, and snap-to-event
buttons. Controlled; owns nothing.

---

## 5. Engine surface

From `tda-wasm` as of 2026-09-01 (branch `feat/complex-menu`). The adapter
exposes only what exists.

| Complex | Binding | Weights | Dimension | Shape / vertices |
|---|---|---|---|---|
| Weighted alpha | `alphaPersistence` | **yes** (x,y,z,w) | 3D at binding; 2D embeds at z=0 | ball / points |
| Rips | `ripsComplex` | no → adapter throws | any | ball / points |
| Čech | `cechComplex` | no → adapter throws | any | ball / points |
| k-fold cover | `kFoldCoverComplex` | no → adapter throws | **3D only**, distinct points | ball at √t / **k-subsets** (`mosaicVertices`) |
| Ellipsoid-Rips | `ellipsoidRipsComplex` | no → adapter throws | 2D/3D | ellipsoid / points |
| Ellipsoid-Čech | `ellipsoidCechComplex` | no → adapter throws | 2D/3D | ellipsoid / points |
| Ellipsoid geometry | `ellipsoids` | — | 2D/3D | the fitted frames + semi-axis profiles, for drawing |
| Wing | `wingComplex` | no → adapter throws | **2D only** | concave hexagon / points |
| Wing geometry | `wings` | — | **2D only** | the normal the builder used + its provenance + the unit outline, for drawing |
| Box | `boxFiltration` | no → adapter throws | 2D/3D | axis-aligned box, on a π grid / points |
| Cubical | `cubicalPersistence(grid, {construction: "T" | "V", coeff})` | n/a — no cloud | 2D grid | none: cells are fixed, t is a threshold / grid values |
| Witness (weak) | `computeEuclideanWitnessComplex` | no | any; vertex ids index the landmark subset | not wired (§8 Q3) |

Weighted alpha is the only weighted path and is therefore the **primary**
complex for this library, not an afterthought. Rips is the cheap fallback.
Everything else on the menu is unweighted at the binding, which is a property
of the mathematics as much as of the bindings: multicover persistence is proved
for unweighted points (Edelsbrunner–Osang Theorem 5 does not carry to weights),
and the ellipsoid, wing and box constructions are defined without weights.

Two things about this surface made the adapter awkward, and both are recorded
because they are the engine's design, not this library's:

1. ~~**Wing normals are not exposed.** `wingComplex(…, k)` estimates
   osculating-circle normals internally and returns only the complex, so a wing
   built that way cannot be drawn without re-estimating — and a re-estimate is a
   *different* wing than the one whose births are on screen. The library reports
   the shape as unavailable (§1.6) rather than drawing an approximation.~~
   **Fixed upstream (2026-09-02): `wings`.** It returns, per point,
   the unit normal the builder used, where that normal came from
   (`normalSource`), the curvature diagnostics behind the |κ| clamp, and the six
   unit-scale outline offsets of the same `unit_wing()` the birth solver
   intersects. So the k mode is drawable, the drawing is EXACT rather than a
   re-derivation, and the special case is gone: this library scales the returned
   offsets and never rebuilds the hexagon from (q, θ, α). What replaces the
   refusal is provenance on every wing (§1.6).
2. **Box shapes are opt-in.** `includeBoxes` returns `(steps + 1) × n` box
   records or nothing at all; there is no binding for a single step. This library
   defaults it ON, because the growing shape is the subject, accepts the memory,
   and exposes the engine's rows as they are through `boxesAtStep` (§3.1a) so a
   renderer neither re-slices them nor redoes the grid arithmetic.

---

## 6. What gets rebuilt

| v1 | v2 |
|---|---|
| `GrowingBalls2D` (one radius, translucent discs) | `<Field2D>` (per-point radius, union region) |
| `ComplexOverlay2D` (takes raw simplices) | `<Nerve2D>` (takes Filtration) |
| `ComplexMesh3D` | `<Nerve3D>` (takes Filtration) |
| `PointCloud2D/3D` (unweighted) | keep, add weight glyph; 2D also supports controlled drag and exact-coordinate editing |
| `EpsilonPlayhead` | `<ScaleControl>` with convention + snapping |
| `usePipeline` | `buildFiltration` + `useScale` |
| Barcode/Diagram/Betti/Image | keep, re-key on `(filtration, t)` |
| `CycleHighlight3D` | keep; unchanged contract |
| homepage hero | must show the union growing and the nerve forming, with weights |

---

## 7. Stories that must exist

Beyond per-component coverage, these end-to-end stories are the acceptance
test for v2:

1. **Unweighted circle, alpha.** Move t; watch the annulus thicken and the
   nerve form a ring, then fill. Barcode playhead tracks t.
2. **Weighted cloud.** Three points, one heavy (w = 0.5, others w = 0). At
   t = 0 the heavy ball has radius √0.5 while the light ones are points. The
   nerve edges to the heavy point appear before the light–light edge. Negative
   weights are rejected by the adapter with a clear error (engine constraint,
   §1.2) — a story asserts that rejection rather than pretending to draw it.
3. **Rips vs Čech on the same cloud.** Same t, same points, different
   complexes; the Rips triangle that is not a nerve triangle is highlighted
   and labelled.
4. **Snapping.** Step through critical values and see exactly one change per
   step.
5. **Honesty.** 2D circle at cap 2: the 18,424 spurious H₂ pairs are gone from
   the filtration's `pairs` and present in `rawPairs`.

The complex menu adds four more. They shipped with the shape renderers
(2026-09-01) in `src/stories/ComplexMenu.stories.tsx`, on recorded engine
output, and every number they state about the fixtures is COMPUTED in the story
rather than written into its prose:

6. **Ellipsoid-Rips vs ellipsoid-Čech, same cloud, same ellipsoids.** Identical
   shapes on screen and identical 1-skeletons — 40 shared edges, maximum birth
   difference 0 — but no shared simplex is born earlier in the nerve and 8 are
   born strictly later, so the H₁ picture is not the same picture even where the
   simplices are. The chips read `flag complex (Rips-type)` and
   `true nerve (ellipsoidal Cech)`, and the story says which of the two the
   union of ellipsoids beside it is actually equivalent to (the nerve).
7. **Wing, exact normals vs estimated.** Both builds draw their hexagons, and
   both draw the ENGINE's: each polygon is `point + ε · outline[v]` from
   `wings`, so the k-mode build — which used to draw nothing — is
   drawable without any re-estimation. On a circle the two complexes are
   *identical* (84 simplices, zero birth difference) and the two drawings agree
   to ~1e-8, both computed in the story rather than quoted. What the panels
   contrast is PROVENANCE: `supplied` on the left, `osculating` on the right, and
   the story states that the agreement is the fit's accuracy on this cloud rather
   than a guarantee — at an inflection the estimate flips sides, and
   `normalSource` is what tells a reader which case they are looking at.
8. **Box, two step sizes.** The same 6-point ring at π = 0.25 and π = 0.125:
   every filtration value is on its own grid (0 off-grid values in either), the
   drawn box is the last completed step, and the story states outright that the
   two diagrams are not comparable.
9. **k-fold cover, k = 1 vs k = 2.** At k = 1 the mosaic has 8 singleton
   vertices over 8 points and the filtration reproduces alpha (the engine's own
   claim, checked against the live engine in
   `buildFiltrationMenu.integration.test.ts`). At k = 2 there are 22 vertices
   over the same 8 points, each drawn at its pair's barycentre, while the balls
   still grow around the input points at √t.
10. **One array, two conventions.** The nine numbers `0 2 2 / 2 0 2 / 2 2 0`
    drawn twice: under `cubical-t` the three low pixels meet at shared corner
    vertices and the story shows β₀ = 1 with a single essential bar; under
    `cubical-v` the same numbers are lattice vertices with no diagonal edge
    between them and the story shows β₀ = 3, two of the classes dying at 2.
    Both Betti numbers are counted from the filtration on the spot, never
    written into the prose. A second panel repeats the contrast at a size the
    eye can read — two 5 × 5 rings touching at one corner, where T counts one
    dark region and V counts two, and both count the same two loops, so the
    disagreement is precisely and only about the corner.

---

## 8. Open questions

1. ~~`<Field2D>` union rendering: Canvas (fast, raster) vs SVG merged path
   (crisp, slow above ~500 points). Start Canvas; SVG if someone needs print.~~
   **Decided (2026-09-01): the SVG merged path.** The objection to SVG was node
   count, and a merged union path has none — it is ONE `<path>` element whatever
   n is, and the per-t work is building its `d` string, which is the same
   O(n) traversal the canvas path was. What tipped it is the shape menu: a
   rotated ellipse is one `A` command and a concave hexagon is one polygon, so
   the declarative form states each shape once, where the canvas form is a
   branch of imperative calls whose union property is invisible in the source.
   The remaining cost is string allocation per frame; above a few thousand
   shapes a canvas fallback is still the right answer, and nothing in the
   contract prevents adding one — `shapeSubpath` is the only shape-specific
   code and it is already separate from the component.
2. 3D union: marching cubes over the SDF is correct but heavy; an
   instanced-sphere approximation is cheap but double-counts overlaps. Start
   with instanced spheres and `depthWrite` tricks, label it approximate.
3. Witness complex in a weighted setting is not defined by the engine. Out of
   scope until it is.
4. ~~Union rendering for non-ball shapes. `<Field2D>`'s union argument (§4.1)
   applies unchanged to ellipsoids, wings and boxes — overlaps double-count the
   region the complex is about — but a merged path over rotated ellipses and
   concave hexagons is harder than over discs. Decide per shape in the renderer
   task; boxes are the easy case, wings the awkward one.~~
   **Resolved (2026-09-01): one merged path for all four kinds**, no per-shape
   decision needed. The wing turned out not to be the awkward case: nonzero
   winding fills a simple concave polygon correctly, and the hexagon's
   handedness cannot flip between points, because its signed area is a
   continuous, nowhere-zero function of the unit normal α (the renderer
   normalizes handedness anyway rather than resting the union on that argument).
   One 2D refusal remains, and it is honesty, not difficulty: a **3D** ellipsoid
   seen from above is refused because dropping z draws the ellipse of `frame[0]`,
   `frame[1]`, which is a central slice and not the ellipsoid's outline. Balls
   and axis-aligned boxes project to their exact silhouettes, so those are drawn.
   The second refusal — a wing whose normals the engine estimated internally —
   is gone as of 2026-09-02: `wings` hands back those normals and
   the outline built from them, so the wing is drawn exactly (§1.6, §5).
5. ~~Should a k-fold cover surface draw the balls at all? The mosaic vertices are
   subsets, so a ball and a vertex are different objects on the same canvas.
   Drawing both is the honest picture of the construction, but it needs a visual
   grammar that does not read as one thing.~~
   **Decided (2026-09-01): draw both, in two grammars.** The balls are the cover
   and the mosaic vertices are the complex; hiding either would hide half the
   construction. A ball is a filled region at an input point; a subset vertex is
   a hollow diamond in 2D and an opaque cube marker in 3D, at a barycentre where
   no input point sits. Both surfaces also SAY it — 2D on the drawing, 3D in the
   entity's `userData` and in the chip beside the canvas — with the vertex count
   against the point count, because `vertexCount ≠ n` is the fact that makes the
   picture legible. What was rejected: spokes from each subset vertex to its
   member points. They carry the membership, but on a canvas whose other line
   segments are 1-simplices they would read as simplices, which is a worse lie
   than leaving membership to a hover title (`data-subset`, `<title>`).
6. Multi-parameter box filtrations. The engine's source paper is
   multiparameter; the shipped binding is a one-parameter slice at fixed
   `alpha`. Out of scope until the engine offers more.

---

## 9. Distribution

Unchanged: private repo, a `file:` dependency on the engine checkout,
unpublished until the founder's go-public gate lifts. The dependency resolves
to `file:../tda-wasm` — the engine's `feat/complex-menu` work merged to the
engine's main checkout on 2026-09-02, so the ordinary sibling checkout carries
every builder again, and no separate worktree is needed. Once `tda-wasm@0.2.0`
is published, that development dependency may move to `^0.2.0` before this
package's own pack audit; `private: true` stays until the founder's gate
lifts. The test setup externalizes the
package by its RESOLVED root, not by name, because a `file:` dependency is a
symlink (README, "Consuming tda-wasm"). License: MIT. History: this package was
GPL-3.0-or-later while the engine (`tda-wasm`) linked CGAL; the engine
relicensed to MIT on 2026-08-27 when CGAL was removed (tda-wasm 0.2.0), and
the founder's umbrella decision is MIT.
